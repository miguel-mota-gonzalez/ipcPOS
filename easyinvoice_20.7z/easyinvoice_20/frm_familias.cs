﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_cambiarclave.
	/// </summary>
	public partial class frm_familias : Form
	{
		
		private System.Data.Odbc.OdbcConnection m_conn;

        public frm_familias()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
			
		}
		
		void Cmd_cancelClick(object sender, EventArgs e)
		{
			this.Close();
		}
		
        //obsoleto
		void Cmd_okClick(object sender, EventArgs e)
		{
            /*
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT clave FROM ConfSystem;";
			
			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();   

			l_reader.Read();
 
			string l_pwd = l_reader[0].ToString().ToUpper();
			System.Text.StringBuilder l_pwdb = new System.Text.StringBuilder();

			l_reader.Close();
			this.m_conn.Close();  			
			
			///////////////////////////////////////////////
			 
			foreach(char l_char in this.txt_clave.Text.Trim().ToUpper())
			{
				switch(l_char)
				{
					case 'A':
						l_pwdb.Append('1');
						break;
					case 'E':
						l_pwdb.Append('2');
						break;
					case 'I':
						l_pwdb.Append('3');
						break;
					case '0':
						l_pwdb.Append('4');
						break;
					case 'U':
						l_pwdb.Append('5');
						break;	
					case 'J':
						l_pwdb.Append('6');
						break;	
					case 'N':
						l_pwdb.Append('7');
						break;	
					case 'S':
						l_pwdb.Append('8');
						break;	
					case 'M':
						l_pwdb.Append('9');
						break;								
					default:
						l_pwdb.Append(l_char);
						break;
				}
			}
			

			if( l_pwd == l_pwdb.ToString() && this.txt_new1.Text == this.txt_new2.Text )
			{				
				System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();
				
				System.Text.StringBuilder l_pwdb1 = new System.Text.StringBuilder();
				
				foreach(char l_char in this.txt_new1.Text.Trim().ToUpper())
				{
					switch(l_char)
					{
						case 'A':
							l_pwdb1.Append('1');
							break;
						case 'E':
							l_pwdb1.Append('2');
							break;
						case 'I':
							l_pwdb1.Append('3');
							break;
						case '0':
							l_pwdb1.Append('4');
							break;
						case 'U':
							l_pwdb1.Append('5');
							break;	
						case 'J':
							l_pwdb1.Append('6');
							break;	
						case 'N':
							l_pwdb1.Append('7');
							break;	
						case 'S':
							l_pwdb1.Append('8');
							break;	
						case 'M':
							l_pwdb1.Append('9');
							break;								
						default:
							l_pwdb1.Append(l_char);
							break;
					}
				}				
				
				//////////////////////////////////////////
				
				l_cmd1.Connection = this.m_conn;
				l_cmd1.CommandText = "UPDATE ConfSystem SET clave = ?";
				l_cmd1.Parameters.AddWithValue("@clave",l_pwdb1.ToString());
				
				this.m_conn.Open(); 

				//Update...
				l_cmd1.ExecuteNonQuery();
				
				this.m_conn.Close();  							
				
				//////////////////////////////////////////
				
				
				MessageBox.Show( "Clave actualizada", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information );				
				this.Close();
			}			
			else
			{
				MessageBox.Show("Verifique la información","ERRROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			*/
		}
        //obsoleto
		void Txt_new1Enter(object sender, EventArgs e)
		{
			this.txt_nombre.SelectAll();
			this.txt_nombre.SelectAll();
			//this.txt_clave2.SelectAll();
		}

        private void frm_cambiarclave_Load(object sender, EventArgs e)
        {
            String idPadre;
            System.Collections.SortedList sl = new System.Collections.SortedList();
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            this.cmb_acceso.Items.Clear();
            this.cmb_acceso.Items.Add("-Sin Padre-");
            this.lvw_main.Items.Clear();
            this.cmb_acceso.SelectedIndex = 0;
            
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "SELECT * FROM catFamilias order by codigo;";

            try
            {
                l_conn.Open();
                             
                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                while (l_rdr.Read())
                {
                    sl.Add(l_rdr["idFamilia"].ToString(), l_rdr["descripcion"].ToString());
                }
                l_rdr.Close(); 

                l_rdr = l_cmd.ExecuteReader();
                
                while (l_rdr.Read())
                {
                    ListViewItem l_lvwi = this.lvw_main.Items.Add(l_rdr["codigo"].ToString());
                    l_lvwi.SubItems.Add(l_rdr["descripcion"].ToString());
                    idPadre = l_rdr["idPadre"].ToString();
                    if (idPadre.Equals(System.DBNull.Value) || idPadre.Length == 0 || Convert.ToInt32(idPadre) <= 0)
                    {
                        l_lvwi.SubItems.Add("");
                        l_lvwi.SubItems.Add("0");
                    }
                    else
                    {
                        if (sl.Contains(idPadre))
                        {
                            l_lvwi.SubItems.Add(sl[idPadre].ToString() );
                            l_lvwi.SubItems.Add(idPadre);
                        }
                        else
                        {
                            l_lvwi.SubItems.Add("");
                            l_lvwi.SubItems.Add("0");
                        }
                    }
                    this.cmb_acceso.Items.Add(l_rdr["descripcion"].ToString().Trim());

                }

                l_rdr.Close();

                l_conn.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
            
        }

        private void lvw_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lvw_main.SelectedItems.Count == 0)
                return;

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            this.cmb_acceso.SelectedIndex = 0;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "SELECT * FROM catFamilias where codigo = ?;";

            l_cmd.Parameters.AddWithValue("@codigo", this.lvw_main.SelectedItems[0].SubItems[0].Text);

            try
            {
                l_conn.Open();

                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();

                if (l_rdr.Read())
                {
                    this.txt_nombre.Text = l_rdr["codigo"].ToString();
                    this.txt_login.Text = l_rdr["descripcion"].ToString();
                    if (Convert.ToInt32(l_rdr["idPadre"].ToString()) > 0)
                        this.cmb_acceso.Text = this.lvw_main.SelectedItems[0].SubItems[2].Text;
                    else
                        this.cmb_acceso.SelectedIndex = 0;
                }

                l_rdr.Close();

                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            bool l_new = false;
            //Es un registro nuevo
            if (this.lvw_main.SelectedItems.Count > 0)
            {
                if (this.lvw_main.SelectedItems[0].SubItems[0].Text == this.txt_nombre.Text)
                    l_new = false;
                else
                    l_new = true;
            }
            else 
            {
                l_new = true;
            }

            if (this.txt_nombre.Text.Trim() == "")
                return;

            if (this.txt_login.Text.Trim() == "")
                return;

            if (this.cmb_acceso.Text.Trim() == this.txt_login.Text.Trim() )
                return;


            if (l_new)
            {
                if( this.AgregarRegistro())
                    this.frm_cambiarclave_Load(null, null);
            }
            else
            { 
                //Actualizar el registro...

                if(this.ActualizarRegistro())
                    this.frm_cambiarclave_Load(null, null);
            }

        }

        private bool ActualizarRegistro()
        {
            bool lok = true;
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                l_cmd.Connection = l_conn;
                l_conn.Open();
                int idPadre = 0;
                if (this.cmb_acceso.SelectedIndex == 0)
                    idPadre=0;
                else
                {
                    l_cmd.CommandText = "SELECT idFamilia from catFamilias where descripcion = ?;";
                    l_cmd.Parameters.AddWithValue("@descripcion", this.cmb_acceso.Text.Trim());
                    System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                    if (l_rdr.Read())
                        idPadre = Convert.ToInt32(l_rdr[0]);
                    l_rdr.Close();
                }

                l_cmd.Parameters.Clear();
                l_cmd.CommandText = "UPDATE catFamilias set descripcion = ?,idPadre = ? WHERE codigo = ?;";

                l_cmd.Parameters.AddWithValue("@descripcion", this.txt_login.Text);
                l_cmd.Parameters.AddWithValue("@idPadre", idPadre);

                l_cmd.Parameters.AddWithValue("@codigo", this.txt_nombre.Text);

                //Guardar...
                if (l_cmd.ExecuteNonQuery() <= 0)
                    lok = false;
                MessageBox.Show("Registro " + this.txt_login.Text + " actualizado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lok = false;
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
            return lok;
        }

        private bool AgregarRegistro()
        {
            bool lok = true;
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            try
            {
                l_cmd.Connection = l_conn;
                l_conn.Open();
                // valida que no exista el codigo
                l_cmd.CommandText = "SELECT idFamilia from catFamilias where codigo = ?;";
                l_cmd.Parameters.AddWithValue("@codigo", this.txt_nombre.Text.Trim());
                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                if (l_rdr.Read())
                {
                    l_rdr.Close();
                    return false ;
                }
                l_rdr.Close();

                l_cmd.Parameters.Clear();
                int idPadre = 0;
                if (this.cmb_acceso.SelectedIndex == 0)
                    idPadre = 0;
                else
                {
                    l_cmd.CommandText = "SELECT idFamilia from catFamilias where descripcion = ?;";
                    l_cmd.Parameters.AddWithValue("@descripcion", this.cmb_acceso.Text.Trim());
                    l_rdr = l_cmd.ExecuteReader();
                    if (l_rdr.Read())
                        idPadre = Convert.ToInt32(l_rdr[0]);
                    l_rdr.Close();
                }

                l_cmd.Parameters.Clear();
                l_cmd.CommandText = "INSERT INTO catFamilias (codigo,descripcion,idPadre) VALUES(?,?,?);";

                l_cmd.Parameters.AddWithValue("@codigo", this.txt_nombre.Text);
                l_cmd.Parameters.AddWithValue("@descripcion", this.txt_login.Text);
                l_cmd.Parameters.AddWithValue("@idPadre", idPadre);

                //Guardar...
                if (l_cmd.ExecuteNonQuery() <= 0)
                    lok = false;

                MessageBox.Show("Registro " + this.txt_login.Text + " agregado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lok = false;
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
            return lok;
        }

        private void cmd_del_Click(object sender, EventArgs e)
        {
            if (this.lvw_main.SelectedItems.Count > 0)
            {
                if (MessageBox.Show("¿Realmente desea eliminar el registro " + this.txt_login.Text + "?", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;

                this.BorrarUsuario();
                this.frm_cambiarclave_Load(null, null);
            }
        }

        private void BorrarUsuario()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "DELETE FROM catFamilias WHERE codigo = ?";

            l_cmd.Parameters.AddWithValue("@codigo", this.txt_nombre.Text);

            try
            {
                l_conn.Open();

                //Guardar...
                l_cmd.ExecuteNonQuery();

                MessageBox.Show("Familia " + this.txt_login.Text + " eliminado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void cmd_add_Click(object sender, EventArgs e)
        {
            this.lvw_main.SelectedItems.Clear();
            this.txt_nombre.Text="";
            this.txt_login.Text = "";
            this.cmb_acceso.SelectedIndex = 0;
            this.txt_nombre.Focus();
        }


	}
}
