﻿namespace EasyInvoice
{
    partial class frm_nuevosaldo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_nuevosaldo));
        	this.cmd_cancelar = new System.Windows.Forms.Button();
        	this.cmd_aceptar = new System.Windows.Forms.Button();
        	this.textBox1 = new System.Windows.Forms.TextBox();
        	this.label1 = new System.Windows.Forms.Label();
        	this.SuspendLayout();
        	// 
        	// cmd_cancelar
        	// 
        	this.cmd_cancelar.Location = new System.Drawing.Point(202, 72);
        	this.cmd_cancelar.Name = "cmd_cancelar";
        	this.cmd_cancelar.Size = new System.Drawing.Size(75, 23);
        	this.cmd_cancelar.TabIndex = 7;
        	this.cmd_cancelar.Text = "Cancelar";
        	this.cmd_cancelar.UseVisualStyleBackColor = true;
        	// 
        	// cmd_aceptar
        	// 
        	this.cmd_aceptar.Location = new System.Drawing.Point(121, 72);
        	this.cmd_aceptar.Name = "cmd_aceptar";
        	this.cmd_aceptar.Size = new System.Drawing.Size(75, 23);
        	this.cmd_aceptar.TabIndex = 6;
        	this.cmd_aceptar.Text = "Aceptar";
        	this.cmd_aceptar.UseVisualStyleBackColor = true;
        	// 
        	// textBox1
        	// 
        	this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.textBox1.ForeColor = System.Drawing.Color.Blue;
        	this.textBox1.Location = new System.Drawing.Point(94, 20);
        	this.textBox1.Name = "textBox1";
        	this.textBox1.Size = new System.Drawing.Size(156, 26);
        	this.textBox1.TabIndex = 4;
        	// 
        	// label1
        	// 
        	this.label1.AutoSize = true;
        	this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label1.Location = new System.Drawing.Point(11, 20);
        	this.label1.Name = "label1";
        	this.label1.Size = new System.Drawing.Size(86, 20);
        	this.label1.TabIndex = 5;
        	this.label1.Text = "Cantidad $";
        	// 
        	// frm_nuevosaldo
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.BackColor = System.Drawing.Color.LightSteelBlue;
        	this.ClientSize = new System.Drawing.Size(289, 115);
        	this.Controls.Add(this.cmd_cancelar);
        	this.Controls.Add(this.cmd_aceptar);
        	this.Controls.Add(this.textBox1);
        	this.Controls.Add(this.label1);
        	this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        	this.KeyPreview = true;
        	this.Name = "frm_nuevosaldo";
        	this.Text = "frm_nuevosaldo";
        	this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_nuevosaldoKeyDown);
        	this.Load += new System.EventHandler(this.Frm_nuevosaldoLoad);
        	this.ResumeLayout(false);
        	this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button cmd_cancelar;
        private System.Windows.Forms.Button cmd_aceptar;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}