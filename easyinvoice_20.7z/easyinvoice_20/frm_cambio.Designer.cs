﻿/*
 * Creado por SharpDevelop.
 * Usuario: mikem
 * Fecha: 13/11/2008
 * Hora: 01:18 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace EasyInvoice
{
	partial class frm_cambio
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_cambio));
			this.lbl_total = new System.Windows.Forms.Label();
			this.txt_entregado = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lbl_cambio = new System.Windows.Forms.Label();
			this.cmd_cerrar = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// lbl_total
			// 
			this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_total.ForeColor = System.Drawing.Color.Blue;
			this.lbl_total.Location = new System.Drawing.Point(15, 17);
			this.lbl_total.Name = "lbl_total";
			this.lbl_total.Size = new System.Drawing.Size(371, 50);
			this.lbl_total.TabIndex = 0;
			this.lbl_total.Text = "Total $0.00";
			this.lbl_total.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.lbl_total.Click += new System.EventHandler(this.Lbl_totalClick);
			// 
			// txt_entregado
			// 
			this.txt_entregado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txt_entregado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txt_entregado.Location = new System.Drawing.Point(12, 105);
			this.txt_entregado.Name = "txt_entregado";
			this.txt_entregado.Size = new System.Drawing.Size(386, 38);
			this.txt_entregado.TabIndex = 1;
			this.txt_entregado.TextChanged += new System.EventHandler(this.Txt_entregadoTextChanged);
			this.txt_entregado.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_entregadoKeyDown);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(12, 85);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(320, 17);
			this.label1.TabIndex = 2;
			this.label1.Text = "¿Cantidad entregada?";
			// 
			// lbl_cambio
			// 
			this.lbl_cambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_cambio.ForeColor = System.Drawing.Color.Red;
			this.lbl_cambio.Location = new System.Drawing.Point(15, 146);
			this.lbl_cambio.Name = "lbl_cambio";
			this.lbl_cambio.Size = new System.Drawing.Size(371, 50);
			this.lbl_cambio.TabIndex = 3;
			this.lbl_cambio.Text = "Cambio $0.00";
			this.lbl_cambio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// cmd_cerrar
			// 
			this.cmd_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("cmd_cerrar.Image")));
			this.cmd_cerrar.Location = new System.Drawing.Point(335, 206);
			this.cmd_cerrar.Name = "cmd_cerrar";
			this.cmd_cerrar.Size = new System.Drawing.Size(63, 23);
			this.cmd_cerrar.TabIndex = 4;
			this.cmd_cerrar.Text = "Cerrar";
			this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cmd_cerrar.UseVisualStyleBackColor = true;
			this.cmd_cerrar.Click += new System.EventHandler(this.Cmd_cerrarClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(350, 50);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(48, 52);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// frm_cambio
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.ClientSize = new System.Drawing.Size(410, 241);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.cmd_cerrar);
			this.Controls.Add(this.lbl_cambio);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txt_entregado);
			this.Controls.Add(this.lbl_total);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frm_cambio";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Pago";
			this.Load += new System.EventHandler(this.Frm_cambioLoad);
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_cambioKeyDown);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label lbl_cambio;
		private System.Windows.Forms.Button cmd_cerrar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_entregado;
		private System.Windows.Forms.Label lbl_total;
	}
}
