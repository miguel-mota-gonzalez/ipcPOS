using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Runtime.InteropServices;
using System.Management;
 

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frmAbout.
	/// </summary>
	public class frmAbout : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.PictureBox pictureBox1;
        private PictureBox pictureBox2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAbout()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(14, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 93);
            this.label1.TabIndex = 0;
            this.label1.Text = "Desarrollado por InalambricaPC\r\nVersion 3.0\r\nhttp://www.inalambricapc.com\r\nM�rida" +
    ", Yucatan, Mexico\r\nFeb 2023\r\n\r\n";
            this.label1.Click += new System.EventHandler(this.Label1Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(376, 320);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 26);
            this.button1.TabIndex = 1;
            this.button1.Text = "Ok";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(285, 107);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(16, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Serie";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(16, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Clave de Activaci�n";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(146, 260);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(320, 22);
            this.textBox1.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(278, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 26);
            this.button2.TabIndex = 4;
            this.button2.Text = "Registrar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(146, 223);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(320, 22);
            this.textBox2.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(14, 320);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 17);
            this.label4.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::EasyInvoice.Properties.Resources.ipclogo;
            this.pictureBox2.Location = new System.Drawing.Point(335, 127);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(131, 65);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // frmAbout
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(483, 312);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Acerca de...";
            this.Load += new System.EventHandler(this.FrmAboutLoad);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.Close(); 
		}
		
		void FrmAboutLoad(object sender, EventArgs e)
		{		
			//MessageBox.Show( this.GetCPUId() + "-" + this.GetVolumeSerial(System.Environment.CurrentDirectory.Substring(0,1)) );			
			//this.textBox2.Text = this.GetCPUId() + "-" + this.GetVolumeSerial(System.Environment.CurrentDirectory.Substring(0,1));
			this.textBox2.Text = "";
			
			try
			{
				/*
				object l_objrg = Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Key","");
				
				if(l_objrg.ToString()=="054FFADCF589878-547985324-AB986D098-1524A")
				{
					this.label3.Visible = false;
					this.label4.Visible = false;
					this.textBox1.Visible = false;
					this.button2.Visible = false;
				}	
				*/			
			}
			catch
			{
			}
			
		}
		
        public string GetVolumeSerial(string strDriveLetter)
        {
        if( strDriveLetter=="" || strDriveLetter==null) strDriveLetter="C";
        ManagementObject disk = 
            new ManagementObject("win32_logicaldisk.deviceid=\"" + strDriveLetter +":\"");
        disk.Get();
        return disk["VolumeSerialNumber"].ToString();
        }		
		
        public string GetCPUId()
        {
            string cpuInfo =  String.Empty;
            string temp=String.Empty;
            ManagementClass mc = new ManagementClass("Win32_Processor");
            ManagementObjectCollection moc = mc.GetInstances();
            foreach(ManagementObject mo in moc)
            {
                if(cpuInfo==String.Empty) 
                {// only return cpuInfo from first CPU
                    cpuInfo = mo.Properties["ProcessorId"].Value.ToString();
                }             
            }
            return cpuInfo;
        }		
		
		public string GenerateKey(string p_llave)
		{
			System.Text.StringBuilder l_ret = new System.Text.StringBuilder();
			bool l_upordown = false;
			
			string[] l_santi = new string[] {"S","1","N","T","3","1","G","4","M","4","U","1","O","4","P","2"};
			string[] l_myself = new string[] {"M","3","G","2","L","R","4","Y","1","W","4","A","E","1","I","2"};
			
			foreach(char l_char in p_llave)
			{							
				//Console.WriteLine(System.Convert.ToByte(l_char));
				System.Byte l_byte = System.Convert.ToByte(l_char);
				l_byte = (byte)((byte)l_byte & (byte)0x0F);
				
				if(l_upordown == true)
				{
					l_upordown = false;
					l_ret.Append(l_santi[l_byte]);
				}
				else
				{
					l_upordown = true;
					l_ret.Append(l_myself[l_byte]);
				}
				
			}
			
			return l_ret.ToString();
		}	
		
		void Button2Click(object sender, EventArgs e)
		{			
			try
			{
				string[] l_llave = this.textBox2.Text.Split('-');			
				string l_llavet = l_llave[0] + l_llave[1];
				
				if(this.textBox1.Text ==  this.GenerateKey(l_llavet)  )
				{
					//MessageBox.Show("Registrado!");
					//Microsoft.Win32.Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Key","054FFADCF589878-547985324-AB986D098-1524A");
					MessageBox.Show("Sistema registrado exitosamente","EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
					this.Close();
					Application.Restart();
				}
				else
				{
					MessageBox.Show("Clave Incorrecta!","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
			catch
			{
			}
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
	}
}
