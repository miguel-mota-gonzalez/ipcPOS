﻿namespace EasyInvoice
{
    partial class frm_historico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label13 = new System.Windows.Forms.Label();
            this.txt_observs = new System.Windows.Forms.TextBox();
            this.cmd_save = new System.Windows.Forms.Button();
            this.lbl_table = new System.Windows.Forms.Label();
            this.lbl_cambios = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(175, 13);
            this.label13.TabIndex = 37;
            this.label13.Text = "Observaciones / Motivo del cambio";
            // 
            // txt_observs
            // 
            this.txt_observs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_observs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_observs.Location = new System.Drawing.Point(12, 121);
            this.txt_observs.Multiline = true;
            this.txt_observs.Name = "txt_observs";
            this.txt_observs.Size = new System.Drawing.Size(492, 52);
            this.txt_observs.TabIndex = 38;
            // 
            // cmd_save
            // 
            this.cmd_save.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cmd_save.Location = new System.Drawing.Point(203, 182);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(116, 23);
            this.cmd_save.TabIndex = 39;
            this.cmd_save.Text = "&Aceptar";
            this.cmd_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // lbl_table
            // 
            this.lbl_table.AutoSize = true;
            this.lbl_table.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_table.Location = new System.Drawing.Point(12, 9);
            this.lbl_table.Name = "lbl_table";
            this.lbl_table.Size = new System.Drawing.Size(103, 13);
            this.lbl_table.TabIndex = 40;
            this.lbl_table.Text = "Catálogo de XXX";
            // 
            // lbl_cambios
            // 
            this.lbl_cambios.AutoSize = true;
            this.lbl_cambios.Location = new System.Drawing.Point(12, 55);
            this.lbl_cambios.Name = "lbl_cambios";
            this.lbl_cambios.Size = new System.Drawing.Size(89, 13);
            this.lbl_cambios.TabIndex = 41;
            this.lbl_cambios.Text = "campo1, campo2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "Se han modificado los siguientes datos:";
            // 
            // frm_historico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 217);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_cambios);
            this.Controls.Add(this.lbl_table);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_observs);
            this.Controls.Add(this.cmd_save);
            this.Name = "frm_historico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historico de cambios";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frm_historico_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txt_observs;
        public System.Windows.Forms.Label lbl_table;
        public System.Windows.Forms.Label lbl_cambios;
    }
}