/*
 * Creado por SharpDevelop.
 * Usuario: mikem
 * Fecha: 13/11/2008
 * Hora: 01:18 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificaci�n | Editar Encabezados Est�ndar
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_cambio.
	/// </summary>
	public partial class frm_cambio : Form
	{
		public double m_total = 1000.5;
        public bool m_esnota = true;
        public string m_docto = "1000";
        public int m_mode_docs=0;
		
		public frm_cambio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Txt_entregadoKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Enter )
			{
                this.Cierra();
            }
		}
		
		void Txt_entregadoTextChanged(object sender, EventArgs e)
		{
			
		}
		
		void Lbl_totalClick(object sender, EventArgs e)
		{
			
		}
		
		void Frm_cambioLoad(object sender, EventArgs e)
		{
			this.lbl_total.Text = "Total $" + this.m_total.ToString("###,###,###.00");
            this.txt_entregado.Text = this.m_total.ToString("###,###,###.00");
		}
		
		void Frm_cambioKeyDown(object sender, KeyEventArgs e)
		{
            if (this.m_mode_docs == 0)
            {
                if (e.KeyCode == Keys.Escape)
                {
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        this.Cmd_cerrarClick(sender, null);
                }
                //this.Close();
            }
		}
		
		void Cmd_cerrarClick(object sender, EventArgs e)
		{
            if (this.Cierra())
            {
                double l_entregado = Convert.ToDouble(this.txt_entregado.Text);

                //Actualizar la nota/factura
                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();

                try
                {
                    l_conn.ConnectionString = frm_Main.mps_strconnection;
                    l_conn.Open();
                    l_inc.Connection = l_conn;

                    if (this.m_esnota == false)
                        l_inc.CommandText = "UPDATE catFacturas SET entregado=?, estatus=?, usuarioventa=? WHERE NumeroFactura = ?;";
                    else
                        l_inc.CommandText = "UPDATE catNotas SET entregado=?, estatus=?, usuarioventa=? WHERE NumeroFactura = ?;";

                    l_inc.Parameters.AddWithValue("@entregado", l_entregado);
                    l_inc.Parameters.AddWithValue("@estatus", 1);
                    l_inc.Parameters.AddWithValue("@usuarioventa", frm_Main.mps_usuario);
                    l_inc.Parameters.AddWithValue("@NumeroFactura", m_docto);

                    l_inc.ExecuteNonQuery();

                    l_conn.Close();
                    l_conn = null;

                }
                catch(Exception ee)
                {
                    MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                this.Close();
            }
		}

        bool Cierra()
        {
            try
			{
				double l_entregado = Convert.ToDouble( this.txt_entregado.Text );
				double l_cambio = l_entregado - this.m_total;
                if (System.Math.Round(l_entregado,2) < System.Math.Round(this.m_total,2))
                {
                    if (this.m_esnota)
                        MessageBox.Show("Lo entregado debe ser mayor al total de la nota", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    else
                        MessageBox.Show("Lo entregado debe ser mayor al total de la factura", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txt_entregado.Focus();
                    return false;
                }
				if(l_cambio >= 0)
				{
					this.lbl_cambio.Text = "Cambio $" + l_cambio.ToString("###,###,###.00");
				}
				else
				{
					this.lbl_cambio.Text = "Cambio $0.00";	
				}
                return true;
		    }
			catch
			{
				this.lbl_cambio.Text = "Cambio $0.00";
                return false; 
			}
        }

	}
}
