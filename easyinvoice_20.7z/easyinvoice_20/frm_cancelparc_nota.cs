﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
    public partial class frm_cancelparc_nota : Form
    {
        public frm_Facturaslist frm_facturaslist = null;
        public System.String numDocto = "";
        public System.Int32 idDocto = -1;
        System.Data.Odbc.OdbcConnection m_conn = new System.Data.Odbc.OdbcConnection();
        private System.Data.DataSet m_detail = new System.Data.DataSet();
        private System.Double m_subtotal;
        private System.Double m_total;

        public frm_cancelparc_nota()
        {
            InitializeComponent();

            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.m_detail.Tables.Add("detail");
            this.m_detail.Tables[0].Columns.Add("IdDetFactura");
            this.m_detail.Tables[0].Columns.Add("Secuencia");
            this.m_detail.Tables[0].Columns.Add("ID");
            this.m_detail.Tables[0].Columns.Add("Codigo");
            this.m_detail.Tables[0].Columns.Add("Descripcion");
            this.m_detail.Tables[0].Columns.Add("Precio", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("PrecioDesc", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("Cantidad", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("CantidadNva", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("Descuento", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("Total", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("Total mas IVA", System.Type.GetType("System.Decimal"));
            //this.m_detail.Tables[0].Columns.Add("unidad");
            this.m_detail.Tables[0].Columns.Add("iva", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("Total2", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[0].Columns.Add("TotalmasIVA2", System.Type.GetType("System.Decimal"));

            this.dataGridView1.DataSource = this.m_detail.Tables[0];
            this.dataGridView1.Columns[0].Visible = false;
            this.dataGridView1.Columns[1].Visible = false;
            this.dataGridView1.Columns[2].Visible = false;
            this.dataGridView1.Columns[8].DefaultCellStyle.SelectionBackColor = Color.Beige;
            this.dataGridView1.Columns[8].DefaultCellStyle.SelectionForeColor  = Color.Black ;
            this.dataGridView1.Columns[13].Visible = false;
            this.dataGridView1.Columns[14].Visible = false;

            for (int i = 0; i < this.dataGridView1.Columns.Count; i++)
            {
                this.dataGridView1.Columns[i].ReadOnly = (i!=8);
            }
        }

        private void cmd_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            if (this.SaveNotaCancelacionParcial())
            {
                this.Close();
            }
        }

        private void frm_cancelparc_nota_Load(object sender, EventArgs e)
        {
            this.LoadNota();
        }

        private void LoadNota()
        {
            if (this.idDocto <= 0)
                return;

            System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
            System.Data.DataRow lrow;
            System.Int32 seq=0;

            // lee los datos de catNotas y catClientes
            l_recid.Connection = this.m_conn;
            l_recid.CommandText = "SELECT catNotas.NumeroFactura, catClientes.Nombre, catClientes.RFC, catClientes.Direccion FROM catNotas LEFT JOIN catClientes ON catNotas.IdCliente=catClientes.IdCliente WHERE IdFactura = ?;";
            l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@IdFactura", this.idDocto));

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();

            if (l_reader.Read())
            {
                this.numDocto = l_reader.GetString(0);
                this.txt_numfact.Text = this.numDocto;
                this.txt_nombre.Text = l_reader.GetString(1);
                this.txt_dir.Text = l_reader.GetString(3);
                this.txt_rfc.Text = l_reader.GetString(2);
            }
            else
            {
                MessageBox.Show("Nota " + this.numDocto + " NO EXISTE", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                l_reader.Close();
                this.m_conn.Close();
                return;
            }
            l_reader.Close();

            // una vez obtenido el idDocto procede a leer el detalle
            l_recid.Parameters.Clear();
            l_recid.CommandText = "SELECT detNota.*, catProductos.Descripcion,catProductos.CodigoProd FROM detNota LEFT JOIN catProductos ON detNota.IdProducto=catProductos.IdProducto WHERE IdFactura = ?;";
            l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@IdFactura", this.idDocto));
            l_reader = l_recid.ExecuteReader();

            m_subtotal = 0;
            m_total = 0;
            while (l_reader.Read())
            {
                lrow = this.m_detail.Tables[0].NewRow();
                seq += 1;
                lrow["IdDetFactura"] = l_reader["IdDetFactura"];
                lrow["Secuencia"] = seq;
                lrow["ID"] = l_reader["IdProducto"];
                lrow["Codigo"] = l_reader["CodigoProd"];
                lrow["Descripcion"] = l_reader["Descripcion"];
                lrow["Precio"] = l_reader["PrecioOriginal"];
                lrow["PrecioDesc"] = l_reader["PrecioDescuento"];
                lrow["Cantidad"] = l_reader["Cantidad"];
                lrow["CantidadNva"] = lrow["Cantidad"];
                lrow["Descuento"] = l_reader["DescuentoAplicado"];
                lrow["Total"] = l_reader["PrecioCalculado"];
                lrow["iva"] = l_reader["iva"];
                lrow["Total mas IVA"] = System.Math.Round(Convert.ToDecimal(lrow["Total"]) * (1 + Convert.ToDecimal(lrow["iva"])/100),2);
                lrow["Total2"] = lrow["Total"];
                lrow["TotalmasIVA2"] = lrow["Total mas IVA"];
                this.m_detail.Tables[0].Rows.Add(lrow);
                m_subtotal += Convert.ToDouble(lrow["Total"]);
                m_total += Convert.ToDouble(lrow["Total mas IVA"]);
            }

            l_reader.Close();
            this.m_conn.Close();

            this.lbl_total.Text = "Total " + System.String.Format("{0:C}", m_subtotal);
            this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}", m_total);

            try
            {
                this.dataGridView1.Columns[4].Width = 200;
            }
            catch
            { }
            if(this.dataGridView1.Rows.Count>0)
                this.dataGridView1.CurrentCell  = this.dataGridView1.Rows[0].Cells[8];
            return;
        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            Decimal val;
            Decimal max;
            if (e.ColumnIndex == 8)
            {
                try
                {
                    val = Convert.ToDecimal(e.FormattedValue);
                }
                catch
                {
                    MessageBox.Show("valor incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                if (e.FormattedValue.ToString().Length == 0)
                {
                    MessageBox.Show("valor incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                max=Convert.ToDecimal(this.dataGridView1.Rows[e.RowIndex].Cells[7].Value);
                if (val < 0 || val>max)
                {
                    MessageBox.Show("La nueva cantidad debe ser mayor o igual a cero y menor a lo original!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                }
                else
                {
                    DataGridViewRow dgrow = this.dataGridView1.Rows[e.RowIndex];
                    dgrow.Cells[10].Value = Math.Round(Convert.ToDecimal(dgrow.Cells[6].Value) * val,2);
                    dgrow.Cells[11].Value = Math.Round(Convert.ToDecimal(dgrow.Cells[10].Value) * (1 + Convert.ToDecimal(dgrow.Cells["iva"].Value) / 100), 2);
                    this.RealculaTotales();
                }
            }

        }

        private void RealculaTotales()
        {
            m_subtotal = 0;
            m_total = 0;
            for(int i=0; i<this.dataGridView1.Rows.Count;i++)
            {
                m_subtotal += Convert.ToDouble(this.dataGridView1.Rows[i].Cells[10].Value);
                m_total += Convert.ToDouble(this.dataGridView1.Rows[i].Cells[11].Value);
            }

            this.lbl_total.Text = "Total " + System.String.Format("{0:C}", m_subtotal);
            this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}", m_total);

        }

        private Boolean SaveNotaCancelacionParcial()
        {
            Boolean lOk = false;
            System.Data.DataRow lrow;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction l_trans = null;
            try
            {
                if (MessageBox.Show("Confirme la actualización de la nota " + this.numDocto + ". Este proceso es IRREVERSIBLE", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return false;

                this.m_conn.Open();
                l_cmd.Connection = this.m_conn;
                l_trans = this.m_conn.BeginTransaction();
                l_cmd.Transaction = l_trans;

                for (int i = 0; i < this.m_detail.Tables[0].Rows.Count; i++)
                {
                    lrow = this.m_detail.Tables[0].Rows[i];
                    if (Convert.ToDecimal(lrow["Cantidad"]) != Convert.ToDecimal(lrow["CantidadNva"]))
                    {
                        // graba el cambio en el detalle

                        l_cmd.Parameters.Clear();
                        l_cmd.CommandText = "UPDATE detNota SET Cantidad = ?, PrecioCalculado = ? WHERE IdFactura = ? AND IdProducto=?;";
                        l_cmd.CommandType = System.Data.CommandType.Text;
                        l_cmd.Parameters.AddWithValue("@Cantidad", lrow["CantidadNva"]);
                        l_cmd.Parameters.AddWithValue("@PrecioCalculado", lrow["Total"]);
                        l_cmd.Parameters.AddWithValue("@IdFactura", this.idDocto);
                        l_cmd.Parameters.AddWithValue("@IdProducto", lrow["ID"]);
                        l_cmd.ExecuteNonQuery();
                        // ajusta el inventario
              this.frm_facturaslist.DeducirInventario(Convert.ToInt32(this.numDocto),Convert.ToInt32(lrow["ID"]),Convert.ToString(lrow["Codigo"]),Convert.ToString(lrow["Descripcion"]),
                  Math.Round(Convert.ToDouble(lrow["CantidadNva"]) - Convert.ToDouble(lrow["Cantidad"]),2),
                  Math.Round(Convert.ToDouble(lrow["Total mas IVA"]) - Convert.ToDouble(lrow["TotalmasIVA2"]), 2),
                  this.m_conn,l_trans,"CANC.PARCIAL");
                        lOk = true;
                    }
                }
                if (lOk)
                {
                    //Actualiza los datos maestros
                    l_cmd = new System.Data.Odbc.OdbcCommand();
                    l_cmd.Connection = this.m_conn;
                    l_cmd.Transaction = l_trans;
                    l_cmd.Parameters.Clear();
                    l_cmd.CommandText = "UPDATE catNotas SET SubTotal = ?, Total = ? WHERE IdFactura = ?;";
                    l_cmd.CommandType = System.Data.CommandType.Text;
                    l_cmd.Parameters.AddWithValue("@SubTotal", m_subtotal);
                    l_cmd.Parameters.AddWithValue("@Total", m_total);
                    l_cmd.Parameters.AddWithValue("@IdFactura", this.idDocto);
                    l_cmd.ExecuteNonQuery();

                    l_trans.Commit();
                }
                else
                {
                    MessageBox.Show("No proporciono ningún ajuste para aplicar en la nota", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                l_trans.Rollback();
                MessageBox.Show("ERROR al guardar la cancelacion parcial de la nota (" + ex.Message + ")", "EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lOk = false;
            }
            finally 
            {
                if (this.m_conn.State == ConnectionState.Open)
                    this.m_conn.Close();
            }
            if (lOk)
                this.frm_facturaslist.FillDataset();
            return lOk;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

    }

}
