/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 3/17/2009
 * Time: 2:46 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_altas_caja.
	/// </summary>
	public partial class frm_altas_caja : Form
	{
		private System.Data.Odbc.OdbcConnection m_conn;
        private bool mustSave = false;
        private System.Data.DataSet m_detail = new System.Data.DataSet();
        private System.Int32 idOrdenCompra=-1;
        private System.Int32 idProveedor = -1;
        private Boolean mustValidate = true;
        private Boolean Initentregado0 = false;
        private System.Decimal IvaSistema = 0;

        private Boolean UnaSolaFacturaProv = true;

		public frm_altas_caja()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.LeeConfSystem();

            this.lblProveedor.Text = "";
            if(frm_Main.mp_idAlmacen>0)
                this.Text = this.Text + " - " + frm_Main.mp_strAlmacen; 
		}
		
		void Cmd_closeClick(object sender, EventArgs e)
		{
            if (mustSave)
            { 
                if(MessageBox.Show("No ha grabado las entradas capturadas, se perdera TODO lo registrado, a�n desea salir de esta ventana?","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)
                    return;
            }
			this.Close();
		}
		
		void Txt_cantidadSelectedItemChanged(object sender, EventArgs e)
		{
			
		}
		
		void TextBox1KeyDown(object sender, KeyEventArgs e)
		{
            if (e.KeyCode == Keys.F1)
            {
                frm_productoslist l_frmProductos = new frm_productoslist();
                l_frmProductos.cmd_nuevo.Enabled = false;
                l_frmProductos.ShowDialog();

                if (l_frmProductos.m_KeyRecord != -1)
                {
                    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                    l_recid.Connection = this.m_conn;
                    l_recid.CommandText = "SELECT Codigo FROM catProductos WHERE IdProducto = ?;";
                    l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@IdProducto", l_frmProductos.m_KeyRecord));

                    this.m_conn.Open();
                    System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();
                    l_reader.Read();

                    this.txt_codigo.Text = l_reader["Codigo"].ToString();  

                    l_reader.Close();
                    this.m_conn.Close();

                }
                return;
            }

			if( e.KeyCode == Keys.Enter )
			{
                try
                {
				    //Buscar el articulo...
                    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				    l_recid.Connection = this.m_conn;
				    l_recid.CommandText = "SELECT * FROM catProductos WHERE Codigo = ?;";
				    l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Codigo",this.txt_codigo.Text )  );
    				
				    //this.m_idproduct = l_frmProductos.m_KeyRecord;

				    this.m_conn.Open();  
				    System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				    if(l_reader.Read()==false)
				    {									
					    l_reader.Close();
					    this.m_conn.Close();
                        this.lbl_msg.Text = "";
                        MessageBox.Show("El �rticulo no existe", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					    return;
                    }
                    else
				    {
				        string l_descripcion = l_reader["Descripcion"].ToString();
				        this.lbl_msg.Text = this.txt_cantidad.Value.ToString() + " Agregado(s) - " +  l_reader["Descripcion"].ToString();
    				
				        //Agregar al grid
                        System.Data.DataRow dr = this.m_detail.Tables[0].NewRow();
                        dr["ID"] = l_reader["IdProducto"].ToString();
                        dr["Codigo"] = l_reader["Codigo"].ToString();
                        dr["Descripcion"] = l_reader["Descripcion"].ToString();
                        if (this.radioButton1.Checked)
                        {
                            dr["Cantidad"] = this.txt_cantidad.Value;
                            dr["Importe"] = this.txt_importe.Value;
                            dr["Entrada"] = "1";
                        }
                        else
                        {
                            dr["Cantidad"] = -1 * this.txt_cantidad.Value;
                            dr["Importe"] = -1 * this.txt_importe.Value;
                            dr["Entrada"] = "0";
                        }
                        this.m_detail.Tables[0].Rows.Add(dr);

                        l_reader.Close();
                        mustSave = true;
                    }
                }
                catch(Exception ee)
                {
                    MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
				finally
                {
                    if(this.m_conn.State== System.Data.ConnectionState.Open)
                        this.m_conn.Close();  				
                }

            }   //if( e.KeyCode == Keys.Enter )
		}
		
        private void txt_codigo_Enter(object sender, EventArgs e)
        {
            this.txt_codigo.SelectAll();
        }

        private void txt_codigo_MouseClick(object sender, MouseEventArgs e)
        {
            this.txt_codigo.SelectAll();
        }

        private void frm_altas_caja_Load(object sender, EventArgs e)
        {
            this.m_detail.Tables.Add("detail");
            this.m_detail.Tables[0].Columns.Add("ID");
            this.m_detail.Tables[0].Columns.Add("Codigo");
            this.m_detail.Tables[0].Columns.Add("Descripcion");
            this.m_detail.Tables[0].Columns.Add("Cantidad");
            this.m_detail.Tables[0].Columns.Add("Importe");
            this.m_detail.Tables[0].Columns.Add("Entrada");

            this.m_detail.Tables.Add("orden");
            //this.m_detail.Tables[1].Columns.Add("ID");
            this.m_detail.Tables[1].Columns.Add("idProducto");
            this.m_detail.Tables[1].Columns.Add("Codigo");
            this.m_detail.Tables[1].Columns.Add("Descripcion");
            this.m_detail.Tables[1].Columns.Add("Solicitado", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Surtido", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Entregado", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Saldo", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Subtotal", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Descuento", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Iva", System.Type.GetType("System.Decimal"));
            this.m_detail.Tables[1].Columns.Add("Importe", System.Type.GetType("System.Decimal"));
            this.dataGridOrden.DataSource = this.m_detail.Tables[1];


            this.dataGridView1.DataSource = this.m_detail.Tables[0];
            try
            {
                // SVM feb2010 no se pq aca m marca error
                //this.dataGridView1.Columns[2].Width = (int)(this.dataGridView1.Columns[2].Width * 1.5);
            }
            catch
            {
                //this.dataGridView1.Columns[2].Width = (int)(this.dataGridView1.Columns[2].Width * 1.5);
            }
            this.dataGridView1.Columns[0].Visible = false;
            this.dataGridView1.Columns[5].Visible = false;

            this.dataGridOrden.Columns[0].Visible=false;
            this.dataGridOrden.Columns[1].Width += 30;
            this.dataGridOrden.Columns[2].Width += 100;
            this.dataGridOrden.Columns[1].ReadOnly = true;
            this.dataGridOrden.Columns[2].ReadOnly = true;
            this.dataGridOrden.Columns[3].ReadOnly=true;
            this.dataGridOrden.Columns[4].ReadOnly = true;
            //this.dataGridOrden.Columns[5].ReadOnly = true;
            this.dataGridOrden.Columns[6].ReadOnly = true;  // saldo
            this.dataGridOrden.Columns[8].HeaderText = "% Descto";
            this.dataGridOrden.Columns[9].HeaderText = "% Iva";
            this.dataGridOrden.Columns[10].ReadOnly = true;
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            string tag_ = (string)tabControl1.SelectedTab.Tag; 
            if(tag_ == "DEV")
            {
                SaveDevolucion();
            }
            else
            {
                SaveRecepcion();
            }
        }

        private void SaveRecepcion()
        {
            if (this.txtNumOrden.Text.Trim().Length <= 0)
                return;
            if(lblProveedor.Text.Length == 0)
                return;
            if(this.m_detail.Tables[1].Rows.Count == 0)
                return;
            if (this.txtFacturaProv.Text.Length == 0)
            {
                MessageBox.Show("Indique la factura del proveedor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Decimal tot_cantidad = 0;
            Decimal tot_importe = 0;

            this.m_detail.Tables[1].AcceptChanges();
            this.dataGridOrden.Refresh();

            foreach (System.Data.DataRow dr in this.m_detail.Tables[1].Rows)
            {
                if (Convert.ToDecimal(dr["Entregado"]) > 0)
                {
                    tot_cantidad += Convert.ToDecimal(dr["Entregado"]);
                    if(dr["Importe"]!=System.DBNull.Value)
                        tot_importe += Convert.ToDecimal(dr["Importe"]);
                }
            }

            if (tot_cantidad <= 0)
            {
                MessageBox.Show("No se indico ninguna cantidad a entregar!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            //if (MessageBox.Show("Confirme la generaci�n de la factura " + this.txtFacturaProv.Text  + " para " + this.lblProveedor.Text + " por $ " + tot_importe.ToString("########0.00"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            //{
            //    return;
            //}

            // almacena los datos
            if (UnaSolaFacturaProv)
            {
                if (!Save_FacturaProveedorUna(tot_importe))
                    return;
            }
            else
            {
                if (MessageBox.Show("Confirme la generaci�n de la factura " + this.txtFacturaProv.Text + " para " + this.lblProveedor.Text + " por $ " + tot_importe.ToString("########0.00"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
                else
                    Save_FacturaProveedor(tot_importe);
            }
            // limpia campos
            this.txtNumOrden.Text="";
            this.lblFecha.Text = "";
            this.lblProveedor.Text = "";
            this.txtFacturaProv.Text = "";
            this.m_detail.Tables[1].Rows.Clear();
            this.idOrdenCompra = -1;
            this.chkCredito.Checked = true;
            this.txtNumOrden.Focus();
            return;
        }

        private void Save_FacturaProveedor(Decimal tot_importe)
        {
            try
            {
                int lIdcatFacturaProv;
                Boolean seCierra = true;
                this.m_conn.Open();

                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "INSERT INTO catFacturasProv(IdProveedor,Numero,FechaEntrada,Fecha,TotalFactura,Pagado,FechaPago,IdOrdenCompra) VALUES (?,?,?,?,?,?,?,?)";
                l_cmd.Parameters.Clear();
                l_cmd.Parameters.AddWithValue("@IdProveedor", this.idProveedor);
                l_cmd.Parameters.AddWithValue("@Numero", this.txtFacturaProv.Text);
                l_cmd.Parameters.AddWithValue("@FechaEntrada", this.dtFechaEntrada.Value );
                l_cmd.Parameters.AddWithValue("@Fecha", this.dtFechaFact.Value);
                l_cmd.Parameters.AddWithValue("@TotalFactura", System.Math.Round(tot_importe,2));
                if (this.chkCredito.Checked)
                {
                    l_cmd.Parameters.AddWithValue("@Pagado", 0);
                }
                else
                {
                    l_cmd.Parameters.AddWithValue("@Pagado", System.Math.Round(tot_importe, 2));
                }
                l_cmd.Parameters.AddWithValue("@FechaPago", this.dtFechaPago.Value);
                l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                l_cmd.ExecuteNonQuery();

                l_cmd.CommandText = "SELECT IdcatFacturaProv FROM catFacturasProv WHERE IdProveedor=? AND Numero=? AND IdOrdenCompra=?;";
                /*l_cmd.CommandText = "SELECT IdcatFacturaProv FROM catFacturasProv WHERE IdProveedor=? AND Numero=? AND FechaEntrada=? AND IdOrdenCompra=?;";*/
                l_cmd.Parameters.Clear();
                l_cmd.Parameters.AddWithValue("@IdProveedor", this.idProveedor);
                l_cmd.Parameters.AddWithValue("@Numero", this.txtFacturaProv.Text);
                /*l_cmd.Parameters.AddWithValue("@FechaEntrada", this.dtFechaEntrada.Value);*/
                l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                lIdcatFacturaProv=Convert.ToInt32(l_cmd.ExecuteScalar());

                foreach (System.Data.DataRow dr in this.m_detail.Tables[1].Rows)
                {
                    if (Convert.ToDecimal(dr["Entregado"]) > 0)
                    {
                        l_cmd.CommandText = "INSERT INTO detFacturasProv (IdcatFacturaProv, IdProducto, Cantidad, Importe) VALUES (?,?,?,?)";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@IdcatFacturaProv", lIdcatFacturaProv);
                        l_cmd.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(dr["idProducto"]));
                        l_cmd.Parameters.AddWithValue("@Cantidad", Convert.ToDecimal(dr["Entregado"]));
                        l_cmd.Parameters.AddWithValue("@Importe", System.Math.Round(Convert.ToDecimal(dr["Importe"]),2));
                        l_cmd.ExecuteNonQuery();

                        l_cmd.CommandText = "UPDATE detOrdenesCompra SET surtido=? WHERE IdOrdenCompra=? AND IdProducto=?;";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@surtido", Convert.ToDecimal(dr["surtido"]) + Convert.ToDecimal(dr["entregado"]));
                        l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                        l_cmd.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(dr["idProducto"]));
                        l_cmd.ExecuteNonQuery();

                        if (!this.Save_Existencia(Convert.ToString(dr["codigo"]), this.dtFechaEntrada.Value, Convert.ToString(dr["descripcion"]), Convert.ToDecimal(dr["Entregado"]), Convert.ToDecimal(dr["importe"]), 1, "ENT " + this.txtNumOrden.Text ))
                        {
                            if (this.m_conn.State == System.Data.ConnectionState.Open)
                                this.m_conn.Close();
                            return;
                        }

                    }
                    //si aun quedan saldos debe preguntar si se cierra
                    if (Convert.ToDecimal(dr["Saldo"]) > 0)
                        seCierra = false;

                }

                if (!seCierra)
                {
                    if (MessageBox.Show("La orden de compra aun tiene productos pendientes de surtir, si la cierra ya no podr� aplicar movimientos de entrada sobre esta. Desea cerrarla?" , "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        seCierra = true;
                    }                    
                }
                if (seCierra)
                {
                    l_cmd.CommandText = "UPDATE catOrdenesCompra SET estatus='S', usuario = ? WHERE IdOrdenCompra=?;";
                    l_cmd.Parameters.Clear();
                    
                    l_cmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                    l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);

                    l_cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error grabado factura de proveedor", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }
        }

        // Esta funcion salva una unica factura de prov por orden de compra y
        // ajusta los importes e iva en la orden de compra solo la primera vez
        private Boolean Save_FacturaProveedorUna(Decimal tot_importe)
        {
            Boolean lOk = true;
            
            try
            {
                object res;
                int lIdcatFacturaProv = 0;
                Boolean seCierra = true;
                Boolean SalvaFacturaProv = true;
                this.m_conn.Open();

                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "SELECT IdcatFacturaProv FROM catFacturasProv WHERE IdProveedor=? AND IdOrdenCompra=?;";
                l_cmd.Parameters.Clear();
                l_cmd.Parameters.AddWithValue("@IdProveedor", this.idProveedor);
                //l_cmd.Parameters.AddWithValue("@Numero", this.txtFacturaProv.Text);
                //l_cmd.Parameters.AddWithValue("@FechaEntrada", this.dtFechaEntrada.Value);
                l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                res = l_cmd.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                {
                    SalvaFacturaProv = false;  // ya existe la factura de prov.
                }

                if (SalvaFacturaProv)
                {
                    if (MessageBox.Show("Confirme la generaci�n de la factura " + this.txtFacturaProv.Text + " para " + this.lblProveedor.Text + " por $ " + tot_importe.ToString("########0.00"), "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        //MessageBox.Show("paso 1a?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                        return false;
                    }
                }
                else 
                {
                    if (MessageBox.Show("Confirme la actualizaci�n de las existencias para la orden de compra", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        return false;
                    }
                }
                //MessageBox.Show("paso a?" + SalvaFacturaProv, "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                //dt = System.DateTime.Now;

                if (SalvaFacturaProv)
                {
                    
                    l_cmd.CommandText = "INSERT INTO catFacturasProv(IdProveedor,Numero,FechaEntrada,Fecha,TotalFactura,Pagado,FechaPago,IdOrdenCompra) VALUES (?,?,?,?,?,?,?,?)";
                    l_cmd.Parameters.Clear();
                    l_cmd.Parameters.AddWithValue("@IdProveedor", this.idProveedor);
                    l_cmd.Parameters.AddWithValue("@Numero", this.txtFacturaProv.Text);
                   
                   l_cmd.Parameters.AddWithValue("@FechaEntrada", this.dtFechaEntrada.Value);
                   
                    
                    l_cmd.Parameters.AddWithValue("@Fecha", this.dtFechaFact.Value);
                    l_cmd.Parameters.AddWithValue("@TotalFactura", System.Math.Round(tot_importe, 2));
                    if (this.chkCredito.Checked)
                    {
                        l_cmd.Parameters.AddWithValue("@Pagado", 0);
                    }
                    else
                    {
                        l_cmd.Parameters.AddWithValue("@Pagado", System.Math.Round(tot_importe, 2));
                    }
                    
                    l_cmd.Parameters.AddWithValue("@FechaPago", this.dtFechaPago.Value);
                    l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                    
                    
                    //MessageBox.Show("paso factura a2?" + " -" + this.idProveedor + this.txtFacturaProv.Text + System.Math.Round(tot_importe, 2) + this.idOrdenCompra, "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    l_cmd.ExecuteNonQuery();
                    //MessageBox.Show("paso factura a2 ok?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                    l_cmd.CommandText = "SELECT IdcatFacturaProv FROM catFacturasProv WHERE IdProveedor=? AND IdOrdenCompra=?;";
                    l_cmd.CommandText = "SELECT IdcatFacturaProv FROM catFacturasProv WHERE IdProveedor=? AND Numero=? AND FechaEntrada=? AND IdOrdenCompra=?;";

                    l_cmd.Parameters.Clear();
                    l_cmd.Parameters.AddWithValue("@IdProveedor", this.idProveedor);
                    l_cmd.Parameters.AddWithValue("@Numero", this.txtFacturaProv.Text);
                    l_cmd.Parameters.AddWithValue("@FechaEntrada", this.dtFechaEntrada.Value);
                    l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                    lIdcatFacturaProv = Convert.ToInt32(l_cmd.ExecuteScalar());                }

               
             
                Decimal subtot = 0;
                Decimal tot = 0;
                
                foreach (System.Data.DataRow dr in this.m_detail.Tables[1].Rows)
                {
                    if (Convert.ToDecimal(dr["Solicitado"]) > 0 && SalvaFacturaProv)
                    {
                        l_cmd.CommandText = "INSERT INTO detFacturasProv (IdcatFacturaProv, IdProducto, Cantidad, Importe) VALUES (?,?,?,?)";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@IdcatFacturaProv", lIdcatFacturaProv);
                        l_cmd.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(dr["idProducto"]));
                        l_cmd.Parameters.AddWithValue("@Cantidad", Convert.ToDecimal(dr["Solicitado"]));
                        l_cmd.Parameters.AddWithValue("@Importe", System.Math.Round(Convert.ToDecimal(dr["Importe"]), 2));
                        l_cmd.ExecuteNonQuery();

                        l_cmd.CommandText = "UPDATE detOrdenesCompra SET Iva=?, Importe=? WHERE IdOrdenCompra=? AND IdProducto=?;";
                        l_cmd.Parameters.Clear();
                        
                        System.Decimal val = Convert.ToDecimal(dr["Subtotal"]) - Convert.ToDecimal(dr["Subtotal"]) * Convert.ToDecimal(dr["Descuento"]) / 100; // descuento
                        val = val * Convert.ToDecimal(dr["Iva"]) / 100;  // iva
                        //System.Decimal val = Convert.ToDecimal(dr["Iva"]);

                        l_cmd.Parameters.AddWithValue("@Iva", Math.Round(val,2));
                        l_cmd.Parameters.AddWithValue("@Importe", Convert.ToDecimal(dr["importe"]));
                        l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                        l_cmd.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(dr["idProducto"]));
                        l_cmd.ExecuteNonQuery();

                        subtot += Convert.ToDecimal(dr["subtotal"]);
                        tot += Convert.ToDecimal(dr["importe"]);
                    }

                    if (Convert.ToDecimal(dr["entregado"]) > 0)
                    {
                        l_cmd.CommandText = "UPDATE detOrdenesCompra SET surtido=? WHERE IdOrdenCompra=? AND IdProducto=?;";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@surtido", Convert.ToDecimal(dr["surtido"]) + Convert.ToDecimal(dr["entregado"]));
                        l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                        l_cmd.Parameters.AddWithValue("@IdProducto", Convert.ToInt32(dr["idProducto"]));
                        l_cmd.ExecuteNonQuery();
                        
                        if (!this.Save_Existencia(Convert.ToString(dr["codigo"]), this.dtFechaEntrada.Value, Convert.ToString(dr["descripcion"]), Convert.ToDecimal(dr["Entregado"]), Convert.ToDecimal(dr["importe"]), 1, "ENT " + this.txtNumOrden.Text))
                        {
                            if (this.m_conn.State == System.Data.ConnectionState.Open)
                                this.m_conn.Close();
                            return false;
                        }
                    }
                    //si aun quedan saldos debe preguntar si se cierra
                    if (Convert.ToDecimal(dr["Saldo"]) > 0)
                        seCierra = false;

                }

               // MessageBox.Show("paso 1?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (SalvaFacturaProv)
                {
                    l_cmd.CommandText = "UPDATE catOrdenesCompra SET Subtotal=?, Total=? WHERE IdOrdenCompra=?;";
                    l_cmd.Parameters.Clear();
                    l_cmd.Parameters.AddWithValue("@Subtotal", Math.Round(subtot, 2));
                    l_cmd.Parameters.AddWithValue("@Total", Math.Round(tot,2));
                    l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                    l_cmd.ExecuteNonQuery();
                }

                if (!seCierra)
                {
                    if (MessageBox.Show("La orden de compra aun tiene productos pendientes de surtir, si la cierra ya no podr� aplicar movimientos de entrada sobre esta. Desea cerrarla?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        seCierra = true;
                    }
                }
                if (seCierra)
                {
                    l_cmd.CommandText = "UPDATE catOrdenesCompra SET estatus='S', usuario = ? WHERE IdOrdenCompra=?;";
                    l_cmd.Parameters.Clear();
                    l_cmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                    l_cmd.Parameters.AddWithValue("@IdOrdenCompra", this.idOrdenCompra);
                    l_cmd.ExecuteNonQuery();


                    


                }

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "A-Error grabado factura de proveedor", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lOk = false;
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }
            return lOk;
        }


        private void SaveDevolucion()
        {
            try
            {
                this.m_conn.Open();
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;

                foreach (DataGridViewRow oRow in this.dataGridView1.Rows)
                {
                    if (!this.Save_Existencia(Convert.ToString(oRow.Cells[1].Value), this.dateTimePicker1.Value, Convert.ToString(oRow.Cells[2].Value), Convert.ToDecimal(oRow.Cells[3].Value), Convert.ToDecimal(oRow.Cells[4].Value), Convert.ToInt32(oRow.Cells[5].Value), this.txt_observs.Text))
                    {
                        if (this.m_conn.State == System.Data.ConnectionState.Open)
                            this.m_conn.Close();
                        return;
                    }
                }
                this.txt_codigo.Text = "";
                this.lbl_msg.Text = "";
                this.m_detail.Tables[0].Rows.Clear();
                this.txt_codigo.Focus();
                mustSave = false;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }
        }
            //try
            //{
            //    this.m_conn.Open();
            //    System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
            //    l_inc.Connection = this.m_conn;

            //    foreach (DataGridViewRow oRow in this.dataGridView1.Rows)
            //    {
            //        //Modificar el inventario
            //        l_inc.CommandText = "UPDATE catProductos SET Existencia = Existencia + " + oRow.Cells[3].Value.ToString() + ",dtRegModificado = ?,UsuarioModif = ? WHERE Codigo = ?;";
            //        l_inc.Parameters.Clear();
            //        l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@dtRegModificado", DateTime.Now));
            //        l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@UsuarioModif", frm_Main.mps_usuario));
            //        l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@Codigo", oRow.Cells[1].Value));
            //        l_inc.ExecuteNonQuery();

            //        //Almacenar la entrada
            //        /*l_inc = new System.Data.Odbc.OdbcCommand();
            //        l_inc.Connection = this.m_conn;*/
            //        l_inc.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,iimporte,clogin,entrada,observaciones) VALUES(?,?,?,?,?,?,?,?);";

            //        l_inc.Parameters.Clear();
            //        l_inc.Parameters.AddWithValue("@ccodigo", oRow.Cells[1].Value);
            //        //l_inc.Parameters.AddWithValue("@dtfecha", Convert.ToDateTime( System.DateTime.Now.ToString() ) );
            //        l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
            //        l_inc.Parameters.AddWithValue("@cdescripcion", oRow.Cells[2].Value);
            //        l_inc.Parameters.AddWithValue("@icantidad", oRow.Cells[3].Value);
            //        l_inc.Parameters.AddWithValue("@iimporte", oRow.Cells[4].Value);
            //        l_inc.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
            //        l_inc.Parameters.AddWithValue("@entrada", Convert.ToInt32(oRow.Cells[5].Value));
            //        l_inc.Parameters.AddWithValue("@observaciones", this.txt_observs.Text);

            //        l_inc.ExecuteNonQuery();
            //    }
            //    this.txt_codigo.Text = "";
            //    this.lbl_msg.Text = "";
            //    this.m_detail.Tables[0].Rows.Clear();
            //    this.txt_codigo.Focus();
            //    mustSave = false;
            //    //MessageBox.Show("Articulo agregado", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //}
            //catch (Exception ee)
            //{
            //    MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //finally
            //{
            //    if (this.m_conn.State == System.Data.ConnectionState.Open)
            //        this.m_conn.Close();
            //}

        private Boolean  Save_Existencia(string ccodigo, DateTime dtfecha, string cdescripcion,decimal icantidad, decimal iimporte, Int32 entrada, string observaciones)
        {
            Boolean resul = true;
            string errMess;
            try
            {
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;

                //Modificar el inventario
                l_inc.CommandText = "UPDATE catProductos SET Existencia = Existencia + " + icantidad.ToString() + ",dtRegModificado = ?,UsuarioModif = ? WHERE Codigo = ?;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@dtRegModificado", DateTime.Now));
                l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@UsuarioModif", frm_Main.mps_usuario));
                l_inc.Parameters.Add(new System.Data.Odbc.OdbcParameter("@Codigo", ccodigo));
                l_inc.ExecuteNonQuery();
                //MessageBox.Show("existencia catproducto agregado", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if(!frm_productos.Save_Existencias_Almacen(ccodigo,icantidad,this.m_conn, out errMess))
                    return false;

                //Almacenar la entrada
                /*l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;*/
                
                l_inc.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,iimporte,clogin,entrada,observaciones,idAlmacen) VALUES(?,?,?,?,?,?,?,?,?);";
               

                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@ccodigo", ccodigo);
                l_inc.Parameters.AddWithValue("@dtfecha", Convert.ToDateTime( System.DateTime.Now.ToString() ) );
                //l_inc.Parameters.AddWithValue("@dtfecha", dtfecha);
                l_inc.Parameters.AddWithValue("@cdescripcion", cdescripcion);
                l_inc.Parameters.AddWithValue("@icantidad", icantidad);
                l_inc.Parameters.AddWithValue("@iimporte", System.Math.Round(iimporte,2));
                l_inc.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                l_inc.Parameters.AddWithValue("@entrada", entrada);
                l_inc.Parameters.AddWithValue("@observaciones", observaciones);
                l_inc.Parameters.AddWithValue("@idAlmacen", frm_Main.mp_idAlmacen);

                l_inc.ExecuteNonQuery();

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error salvando existencias", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resul = false;
            }
            finally
            {
            }
            return resul;
        }


        private void cmd_delete_Click(object sender, EventArgs e)
        {
            string tag_ = (string)tabControl1.SelectedTab.Tag; 
            if (tag_ == "DEV")
            {
                DeleteDevolucion();
            }
            else
            { }
        }

        private void DeleteDevolucion()
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow oRow in this.dataGridView1.SelectedRows)
                {
                    this.dataGridView1.Rows.Remove(oRow);
                }
                this.dataGridView1.Refresh();
            }
        }

        private void txtNumOrden_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if(mustValidate)
                e.Cancel = !this.ValidateOrdenCompra(this.txtNumOrden.Text);
            mustValidate = true;
        }

        // regresa true si encuentra la orden y esta activa, false en caso contrario 
        private Boolean ValidateOrdenCompra(string strOrden)
        {
            Boolean lOk = false;
            try
            {
                this.lblFecha.Text = "";
                this.lblProveedor.Text = "";

                if(strOrden.Trim().Length<=0)
                    return true;

                //Buscar la orden...
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                l_recid.Connection = this.m_conn;
                l_recid.CommandText = "SELECT catOrdenesCompra.*, catProveedores.Nombre FROM catOrdenesCompra left join catProveedores on catOrdenesCompra.IdProveedor=catProveedores.IdProveedor WHERE NumeroOrdenCompra = ?;";
                l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@NumeroOrdenCompra", strOrden));

                //this.m_idproduct = l_frmProductos.m_KeyRecord;

                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();

                if (l_reader.Read() == false)
                {
                    l_reader.Close();
                    this.m_conn.Close();
                    MessageBox.Show("La orden de compra no existe", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    string l_estatus = l_reader["estatus"].ToString();
                    string l_descripcion = string.Format("La orden {0} del {1} se encuentra ", l_reader["NumeroOrdenCompra"].ToString(), l_reader["Fecha"].ToString());
                    switch(l_estatus.ToUpper())
                    {
                        case "C":
                            MessageBox.Show(l_descripcion + "CANCELADA!","",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                            break;
                        case "S":
                            MessageBox.Show(l_descripcion + "SURTIDA!","",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                            break;
                        default:
                            lOk=true;
                            break;
                    }
                }
                if(lOk)
                {
                    this.lblFecha.Text = "FECHA: " + l_reader["Fecha"].ToString();
                    this.lblProveedor.Text = l_reader["Nombre"].ToString();
                    if(idOrdenCompra!=Convert.ToInt32(l_reader["idOrdenCompra"]))
                    {
                        idOrdenCompra = Convert.ToInt32(l_reader["idOrdenCompra"]);
                        idProveedor = Convert.ToInt32(l_reader["idProveedor"]);
                        this.m_conn.Close();
                        this.FillDataOrden();
                    }    
                }
                else
                {
                    this.m_detail.Tables[1].Rows.Clear();
                    idOrdenCompra = -1;
                    idProveedor = -1;
                }

                    ////Agregar al grid
                    //System.Data.DataRow dr = this.m_detail.Tables[0].NewRow();
                    //dr["ID"] = l_reader["IdProducto"].ToString();
                    //dr["Codigo"] = l_reader["Codigo"].ToString();
                    //dr["Descripcion"] = l_reader["Descripcion"].ToString();
                    //if (this.radioButton1.Checked)
                    //{
                    //    dr["Cantidad"] = this.txt_cantidad.Value;
                    //    dr["Importe"] = this.txt_importe.Value;
                    //    dr["Entrada"] = "1";
                    //}
                    //else
                    //{
                    //    dr["Cantidad"] = -1 * this.txt_cantidad.Value;
                    //    dr["Importe"] = -1 * this.txt_importe.Value;
                    //    dr["Entrada"] = "0";
                    //}
                    //this.m_detail.Tables[0].Rows.Add(dr);

                l_reader.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }
            return true;
        }

        private void FillDataOrden()
        {
            try
            {
                //Buscar el detalle de la orden...
                System.Data.DataRow lrow;
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                l_recid.Connection = this.m_conn;
                l_recid.CommandText = "SELECT detOrdenesCompra.*, catProductos.Codigo, catProductos.Descripcion FROM detOrdenesCompra left join catProductos on detOrdenesCompra.IdProducto=catProductos.IdProducto WHERE IdOrdenCompra = ?;";
                l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@IdOrdenCompra", idOrdenCompra));

                //this.m_idproduct = l_frmProductos.m_KeyRecord;

                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();

                this.m_detail.Tables[1].Rows.Clear();
                while (l_reader.Read())
                {
                    lrow = this.m_detail.Tables[1].NewRow();
                    lrow["idProducto"] = l_reader["idProducto"];
                    lrow["Codigo"] = l_reader["Codigo"];
                    lrow["Descripcion"] = l_reader["Descripcion"];
                    if (l_reader["Cantidad"] is DBNull)
                    {
                        lrow["Solicitado"] = 0.0;
                    }
                    else
                    {
                        lrow["Solicitado"] = Convert.ToDecimal(l_reader["Cantidad"]);
                    }
                    if (l_reader["Surtido"] is DBNull)
                    {
                        lrow["Surtido"] = 0.0;
                        if(Initentregado0)
                            lrow["Entregado"] = 0.0;
                        else
                            lrow["Entregado"] = Convert.ToDecimal(lrow["Solicitado"]);
                    }
                    else
                    {
                        lrow["Surtido"] = Convert.ToDecimal(l_reader["Surtido"]);
                        if(Initentregado0)
                            lrow["Entregado"] = 0.0;
                        else
                        lrow["Entregado"] = Convert.ToDecimal(lrow["Solicitado"]) - Convert.ToDecimal(lrow["Surtido"]);
                    }
                    lrow["Saldo"] = 0.0;
                    lrow["Subtotal"] = 0.0;
                    lrow["Descuento"] = 0.0;
                    lrow["Iva"] = IvaSistema;
                    lrow["Importe"] = 0.0;

                    this.m_detail.Tables[1].Rows.Add(lrow);
                }
                l_reader.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }
        }

        private void txt_codigo_KeyDown(object sender, KeyEventArgs e)
        {
            this.TextBox1KeyDown(sender, e);
        }

        private void txt_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtNumOrden_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridOrden_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            Decimal val;
            if (e.ColumnIndex == 5)
            {
                try
                {
                    val = Convert.ToDecimal(e.FormattedValue);
                }
                catch
                {
                    MessageBox.Show("valor incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                if (e.FormattedValue.ToString().Length == 0)
                {
                    MessageBox.Show("valor incorrecto" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                if (val < 0)
                {
                    MessageBox.Show("La cantidad entregada debe ser mayor o igual a cero!" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                    e.Cancel = true;
                }
                else
                {
                    DataGridViewRow dgrow = this.dataGridOrden.Rows[e.RowIndex]; 
                     if(val+Convert.ToDecimal(dgrow.Cells[4].Value)>Convert.ToDecimal(dgrow.Cells[3].Value))
                     {
                         if (MessageBox.Show("El valor de lo previamente surtido m�s lo entregado excede lo solicitado en la orden de compra, desea continuar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                         {
                             e.Cancel = true;
                             return;
                         }
                     }
                     dgrow.Cells[6].Value = Convert.ToDecimal(dgrow.Cells[3].Value) - (val+Convert.ToDecimal(dgrow.Cells[4].Value));
                }
            }
            if (e.ColumnIndex==7 || e.ColumnIndex==8 || e.ColumnIndex==9)
            {
                try
                {
                    val = Convert.ToDecimal(e.FormattedValue);
                }
                catch
                {
                    MessageBox.Show("valor incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                if (e.FormattedValue.ToString().Length == 0)
                {
                    MessageBox.Show("valor incorrecto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    e.Cancel = true;
                    return;
                }
                
                DataGridViewRow dgrow = this.dataGridOrden.Rows[e.RowIndex];
                if (e.ColumnIndex == 7 )
                {
                    val = val - val * Convert.ToDecimal(dgrow.Cells[8].Value) / 100; // descuento
                    val = val + val * Convert.ToDecimal(dgrow.Cells[9].Value) / 100;  // iva
                }
                else if(e.ColumnIndex == 8)
                {
                    val = Convert.ToDecimal(dgrow.Cells[7].Value) - Convert.ToDecimal(dgrow.Cells[7].Value) * val / 100; // descuento
                    val = val + val * Convert.ToDecimal(dgrow.Cells[9].Value) / 100;  // iva

                }
                else
                {
                    //e.ColumnIndex == 9
                    System.Decimal val1;
                    val1 = Convert.ToDecimal(dgrow.Cells[7].Value) - Convert.ToDecimal(dgrow.Cells[7].Value) * Convert.ToDecimal(dgrow.Cells[8].Value) / 100; // descuento
                    val = val1 + val1 * val / 100;  // iva
                }
                //val = Convert.ToDecimal(dgrow.Cells[7].Value) - Convert.ToDecimal(dgrow.Cells[7].Value) * Convert.ToDecimal(dgrow.Cells[8].Value)/100; // descuento
                //val = val + val * Convert.ToDecimal(dgrow.Cells[9].Value) / 100;  // iva
                dgrow.Cells[10].Value = System.Math.Round(val,2);
            }
        }

        private void dataGridOrden_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            MessageBox.Show("Error en el valor indicado: " + e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtNumOrden_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.ValidateOrdenCompra(this.txtNumOrden.Text))
                {
                    mustValidate = false;
                    this.dtFechaEntrada.Focus();
                }
            }
        }

        private void txtCodigo2Seek_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.txtCodigo2Seek.Text.Length > 0)
                {
                    foreach (DataGridViewRow oRow in this.dataGridOrden.Rows)
                    {
                        if (oRow.Cells["Codigo"].Value.ToString() == this.txtCodigo2Seek.Text)
                        {
                            oRow.Cells["Entregado"].Value = Convert.ToDecimal(oRow.Cells["Solicitado"].Value) - Convert.ToDecimal(oRow.Cells["Surtido"].Value);
                            oRow.Cells["Saldo"].Value = Convert.ToDecimal(oRow.Cells["Solicitado"].Value) - Convert.ToDecimal(oRow.Cells["Entregado"].Value);
                            oRow.Selected = true;
                            return;
                        }
                    }
                }
            }
        }

        private void LeeConfSystem()
        {
            Initentregado0 = false;
            IvaSistema = 16;
            try
            {
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "SELECT Iva,RecepEntregado0 FROM confSystem;";

                if (this.m_conn.State == System.Data.ConnectionState.Closed)
                    this.m_conn.Open();

                System.Int32 val = 0;
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
                if (l_reader.Read())
                {
                    IvaSistema = Convert.ToDecimal(l_reader[0])*100;
                    val = Convert.ToInt32(l_reader[1]);
                }
                l_reader.Close();
                if(val==1)
                    Initentregado0 = true;
            }
            catch
            {
                Initentregado0 = false;
            }
            finally
            {
                if (this.m_conn.State != System.Data.ConnectionState.Closed)
                    this.m_conn.Close();
            }

        }



	}
}
