/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50141
Source Host           : localhost:3306
Source Database       : Invoices

Target Server Type    : MYSQL
Target Server Version : 50141
File Encoding         : 65001

Date: 2011-02-10 00:56:37
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `catCaja`
-- ----------------------------
DROP TABLE IF EXISTS `catCaja`;
CREATE TABLE `catCaja` (
  `iidcaja` int(11) NOT NULL AUTO_INCREMENT,
  `dtfecha` datetime DEFAULT NULL,
  `iimporte` float DEFAULT '0',
  `clogin` varchar(50) DEFAULT NULL,
  `entrada` int(1) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`iidcaja`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catCaja
-- ----------------------------

-- ----------------------------
-- Table structure for `catClientes`
-- ----------------------------
DROP TABLE IF EXISTS `catClientes`;
CREATE TABLE `catClientes` (
  `IdCliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) DEFAULT NULL,
  `Direccion` varchar(50) DEFAULT NULL,
  `Fax` varchar(50) DEFAULT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `RFC` varchar(64) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `CURP` varchar(64) DEFAULT NULL,
  `Calle` varchar(64) DEFAULT NULL,
  `Numero` varchar(16) DEFAULT NULL,
  `NumeroInt` varchar(16) DEFAULT NULL,
  `Colonia` varchar(128) DEFAULT NULL,
  `Referencia` varchar(256) DEFAULT NULL,
  `Municipio` varchar(128) DEFAULT NULL,
  `Estado` varchar(128) DEFAULT NULL,
  `Pais` varchar(128) DEFAULT NULL,
  `CodigoPostal` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`IdCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catClientes
-- ----------------------------
INSERT INTO `catClientes` VALUES ('1', 'CLIENTE DE MOSTRADOR', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', '2010-09-27 15:44:47', 'NINGUNO', '', 'NINGUNO', 'MOGJ010101', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO');

-- ----------------------------
-- Table structure for `catConsolidacionFactura`
-- ----------------------------
DROP TABLE IF EXISTS `catConsolidacionFactura`;
CREATE TABLE `catConsolidacionFactura` (
  `iidconsolidacion` int(11) NOT NULL AUTO_INCREMENT,
  `iidfactura` int(11) NOT NULL,
  PRIMARY KEY (`iidconsolidacion`,`iidfactura`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catConsolidacionFactura
-- ----------------------------

-- ----------------------------
-- Table structure for `catCorte`
-- ----------------------------
DROP TABLE IF EXISTS `catCorte`;
CREATE TABLE `catCorte` (
  `iidCorte` int(11) NOT NULL AUTO_INCREMENT,
  `dtFecha` datetime DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `cusuario` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`iidCorte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catCorte
-- ----------------------------

-- ----------------------------
-- Table structure for `catEntradas`
-- ----------------------------
DROP TABLE IF EXISTS `catEntradas`;
CREATE TABLE `catEntradas` (
  `iidEntrada` int(11) NOT NULL AUTO_INCREMENT,
  `ccodigo` varchar(64) DEFAULT NULL,
  `dtfecha` datetime DEFAULT NULL,
  `cdescripcion` varchar(255) DEFAULT NULL,
  `icantidad` float DEFAULT NULL,
  `iimporte` float DEFAULT '0',
  `clogin` varchar(50) DEFAULT NULL,
  `entrada` int(1) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`iidEntrada`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catEntradas
-- ----------------------------

-- ----------------------------
-- Table structure for `catFacturas`
-- ----------------------------
DROP TABLE IF EXISTS `catFacturas`;
CREATE TABLE `catFacturas` (
  `IdFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroFactura` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `NumProductos` int(11) DEFAULT NULL,
  `Subtotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `EsCredito` int(1) NOT NULL DEFAULT '0',
  `Cancelada` int(1) NOT NULL DEFAULT '0',
  `usuario` varchar(50) DEFAULT NULL,
  `esfactura` int(1) NOT NULL DEFAULT '1',
  `estatus` int(11) NOT NULL,
  `entregado` float DEFAULT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  `cadenaoriginal` text,
  `sello` text,
  PRIMARY KEY (`IdFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catFacturas
-- ----------------------------

-- ----------------------------
-- Table structure for `catFamilias`
-- ----------------------------
DROP TABLE IF EXISTS `catFamilias`;
CREATE TABLE `catFamilias` (
  `idFamilia` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `idPadre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idFamilia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catFamilias
-- ----------------------------

-- ----------------------------
-- Table structure for `catNotas`
-- ----------------------------
DROP TABLE IF EXISTS `catNotas`;
CREATE TABLE `catNotas` (
  `IdFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroFactura` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `NumProductos` int(11) DEFAULT NULL,
  `SubTotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `EsCredito` int(1) NOT NULL DEFAULT '0',
  `Cancelada` int(1) NOT NULL DEFAULT '0',
  `usuario` varchar(50) DEFAULT NULL,
  `esfactura` int(1) NOT NULL DEFAULT '0',
  `estatus` int(11) NOT NULL,
  `entregado` float DEFAULT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catNotas
-- ----------------------------

-- ----------------------------
-- Table structure for `catnotascred`
-- ----------------------------
DROP TABLE IF EXISTS `catnotascred`;
CREATE TABLE `catnotascred` (
  `IdNotaCred` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroNotaCred` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Concepto` varchar(255) DEFAULT NULL,
  `SubTotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `estatus` int(1) NOT NULL,
  `Cancelada` int(1) NOT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  `cadenaoriginal` text,
  `sello` text,
  PRIMARY KEY (`IdNotaCred`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catnotascred
-- ----------------------------

-- ----------------------------
-- Table structure for `catOrdenesCompra`
-- ----------------------------
DROP TABLE IF EXISTS `catOrdenesCompra`;
CREATE TABLE `catOrdenesCompra` (
  `IdOrdenCompra` int(11) NOT NULL AUTO_INCREMENT,
  `IdProveedor` int(11) DEFAULT NULL,
  `NumeroOrdenCompra` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `NumProductos` int(11) DEFAULT NULL,
  `Subtotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `estatus` varchar(5) NOT NULL,
  PRIMARY KEY (`IdOrdenCompra`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catOrdenesCompra
-- ----------------------------

-- ----------------------------
-- Table structure for `catProductos`
-- ----------------------------
DROP TABLE IF EXISTS `catProductos`;
CREATE TABLE `catProductos` (
  `IdProducto` int(11) NOT NULL AUTO_INCREMENT,
  `CodigoProd` varchar(255) DEFAULT NULL,
  `Codigo` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Existencia` float DEFAULT NULL,
  `PrecioProveedor` float DEFAULT NULL,
  `PrecioalCliente` float DEFAULT NULL,
  `Proveedores` varchar(255) DEFAULT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `UnidadVenta` varchar(255) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  `PtoReorden` int(11) DEFAULT NULL,
  `Observaciones` varchar(255) DEFAULT NULL,
  `PorcUtilidad` decimal(18,2) DEFAULT NULL,
  `Marca` varchar(255) DEFAULT NULL,
  `Linea` varchar(255) DEFAULT NULL,
  `idFamilia` int(11) DEFAULT NULL,
  `sfamilia` varchar(255) DEFAULT NULL,
  `dtRegModificado` datetime DEFAULT NULL,
  `PtoMaximo` int(11) DEFAULT NULL,
  `UsuarioModif` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=1132 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catProductos
-- ----------------------------
INSERT INTO `catProductos` VALUES ('1', '1', '7502218211542', 'ACEITE COMESTIBLE COCINERA CJA/24  500 ML', '5', '0', '0', '', '', 'Pieza', '16', '0', '', '0.00', 'COCINERA', 'COCINERA', '0', '', '2010-11-20 17:58:12', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('2', '2', '7502218210804', 'ACEITE COMESTIBLE COCINERA CJA/12 1 LTS', '8', '0', '0', 'PROTEINAS Y OLEICO  ', '', 'Pieza', '16', '0', '', '0.00', 'COCINERA', 'COCINERA', '0', '', '2010-11-20 17:58:52', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('3', '3', '75005443', 'ACEITE COMESTIBLE 1,2,3, CJA/24 500 ML', '4', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3,', '1,2,3,', '0', '', '2010-11-20 17:59:40', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('4', '4', '75002343', 'ACEITE COMESTIBLE 1,2,3, CJA/12 1 LTS', '30', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3,', '1,2,3,', '0', '', '2010-11-20 17:59:54', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('5', '5', '7502223770461', 'ACEITE COMESTIBLE CAPULLO CJA/12 945 ML', '1', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CAPULLO', 'CAPULLO', '0', '', '2010-11-20 18:00:45', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('6', '6', '75024437', 'ACEITE COMESTIBLE CAPULLO CJA/12 500 ML', '6', '0', '0', '16 17', '', 'Pieza', '16', '0', '', '0.00', 'CAPULLO', 'CAPULLO', '0', '', '2010-11-20 18:00:59', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('7', '7', '7501039120149', 'ACEITE COMESTIBLE NUTRIOLI CJA/12 946 ML', '1', '0', '0', '3', '', 'Pieza', '16', '0', '', '0.00', 'NUTRIOLI', 'NUTRIOLI', '0', '', '2010-11-20 18:01:17', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('8', '8', '', 'ACEITE COMESTIBLE NUTRIOLI PQT/3 946 ML', '11', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NUTRIOLI', 'NUTRIOLI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('9', '9', '7501491000935', 'ACEITE COMESTIBLE OLEICO CJA/12 946 ML', '1', '0', '0', '23 24 35 36 37 38 39 40 41', '', 'Pieza', '16', '0', '', '0.00', 'OLEICO', 'OLEICO', '0', '', '2010-11-20 18:02:22', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('10', '10', '', 'ACEITE COMESTIBLE/ VERDE GARY CJA/24 145 ML', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('11', '11', '', 'ACEITE COMESTIBLE/ VERDE GARY CJA/12 1 LTS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('12', '12', '7501035908253', 'ACEITE PARA BEBE MENNEN CJA/24    200 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 18:03:53', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('13', '13', '7501035908239', 'ACEITE PARA BEBE MENNEN CJA/36 50 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 18:04:53', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('14', '14', '7501035908246', 'ACEITE PARA BEBE MENNEN CJA/24    100 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 18:04:40', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('15', '15', '', 'ACEITE PARA MAQUINA MOL PZAS 100 ML', '77', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MOL', 'MOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('16', '16', '759684431050', 'ACETONA JALOMA CJA/25 60 ML.', '4', '0', '0', 'SURTIDORA DEL ORIENTE SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 18:05:25', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('17', '17', '', 'ACETONA JALOMA PZA 60 ML.', '2', '0', '0', 'SURTIDORA DEL ORIENTE SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('18', '18', '7501008950012', 'ACHIOTE LA EXTRA CJA/32 PQT 20 CUBITOS', '3', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 18:11:09', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('19', '19', '19', 'ACHIOTE LA EXTRA PQT 20 CUBITOS', '0', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-27 12:52:59', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('20', '20', '', 'ACIDO MURIATICO ALAMO CJA/24 220 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALAMO', 'ALAMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('21', '21', '75006082', 'ACIDO MURIATICO ALAMO CJA/24    420 ML', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALAMO', 'ALAMO', '0', '', '2010-11-20 18:14:39', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('22', '22', '', 'ACIDO MURIATICO ALAMO CJA/15 1 LTS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALAMO', 'ALAMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('23', '23', '737128129008', 'ACIDO MURIATICO LA ANITA CJA/12 1 LTS', '5', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 18:15:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('24', '24', '', 'ACIDO MURIATICO LA ANITA CJA/24 500 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('25', '25', '7503000256055', 'ACIDO MURIATICO RH CJA/24    500 ML', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RH', 'RH', '0', '', '2010-11-20 18:15:11', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('26', '26', '', 'AGUA OXIGENADA RAB PZA 225 ML', '0', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'RAB', 'RAB', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('27', '27', '', 'AGUA OXIGENADA RAB PZA 115 ML', '0', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'RAB', 'RAB', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('28', '28', '', 'ALCOHOL LC CJA/15 830 ML', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LC', 'LC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('29', '29', '', 'ALCOHOL LC CJA/24    430 ML', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LC', 'LC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('30', '30', '', 'ALCOHOL LC CJA/24    230 ML', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LC', 'LC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('31', '31', '', 'ALCOHOL LC CJA/36 110 ML', '6', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LC', 'LC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('32', '32', '', 'ALCOHOL SOLIDO QUICK CHEF CJA/24 250 ML  ', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'QUICK CHEF', 'QUICK CHEF', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('33', '33', '7501048620159', 'ALGODÓN PROTEC  PQT/12 25 GRS', '4', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PROTEC ', 'PROTEC ', '0', '', '2010-11-20 18:26:36', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('34', '34', '7501048621200', 'ALGODÓN PROTEC  PZA 300 GRS', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PROTEC ', 'PROTEC ', '0', '', '2010-11-20 18:28:09', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('35', '35', '75003586', 'ALIMENTO INFANTIL GERBER CJA/24 118 ML', '3', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:34:04', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('36', '36', '7501000903269', 'ALIMENTO INFANTIL CIRUELA PASA 2 ETAPA GERBER CJA/24 100 GRS', '5', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:33:44', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('37', '37', '7501000913305', 'ALIMENTO INFANTIL DURAZNO 2 ETAPA GERBER CJA/24 100 GRS', '7', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:34:29', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('38', '38', '7501000913466', 'ALIMENTO INFANTIL FRUTA MIXTAS 2 ETAPA GERBER CJA/24 100 GRS', '4', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:35:03', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('39', '39', '', 'ALIMENTO INFANTIL MANGO 2 ETAPA GERBER CJA/24 100 GRS', '4', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('40', '40', '', 'ALIMENTO INFANTIL MANZANA 1 ETAPA GERBER CJA/24 71 GRS', '0', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('41', '41', '7501000913312', 'ALIMENTO INFANTIL MANZANA 2 ETAPA GERBER CJA/24 100 GRS', '30', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:35:34', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('42', '42', '75013332', 'ALIMENTO INFANTIL PERA 1 ETAPA GERBER CJA/24 71 GRS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 18:35:57', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('43', '43', '', 'ALIMENTO INFANTIL PERA 2 ETAPA GERBER CJA/24 100 GRS', '4', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('44', '44', '', 'ALIMENTO INFANTIL PLATANO 2 ETAPA GERBER CJA/24 100 GRS', '3', '0', '0', 'LA ANITA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('45', '45', '017500277641', 'ALMIDON FAULTLESS PQT/4 585 ML', '4', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'FAULTLESS', 'FAULTLESS', '0', '', '2010-11-20 18:45:30', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('46', '46', '759684271038', 'APLICADORES KIUTS EXI/20 20 PZA', '4', '0', '0', 'SURTIDORA DEL ORIENTE SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'KIUTS', 'KIUTS', '0', '', '2010-11-20 18:48:54', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('47', '47', '', 'AROMATIZANTE AIR WICK CJA/ 400 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AIR WICK', 'AIR WICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('48', '48', '', 'ATUN EN ACEITE EL DORADO CJA/ 140 GRS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'EL DORADO', 'EL DORADO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('49', '49', '7501003129161', 'ATUN EN ACEITE HERDEZ CJA/48  170 GRS', '2', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 18:53:47', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('50', '50', '7501045400013', 'ATUN EN ACEITE MAZATUN CJA/48  170 GRS', '1', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MAZATUN', 'MAZATUN', '0', '', '2010-11-20 18:55:15', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('51', '51', '7501045400013', 'ATUN EN ACEITE MAZATUN PZA 170 GRS', '40', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', 'ok', '0.00', 'MAZATUN', 'MAZATUN', '0', '', '2010-11-20 14:19:55', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('52', '52', '', 'ATUN EN AGUA HERDEZ CJA/ 170 GRS', '0', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('53', '53', '7501045400020', 'ATUN EN AGUA MAZATUN CJA/48  170 GRS', '3', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MAZATUN', 'MAZATUN', '0', '', '2010-11-20 19:00:20', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('54', '54', '7501041415592', 'ATUN ENSALADA TUNY CJA/48  135 GRS', '2', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TUNY', 'TUNY', '0', '', '2010-11-20 19:01:43', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('55', '55', '', 'ATUN LIGTH TUNY CJA/ 135 GRS', '0', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TUNY', 'TUNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('56', '56', '038527132577', 'AVENA NATURAL QUAKER CJA/12 1.190 KGS', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'QUAKER', 'QUAKER', '0', '', '2010-11-20 19:04:00', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('57', '57', '036731135513', 'AVENA NATURAL QUAKER CJA/12 510 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'QUAKER', 'QUAKER', '0', '', '2010-11-20 19:04:58', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('58', '58', '', 'AVENA NATURAL RIVERO CJA/24 400 GRS', '0', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'RIVERO', 'RIVERO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('59', '59', '7501088005329', 'AVENA POLVO CANELA RIVERO CJA/24    400 GRS', '1', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'RIVERO', 'RIVERO', '0', '', '2010-11-20 19:08:48', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('60', '60', '7501088005220', 'AVENA POLVO CHOCOLATE RIVERO CJA/24    400 GRS', '1', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'RIVERO', 'RIVERO', '0', '', '2010-11-20 19:09:02', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('61', '61', '7501088005428', 'AVENA POLVO PLATANO RIVERO CJA/24    400 GRS', '1', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'RIVERO', 'RIVERO', '0', '', '2010-11-20 19:09:17', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('62', '62', '7501761846515', 'AVENA POLVO TRIGO 3 MINUTOS QUAKER CJA/40 250 GRS', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'QUAKER', 'QUAKER', '0', '', '2010-11-20 19:11:17', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('63', '63', '', 'AZAFRAN VICTORIA CJA/ 100 SOBRES', '0', '0', '0', 'MEXICANA  ', '', 'Pieza', '16', '0', '', '0.00', 'VICTORIA', 'VICTORIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('64', '64', '', 'AZUCAR GLASS GARY CJA/ 1 LTS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('65', '65', '011848288000', 'AZUCAR GLASS LA ANITA CJA/28 500 GRS', '1', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 19:12:54', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('66', '66', '', 'AZUL DE LAVADO ANCLA CJA/8 PQT 50 SOBRES', '1', '0', '0', 'MEXICANA  ', '', 'Pieza', '16', '0', '', '0.00', 'ANCLA', 'ANCLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('67', '67', '', 'BACTERICIDA BAKERSCHEF PZA 20 ML', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'BAKERSCHEF', 'BAKERSCHEF', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('68', '68', '', 'BANDERILLA POP CJA/ 50 PZAS', '0', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'POP', 'POP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('69', '69', '', 'BATERIAS RAYOBAC PQT/ 24 1.5', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'RAYOBAC', 'RAYOBAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('70', '70', '', 'BATERIAS  TRUPPER CJA/6 PARES 1.5 W', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'TRUPPER', 'TRUPPER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('71', '71', '', 'BATERIAS  TRUPPER PAR 1.5 W', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'TRUPPER', 'TRUPPER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('72', '72', '7501206671559', 'BATERIAS  TRUPPER CJA/6 9  V', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'TRUPPER', 'TRUPPER', '0', '', '2010-11-20 19:31:58', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('73', '73', '', 'BATERIAS  KODAK  ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KODAK', 'KODAK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('74', '74', '', 'BATERIAS  KODAK  ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KODAK', 'KODAK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('75', '75', '', 'BATERIAS AA KODAK PQT/12 ', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KODAK', 'KODAK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('76', '76', '', 'BATERIAS AA EVEREADY  CJA/24 ', '4', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'EVEREADY ', 'EVEREADY ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('77', '77', '', 'BATERIAS AA DURACELL CJA/6 PAQ 5 PZA', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DURACELL', 'DURACELL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('78', '78', '', 'BATERIAS AAA DURACELL CAJ/6  PAQ 5 PZA', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DURACELL', 'DURACELL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('79', '79', '7501013154146', 'BEBIDA DE FRUTA PAU PAU JUMEX CJA/24 250 ML', '7', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 19:36:53', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('80', '80', '7501005114516', 'BEBIDA DE SOYA ADES PQT/40 200 ML', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ADES', 'ADES', '0', '', '2010-11-20 19:37:38', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('81', '81', '7501005115742', 'BEBIDA DE SOYA ADES  PQT/24 330 ML', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ADES ', 'ADES ', '0', '', '2010-11-20 19:38:27', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('82', '82', '7501005102674', 'BEBIDA DE SOYA ADES PQT/4 946 ML', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ADES', 'ADES', '0', '', '2010-11-20 19:39:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('83', '83', '7501003186225', 'BEBIDA FESTIN CON PULPA ZANARANJA HERDEZ PQT/27 200 ML', '1', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 19:40:47', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('84', '84', '4310406', 'BEBIDAS  EMBOTELLADAS CHIVA COLA CJA/24 600 ML', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'CHIVA COLA', 'CHIVA COLA', '0', '', '2010-11-20 19:41:49', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('85', '85', '4310506', 'BEBIDAS  EMBOTELLADAS CHIVA COLA CJA/24 355 ML', '3', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'CHIVA COLA', 'CHIVA COLA', '0', '', '2010-11-20 19:42:30', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('86', '86', '', 'BEBIDAS CONCENTRADAS DELICIOSA PZA 700 ML', '0', '0', '0', 'PROALMEX  ', '', 'Pieza', '16', '0', '', '0.00', 'DELICIOSA', 'DELICIOSA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('87', '87', '7501088011214', 'BEBIDAS CONCENTRADAS HORCHATA DELICIOSA CJA/24 180 ML', '3', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'DELICIOSA', 'DELICIOSA', '0', '', '2010-11-20 19:47:10', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('88', '88', '7501088011337', 'BEBIDAS CONCENTRADAS HORCHATA DELICIOSA CJA/12 700 ML', '19', '0', '0', 'SAMS PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'DELICIOSA', 'DELICIOSA', '0', '', '2010-11-20 19:46:24', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('89', '89', '7501088031335', 'BEBIDAS CONCENTRADAS JAMAICA DELICIOSA CJA/12 700 ML', '2', '0', '0', ' PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'DELICIOSA', 'DELICIOSA', '0', '', '2010-11-20 19:46:39', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('90', '90', '7501088021336', 'BEBIDAS CONCENTRADAS TAMARINDO DELICIOSA CJA/12 700 ML', '6', '0', '0', 'SAMS PROALMEX ', '', 'Pieza', '16', '0', '', '0.00', 'DELICIOSA', 'DELICIOSA', '0', '', '2010-11-20 19:46:51', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('91', '91', '', 'BEBIDAS EN POLVO GUANABANA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('92', '92', '', 'BEBIDAS EN POLVO JAMAICA TANG CJA/12 EXI 8 SOBRES', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TANG', 'TANG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('93', '93', '7802800705429', 'BEBIDAS EN POLVO JAMAICA ZUCO CJA/12 EXI 8 PZA/25 GRS', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 19:51:26', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('94', '94', '', 'BEBIDAS EN POLVO MANDARINA TANG CJA/12 EXI 8 SOBRES', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TANG', 'TANG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('95', '95', '', 'BEBIDAS EN POLVO MANDARINA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('96', '96', '', 'BEBIDAS EN POLVO MANGO ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('97', '97', '7802800705771', 'BEBIDAS EN POLVO MELON ZUCO CJA/12 EXI 8 PZA/25 GRS', '1', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 19:55:58', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('98', '98', '', 'BEBIDAS EN POLVO NARANJA TANG CJA/12 EXI ', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TANG', 'TANG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('99', '99', '', 'BEBIDAS EN POLVO NARANJA TANG CJA/12 EXI 680 GR', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'TANG', 'TANG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('100', '100', '7802800705313', 'BEBIDAS EN POLVO NARANJA ZUCO CJA/12 EXI 8 PZA/25 GRS', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 19:57:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('101', '101', '', 'BEBIDAS EN POLVO PAPAYA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('102', '102', '', 'BEBIDAS EN POLVO PERA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('103', '103', '', 'BEBIDAS EN POLVO PIÑA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('104', '104', '', 'BEBIDAS EN POLVO PIÑA COLADA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('105', '105', '7802800708895', 'BEBIDAS EN POLVO SANDIA ZUCO CJA/12 EXI 8 PZA/25 GRS', '1', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 19:58:49', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('106', '106', '7802800705412', 'BEBIDAS EN POLVO TAMARINDO ZUCO CJA/12 EXI 8 PZA/25 GRS', '1', '0', '0', 'AKI GRAN MAYOREO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 19:59:58', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('107', '107', '', 'BEBIDAS EN POLVO TE MC CORMICK CJA/ 25 SOBRES C/U', '0', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('108', '108', '7501059232457', 'BEBIDAS EN POLVO TE DE LIMON NESTEA LATA 2.600 KGS', '4', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESTEA', 'NESTEA', '0', '', '2010-11-20 20:01:38', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('109', '109', '7501001603045', 'BEBIDAS EN POLVO TE VERDE NESTEA CJA/12 EXI 10 SOB/85G', '17', '0', '0', 'SAMS ABRAHAM SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTEA', 'NESTEA', '0', '', '2010-11-20 20:01:52', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('110', '110', '7501059232365', 'BEBIDAS EN POLVO TE VERDE CON MIEL NESTEA CJA/12 EXI 10 SOB/85G', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTEA', 'NESTEA', '0', '', '2010-11-20 20:02:57', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('111', '111', '', 'BEBIDAS EN POLVO TORONJA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO  ', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('112', '112', '', 'BEBIDAS EN POLVO UVA ZUCO CJA/12 EXI 8 PZA/25 GRS', '0', '0', '0', 'AKI GRAN MAYOREO  ', '', 'Pieza', '16', '0', '', '0.00', 'ZUCO', 'ZUCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('113', '113', '', 'BEBIDAS ENERGETICAS DULCIFICANTE ECOPLANT/HIERBAS KOLINA CJA/ ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'KOLINA', 'KOLINA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('114', '114', '', 'BEBIDAS ENERGETICAS DULCIFICANTE ECOPLANT/HIERBAS OMNILIFE CJA/ ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('115', '115', '', 'BEBIDAS ENERGETICAS MANGO /MANZANA OMNILIFE CJA/ ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('116', '116', '4812300', 'BEBIDAS ENERGETICAS/ EGO FRUTA ALIMENTACION OMNILIFE CJA/24 355 ML', '1', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 20:04:07', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('117', '117', '7501035915138', 'BIBERON/ 4 ONZAS CURITY CJA/24 ', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CURITY', 'CURITY', '0', '', '2010-11-20 20:05:47', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('118', '118', '7501035915121', 'BIBERON/ 8 ONZAS CURITY PQS  6 ', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CURITY', 'CURITY', '0', '', '2010-11-20 20:06:50', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('119', '119', '7501035907478', 'BIBERON/9 ONZAS GERBER CJA/36 ', '1', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-20 20:08:25', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('120', '120', '', 'BICARBONATO LA EXTRA PQT/5 EXI 30 SOBRES', '1', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('121', '121', '', 'BICARBONATO LA EXTRA EXI 30 SOBRES', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('122', '122', '', 'BICARBONATO MERCURIO CJA/ 100 GRS', '0', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'MERCURIO', 'MERCURIO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('123', '123', '', 'BOLIGRAFOS/ AZULES BIC CJA/ 12 PIEZAS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'BIC', 'BIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('124', '124', '', 'BOLIGRAFOS/ NEGROS BIC CJA/ 12 PIEZAS', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'BIC', 'BIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('125', '125', '', 'BOLIGRAFOS/ ROJOS BIC CJA/ 12 PIEZAS', '8', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'BIC', 'BIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('126', '126', '', 'BOLSA CAMISETA (CAJA) NUM 1 PARA EMPAQUE BULTO/25 K #1', '0', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA EMPAQUE', 'PARA EMPAQUE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('127', '127', '', 'BOLSA CAMISETA (CAJA) NUM 2 PARA EMPAQUE BULTO/25 K #2', '3', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA EMPAQUE', 'PARA EMPAQUE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('128', '128', '', 'BOLSA CAMISETA (CAJA) NUM 3 PARA EMPAQUE BULTO/25 K #3', '1', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA EMPAQUE', 'PARA EMPAQUE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('129', '129', '', 'BOLSA CAMISETA NUM. 0 PARA EMPAQUE BULTO/25 K #0', '0', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA EMPAQUE', 'PARA EMPAQUE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('130', '130', '', 'BOLSA CAMISETA NUM. 2 PARA VENTA BULTO/25 K #2', '1', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA VENTA', 'PARA VENTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('131', '131', '', 'BOLSA CAMISETA NUM. 3 PARA VENTA BULTO/25 K #3', '4', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA VENTA', 'PARA VENTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('132', '132', '', 'BOLSA CAMISETA NUM.1 PARA VENTA BULTO/25 K #1', '2', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', 'PARA VENTA', 'PARA VENTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('133', '133', '', 'BOLSA COLOR 15 X 25  BULTO/25 K 1/2 KGS', '0', '0', '0', ' BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('134', '134', '', 'BOLSA COLOR 20 X 30  BULTO/25 K 1 KGS', '0', '0', '0', ' BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('135', '135', '', 'BOLSA COLOR 30 X 40  BULTO/25 K 3 KGS', '3', '0', '0', ' BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('136', '136', '', 'BOLSA DE ROLLO 15 X 25  PQT 16 PZA', '7', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('137', '137', '', 'BOLSA DE ROLLO 20 X 30   PQT 16 PZA', '12', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('138', '138', '', 'BOLSA DE ROLLO 25 X 35  PQT 16 PZA', '5', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('139', '139', '', 'BOLSA DE ROLLO 30 X 40  PQT 8 PZA  ', '6', '0', '0', 'DON FERNANDO  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('140', '140', '', 'BOLSA NATURAL 10 X 20  BULTO  1/8', '2', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('141', '141', '', 'BOLSA NATURAL 12 X 22  BULTO/25 K 1/4', '0', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('142', '142', '', 'BOLSA NATURAL 15 X25  BULTO/25 K 1/2 KGS', '0', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('143', '143', '', 'BOLSA NATURAL 20 X 30  BULTO/25 K 1 KGS', '3', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('144', '144', '', 'BOLSA NATURAL 25 X 35  BULTO/25 K 2 KGS', '2', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('145', '145', '', 'BOLSA NATURAL 30 X 40  BULTO/25 K 3 KGS', '0', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('146', '146', '', 'BOLSA NATURAL 35 X 50  BULTO/25 K 5 KGS', '1', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('147', '147', '', 'BOLSA NATURAL 40 X 60  BULTO/25 K 10 KGS', '1', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('148', '148', '', 'BOLSA NATURAL 8 X 22  BULTO/25 K PALETITA', '1', '0', '0', 'DON FERNANDO BOLSAS PLASTICAS ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('149', '149', '', 'BOLSA P/BASURA 60 X 90  BULTO/25 K 60 X 90', '2', '0', '0', 'DON FERNANDO BEDA ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('150', '150', '', 'BOLSA P/BASURA 90 X 120  BULTO/25 K 90 X 120', '2', '0', '0', 'DON FERNANDO BEDA ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('151', '151', '', 'BOTELLAS 1 LTS  COLCHON/ ', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('152', '152', '', 'BOTELLAS 500 ML  COLCHON/ ', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('153', '153', '', 'BRAZO DE HAMACA PRIMERA SUPER HPS PZA ', '9', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'HPS', 'HPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('154', '154', '', 'BRILLANTE MR.MUSCULO WINDEX CJA/ 650 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'WINDEX', 'WINDEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('155', '155', '75001865', 'BRILLANTINA LIQUIDA PALMOLIVE CJA/12 115 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 20:13:04', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('156', '156', '75001872', 'BRILLATINA PALMOLIVE CJA/12 52 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 20:13:55', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('157', '157', '724609312196', 'CACAHUATE  JAPONES MICHEL PQT/20 PZA PQT C/20 PIEZAS', '24', '0', '0', 'MICHEL  ', '', 'Pieza', '16', '0', '', '0.00', 'MICHEL', 'MICHEL', '0', '', '2010-11-20 20:14:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('158', '158', '7501059224827', 'CAFÉ CLASICO NESCAFE CJA/12 200 GRS', '7', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:16:02', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('159', '159', '7501059224834', 'CAFÉ CLASICO NESCAFE CJA/12 100 GRS', '6', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:16:54', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('160', '160', '7501059224841', 'CAFÉ CLASICO NESCAFE CJA/12 50 GRS', '23', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:17:43', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('161', '161', '', 'CAFÉ CLASICO NESCAFE CJA/ 300 GRS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('162', '162', '', 'CAFÉ CON LECHE NESCAFE CJA/12/10 22 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('163', '163', '7501059233096', 'CAFÉ DECAF NESCAFE CJA/12 200 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:19:00', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('164', '164', '7501059233119', 'CAFÉ DECAF NESCAFE CJA/12 100 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:19:13', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('165', '165', '7501059233089', 'CAFÉ DECAF NESCAFE CJA/12 50 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:19:23', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('166', '166', '7501059292406', 'CAFÉ DOLCA NESCAFE CJA/6 EXI 20 PZA', '25', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:21:09', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('167', '167', '7501001602710', 'CAFÉ DOLCA NESCAFE CJA/12 50 GRS', '95', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:22:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('168', '168', '', 'CAFÉ DOLCA NESCAFE EXI 20 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('169', '169', '7501059234017', 'CAFÉ DOLCA NESCAFE CJA/15 180 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:27:27', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('170', '170', '7501001602727', 'CAFÉ DOLCA NESCAFE CJA/24    100 GRS', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:23:48', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('171', '171', '7501059221895', 'CAFÉ DOLCA / CANELA NESCAFE CJA/12 50 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:24:02', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('172', '172', '7501059234956', 'CAFÉ DOLCA / DESCAFEINDADO NESCAFE CJA/12 100 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESCAFE', 'NESCAFE', '0', '', '2010-11-20 20:24:13', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('173', '173', '', 'CALDO DE  POLLO Y TOMATE KNORR SUIZA CJA/12 12 CUBITOS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA', 'KNORR SUIZA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('174', '174', '', 'CALDO DE POLLO KNORR SUIZA CJA/12 24 CUBITOS', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA', 'KNORR SUIZA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('175', '175', '', 'CALDO DE POLLO  KNORR SUIZA FCO 1.600 KGS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA', 'KNORR SUIZA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('176', '176', '', 'CANELA EN POLVO LA EXTRA CJA/ EXI/30 SOBRES', '0', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('177', '177', '', 'CANELA EN RAJAS LA EXTRA CJA/ TIRA/ 30 SOBRES', '0', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('178', '178', '3014260275143', 'CARTUCHOS  PARA AFEITAR MACH 3 GUILLETE CJA/12 ', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'GUILLETE', 'GUILLETE', '0', '', '2010-11-21 10:33:45', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('179', '179', '3014260275143', 'CARTUCHOS  PARA AFEITAR MACH 3 GUILLETE PZA ', '8', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'GUILLETE', 'GUILLETE', '0', '', '2010-11-21 10:34:05', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('180', '180', '7702010630293', 'CEPILLO NIÑO COLGATE CJA/48 INFANTIL', '9', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-21 10:35:16', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('181', '181', '', 'CEPILLO PARA LAVAR CHICA LIBER CJA/30 CHICO', '3', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'LIBER', 'LIBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('182', '182', '', 'CEPILLO PARA LAVAR MANUALITO NUM.3 LIBER CJA/48 GRANDE', '2', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'LIBER', 'LIBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('183', '183', '', 'CEPILLO PREMIER ULTRA/ ADULTO COLGATE CJA/24 EXI 6 PZA', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('184', '184', '', 'CEPILLO PREMIER ULTRA/ ADULTO COLGATE CJA/ 48 PZA', '1', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('185', '185', '7501032940300', 'CERA LIQUIDA CAFÉ COLORFIEL CJA/12 62 ML', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'COLORFIEL', 'COLORFIEL', '0', '', '2010-11-21 11:00:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('186', '186', '7501032940102', 'CERA LIQUIDA NEGRO COLORFIEL CJA/12 61 ML', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'COLORFIEL', 'COLORFIEL', '0', '', '2010-11-21 11:02:01', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('187', '187', '7501000942008', 'CEREAL GERBER CJA/12 300 GRS', '2', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'GERBER', 'GERBER', '0', '', '2010-11-21 11:03:49', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('188', '188', '7613032259488', 'CEREAL 5 CEREALES NESTLE CJA/24 LAT 300 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-21 11:04:42', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('189', '189', '', 'CEREAL 5 CEREALES NESTLE CJA/24 BOL 270 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('190', '190', '7613032258191', 'CEREAL ARROZ NESTLE CJA/24 LAT 300 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-21 11:05:33', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('191', '191', '', 'CEREAL ARROZ NESTLE CJA/24 BOL 270 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('192', '192', '', 'CEREAL CHOCO KING A GRANEL MICHEL CJA/ AGRANEL', '0', '0', '0', 'MICHEL  ', '', 'Pieza', '16', '0', '', '0.00', 'MICHEL', 'MICHEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('193', '193', '7501008038000', 'CEREAL CHOCO KRISPI KELLOGS CJA/50  40 GRS', '2', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:08:03', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('194', '194', '7501008045909', 'CEREAL CHOCO KRISPI KELLOGS CJA/20 180 GRS', '1', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:09:02', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('195', '195', '7501008038024', 'CEREAL CHOCO KRISPI KELLOGS CJA/24 320 GRS', '1', '0', '0', 'KELLOGS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:10:12', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('196', '196', '7501008001028', 'CEREAL CORN FLAKES KELLOGS CJA/24 200 GRS', '2', '0', '0', 'KELLOGS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:11:23', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('197', '197', '7501059204270', 'CEREAL CORN FLAKES LA LECHERA CJA/16 440 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA LECHERA', 'LA LECHERA', '0', '', '2010-11-21 11:16:38', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('198', '198', '7501001625047', 'CEREAL CORN FLAKES NESTLE CJA/20 200 GRS', '2', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-21 11:18:02', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('199', '199', '', 'CEREAL FOOT LOOPS KELLOGS CJA/ 230 GRS', '0', '0', '0', 'KELLOGS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('200', '200', '', 'CEREAL FOOT LOOPS KELLOGS CJA/ 40 GRS', '0', '0', '0', 'KELLOGS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('201', '201', '', 'CEREAL FREEZER FLAKES MICHEL CJA/30 500 GRS', '0', '0', '0', 'MICHEL  ', '', 'Pieza', '16', '0', '', '0.00', 'MICHEL', 'MICHEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('202', '202', '7501001625337', 'CEREAL MAIZ NESQUICK CJA/20 230 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESQUICK', 'NESQUICK', '0', '', '2010-11-21 11:20:14', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('203', '203', '7613032269876', 'CEREAL NESTRUN TRIGO C/MIEL NESTLE CJA/24 300 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-21 11:21:32', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('204', '204', '', 'CEREAL SPECIAL K KELLOGS CJA/ 260 GRS', '0', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('205', '205', '7501008045879', 'CEREAL ZUCARITAS KELLOGS CJA/20 195 GRS', '1', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:24:05', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('206', '206', '7501008015025', 'CEREAL ZUCARITAS KELLOGS CJA/24 300 GRS', '2', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:24:14', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('207', '207', '7501008015001', 'CEREAL ZUCARITAS KELLOGS CJA/50 40 GRS', '2', '0', '0', 'KELLOGS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-21 11:24:23', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('208', '208', '75025144', 'CERILLOS VIAJEROS CJA/20 50 PZAS', '4', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'VIAJEROS', 'VIAJEROS', '0', '', '2010-11-21 11:29:49', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('209', '209', '', 'CERILLOS MANOLA CJA/10 50 PZAS', '1', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'MANOLA', 'MANOLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('210', '210', '', 'CERILLOS CLASICOS CJA/20/ 5 10 PZAS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLASICOS', 'CLASICOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('211', '211', '', 'CHAMOY MIGUELITO MIGUELITO PZA 950 ML', '0', '0', '0', 'MEXICANA YAEL ', '', 'Pieza', '16', '0', '', '0.00', 'MIGUELITO', 'MIGUELITO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('212', '212', '', 'CHAMPIÑION HERDEZ CJA/24 186 GRS', '0', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('213', '213', '', 'CHAROLA REDONDA NUM.12 PRIMO PAQ 10 PZA', '14', '0', '0', 'YUCALPETEN  ', '', 'Pieza', '16', '0', '', '0.00', 'PRIMO', 'PRIMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('214', '214', '', 'CHAROLA REDONDA NUM.14 PRIMO PAQ 10 PZA', '33', '0', '0', 'YUCALPETEN  ', '', 'Pieza', '16', '0', '', '0.00', 'PRIMO', 'PRIMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('215', '215', '', 'CHAROLA REDONDA NUM.20 PRIMO PAQ 10 PZA', '11', '0', '0', 'YUCALPETEN  ', '', 'Pieza', '16', '0', '', '0.00', 'PRIMO', 'PRIMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('216', '216', '', 'CHAROLA RENTANGULAR NUM.14 PRIMO PAQ 10 PZA', '0', '0', '0', 'YUCALPETEN  ', '', 'Pieza', '16', '0', '', '0.00', 'PRIMO', 'PRIMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('217', '217', '', 'CHAROLA TERMICA 066 BUEN HOG COLCH 10 PQT', '7', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOG', 'BUEN HOG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('218', '218', '', 'CHAROLA TERMICA 835  PQT 500 PZA', '1', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('219', '219', '', 'CHAROLA TERMICA 855 PIC NIC COLCH/10 50 PZAS', '5', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'PIC NIC', 'PIC NIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('220', '220', '', 'CHAROLAS RECTANGULAR NUM. 12 PRIMO PAQ 10 PZA', '28', '0', '0', 'YUCALPETEN  ', '', 'Pieza', '16', '0', '', '0.00', 'PRIMO', 'PRIMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('221', '221', '7501003124135', 'CHICHAROS HERDEZ CJA/48 215 GRS', '3', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-21 11:34:31', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('222', '222', '7501079720033', 'CHICHAROS DEL FUERTE CJA/48 225 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-21 11:36:03', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('223', '223', '7501079720026', 'CHICHAROS DEL FUERTE CJA/48 160 GRS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-21 11:36:13', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('224', '224', '7501079720071', 'CHICHAROS DEL FUERTE CJA/6  2.8 KGS', '4', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-21 11:37:33', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('225', '225', '7501079731527', 'CHICHAROS DEL FUERTE CJA/48 190 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-21 11:37:47', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('226', '226', '7501079731015', 'CHICHAROS DEL FUERTE CJA/12 380 GRS', '10', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-21 11:37:56', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('227', '227', '7501003124142', 'CHICHAROS HERDEZ CJA/24 400 GRS', '4', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-21 11:38:57', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('228', '228', '7501003124166', 'CHICHAROS C/ZANAHORIA HERDEZ CJA/48 225 GRS', '1', '0', '0', 'HERDEZ  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-21 11:40:25', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('229', '229', '7501017006021', 'CHILE CHIPOTLES LA COSTEÑA CJA/40 105 GRS', '3', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:42:17', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('230', '230', '7501017006021', 'CHILE CHIPOTLES LA COSTEÑA PQT/10 105 GRS', '10', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:42:28', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('231', '231', '7501017005031', 'CHILE CHIPOTLES LA COSTEÑA CJA/24 220 GRS', '2', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:42:43', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('232', '232', '7501017005031', 'CHILE CHIPOTLES LA COSTEÑA 220 GRS', '6', '5', '5.9', 'SAMS  ', '', 'Pieza', '16', '0', 'ok', '18.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 14:11:59', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('233', '233', '7501017006014', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA CJA/40 105 GRS', '8', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:51:55', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('234', '234', '7501017006014', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA PQT/10 105 GRS', '5', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:52:09', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('235', '235', '7501017005024', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA CJA/48 220 GRS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:53:07', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('236', '236', '7501017050734', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA CJA/24 220 GRS', '3', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:53:48', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('237', '237', '', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA PQT/6 220 GRS', '0', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('238', '238', '7501017004027', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA CJA/24 380 GRS', '4', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:54:17', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('239', '239', '7501017003020', 'CHILE JALAPEÑO C/RAJAS LA COSTEÑA CJA/12 800 GRS', '6', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:54:39', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('240', '240', '7501023310013', 'CHILE JALAPEÑO C/ENTEROS SAN MARCOS CJA/6 2.8 KGS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'SAN MARCOS', 'SAN MARCOS', '0', '', '2010-11-21 11:56:23', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('241', '241', '7501017050741', 'CHILE JALAPEÑO ENTEROS LA COSTEÑA CJA/24 220 GRS', '3', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:56:46', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('242', '242', '7501017005000', 'CHILE JALAPEÑO ENTEROS LA COSTEÑA CJA/48 220 GRS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:56:56', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('243', '243', '7501017002009', 'CHILE JALAPEÑO ENTEROS LA COSTEÑA CJA/6 2.8 KGS', '0', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:57:12', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('244', '244', '7501017002009', 'CHILE JALAPEÑO ENTEROS LA COSTEÑA PZA 2.8 KGS', '19', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:57:30', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('245', '245', '7501017004003', 'CHILE JALAPEÑO ENTEROS LA COSTEÑA CJA/24 380 GRS', '3', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-21 11:57:53', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('246', '246', '', 'CHILE MOLIDO LA EXTRA PAQ/10 EXI TIRA/ 30 SOBRES', '2', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('247', '247', '', 'CHILE MOLIDO LA EXTRA EXI TIRA/ 30 SOBRES', '9', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('248', '248', '40084107', 'CHOCOLATE CON LECHE KINDER SORPRESA FERRERO CJA/12 20 GRS', '16', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'FERRERO', 'FERRERO', '0', '', '2010-11-21 12:03:43', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('249', '249', '757528000523', 'CHOCOLATE EN POLVO CHOCO KIWI CJA/24 400 GRS', '42', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO KIWI', 'CHOCO KIWI', '0', '', '2010-11-21 12:05:05', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('250', '250', '', 'CHOCOLATE EN POLVO CHOCO MILK CJA/ 200 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO MILK', 'CHOCO MILK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('251', '251', '7501095467042', 'CHOCOLATE EN POLVO CHOCO MILK CJA/24 400 GRS', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO MILK', 'CHOCO MILK', '0', '', '2010-11-21 12:08:23', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('252', '252', '7501014300429', 'CHOCOLATE EN POLVO CHOCO CHOCO EXI 20 SOBRES', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO CHOCO', 'CHOCO CHOCO', '0', '', '2010-11-21 12:09:08', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('253', '253', '7501014300177', 'CHOCOLATE EN POLVO CHOCO CHOCO CJA/24  200 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO CHOCO', 'CHOCO CHOCO', '0', '', '2010-11-21 12:09:26', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('254', '254', '7501014300559', 'CHOCOLATE EN POLVO CHOCO CHOCO CJA/24 375 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO CHOCO', 'CHOCO CHOCO', '0', '', '2010-11-21 12:09:35', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('255', '255', '', 'CHOCOLATE EN POLVO IMPERIAL CJA/50 250 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'IMPERIAL', 'IMPERIAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('256', '256', '7503013040184', 'CHOCOLATE EN POLVO CAL-C-TOSE CJA/30 200 GRS', '9', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAL-C-TOSE', 'CAL-C-TOSE', '0', '', '2010-11-21 12:11:55', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('257', '257', '7503013040191', 'CHOCOLATE EN POLVO CAL-C-TOSE CJA/24    400 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAL-C-TOSE', 'CAL-C-TOSE', '0', '', '2010-11-21 12:12:08', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('258', '258', '7501059239623', 'CHOCOLATE EN POLVO NESQUICK CJA/10 180 GRS', '9', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESQUICK', 'NESQUICK', '0', '', '2010-11-21 12:12:19', '0', 'sergio');
INSERT INTO `catProductos` VALUES ('259', '259', '', 'CHOCOLATE EN POLVO NESQUICK CJA/ 2 KGS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESQUICK', 'NESQUICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('260', '260', '', 'CHOCOLATE EN POLVO CHOCO MILK EXI 20 SOBRES', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CHOCO MILK', 'CHOCO MILK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('261', '261', '', 'CHOCOLATE EN TABLILLA  ABUELITA CJA/ 36  GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ABUELITA', 'ABUELITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('262', '262', '', 'CHUPON JALOMA EXI 24 PZA', '3', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('263', '263', '', 'CHUPON ROSMAR EXI/ ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ROSMAR', 'ROSMAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('264', '264', '', 'CIGARROS ALAS-EXT PQT/12 18 CIGARROS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ALAS-EXT', 'ALAS-EXT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('265', '265', '', 'CIGARROS BENSON\'S PQT/10 20 CIGARROS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BENSON\'S', 'BENSON\'S', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('266', '266', '', 'CIGARROS DELICADOS C/FILTRO PQT/10 20 CIGARROS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DELICADOS C/FILTRO', 'DELICADOS C/FILTRO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('267', '267', '', 'CIGARROS DELICADOS/SIN FILTRO PQT/10 18 CIGARROS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DELICADOS/SIN FILTRO', 'DELICADOS/SIN FILTRO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('268', '268', '', 'CIGARROS GRATOS PQT/10 20 CIGARROS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'GRATOS', 'GRATOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('269', '269', '', 'CIGARROS RALEIGH PQT/10 20 CIGARROS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'RALEIGH', 'RALEIGH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('270', '270', '', 'CIGARROS/ BLANCOS MARLBORO PQT/10 20 CIGARROS', '4', '0', '0', 'MARLBORO  ', '', 'Pieza', '16', '0', '', '0.00', 'MARLBORO', 'MARLBORO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('271', '271', '', 'CIGARROS/ BLANCOS MONTANA PQT/10 20 CIGARROS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MONTANA', 'MONTANA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('272', '272', '', 'CIGARROS/ ROJOS MARLBORO  PQT/10 20 CIGARROS', '3', '0', '0', 'MARLBORO  ', '', 'Pieza', '16', '0', '', '0.00', 'MARLBORO ', 'MARLBORO ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('273', '273', '', 'CIGARROS/ ROJOS MONTANA PQT/10 20 CIGARROS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MONTANA', 'MONTANA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('274', '274', '', 'CLORO CLORALEX CJA/20 500 ML', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('275', '275', '', 'CLORO CLORALEX PQT/15 500 ML', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('276', '276', '', 'CLORO CLORALEX CJA/30 250  ML', '7', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('277', '277', '', 'CLORO CLORALEX CJA/20 250  ML', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('278', '278', '', 'CLORO CLORALEX CJA/15 950 ML', '5', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('279', '279', '', 'CLORO CLORALEX PQT/8 950 ML', '10', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALEX', 'CLORALEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('280', '280', '', 'CLORO CLORALUZ CJA/12 900ML', '10', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALUZ', 'CLORALUZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('281', '281', '', 'CLORO CLORALUZ CJA/20 500 ML', '9', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLORALUZ', 'CLORALUZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('282', '282', '', 'CLORO  CLOROX CJA/20 500 ML', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLOROX', 'CLOROX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('283', '283', '', 'CLORO  CLOROX CJA/15 930 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLOROX', 'CLOROX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('284', '284', '', 'CLORO  PUROSOL CJA/12 1000 ML', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'PUROSOL', 'PUROSOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('285', '285', '', 'COCTEL DE FRUTAS HERDEZ CJA/12 850 GRS', '3', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('286', '286', '', 'CONDIMENTO  BISTEK LA EXTRA CJA/32 /20 25 GRS', '1', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('287', '287', '', 'CONDIMENTO ESPAÑOL VICTORIA PQT 100 PZA', '1', '0', '0', 'MEXICANA COMA ', '', 'Pieza', '16', '0', '', '0.00', 'VICTORIA', 'VICTORIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('288', '288', '', 'CONO PAPEL DICK CJA/ 20 PQT', '2', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'DICK', 'DICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('289', '289', '', 'CONO PLASTICO DICK CJA/ ', '0', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'DICK', 'DICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('290', '290', '', 'CONTENEDOR  HAMBURGUESERA INIX CJA/250 ', '2', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'INIX', 'INIX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('291', '291', '', 'CONTENEDOR /PLATO 10-D URPRI COLCH/25  25 PZA', '1', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('292', '292', '', 'CONTENEDOR /PLATO 10-L URPRI COLCH/25  20 PZA', '0', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('293', '293', '', 'CONTENEDOR /PLATO 10-L JAGUAR COLCH/25  20 PZA', '2', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('294', '294', '', 'CONTENEDOR /PLATO PH6 URPRI COLCH/25  20 PZA.', '3', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('295', '295', '', 'CONTENEDOR /PLATO T6 URPRI COLCH/25 20 PZA', '4', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('296', '296', '', 'CONTENEDOR /PLATO/PH8 URPRI COLCH/25  20 PZA', '1', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('297', '297', '', 'CONTENEDOR TERMICO   9 X 9 C/D JAGUAR CAJ/2 125 PZAS', '4', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('298', '298', '', 'CONTENEDOR TERMICO   9X9 S/D JAGUAR PQT 125 PZAS', '4', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('299', '299', '', 'CONTENEDOR TERMICO HAMBURGUESERA  PQT/125 ', '1', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('300', '300', '', 'CREMA DENTAL  TRIPLE ACCION COLGATE CJA/ 150 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('301', '301', '', 'CREMA DENTAL MAX PROTECCION COLGATE PQT/12 33 GRS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('302', '302', '', 'CREMA DENTAL MAX PROTECCION COLGATE CJA/ 50 GRS', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('303', '303', '', 'CREMA DENTAL PROTECCION FAM CREST CJA/12 / 6 110 GRS', '7', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CREST', 'CREST', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('304', '304', '', 'CREMA DENTAL TOTAL COLGATE CJA/72  150 GRS', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('305', '305', '', 'CREMA DENTAL TOTAL COLGATE PQT/4  150 GRS', '10', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('306', '306', '', 'CREMA DENTAL TRIPLE ACCION COLGATE CJA/72  75 GRS', '30', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('307', '307', '', 'CREMA DENTAL TRIPLE ACCION COLGATE PQT/12 100 GRS', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('308', '308', '', 'CREMA P/CUERPO CLASICA HINDS CJA/30 90 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HINDS', 'HINDS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('309', '309', '', 'CREMA P/CUERPO NATURAL FRESCA HINDS CJA/30 90 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HINDS', 'HINDS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('310', '310', '', 'CREMA P/CUERPO NATURAL FRESCA HINDS CJA/15 230 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HINDS', 'HINDS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('311', '311', '', 'CREMA P/CUERPO ROSA HINDS CJA/15 230 ML', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'HINDS', 'HINDS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('312', '312', '', 'CREMA PARA PEINAR CAPAS DESTACADAS SEDAL CJA/12 300 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('313', '313', '', 'CREMA PARA PEINAR LISO PERFECTO SEDAL CJA/12 300 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('314', '314', '', 'CREMA PARA PEINAR ONDAS DEFINIDAS SEDAL CJA/12 300 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('315', '315', '', 'CREMA PARA PEINAR RIZOS OBEDIENTES SEDAL CJA/12 300 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('316', '316', '', 'CREMA PARA PEINAR SOS CERAMINAS SEDAL CJA/12 300 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('317', '317', '', 'CREMA PARA PEINAR SPONGE SEDAL CJA/12 300 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('318', '318', '', 'CUCHARA HELADERA BUEN HOG CJA/6 500 PZAS', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOG', 'BUEN HOG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('319', '319', '', 'CUCHARA NEVERA BUEN HOG CJA/6 500 PZAS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOG', 'BUEN HOG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('320', '320', '', 'CUCHARA PASTELERA BUEN HOG CJA/120 25 PZA', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOG', 'BUEN HOG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('321', '321', '', 'CUCHARA PASTELERA JAGUAR CJA/ ', '0', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('322', '322', '', 'CUCHARA SOPERA BUEN HOG CJA/40  BOL 25 PZA/ MEDIANA', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOG', 'BUEN HOG', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('323', '323', '', 'DESODORANTE  AXE CLICK AXE PZA 54 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'AXE', 'AXE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('324', '324', '', 'DESODORANTE  AXE FUSION AXE PZA 54 GRS', '54', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'AXE', 'AXE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('325', '325', '', 'DESODORANTE  AXE INSTINCT AXE PZA 54 GRS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'AXE', 'AXE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('326', '326', '', 'DESODORANTE  AXE TWIST AXE PZA 50 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'AXE', 'AXE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('327', '327', '', 'DESODORANTE  COOL FUSION SPEED STICK PZA 76 GRS', '16', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SPEED STICK', 'SPEED STICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('328', '328', '', 'DESODORANTE  WATERPROOF SPEED STICK PZA 165 ML', '19', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SPEED STICK', 'SPEED STICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('329', '329', '', 'DESODORANTE ACTIVE OBAO PZA 65 GRS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'OBAO', 'OBAO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('330', '330', '', 'DESODORANTE AUDAZ OBAO PZA 65 GRS', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'OBAO', 'OBAO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('331', '331', '', 'DESODORANTE BLAC HICKOK PZA 60 GRS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'HICKOK', 'HICKOK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('332', '332', '', 'DESODORANTE CLASSIC OBAO PZA 65 GRS', '9', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'OBAO', 'OBAO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('333', '333', '', 'DESODORANTE CLASSIC HICKOK PZA 60 GRS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'HICKOK', 'HICKOK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('334', '334', '', 'DESODORANTE COOL METAL OBAO PZA 65 GRS', '11', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'OBAO', 'OBAO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('335', '335', '', 'DESODORANTE DARK HICKOK PZA 60 GRS', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'HICKOK', 'HICKOK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('336', '336', '', 'DESODORANTE FRESCURA SUAVE OBAO PZA 65 GRS', '12', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'OBAO', 'OBAO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('337', '337', '', 'DESODORANTE SPORT HICKOK PZA 60 GRS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'HICKOK', 'HICKOK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('338', '338', '', 'DESODORANTE WILD FREESIA LAYDY SPEED STICK PZA 65 GRS', '12', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LAYDY SPEED STICK', 'LAYDY SPEED STICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('339', '339', '', 'DESTUPIDOR WC GRANDE NEGRO GONZALEZ PZA ', '0', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'GONZALEZ', 'GONZALEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('340', '340', '', 'DETERGENTE ACE CJA/48 250 GRS', '11', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('341', '341', '', 'DETERGENTE ARIEL CJA/18 1 KGS', '7', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ARIEL', 'ARIEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('342', '342', '', 'DETERGENTE ARIEL CJA/9 1 KGS', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ARIEL', 'ARIEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('343', '343', '', 'DETERGENTE ARIEL CJA/30 500 GRS', '4', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ARIEL', 'ARIEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('344', '344', '', 'DETERGENTE ARIEL CJA/48 250 GRS', '14', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ARIEL', 'ARIEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('345', '345', '', 'DETERGENTE AXION CJA/48 250 GRS', '4', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('346', '346', '', 'DETERGENTE AXION CJA/20 500 GRS', '28', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('347', '347', '', 'DETERGENTE AXION CJA/20 900 GRS', '8', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('348', '348', '', 'DETERGENTE BCA.NIEVES CJA/20 500 GRS', '4', '0', '0', 'SAMS CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'BCA.NIEVES', 'BCA.NIEVES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('349', '349', '', 'DETERGENTE BCA.NIEVES CJA/40 250 GRS', '17', '0', '0', 'SAMS CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'BCA.NIEVES', 'BCA.NIEVES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('350', '350', '', 'DETERGENTE FOCA CJA/40 250 GRS', '5', '0', '0', 'SAMS CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'FOCA', 'FOCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('351', '351', '', 'DETERGENTE FOCA CJA/10 1 KGS', '4', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'FOCA', 'FOCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('352', '352', '', 'DETERGENTE FOCA CJA/20 500 GRS', '5', '0', '0', 'SAMS CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'FOCA', 'FOCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('353', '353', '', 'DETERGENTE MAS COLOR CJA/12 500 ML', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MAS COLOR', 'MAS COLOR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('354', '354', '', 'DETERGENTE MAS COLOR CJA/10 1 LTS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MAS COLOR', 'MAS COLOR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('355', '355', '', 'DETERGENTE ROMA PZA 250 GRS', '20', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROMA', 'ROMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('356', '356', '', 'DETERGENTE ROMA CJA/ 500 GRS', '2', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROMA', 'ROMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('357', '357', '', 'DETERGENTE RUTH PZA 500 GRS', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'RUTH', 'RUTH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('358', '358', '', 'DETERGENTE RUTH PZA 250 GRS', '7', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'RUTH', 'RUTH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('359', '359', '', 'DETERGENTE SALVO CJA/24 500 GRS', '7', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SALVO', 'SALVO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('360', '360', '', 'DETERGENTE SALVO CJA/20 900 GRS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SALVO', 'SALVO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('361', '361', '', 'DETERGENTE SALVO CJA/48 250 GRS', '20', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SALVO', 'SALVO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('362', '362', '', 'DETERGENTE ACCION INSTANTANEA ACE CJA/18 1 KGS', '7', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('363', '363', '', 'DETERGENTE ACCION INSTANTANEA ACE CJA/30 500 GRS', '10', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('364', '364', '', 'DETERGENTE ACCION INSTANTANEA ACE CJA/24 500 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('365', '365', '', 'DETERGENTE NATURALS ACE CJA/24 500 GRS', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('366', '366', '', 'DETERGENTE NATURALS ACE CJA/18 1 KGS', '9', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ACE', 'ACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('367', '367', '', 'DETERGENTE P/PLATOS  LIMON  AXION CJA/ 1.07 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('368', '368', '', 'DETERGENTE P/PLATOS  LIMON  AXION CJA/12 400 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('369', '369', '', 'DETERGENTE P/PLATOS ANTIBACTERIAL  AXION CJA/12 400 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('370', '370', '', 'DETERGENTE P/PLATOS ANTIBACTERIAL CITRUS AXION CJA/12 700 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('371', '371', '', 'DETERGENTE P/PLATOS LIMON AXION CJA/ 750 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('372', '372', '', 'DETERGENTE P/PLATOS TRICLORO AXION CJA/ 400 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'AXION', 'AXION', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('373', '373', '', 'DETERGENTE/ LIQUIDO VEL ROSITA CJA/ 500 MLS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'VEL ROSITA', 'VEL ROSITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('374', '374', '', 'DULCES BOTU DOS MITCHEL PQT/ 12 PZA', '17', '0', '0', 'MICHEL  ', '', 'Pieza', '16', '0', '', '0.00', 'MITCHEL', 'MITCHEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('375', '375', '', 'DULCES DALE DALE DALE SONRICS BOL/ 2 KGS', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SONRICS', 'SONRICS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('376', '376', '', 'ELOTE DEL MONTE CJA/6 2.9 KGS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'DEL MONTE', 'DEL MONTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('377', '377', '', 'ELOTE DEL MONTE CJA/24 225 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL MONTE', 'DEL MONTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('378', '378', '', 'ELOTE HERDEZ CJA/24 220 GRS', '3', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('379', '379', '', 'ELOTE HERDEZ CJA/24 400 GRS', '2', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('380', '380', '', 'EMPANIZADOR KELLOGS CJA/ 350 GRS', '0', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('381', '381', '', 'EMPANIZADOR KELLOGS CJA/52 160 GRS', '2', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'KELLOGS', 'KELLOGS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('382', '382', '', 'EMPANIZADOR DONDE CJA/ 500 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('383', '383', '', 'EMPANIZADOR DONDE CJA/30  150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('384', '384', '', 'ENCENDEDOR GIL PQT/25 ', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'GIL', 'GIL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('385', '385', '', 'ENJUAGUE BUCAL ASTRINGOSOL CJA/24 300 ML', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ASTRINGOSOL', 'ASTRINGOSOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('386', '386', '', 'ENJUAGUE BUCAL  LISTERINE PZA 500 ML.', '15', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'LISTERINE', 'LISTERINE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('387', '387', '', 'ENJUAGUE BUCAL PLAX COLGATE PZA 500 ML', '8', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'COLGATE', 'COLGATE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('388', '388', '', 'ENSALADA DE LEGUMBRES HERDEZ CJA/48 220 GRS', '1', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('389', '389', '', 'ESCABILLON BIBERON  DUENDE PZA ', '45', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'DUENDE', 'DUENDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('390', '390', '', 'ESCABILLON WC SAN PABLO DUENDE PZA ', '24', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'DUENDE', 'DUENDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('391', '391', '', 'ESCOBILLON WC BOLA  FONTANELL PZA ', '24', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'FONTANELL', 'FONTANELL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('392', '392', '', 'ESPECTORANTE VICKPAVOR CJA/40 ', '13', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'VICKPAVOR', 'VICKPAVOR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('393', '393', '', 'ESPIRALES PLAGATOX CJA/48 CAJ/48', '1', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'PLAGATOX', 'PLAGATOX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('394', '394', '', 'ESPIRALES LAVANDA RAID CJA/24 12 PZA', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('395', '395', '', 'ESPIRALES VERDES RAID CJA/24 12 PZA', '6', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('396', '396', '', 'ESPIRALES VERDES KILLER CJA/36 12 PZA', '6', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KILLER', 'KILLER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('397', '397', '', 'ESTURAQUE LA EXTRA PQT/5 /30 60 GRS', '7', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('398', '398', '', 'ESTURAQUE LA EXTRA EXI/30 60 GRS', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('399', '399', '', 'FECULA DE MAIZ MAIZENA CJA/ 425 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MAIZENA', 'MAIZENA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('400', '400', '', 'FECULA DE MAIZ MAIZENA CJA/ 160 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MAIZENA', 'MAIZENA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('401', '401', '', 'FECULA DE MAIZ MAIZENA CJA/ 95 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MAIZENA', 'MAIZENA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('402', '402', '', 'FIBRA COCI CHI / FREGON LIMPIN PZA ', '80', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LIMPIN', 'LIMPIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('403', '403', '', 'FIBRA COCI GDE / FREGON LIMPIN PZA ', '80', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LIMPIN', 'LIMPIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('404', '404', '', 'FIBRA ESPONJA LIBER PQT/100 CHICA', '1', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'LIBER', 'LIBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('405', '405', '', 'FIBRA ESPONJA SCOTCH BRIT PQT/10 REGULAR', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'SCOTCH BRIT', 'SCOTCH BRIT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('406', '406', '', 'FIBRA METALICA  NUM.4 JIMENEZ PQT/50 GRANDE', '3', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'JIMENEZ', 'JIMENEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('407', '407', '', 'FIBRA METALICA NUM.2 JIMENEZ PQT/100 CHICA', '2', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'JIMENEZ', 'JIMENEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('408', '408', '', 'FIBRA POLIPRO CHICA DIAMANTE PQT 50 PZA', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DIAMANTE', 'DIAMANTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('409', '409', '', 'FIBRA REDONDA  CJA/ GRANDE', '0', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('410', '410', '', 'FIBRA VERDE LIBER CJA 100 PZA', '3', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', 'LIBER', 'LIBER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('411', '411', '', 'FIBRA VERDE SCOTCH BRIT CJA/4  12 PZA', '4', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'SCOTCH BRIT', 'SCOTCH BRIT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('412', '412', '', 'FIBRA VERDE SCOTCH BRIT PQT 6 PZA', '47', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'SCOTCH BRIT', 'SCOTCH BRIT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('413', '413', '', 'FIJADOR DE CABELLO/SPRAY ALGAS CAPRICE CJA/12 372 ML', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('414', '414', '', 'FIJADOR DE CABELLO/SPRAY ANTICERAMINAS CAPRICE CJA/21 372 ML', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('415', '415', '', 'FIJADOR DE CABELLO/SPRAY MANDARINA CAPRICE CJA/12 372 ML', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('416', '416', '', 'FIJADOR DE CABELLO/SPRAY SABILA CAPRICE CJA/21 372 ML', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('417', '417', '', 'FILOS DE RASURAR SHARP CJA/ ', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SHARP', 'SHARP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('418', '418', '', 'FILOS DE RASURAR GUILLETE CJA/ 5 HOJAS X PQTE', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GUILLETE', 'GUILLETE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('419', '419', '', 'FLAN PRONTO CJA/24 84 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('420', '420', '', 'FLAN VAINILLA JELL-O CJA/ 84 GRS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'JELL-O', 'JELL-O', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('421', '421', '', 'FOCO PHILIPS CJA/22/10 100 W', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('422', '422', '', 'FOCO PHILIPS PQT/10 100 W', '6', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('423', '423', '', 'FOCO PHILIPS CJA/20/10 75 W', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('424', '424', '', 'FOCO PHILIPS PQT/10 75 W', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('425', '425', '', 'FOCO PHILIPS CJA/6 14 W', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('426', '426', '', 'FOCO PHILIPS PZA 14 W', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('427', '427', '', 'FOCO PHILIPS CJA/ 18 W', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('428', '428', '', 'FOCO  PHILIPS CJA/20/10 60 W', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('429', '429', '', 'FOCO  PHILIPS PQT/10 60 W', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'PHILIPS', 'PHILIPS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('430', '430', '', 'FRANELA  CJA/ ', '0', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('431', '431', '', 'FRESA DE LA ROSA  BOL/ 500 GRS', '0', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('432', '432', '', 'FRESITA ALTEÑO BOL/ 40 PZA', '0', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', 'ALTEÑO', 'ALTEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('433', '433', '', 'FRIJOLES BAYOS REFRITOS RANCHERITA CJA/ 430 GRS', '0', '0', '0', 'LA COSTEÑA  ', '', 'Pieza', '16', '0', '', '0.00', 'RANCHERITA', 'RANCHERITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('434', '434', '', 'FRIJOLES CHARROS LA COSTEÑA CJA/12 560 GRS', '10', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('435', '435', '', 'FRIJOLES CLAROS LA SIERRA CJA/24 440 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA SIERRA', 'LA SIERRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('436', '436', '', 'FRIJOLES MOLIDOS NEGRO LA SIERRA CJA/24 440 GRS', '24', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA SIERRA', 'LA SIERRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('437', '437', '', 'FRIJOLES NEGROS ISADORA CJA/8 PQT/6 430 GRS', '0', '0', '0', 'SAMS ABRAHAM SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ISADORA', 'ISADORA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('438', '438', '', 'FRIJOLES NEGROS ENTEROS LA COSTEÑA CJA/12 560 GRS', '6', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('439', '439', '', 'FRIJOLES NEGROS ENTEROS LA COSTEÑA CJA/12 400 GRS', '6', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('440', '440', '', 'FRIJOLES NEGROS MOLIDOS LA COSTEÑA CJA/12 440 GRS', '2', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('441', '441', '', 'FRIJOLES NEGROS REFRITOS LA COSTEÑA CJA/12 400 GRS', '8', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('442', '442', '', 'FRIJOLES NEGROS REFRITOS LA COSTEÑA CJA/12 580 GRS', '7', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('443', '443', '', 'FRIJOLES NEGROS REFRITOS LA COSTEÑA CJA/12 820 GRS', '7', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('444', '444', '', 'FRIJOLES NEGROS REFRITOS RANCHERITA CJA/24 430 GRS', '3', '0', '0', 'LA COSTEÑA  ', '', 'Pieza', '16', '0', '', '0.00', 'RANCHERITA', 'RANCHERITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('445', '445', '', 'GALLETAS DONDE CJA/ 10  180 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('446', '446', '', 'GALLETAS  ARCO IRIS GAMESA CJA/ 16 75 GRS', '2', '0', '0', 'GAMESA  ', '', 'Pieza', '16', '0', '', '0.00', 'GAMESA', 'GAMESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('447', '447', '', 'GALLETAS  CRAKETS GAMESA CJA/20 135 GRS', '0', '0', '0', 'GAMESA  ', '', 'Pieza', '16', '0', '', '0.00', 'GAMESA', 'GAMESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('448', '448', '', 'GALLETAS ALICIAS DONDE CJA/ 180 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('449', '449', '', 'GALLETAS ANIMALITOS DONDE CJA/ 2.150 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('450', '450', '', 'GALLETAS ANIMALITOS DONDE CJA/ 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('451', '451', '', 'GALLETAS ANIMALITOS DONDE CJA/ 1 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('452', '452', '', 'GALLETAS ANIMALITOS DONDE CJA/ 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('453', '453', '', 'GALLETAS AVIONES DONDE CJA/ 5 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('454', '454', '', 'GALLETAS BISCOCHITOS DONDE CJA/ 180 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('455', '455', '', 'GALLETAS BISCOCHITOS DONDE CJA/ 1 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('456', '456', '', 'GALLETAS BISCOCHITOS DONDE CJA/12 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('457', '457', '', 'GALLETAS BISCOCHITOS DONDE CJA/ 2.150 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('458', '458', '', 'GALLETAS D\'CANELA DONDE CJA/12 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('459', '459', '', 'GALLETAS DIPS DONDE CJA/12 160 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('460', '460', '', 'GALLETAS EMPERADOR GAMESA CAJ/16 86 GRS', '0', '0', '0', 'GAMESA  ', '', 'Pieza', '16', '0', '', '0.00', 'GAMESA', 'GAMESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('461', '461', '', 'GALLETAS FLOR DE ALMENDRA DONDE CJA/ 110 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('462', '462', '', 'GALLETAS GALLEQUILLAS DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('463', '463', '', 'GALLETAS GLOBITOS DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('464', '464', '', 'GALLETAS GLOBITOS DONDE CJA/ 1 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('465', '465', '', 'GALLETAS GLOBITOS DONDE CJA/ 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('466', '466', '', 'GALLETAS LEALES DONDE CJA/ 2.150 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('467', '467', '', 'GALLETAS LEALES DONDE CJA/ 2 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('468', '468', '', 'GALLETAS LIMON DONDE CJA/ 1 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('469', '469', '', 'GALLETAS MARIAS DONDE CJA/10 180 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('470', '470', '', 'GALLETAS MARIAS DONDE CJA/ 160 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('471', '471', '', 'GALLETAS MARIAS DONDE CJA/ 170 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('472', '472', '', 'GALLETAS MARIAS GAMESA CJA/20 170 GRS', '1', '0', '0', 'GAMESA  ', '', 'Pieza', '16', '0', '', '0.00', 'GAMESA', 'GAMESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('473', '473', '', 'GALLETAS OVALADAS DONDE CJA/ 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('474', '474', '', 'GALLETAS OVALADAS DONDE CJA/ 1 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('475', '475', '', 'GALLETAS OVALADAS DONDE CJA/12 150 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('476', '476', '', 'GALLETAS OVALBOL RICHAUD CJA/ 5 KGS', '0', '0', '0', 'KELLOGS  ', '', 'Pieza', '16', '0', '', '0.00', 'RICHAUD', 'RICHAUD', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('477', '477', '', 'GALLETAS SALADAS GAMESA  ', '0', '0', '0', 'GAMESA  ', '', 'Pieza', '16', '0', '', '0.00', 'GAMESA', 'GAMESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('478', '478', '', 'GALLETAS SODA DONDE CJA/ 800 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('479', '479', '', 'GALLETAS SODA DONDE CJA/ 2.150 KGS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('480', '480', '', 'GALLETAS SOLES DONDE CJA/12 160 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('481', '481', '', 'GALLETAS SOLES DONDE CJA/ 180 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('482', '482', '', 'GEL XTREME CJA/24 250 ML', '4', '0', '0', 'LA ANITA  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'XTREME', 'XTREME', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('483', '483', '', 'GEL XTREME CJA/12 900 ML', '1', '0', '0', 'LA ANITA  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'XTREME', 'XTREME', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('484', '484', '', 'GEL CLEAR XTREME CJA/24 125 GRS', '6', '0', '0', 'LA ANITA  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'XTREME', 'XTREME', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('485', '485', '', 'GEL GALAN MOCO DE GORILA CJA/24 270 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MOCO DE GORILA', 'MOCO DE GORILA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('486', '486', '', 'GEL PUNK MOCO DE GORILA CJA/12 270 ML', '1', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MOCO DE GORILA', 'MOCO DE GORILA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('487', '487', '', 'GEL ROCKERO MOCO DE GORILA CJA/ 270 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MOCO DE GORILA', 'MOCO DE GORILA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('488', '488', '', 'GEL TRANSPARENTE FRUIT PQT/3 500 GRS', '63', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'FRUIT', 'FRUIT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('489', '489', '', 'GEL TRANSPARENTE XTREME CJA/6 600 GRS', '2', '0', '0', 'LA ANITA  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'XTREME', 'XTREME', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('490', '490', '', 'GELATINA/ FRESA PRONTO CJA/24 84 GRS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('491', '491', '', 'GELATINA/ PIÑA PRONTO CJA/24 84 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('492', '492', '', 'GELATINA/ UVA PRONTO CJA/24 84 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('493', '493', '', 'GOMA DE MASCAR CLORETS CJA 60 PQTS METAL', '14', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CLORETS', 'CLORETS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('494', '494', '', 'GOMA DE MASCAR CLORETS CJA/ 60 PQTS CELOFAL', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CLORETS', 'CLORETS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('495', '495', '', 'GOMA DE MASCAR CANELS CJA/ 60 PQTS', '1', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', 'CANELS', 'CANELS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('496', '496', '', 'GOMA DE MASCAR CANELS PQT 50 PAQTS', '0', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', 'CANELS', 'CANELS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('497', '497', '', 'GOMA DE MASCAR BUBBALOO CAJ/ 60 PZA', '17', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BUBBALOO', 'BUBBALOO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('498', '498', '', 'GOMA DE MASCAR BOLICHIC BOL/ 100 PZA', '10', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BOLICHIC', 'BOLICHIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('499', '499', '', 'GOMA DE MASCAR MENTA TRIDENT CJA/40 40 PQTS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'TRIDENT', 'TRIDENT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('500', '500', '', 'GOMA DE MASCAR MENTA TRIDENT CJA/40 40 PQT', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'TRIDENT', 'TRIDENT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('501', '501', '', 'GOMA DE MASCAR MENTA CHICLETS CJA/40 60 PQT', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CHICLETS', 'CHICLETS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('502', '502', '', 'GOMA DE MASCAR SURTIDO CHICLETS CJA/40 60 PQT', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CHICLETS', 'CHICLETS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('503', '503', '', 'HARINA PREPARADAS/ HOT CAKES PRONTO CJA/12 350 GRS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('504', '504', '', 'HARINA PREPARADAS/ HOT CAKES PRONTO CJA/3 500 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRONTO', 'PRONTO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('505', '505', '', 'INSECTICIDA OKO CJA/12 400 ML', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'OKO', 'OKO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('506', '506', '', 'INSECTICIDA AEROSOL H24 CJA/12 426 ML', '8', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'H24', 'H24', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('507', '507', '', 'INSECTICIDA CASA Y JARDIN BAYGON CJA/12 400 ML', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'BAYGON', 'BAYGON', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('508', '508', '', 'INSECTICIDA CASA Y JARDIN RAID PQT/3 400 ML', '8', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('509', '509', '', 'INSECTICIDA CASA Y JARDIN RAID A.T CJA/12 400 ML', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID A.T', 'RAID A.T', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('510', '510', '', 'INSECTICIDA DOMESTICO OKO CJA/12 230 ML', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'OKO', 'OKO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('511', '511', '', 'INSECTICIDA LIQUIDO H24 CJA/12 480 ML', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'H24', 'H24', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('512', '512', '', 'INSECTICIDA LIQUIDO H24 CJA/24 240 ML', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'H24', 'H24', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('513', '513', '', 'INSECTICIDA LIQUIDO H24 CJA/12 960 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'H24', 'H24', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('514', '514', '', 'INSECTICIDA MAX RAID PQT/3 450 ML', '6', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('515', '515', '', 'INSECTICIDA MAX RAID PZA 300 ML', '11', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('516', '516', '', 'INSECTICIDA VERDE BAYGON CJA/12 400 ML', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'BAYGON', 'BAYGON', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('517', '517', '', 'INSECTICIDA VERDE BAYGON CJA/12 250 ML', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BAYGON', 'BAYGON', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('518', '518', '', 'JABON DE BAÑO CAMAY CJA/48 90 GRS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CAMAY', 'CAMAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('519', '519', '', 'JABON DE BAÑO CAMAY PQT/12 90 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CAMAY', 'CAMAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('520', '520', '', 'JABON DE BAÑO CAMAY CJA/96 150 GRS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CAMAY', 'CAMAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('521', '521', '', 'JABON DE BAÑO CAMAY CJA/64 150 GRS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CAMAY', 'CAMAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('522', '522', '', 'JABON DE BAÑO CAMAY PQT/12 150 GRS', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CAMAY', 'CAMAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('523', '523', '', 'JABON DE BAÑO DOVE CJA/10 135 GRS', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'DOVE', 'DOVE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('524', '524', '', 'JABON DE BAÑO MENNEN PZA 90 GRS', '45', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('525', '525', '', 'JABON DE BAÑO NATURANS CJA/ 130 GRS', '0', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NATURANS', 'NATURANS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('526', '526', '', 'JABON DE BAÑO PALMOLIVE CJA/72 90 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('527', '527', '', 'JABON DE BAÑO  TEPEYAC CJA/60 100 GRS', '6', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('528', '528', '', 'JABON DE BAÑO BLANCO ROSA VENNUS CJA/240 25 GRS', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENNUS', 'ROSA VENNUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('529', '529', '', 'JABON DE BAÑO BLANCO ROSA VENUS CJA/40 150 GRS', '2', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('530', '530', '', 'JABON DE BAÑO BLANCO    ROSA VENUS CJA/60 100 GRS', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('531', '531', '', 'JABON DE BAÑO BLANCO NEUTRO ESCUDO CJA/96 150 GRS', '2', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('532', '532', '', 'JABON DE BAÑO BLANCO NEUTRO ESCUDO PQT/12 150 GRS', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('533', '533', '', 'JABON DE BAÑO LILA TEPEYAC CJA/40 150 GRS', '1', '0', '0', ' CORONA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('534', '534', '', 'JABON DE BAÑO ROSA ROSA VENUS CJA/40 150 GRS', '0', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('535', '535', '', 'JABON DE BAÑO ROSA ESCUDO PQT/12 150 GRS', '16', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('536', '536', '', 'JABON DE BAÑO ROSA ESCUDO CJA/96 100 GRS', '2', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('537', '537', '', 'JABON DE BAÑO ROSA ESCUDO PQT/12 100 GRS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('538', '538', '', 'JABON DE BAÑO ROSA ROSA VENUS CJA/40 100 GRS', '4', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('539', '539', '', 'JABON DE BAÑO ROSA TEPEYAC CJA/40 150 GRS', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('540', '540', '', 'JABON DE BAÑO ROSA C/ENVOLTURA ROSA VENUS CJA/240 25 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('541', '541', '', 'JABON DE BAÑO SURTIDO TEPEYAC CJA/40 150 GRS', '0', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('542', '542', '', 'JABON DE BAÑO VERDE TEPEYAC CJA/40 150 GRS', '2', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('543', '543', '', 'JABON DE BAÑO/ AQUA ZEST CJA/96 150 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ZEST', 'ZEST', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('544', '544', '', 'JABON DE BAÑO/ AQUA ZEST PQT/12 150 GRS', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ZEST', 'ZEST', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('545', '545', '', 'JABON DE BAÑO/ NATURAL PALMOLIVE PQT/12 130 GRS', '8', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('546', '546', '', 'JABON DE BAÑO/ NEUTRO PALMOLIVE PQT/12 130 GRS', '25', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('547', '547', '', 'JABON DE BAÑO/ ROSA ESCUDO CJA/96 150 GRS', '0', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'ESCUDO', 'ESCUDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('548', '548', '', 'JABON DE LAVANDERIA DAROMA CJA/25 400 GRS', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'DAROMA', 'DAROMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('549', '549', '', 'JABON DE LAVANDERIA AZUL PRINCESA CJA/40 200 GRS', '17', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('550', '550', '', 'JABON DE LAVANDERIA ROSA PRINCESA CJA/40 200 GRS', '8', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('551', '551', '', 'JABON DE LAVANDERIA/ AMARILLO LA CORONA CJA/25 400 GRS', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'LA CORONA', 'LA CORONA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('552', '552', '', 'JABON DE LAVANDERIA/ AMARILLO/ SIN EVOLTURA TEPEYAC CJA/ 50 200 GRS ', '1', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'TEPEYAC', 'TEPEYAC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('553', '553', '', 'JABON DE LAVANDERIA/ ANTIBACTERIAL 1,2,3 CJA/20 350 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3', '1,2,3', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('554', '554', '', 'JABON DE LAVANDERIA/ ANTIBACTERIAL 1,2,3 PQT/4 350 GRS', '20', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3', '1,2,3', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('555', '555', '', 'JABON DE LAVANDERIA/ AZUL ZOTE CJA/25 400 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ZOTE', 'ZOTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('556', '556', '', 'JABON DE LAVANDERIA/ BIOLOGICO 1,2,3 CJA/20 350 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3', '1,2,3', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('557', '557', '', 'JABON DE LAVANDERIA/ BLANCO ZOTE CJA/25 400 GRS', '3', '0', '0', ' CORONA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZOTE', 'ZOTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('558', '558', '', 'JABON DE LAVANDERIA/ BLANCO ZOTE CJA/50 2OO GRS', '4', '0', '0', ' CORONA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZOTE', 'ZOTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('559', '559', '', 'JABON DE LAVANDERIA/ BLANCO ZOTE CJA/60 100 GRS', '6', '0', '0', ' CORONA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZOTE', 'ZOTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('560', '560', '', 'JABON DE LAVANDERIA/ ROSA 1,2,3 CJA/20 350 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', '1,2,3', '1,2,3', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('561', '561', '', 'JABON DE LAVANDERIA/ ROSA VEL ROSITA CJA/40 350 GRS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'VEL ROSITA', 'VEL ROSITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('562', '562', '', 'JABON DE LAVANDERIA/ ROSA ZOTE CJA/25 400 GRS', '1', '0', '0', ' CORONA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ZOTE', 'ZOTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('563', '563', '', 'JABON EN ESCAMAS/ AZUL PRINCESA PQT/30 250 GRS', '11', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('564', '564', '', 'JABON EN ESCAMAS/ BLANCO PRINCESA PQT/20 500 GRS', '1', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('565', '565', '', 'JABON EN ESCAMAS/ BLANCO PRINCESA PQT/30 250 GRS', '9', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('566', '566', '', 'JABON LIQUIDO PINOL PQT/6 1 LTS', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PINOL', 'PINOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('567', '567', '', 'JABON LIQUIDO  ROSA VENUS CJA/ ', '0', '0', '0', ' CORONA ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA VENUS', 'ROSA VENUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('568', '568', '', 'JABON SIN ENVOLTURA PRINCESA CJA/80 165 GRS', '6', '0', '0', 'PROTEINAS Y OLEICO COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PRINCESA', 'PRINCESA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('569', '569', '', 'JERINGA DESECHABLE PLASTIPACK CJA/ 5 PIEZAS', '18', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PLASTIPACK', 'PLASTIPACK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('570', '570', '', 'JUGO BIDA MANZANA JUMEX CJA/ 12 500 ML', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('571', '571', '', 'JUGO BIDA UVA JUMEX CJA/ 12 500 ML', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('572', '572', '', 'JUGO MANZANA  JUMEX PQT/4 1 LTS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('573', '573', '', 'JUGO MANZANA JUMEX JUMEX PQT/4 1 LTS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('574', '574', '', 'JUGO PIÑA  JUMEX PQT/4 1 LTS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('575', '575', '', 'JUGO PIÑA JUMEX JUMEX PQT/4 1 LTS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('576', '576', '', 'JUGO SAZONADOR MAGGI CJA/6 100 ML', '14', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'MAGGI', 'MAGGI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('577', '577', '', 'JUGO UVA  JUMEX PQT/4 1 LTS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('578', '578', '', 'JUGO UVA JUMEX JUMEX PQT/4 1 LTS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'JUMEX', 'JUMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('579', '579', '', 'LAPICES  MIRADO CJA/ ', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'MIRADO', 'MIRADO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('580', '580', '', 'LE CHE LIQUIDA  NUTRILECHE CAJ/12 1 LTS', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NUTRILECHE', 'NUTRILECHE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('581', '581', '', 'LE CHE LIQUIDA DESLAC LITH LALA CAJ/12 1 LTS', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'LALA', 'LALA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('582', '582', '', 'LE CHE LIQUIDA DESLACTOSADA LALA CAJ/12 1 LTS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LALA', 'LALA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('583', '583', '', 'LE CHE LIQUIDA EXTRA CALCIO LALA CAJ/12 1 LTS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LALA', 'LALA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('584', '584', '', 'LECHE CONDENSADA LA LECHERA NESTLE PQT/6 100 GRS', '11', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('585', '585', '', 'LECHE CONDENSADA LA LECHERA NESTLE CJA/48 397 GRS', '10', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('586', '586', '', 'LECHE EN POLVO ALPURA CJA/ 480 GRS', '0', '0', '0', 'AKI GRAN MAYOREO  ', '', 'Pieza', '16', '0', '', '0.00', 'ALPURA', 'ALPURA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('587', '587', '', 'LECHE EN POLVO FORTILECHE CJA/ 500 GRS', '0', '0', '0', 'AKI GRAN MAYOREO  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FORTILECHE', 'FORTILECHE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('588', '588', '', 'LECHE EN POLVO CARNATION NESTLE CJA/24 500 GRS', '0', '0', '0', ' ABRAHAM ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('589', '589', '', 'LECHE EN POLVO NAN 1 NESTLE CJA/12 800 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('590', '590', '', 'LECHE EN POLVO NAN 1 NESTLE CJA/24 350 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('591', '591', '', 'LECHE EN POLVO NAN 2 NESTLE CJA/12 800 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('592', '592', '', 'LECHE EN POLVO NAN 2 NESTLE CJA/24 350 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('593', '593', '', 'LECHE EN POLVO NIDO 3+ NESTLE CJA/12 800 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('594', '594', '', 'LECHE EN POLVO NIDO 3+ NESTLE CJA/6 1.6 KGS', '1', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('595', '595', '', 'LECHE EN POLVO NIDO 5+ O EXTRACALCIO NESTLE PIEZA 800 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('596', '596', '', 'LECHE EN POLVO NIDO CLASICA NESTLE CJA/24 360 GRS', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('597', '597', '', 'LECHE EN POLVO NIDO CLASICA NESTLE PQT/6 360 GRS', '22', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('598', '598', '', 'LECHE EN POLVO NIDO CLASICA NESTLE CJA/12 800 GRS', '9', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('599', '599', '', 'LECHE EN POLVO NIDO CLASICA NESTLE CJA/6 1600 KGS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('600', '600', '', 'LECHE EN POLVO NIDO CLASICA NESTLE CJA/6 2.3 KGS', '2', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('601', '601', '', 'LECHE EN POLVO NIDO CLASICA NESTLE PZA 2.3 KGS', '4', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('602', '602', '', 'LECHE EN POLVO NIDO CLASICA  NESTLE CJA/12 130 GRS', '36', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('603', '603', '', 'LECHE EN POLVO NIDO DESLACTOSADA NESTLE CJA/12 800 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('604', '604', '', 'LECHE EN POLVO NIDO EXTRA CALCIO NIDO CAJA/12 800 GRS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NIDO', 'NIDO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('605', '605', '', 'LECHE EN POLVO NIDO KINDER 1+ NESTLE CJA/12 800 GRS', '13', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('606', '606', '', 'LECHE EN POLVO NIDO KINDER 1+ NESTLE CJA/12 144 GRS', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('607', '607', '', 'LECHE EN POLVO NIDO KINDER 1+ NESTLE CJA/6 1.6 KGS', '9', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('608', '608', '', 'LECHE EN POLVO NIDO KINDER 1+ NESTLE PZA 1.6 KGS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('609', '609', '', 'LECHE EN POLVO NIDO KINDER 1+ NESTLE CAJ/24 360 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('610', '610', '', 'LECHE EN POLVO NIDO NIDAL NESTLE CJA/6 135 GRS', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('611', '611', '', 'LECHE EN POLVO NIDO RINDES DIARIO NESTLE CJA/36 240 GRS', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('612', '612', '', 'LECHE EN POLVO NIDO RINDES DIARIO NESTLE CJA/24 480 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('613', '613', '', 'LECHE EN POLVO SVELTY ACTI FIBRAS NESTLE CJA/12 800 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('614', '614', '', 'LECHE EN POLVO SVELTY SIN  GRASAS NESTLE CJA/6 1.6 KG', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('615', '615', '', 'LECHE EVAPORADA CARNATION NESTLE CJA/48 378 GRS', '9', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NESTLE', 'NESTLE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('616', '616', '', 'LECHE FORMULA LACTEA VALLE AZUL VALLE AZUL CAJ/12 1 LTS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'VALLE AZUL', 'VALLE AZUL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('617', '617', '', 'LECHE LIQUIDA DESLACTOSADA SAN MARCOS CAJ/12 1 LTS', '6', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SAN MARCOS', 'SAN MARCOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('618', '618', '', 'LECHE LIQUIDA LIGHT SAN MARCOS CAJ/12 1 LTS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SAN MARCOS', 'SAN MARCOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('619', '619', '', 'LECHE LIQUIDA SEMI SAN MARCOS CAJ/12 1 LTS', '8', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'SAN MARCOS', 'SAN MARCOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('620', '620', '', 'LECHE LIQUIDA SILUETTE LALA CAJ/12 1 LTS', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LALA', 'LALA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('621', '621', '', 'LEVADURA SECA MAGIDELY CJA/ 450 ML', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'MAGIDELY', 'MAGIDELY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('622', '622', '', 'LIMPIADOR  LAVANDA FABULOSO CJA/24 500 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('623', '623', '', 'LIMPIADOR ALGODÓN POETT CJA/12 900 ML', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('624', '624', '', 'LIMPIADOR BAMBU POETT CJA/12 900 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('625', '625', '', 'LIMPIADOR BEBE POETT CJA/12 900 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('626', '626', '', 'LIMPIADOR BRISA MARINA FLASH CJA/12 1.25 LTS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('627', '627', '', 'LIMPIADOR BRISA MARINA FLASH CJA/20 500 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('628', '628', '', 'LIMPIADOR ESPIRITU JOVEN POETT CJA/12 900 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('629', '629', '', 'LIMPIADOR FLORAL FLASH CJA/12 1.25 LTS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('630', '630', '', 'LIMPIADOR FLORAL FLASH CJA/20 500 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('631', '631', '', 'LIMPIADOR FRESCA LAVANDA BREF CJA/12 850 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BREF', 'BREF', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('632', '632', '', 'LIMPIADOR FRESCA MENTA FABULOSO CJA/12 1 LTS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('633', '633', '', 'LIMPIADOR FRESCO AMANECER FABULOSO CJA/24 500 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('634', '634', '', 'LIMPIADOR FRESCURA DE LAVANDA FABULOSO CJA/12 1 LTS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('635', '635', '', 'LIMPIADOR FRESCURA FRUTAL POETT CJA/12 900 ML', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('636', '636', '', 'LIMPIADOR LAVANDA FLASH CJA/12 1.25 LTS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('637', '637', '', 'LIMPIADOR LAVANDA FLASH CJA/20 500 ML', '7', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('638', '638', '', 'LIMPIADOR MAR FRESCO FABULOSO CJA/24 500 ML', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('639', '639', '', 'LIMPIADOR MAR FRESCO FABULOSO CJA/12 1 LTS', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FABULOSO', 'FABULOSO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('640', '640', '', 'LIMPIADOR PINOL PINOL CJA/15 1 LTS', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PINOL', 'PINOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('641', '641', '', 'LIMPIADOR PINOL PINOL CJA/30 250 ML', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PINOL', 'PINOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('642', '642', '', 'LIMPIADOR PINOL PINOL CJA/20 500 ML', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PINOL', 'PINOL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('643', '643', '', 'LIMPIADOR PRIMAVERA POETT CJA/12 900 ML', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'POETT', 'POETT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('644', '644', '', 'MAMILA  JALOMA CJA/ ', '0', '0', '0', 'SURTIDORA DEL ORIENTE SURTIDORA FARMACEUTICA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('645', '645', '', 'MAMILA INDIVIDUAL CURITY CJA/36 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CURITY', 'CURITY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('646', '646', '', 'MAMILA SILICON CURITY CJA/ ', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CURITY', 'CURITY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('647', '647', '', 'MAMILA TRIPLE CURITY CJA/24 3 PZA', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CURITY', 'CURITY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('648', '648', '', 'MANTECA INCA CJA/24 500 GRS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'INCA', 'INCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('649', '649', '', 'MANTECA INCA CJA/12 1 KGS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'INCA', 'INCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('650', '650', '', 'MAQUILLAJE  COLOR BRONCEADO ANGEL FACE PZA 11 GRS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('651', '651', '', 'MAQUILLAJE  COLOR CANELA ANGEL FACE PZA 11 GRS', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('652', '652', '', 'MAQUILLAJE  COLOR CARIBE ANGEL FACE PZA 11 GRS', '10', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('653', '653', '', 'MAQUILLAJE  COLOR GITANO ANGEL FACE PZA 11 GRS', '9', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('654', '654', '', 'MAQUILLAJE  COLOR NATURAL ANGEL FACE PZA 11 GRS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('655', '655', '', 'MAQUILLAJE  COLOR TOPACIO ANGEL FACE PZA 11 GRS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('656', '656', '', 'MAQUILLAJE  COLOR TROPICAL ANGEL FACE PZA 11 GRS', '6', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ANGEL FACE', 'ANGEL FACE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('657', '657', '', 'MARGARINA LISS CJA/12 250 GRS', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LISS', 'LISS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('658', '658', '', 'MASA INSTANTANEA MASECA PQT/10 1 KGS', '26', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MASECA', 'MASECA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('659', '659', '', 'MAYONESA CHULA VIS. CJA/4 3.8 KGS', '4', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CHULA VIS.', 'CHULA VIS.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('660', '660', '', 'MAYONESA CHULA VIS. PZA 3.8 KGS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CHULA VIS.', 'CHULA VIS.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('661', '661', '', 'MAYONESA CHULA VIS. CJA/6 1.88 KGS', '2', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'CHULA VIS.', 'CHULA VIS.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('662', '662', '', 'MAYONESA MEGA SUP CJA/12 950 GRS', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MEGA SUP', 'MEGA SUP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('663', '663', '', 'MAYONESA  MC CORMICK CJA/4 3.8 KGS', '11', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('664', '664', '', 'MAYONESA LIGTH C/LIMON  MC CORMICK CJA/24 207 GRS', '0', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('665', '665', '', 'MAYONESA NUM.16 MC CORMICK CJA/12 420 GRS', '8', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('666', '666', '', 'MAYONESA NUM.32 MC CORMICK CJA/12 850 GRS', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('667', '667', '', 'MAYONESA NUM.4  MC CORMICK CJA/24 110 GRS', '27', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('668', '668', '', 'MAYONESA NUM.64 MC CORMICK CJA/6 1.88 KGS', '4', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('669', '669', '', 'MAYONESA NUM.8 MC CORMICK CJA/24 210 GRS', '6', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MC CORMICK', 'MC CORMICK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('670', '670', '', 'MAYONESA P/ENVASAR 3.800 KG CHULA VISTA CAJ/4 3.800 KGS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CHULA VISTA', 'CHULA VISTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('671', '671', '', 'MEDIA CREMA 250 ML SAN MARCOS CAJ/27 250 ML', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SAN MARCOS', 'SAN MARCOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('672', '672', '', 'MERMELADA FRESA DEL MONTE CJA/24 270 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL MONTE', 'DEL MONTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('673', '673', '', 'MERTEOLATE BLANCO JALOMA PZA 40 ML', '0', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('674', '674', '', 'MERTEOLATE ROJO JALOMA PZA 40 ML', '0', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('675', '675', '', 'MOLE DÑA MARIA CJA/24 125 GRS', '39', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DÑA MARIA', 'DÑA MARIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('676', '676', '', 'MOLE PAOLA PZA 2.5 KGS', '8', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', 'PAOLA', 'PAOLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('677', '677', '', 'MOLE DÑA MARIA CJA/24 235 GRS', '4', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DÑA MARIA', 'DÑA MARIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('678', '678', '', 'MOLE DÑA MARIA CJA/24 540 GRS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DÑA MARIA', 'DÑA MARIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('679', '679', '', 'PALETA DULCE PIÑA LOCA  BLS/40 40 PALETAS', '10', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('680', '680', '', 'PALETA MANGUIUS  VITROLERO 20 PZA', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('681', '681', '', 'PALETAS CORAZONADA ALTEÑO PQT/ 40 PZA', '18', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ALTEÑO', 'ALTEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('682', '682', '', 'PALETAS SANDY POP ALTEÑO BOL/ 40 PZA', '28', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', 'ALTEÑO', 'ALTEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('683', '683', '', 'PALILLOS DE DIENTES PINGÜINO CJA/ 250 PALILLOS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PINGÜINO', 'PINGÜINO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('684', '684', '', 'PALILLOS DE DIENTES MAYA RESTAURANTERO CJA/24 800 PALILLOS', '2', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'MAYA RESTAURANTERO', 'MAYA RESTAURANTERO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('685', '685', '', 'PALILLOS DE DIENTES MAYA CJA/48 200 PALILLOS', '1', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'MAYA', 'MAYA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('686', '686', '', 'PALILLOS DE DIENTES MAYA PQT/12 200 PALILLOS', '1', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'MAYA', 'MAYA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('687', '687', '', 'PALILLOS DE DIENTES MULTICHEF PQT/12 250 PALILLOS', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MULTICHEF', 'MULTICHEF', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('688', '688', '', 'PALOMITAS EXTRA MANTEQUILLA ACT II CAJ/ 20 PZA', '16', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ACT II', 'ACT II', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('689', '689', '', 'PALOMITAS MANTEQUILLA ACT II CAJ/ 20 PZA', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ACT II', 'ACT II', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('690', '690', '', 'PALOMITAS NATURALES ACT II CAJ/ 20 PZA', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ACT II', 'ACT II', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('691', '691', '', 'PALOS DE PALETA CON PUNTA BULTO 25 KILOS', '1', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'CON PUNTA', 'CON PUNTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('692', '692', '', 'PALOS DE PALETA CUADRADO BULTO 25 KILOS', '11', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'CUADRADO', 'CUADRADO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('693', '693', '', 'PALOS DE PALETA KIKOLETA CJA/20 500 PZA', '1', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'KIKOLETA', 'KIKOLETA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('694', '694', '', 'PANCHERINGO MITCHEL BOL/ 16 PZA', '14', '0', '0', 'MICHEL  ', '', 'Pieza', '16', '0', '', '0.00', 'MITCHEL', 'MITCHEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('695', '695', '', 'PAÑAL  DESECHABLE ADULTO DIAPRO CJA/4 C/10', '6', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'DIAPRO', 'DIAPRO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('696', '696', '', 'PAÑAL  DESECHABLE ADULTO DIAPRO PQT C/10', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DIAPRO', 'DIAPRO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('697', '697', '', 'PAÑAL  DESECHABLE CHICO QUERUBIN CJA/6 C/14', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'QUERUBIN', 'QUERUBIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('698', '698', '', 'PAÑAL  DESECHABLE CHICO SUAVELASTIC MAX CJA/4 C/ 40', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('699', '699', '', 'PAÑAL  DESECHABLE CHICO SUAVELASTIC MAX CJA/6 C/14', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('700', '700', '', 'PAÑAL  DESECHABLE ETAPA 1 ULTRA CONFORT HUGGIES CJA/8 20 PZA', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HUGGIES', 'HUGGIES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('701', '701', '', 'PAÑAL  DESECHABLE GRANDE ABSORSEC CJA/5 40 PZA', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('702', '702', '', 'PAÑAL  DESECHABLE GRANDE ABSORSEC CJA/6 14 PZA', '7', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('703', '703', '', 'PAÑAL  DESECHABLE GRANDE QUERUBIN CJA/6 14 PZA', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'QUERUBIN', 'QUERUBIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('704', '704', '', 'PAÑAL  DESECHABLE GRANDE SUAVELASTIC MAX CJA/6 14 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('705', '705', '', 'PAÑAL  DESECHABLE GRANDE SUAVELASTIC MAX CJA/4 40 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('706', '706', '', 'PAÑAL  DESECHABLE JUMBO ABSORSEC CJA/6 14 PZA', '8', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('707', '707', '', 'PAÑAL  DESECHABLE JUMBO ABSORSEC CJA/5 40 PZA', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('708', '708', '', 'PAÑAL  DESECHABLE JUMBO SUAVELASTIC MAX CJA/6 14 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('709', '709', '', 'PAÑAL  DESECHABLE JUMBO SUAVELASTIC MAX CJA/4 40 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('710', '710', '', 'PAÑAL  DESECHABLE MEDIANO ABSORSEC CJA/6 14 PZA', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('711', '711', '', 'PAÑAL  DESECHABLE MEDIANO ABSORSEC CJA/5 40 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('712', '712', '', 'PAÑAL  DESECHABLE MEDIANO QUERUBIN CJA/6 14 PZA', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'QUERUBIN', 'QUERUBIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('713', '713', '', 'PAÑAL  DESECHABLE MEDIANO SUAVELASTIC MAX CJA/6 14 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('714', '714', '', 'PAÑAL  DESECHABLE MEDIANO SUAVELASTIC MAX CJA/4 40 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('715', '715', '', 'PAÑAL  DESECHABLE MEDIANO SUAVELASTIC MAX PQT 40 PZA', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('716', '716', '', 'PAÑAL  DESECHABLE RECIEN NACIDO ABSORSEC CJA/6 14 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('717', '717', '', 'PAÑAL  DESECHABLE RECIEN NACIDO HUGGIES SUP CJA/8 20 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HUGGIES SUP', 'HUGGIES SUP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('718', '718', '', 'PAÑAL  DESECHABLE RECIEN NACIDO SUAVELASTIC MAX CJA/8 14 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVELASTIC MAX', 'SUAVELASTIC MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('719', '719', '', 'PAÑO CELTEX PQT 15 PZA', '10', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CELTEX', 'CELTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('720', '720', '', 'PAÑUELOS DE BOLSILLO KLEENEX CJA/ ', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'KLEENEX', 'KLEENEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('721', '721', '', 'PAÑUELOS HIGIENICOS KLEENEX PZA 90 PZA', '7', '0', '0', 'SAMS COMA ', '', 'Pieza', '16', '0', '', '0.00', 'KLEENEX', 'KLEENEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('722', '722', '', 'PAPEL ALUMINIO REYNOLS CJA/ 200  PZA', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'REYNOLS', 'REYNOLS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('723', '723', '', 'PAPEL ALUMINIO ALUPLUS PQT/2 60 MTS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ALUPLUS', 'ALUPLUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('724', '724', '', 'PAPEL ALUMINIO ALUPLUS PZA 3 KGS', '7', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ALUPLUS', 'ALUPLUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('725', '725', '', 'PAPEL ALUMINIO ALUPLUS CJA/24 7.5 MTS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ALUPLUS', 'ALUPLUS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('726', '726', '', 'PAPEL ALUMINIO ALUREY CJA/24/  7 MTS', '4', '0', '0', 'DESECHABLES MARTIN JUAN MOO ', '', 'Pieza', '16', '0', '', '0.00', 'ALUREY', 'ALUREY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('727', '727', '', 'PAPEL ALUMINIO ALUTAP CJA/24 95 GRS', '1', '0', '0', 'DESECHABLES MARTIN  ', '', 'Pieza', '16', '0', '', '0.00', 'ALUTAP', 'ALUTAP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('728', '728', '', 'PAPEL HIGIENICO FLAMINGO CJA/24 4 PZA', '11', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLAMINGO', 'FLAMINGO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('729', '729', '', 'PAPEL HIGIENICO LYS CJA/24 4 PZA', '9', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LYS', 'LYS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('730', '730', '', 'PAPEL HIGIENICO  PACIFIC PQT/20 4 PZA', '6', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PACIFIC', 'PACIFIC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('731', '731', '', 'PAPEL HIGIENICO  PETALO CJA/40 40 PZA', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PETALO', 'PETALO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('732', '732', '', 'PAPEL HIGIENICO  SUAVEL CJA/40 40 PZA', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'SUAVEL', 'SUAVEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('733', '733', '', 'PAPEL HIGIENICO  SUAVEL CJA/12 4 PZA', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVEL', 'SUAVEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('734', '734', '', 'PAPEL HIGIENICO 400 HOJAS DELSEY CJA/12 4 PZA', '0', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DELSEY', 'DELSEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('735', '735', '', 'PAPEL HIGIENICO 500 HOJAS MONARCA CJA/12 4 PZA', '6', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MONARCA', 'MONARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('736', '736', '', 'PAPEL HIGIENICO 500 HOJAS SUAVEL CJA/20 4 PZA', '5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SUAVEL', 'SUAVEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('737', '737', '', 'PAPEL HIGIENICO INDIVIDUAL 500 HOJAS MONARCA CJA/48 1 PZA ', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MONARCA', 'MONARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('738', '738', '', 'PAPEL HIGIENICO MANZANILLA CHARMIN CJA/12 4 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHARMIN', 'CHARMIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('739', '739', '', 'PAPEL HIGIENICO MANZANILLA CHARMIN CJA/4 12 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHARMIN', 'CHARMIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('740', '740', '', 'PAPEL HIGIENICO SUAVE AROMA CHARMIN CJA/12 4 PZA', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CHARMIN', 'CHARMIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('741', '741', '', 'PASADORES FINOS ARI CJA/ 40 PZAS', '0', '0', '0', 'SURTIDORA DEL ORIENTE  ', '', 'Pieza', '16', '0', '', '0.00', 'ARI', 'ARI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('742', '742', '', 'PASTA DE SOPA CARACOL  ITALPASTA CJA/20 200 GRS', '10', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('743', '743', '', 'PASTA DE SOPA CARACOLES DONDE CJA/24 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('744', '744', '', 'PASTA DE SOPA CODITOS DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('745', '745', '', 'PASTA DE SOPA CODO MEDIANO ITALPASTA CJA/20 200 GRS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('746', '746', '', 'PASTA DE SOPA CODO RAYADO ITALPASTA CJA/20 200 GRS', '25', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('747', '747', '', 'PASTA DE SOPA FIDEO DELGADO ITALPASTA CJA/20 180 GRS', '10', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('748', '748', '', 'PASTA DE SOPA FIDEO GRUESO ITALPASTA CJA/20 180 GRS', '4', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('749', '749', '', 'PASTA DE SOPA FIDEOS DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('750', '750', '', 'PASTA DE SOPA LACITOS DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('751', '751', '', 'PASTA DE SOPA MOÑO DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('752', '752', '', 'PASTA DE SOPA MOÑO ITALPASTA CJA/20 200 GRS', '6', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('753', '753', '', 'PASTA DE SOPA PLUMA DONDE CJA/ 200 GRS', '0', '0', '0', 'DONDE  ', '', 'Pieza', '16', '0', '', '0.00', 'DONDE', 'DONDE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('754', '754', '', 'PASTA DE SOPA PLUMA ITALPASTA CJA/20 200 GRS', '0', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('755', '755', '', 'PASTA DE SOPA SPAGUETTI BARILLA CJA/40 200 GRS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BARILLA', 'BARILLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('756', '756', '', 'PASTA DE SOPA SPAGUETTI ITALPASTA CJA/20 200 GRS', '14', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ITALPASTA', 'ITALPASTA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('757', '757', '', 'PASTILLA SANITARIA BRISA MARINA FLASH CJA/50 80 GRS', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('758', '758', '', 'PASTILLA SANITARIA FLORAL LA ANITA CJA/50 100 GRS', '2', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('759', '759', '', 'PASTILLA SANITARIA FLORAL FLASH CJA/50 80 GRS', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('760', '760', '', 'PASTILLA SANITARIA LAVANDA LA ANITA CJA/50 100 GRS', '4', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('761', '761', '', 'PASTILLA SANITARIA LAVANDA FLASH CJA/50 80 GRS', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FLASH', 'FLASH', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('762', '762', '', 'PASTILLA SANITARIA LIMA LIMON LA ANITA CJA/50 100 GRS', '3', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('763', '763', '', 'PEGAMENTO INSTANTANEO KOLA LOCA CJA 10 PIEZAS+ 1', '13', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOLA LOCA', 'KOLA LOCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('764', '764', '', 'PIMIENTA  MOLIDA LA EXTRA PQT/10 30 PZA', '1', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('765', '765', '', 'PIMIENTA  MOLIDA LA EXTRA EXI 30 PZA', '6', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LA EXTRA', 'LA EXTRA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('766', '766', '', 'PIMIENTO MORRON LA COSTEÑA CJA/24 220 GRS', '3', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('767', '767', '', 'PIMIENTO MORRON LA PASIEGA PZA 780 GRS', '20', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'LA PASIEGA', 'LA PASIEGA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('768', '768', '', 'PINZAS PARA ROPA  PQT/ 50 PZA', '24', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('769', '769', '', 'PIÑA REBANADA HERDEZ CJA/24 800 GRS', '2', '0', '0', 'HERDEZ COMA ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('770', '770', '', 'PISTACHE MERMERS MARK BOL/ 1.36 KGS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MERMERS MARK', 'MERMERS MARK', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('771', '771', '', 'PLAQUITAS BAYGON CJA/24 20 PZA', '7', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'BAYGON', 'BAYGON', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('772', '772', '', 'PLAQUITAS RAID CJA/8 72 PZA', '4', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'RAID', 'RAID', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('773', '773', '', 'PLATO TERMICO NUM.10 D CONVERMEX CJA 24 PZA', '0', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('774', '774', '', 'PLATO TERMICO NUM.10 L CONVERMEX CJA 24 PZA', '0', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('775', '775', '', 'PLATO TERMICO NUM.16 CONVERMEX CJA 20 PZAS', '1', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('776', '776', '', 'POMADA LABIOS JALOMA BOT 60 PIEZAS', '1', '0', '0', ' SURTIDORA FARMACEUTICA ', '', 'Pieza', '16', '0', '', '0.00', 'JALOMA', 'JALOMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('777', '777', '', 'POPOTES PINGÜINO PQT/3 1 KILO', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PINGÜINO', 'PINGÜINO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('778', '778', '', 'POPOTES SIPP CJA/9 150 PZAS', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'SIPP', 'SIPP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('779', '779', '', 'PURE DE TOMATE DEL FUERTE CJA/24 210 GRS', '14', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('780', '780', '', 'PURE DE TOMATE DEL FUERTE CJA/24 345 GRS', '7', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('781', '781', '', 'PURE DE TOMATE DEL FUERTE CJA/12 1 KGS', '48', '0', '0', 'SAMS ABRAHAM ', '', 'Pieza', '16', '0', '', '0.00', 'DEL FUERTE', 'DEL FUERTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('782', '782', '', 'PURE DE TOMATE LA COSTEÑA CJA/4  3 KGS', '37', '0', '0', 'LA COSTEÑA  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'LA COSTEÑA', 'LA COSTEÑA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('783', '783', '', 'QUESO BOLA EDAN CAJ 6 PZA', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'EDAN', 'EDAN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('784', '784', '', 'QUESO FUNDIDO CHEEZE WHIZ CJA/24 235 GRS', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHEEZE WHIZ', 'CHEEZE WHIZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('785', '785', '', 'QUESO FUNDIDO CHEEZE WHIZ CJA/12 120 GRS', '30', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CHEEZE WHIZ', 'CHEEZE WHIZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('786', '786', '', 'QUESO SOPERO 1/4 2 HERMANOS PZA 250 GRS', '192', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '2 HERMANOS', '2 HERMANOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('787', '787', '', 'QUESO SOPERO KILO 2 HERMANOS PZA 1 KILO', '42', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '2 HERMANOS', '2 HERMANOS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('788', '788', '', 'RASURADORA GUILLETE PQT/20 ', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'GUILLETE', 'GUILLETE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('789', '789', '', 'RASURADORA PERMA SHARP PQT 30 PZA', '11', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PERMA SHARP', 'PERMA SHARP', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('790', '790', '', 'REMOVEDOR DE MANCHAS VANISH MAX CJA/12 450 ML', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'VANISH MAX', 'VANISH MAX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('791', '791', '', 'SABRISURTIDO SABRITAS CJA/2  30 PZA', '1', '0', '0', 'SABRITAS  ', '', 'Pieza', '16', '0', '', '0.00', 'SABRITAS', 'SABRITAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('792', '792', '', 'SABUCAN CUADRADO DOBLE ASA   PZA', '23', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('793', '793', '', 'SABUCAN CUANDRADO SENCILLO   PZA', '72', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('794', '794', '', 'SABUCAN REDONDO CHICO   PZA', '38', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('795', '795', '', 'SABUCAN REDONDO GRANDE   PZA', '13', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('796', '796', '', 'SABUCAN REDONDO MEDIANO   PZA', '46', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('797', '797', '', 'SAL DE UVAS PICOT CJA 50 PZA', '13', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PICOT', 'PICOT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('798', '798', '', 'SALSA LA BOTANERA CJA/12 1.5 LTS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'LA BOTANERA', 'LA BOTANERA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('799', '799', '', 'SALSA LA BOTANERA CJA/12 1 LTS', '5', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA BOTANERA', 'LA BOTANERA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('800', '800', '', 'SALSA LA BOTANERA CJA/24 500 ML', '4', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA BOTANERA', 'LA BOTANERA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('801', '801', '', 'SALSA LA BOTANERA CJA/6 5 LTS', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA BOTANERA', 'LA BOTANERA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('802', '802', '', 'SALSA LA PICOSITA CJA/12 1 LTS', '6', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA PICOSITA', 'LA PICOSITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('803', '803', '', 'SALSA LA PICOSITA CJA/4 GALON', '4', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA PICOSITA', 'LA PICOSITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('804', '804', '', 'SALSA LA PICOSITA CJA/24 500 ML', '4', '0', '0', 'LA EXTRA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA PICOSITA', 'LA PICOSITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('805', '805', '', 'SALSA MEGA CJA/12 1.02 LTS', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MEGA', 'MEGA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('806', '806', '', 'SALSA MR CHILES A. CJA/ GALON', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'MR CHILES A.', 'MR CHILES A.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('807', '807', '', 'SALSA LA BOTANERA CJA/6 4 LTS', '3', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA BOTANERA', 'LA BOTANERA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('808', '808', '', 'SALSA VALENTINA PQT/6 370 ML', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'VALENTINA', 'VALENTINA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('809', '809', '', 'SALSA CASERA HERDEZ CJA/12 453 ML', '1', '0', '0', 'HERDEZ COMA ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('810', '810', '', 'SALSA CASERA HERDEZ CJA/48 210 GRS', '7', '0', '0', 'HERDEZ COMA ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('811', '811', '', 'SALSA CASERA HERDEZ PQT/8 210 GRS', '31', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('812', '812', '', 'SALSA CATSUP CLEMENTE J. CJA/24 390 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLEMENTE J.', 'CLEMENTE J.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('813', '813', '', 'SALSA CATSUP CLEMENTE J. CJA/24 220 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLEMENTE J.', 'CLEMENTE J.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('814', '814', '', 'SALSA CATSUP EMBASSA CJA/24 385 GRS', '1', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'EMBASSA', 'EMBASSA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('815', '815', '', 'SALSA CATSUP EMBASSA CJA/12 1 KGS', '2', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'EMBASSA', 'EMBASSA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('816', '816', '', 'SALSA CHAMOY CHILERITO CJA/12 1 LTS', '0', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', 'CHILERITO', 'CHILERITO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('817', '817', '', 'SALSA CHAMOY CHILERITO CJA/3 5 LTS', '0', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', 'CHILERITO', 'CHILERITO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('818', '818', '', 'SALSA CHAMOY MEGA CJA/24 520 GRS', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MEGA', 'MEGA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('819', '819', '', 'SALSA CHAMOY MEGA CJA/6 4.14 KGS', '1', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'MEGA', 'MEGA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('820', '820', '', 'SALSA CHAMOY MEGA CJA/12 1 LTS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'MEGA', 'MEGA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('821', '821', '', 'SALSA DE CHILE ROJA GARY CJA/ 145 ML', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('822', '822', '', 'SALSA DE CHILE ROJA LA ANITA CJA/ 230 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('823', '823', '', 'SALSA DE CHILE VERDE GARY CJA/24 145 ML', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('824', '824', '', 'SALSA DE CHILE VERDE LA ANITA CJA/ 230 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('825', '825', '', 'SALSA INGLESA CROSSE CJA/6 980 GRS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CROSSE', 'CROSSE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('826', '826', '', 'SALSA INGLESA CROSSE PQT/6 145 GRS', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CROSSE', 'CROSSE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('827', '827', '', 'SALSA MEXICANA DEL MONTE CJA/24 210 GRS', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL MONTE', 'DEL MONTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('828', '828', '', 'SALSA SOYA KIKOMAN CJA/1VISTA 296 ML', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'KIKOMAN', 'KIKOMAN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('829', '829', '', 'SALSA SOYA BAKERS & CHEFS PZA 2 LTS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BAKERS & CHEFS', 'BAKERS & CHEFS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('830', '830', '', 'SALSA TAQUERA HERDEZ CJA/ 453 ML', '0', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('831', '831', '', 'SALSA VERDE HERDEZ CJA/12 453 ML', '1', '0', '0', 'HERDEZ  ', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('832', '832', '', 'SALSA VERDE HERDEZ CJA/48 210 GRS', '6', '0', '0', 'HERDEZ COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HERDEZ', 'HERDEZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('833', '833', '', 'SALSA VERDE DEL MONTE CJA/24 210 GRS', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DEL MONTE', 'DEL MONTE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('834', '834', '', 'SARDINA YAVAROS CJA/24 425 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'YAVAROS', 'YAVAROS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('835', '835', '', 'SARRICIDA LS.JEL CJA/12 1 LTS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LS.JEL', 'LS.JEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('836', '836', '', 'SAZONADOR BLANCO MIARROZ KNORR SUIZA  TIR 06 10 PZA', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('837', '837', '', 'SAZONADOR ROJO KNORR SUIZA  TIR 06 10 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('838', '838', '', 'SERVILLETAS CHARMIN CHEFF CJA/36 100 PZA', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'CHARMIN CHEFF', 'CHARMIN CHEFF', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('839', '839', '', 'SERVILLETAS DELSEY CJA/24 250 PZA', '3', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DELSEY', 'DELSEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('840', '840', '', 'SERVILLETAS DELSEY CJA/12 125 PZA', '16', '0', '0', 'SAMS  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DELSEY', 'DELSEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('841', '841', '', 'SERVILLETAS DELSEY CJA/12 500 PZA', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DELSEY', 'DELSEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('842', '842', '', 'SERVILLETAS FANCY CJA/12 500 PZA', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FANCY', 'FANCY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('843', '843', '', 'SERVILLETAS FANCY CJA/48 125 PZA', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'FANCY', 'FANCY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('844', '844', '', 'SERVILLETAS PETALO PZA 500 PZA', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'PETALO', 'PETALO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('845', '845', '', 'SERVITOALLA MONARCA COLCH/24 70 PZA', '5', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MONARCA', 'MONARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('846', '846', '', 'SHAMPOO  CAPRICE CJA/24 20 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('847', '847', '', 'SHAMPOO  HEAD & SHOLDER CJA/20 EXI/24 10 ML', '9', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HEAD & SHOLDER', 'HEAD & SHOLDER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('848', '848', '', 'SHAMPOO  PALMOLIVE/OPTIMS EXI/24 10 ML', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE/OPTIMS', 'PALMOLIVE/OPTIMS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('849', '849', '', 'SHAMPOO  MENNEN CJA/15 250 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('850', '850', '', 'SHAMPOO  PALMOLIVE CJA/ 24 EXI/ 24 10 ML', '9', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PALMOLIVE', 'PALMOLIVE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('851', '851', '', 'SHAMPOO  CAPRICE EXI/24 10 ML', '14', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('852', '852', '', 'SHAMPOO  PANTENE CJA/24 / 24 EXH', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PANTENE', 'PANTENE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('853', '853', '', 'SHAMPOO  PANTENE 48 PZA EXH', '8', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'PANTENE', 'PANTENE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('854', '854', '', 'SHAMPOO  ACTICERAMIDAS CAPRICE CJA/12 400 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('855', '855', '', 'SHAMPOO  ACTICERAMIDAS CAPRICE CJA/15 220 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('856', '856', '', 'SHAMPOO  HIDRATANTE PERT CJA/12 180 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PERT', 'PERT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('857', '857', '', 'SHAMPOO  MIEL Y GERMEN SEDAL CJA/6 200 ML', '7', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('858', '858', '', 'SHAMPOO  NECTAR DE MIEL MENNEN CJA/12 500 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('859', '859', '', 'SHAMPOO ACCION HUMECTANTE HEAD & SHOLDER CJA/12 400 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HEAD & SHOLDER', 'HEAD & SHOLDER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('860', '860', '', 'SHAMPOO CERAMIDAS SEDAL CJA/12 200 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('861', '861', '', 'SHAMPOO CERAMIDAS SEDAL CJA/6 200 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('862', '862', '', 'SHAMPOO CONTROL CAIDA CAPRICE CJA/15 220 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('863', '863', '', 'SHAMPOO CONTROL CAIDA CAPRICE CJA/12 400 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('864', '864', '', 'SHAMPOO COWCO DISNEY CJA/ 300 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DISNEY', 'DISNEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('865', '865', '', 'SHAMPOO DISNEY DISNEY CJA/ 300 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DISNEY', 'DISNEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('866', '866', '', 'SHAMPOO FAMILIA PERT CJA/12 180 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'PERT', 'PERT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('867', '867', '', 'SHAMPOO GERMEN DE TRIGO SEDAL CJA/12 350 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('868', '868', '', 'SHAMPOO HIDRATANTE ALERT CJA/12 400 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALERT', 'ALERT', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('869', '869', '', 'SHAMPOO LIMPIEZA RENOVADORA HEAD & SHOLDER CJA/12 200 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HEAD & SHOLDER', 'HEAD & SHOLDER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('870', '870', '', 'SHAMPOO MAXI GLOSS CAPRICE CJA/15 220 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('871', '871', '', 'SHAMPOO MAXI GLOSS CAPRICE CJA/ 400 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CAPRICE', 'CAPRICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('872', '872', '', 'SHAMPOO PUREZA BRILLO HEAD & SHOLDER CJA/12 400 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'HEAD & SHOLDER', 'HEAD & SHOLDER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('873', '873', '', 'SHAMPOO RECONSTRUCCION SEDAL CJA/12 200 ML', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('874', '874', '', 'SHAMPOO RIZOS OBEDIENTES SEDAL CJA/12 200 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('875', '875', '', 'SHAMPOO SOS CAIDA SEDAL CJA/12 200 ML', '5', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('876', '876', '', 'SHAMPOO SOS CERAMINAS SEDAL CJA/12 350 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SEDAL', 'SEDAL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('877', '877', '', 'SOPA CAMARON NISSIN CJA/ 12 PZA', '12', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('878', '878', '', 'SOPA CAMARON C/HABANERO NISSIN CJA/ 12 PZA', '8', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('879', '879', '', 'SOPA CAMARON HOT SAUCE NISSIN CJA/ 12 PZA', '10', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('880', '880', '', 'SOPA CAMARON PICANTE NISSIN CJA/ 12 PZA', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('881', '881', '', 'SOPA POLLO NISSIN CJA/ 12 PZA', '18', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('882', '882', '', 'SOPA POLLO C/HABANERO NISSIN CJA/ 12 PZA', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('883', '883', '', 'SOPA POLLO HOT SAUCE NISSIN CJA/ 12 PZA', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'NISSIN', 'NISSIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('884', '884', '', 'SOPA PREPARADA DE CODOS KNORR SUIZA  CJA/2 EXI 6 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('885', '885', '', 'SOPA PREPARADA DE ESTRELLAS KNORR SUIZA  CJA/2 EXI 6 PZA', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('886', '886', '', 'SOPA PREPARADA DE FIDEOS KNORR SUIZA  CJA/2 EXI 6 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('887', '887', '', 'SOPA PREPARADA DE LETRAS KNORR SUIZA  CJA/2 EXI 6 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('888', '888', '', 'SOPA PREPARADA FIDEOS C/POLLO KNORR SUIZA  CJA/2 EXI 6 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'KNORR SUIZA ', 'KNORR SUIZA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('889', '889', '', 'SUAVIZANTE ABRAZO AMOR SUAVITEL CJA/12 750 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('890', '890', '', 'SUAVIZANTE ABRAZO SOL SUAVITEL CJA/12 750 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('891', '891', '', 'SUAVIZANTE AQUA SUAVITEL CJA/24 450 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('892', '892', '', 'SUAVIZANTE AQUA SUAVITEL CJA/12 850 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('893', '893', '', 'SUAVIZANTE AROMA SOL SUAVITEL CJA/24 450 ML', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('894', '894', '', 'SUAVIZANTE AROMA SOL SUAVITEL CJA/12 850 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('895', '895', '', 'SUAVIZANTE BEBE ENSUEÑO CJA/12 500 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ENSUEÑO', 'ENSUEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('896', '896', '', 'SUAVIZANTE BEBE ENSUEÑO CJA/12 850 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ENSUEÑO', 'ENSUEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('897', '897', '', 'SUAVIZANTE BEBE SUAVITEL CJA/12 850 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('898', '898', '', 'SUAVIZANTE BESOS FLORES SUAVITEL CJA/12 750 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('899', '899', '', 'SUAVIZANTE ELEGANTE DOWNY CJA/12 850 ML', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DOWNY', 'DOWNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('900', '900', '', 'SUAVIZANTE FLOR DE LUNA DOWNY CJA/12 850 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DOWNY', 'DOWNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('901', '901', '', 'SUAVIZANTE FLORAL DOWNY CJA/12 450 ML', '1', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DOWNY', 'DOWNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('902', '902', '', 'SUAVIZANTE FLORAL DOWNY CJA/12 850 ML', '0', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DOWNY', 'DOWNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('903', '903', '', 'SUAVIZANTE FRESCA PRIMAVERA SUAVITEL CJA/12 850 ML', '3', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('904', '904', '', 'SUAVIZANTE FRESCO VERANO ENSUEÑO CJA/12 500 ML', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ENSUEÑO', 'ENSUEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('905', '905', '', 'SUAVIZANTE FRESCURA PRIMAVERAL ENSUEÑO CJA/12 850 ML', '9', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ENSUEÑO', 'ENSUEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('906', '906', '', 'SUAVIZANTE PRIMAVERA SUAVITEL CJA/24 450 ML', '2', '0', '0', 'SAMS COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SUAVITEL', 'SUAVITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('907', '907', '', 'SUAVIZANTE PRIMAVERAL MAX ENSUEÑO CJA/12 500 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ENSUEÑO', 'ENSUEÑO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('908', '908', '', 'SUAVIZANTE PUREZA SILVESTRE DOWNY CJA/12 850 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'DOWNY', 'DOWNY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('909', '909', '', 'SUPLEMENTO ALIMENT. ALOE PIÑA OMNILIFE PZA 200 ML', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('910', '910', '', 'SUPLEMENTO ALIMENT. CAFEE OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('911', '911', '', 'SUPLEMENTO ALIMENT. EGO 10 OMNILIFE PZA 200 ML', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('912', '912', '', 'SUPLEMENTO ALIMENT. EGO FRUTAS OMNILIFE CJA/24 LATA', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('913', '913', '', 'SUPLEMENTO ALIMENT. EGO LIFE OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('914', '914', '', 'SUPLEMENTO ALIMENT. FEM OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('915', '915', '', 'SUPLEMENTO ALIMENT. FIBER PLUS OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('916', '916', '', 'SUPLEMENTO ALIMENT. KOLINA OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('917', '917', '', 'SUPLEMENTO ALIMENT. MAGNUS OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('918', '918', '', 'SUPLEMENTO ALIMENT. MARACUYA OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('919', '919', '', 'SUPLEMENTO ALIMENT. OMNIPLUS            OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('920', '920', '', 'SUPLEMENTO ALIMENT. OMNIPLUS NARANJA OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('921', '921', '', 'SUPLEMENTO ALIMENT. ONE PER MEAL OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('922', '922', '', 'SUPLEMENTO ALIMENT. OPTIMUS OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('923', '923', '', 'SUPLEMENTO ALIMENT. OPTIMUS/ JAMAICA OMNILIFE PZA/ 200 ML', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('924', '924', '', 'SUPLEMENTO ALIMENT. POWER MAKER OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('925', '925', '', 'SUPLEMENTO ALIMENT. STAR BIEN OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('926', '926', '', 'SUPLEMENTO ALIMENT. THERMOGEN TE LIMON OMNILIFE CJA/30 ', '0', '0', '0', 'OMNILIFE  ', '', 'Pieza', '16', '0', '', '0.00', 'OMNILIFE', 'OMNILIFE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('927', '927', '', 'SUSTITUTO DE CREMA PARA CAFÉ MEMBERS M. PZA 1 KGS', '12', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'MEMBERS M.', 'MEMBERS M.', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('928', '928', '', 'TABLETAS EFERVECENTES ALKA SELTZ CJA/ 150 PZAS', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ALKA SELTZ', 'ALKA SELTZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('929', '929', '', 'TALCO ROSA Y AZAHARES CJA/ 250 GRS', '0', '0', '0', 'MADRES DE LA LUZ  ', '', 'Pieza', '16', '0', '', '0.00', 'ROSA Y AZAHARES', 'ROSA Y AZAHARES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('930', '930', '', 'TALCO ALCANFORADO LAS DOS CARAS CJA/ 150 GRS', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('931', '931', '', 'TALCO BEBE LAS DOS CARAS PZA 625 GRS', '9', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('932', '932', '', 'TALCO BEBE BABY POWDER PZA 600 GRS', '20', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'BABY POWDER', 'BABY POWDER', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('933', '933', '', 'TALCO BEBE LAS DOS CARAS CJA/24 150 GRS', '2', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('934', '934', '', 'TALCO PARA BEBE AZUL MENNEN CJA/24 200 GRS', '2', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('935', '935', '', 'TALCO PARA BEBE AZUL MENNEN CJA/ 100 GRS', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('936', '936', '', 'TALCO PARA BEBE ROSA MENNEN CJA/24 200 GRS', '1', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('937', '937', '', 'TALCO PARA BEBE ROSA MENNEN CJA/24 100 GRS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'MENNEN', 'MENNEN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('938', '938', '', 'TALCO TRADICIONAL LAS DOS CARAS PZA 625 GRS', '9', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('939', '939', '', 'TALCO TRADICIONAL LAS DOS CARAS CJA/10 125 GRS', '10', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('940', '940', '', 'TALCO TRADICIONAL LAS DOS CARAS CJA/16 250 GR', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LAS DOS CARAS', 'LAS DOS CARAS', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('941', '941', '', 'TAPA REYMA CJA/20 25 PZAS', '0', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'REYMA', 'REYMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('942', '942', '', 'TAPA DART CJA 500 PZA', '4', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'DART', 'DART', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('943', '943', '', 'TELA/MULTIUSOS  SCOTCH BRITE CJA/24 5 PZA', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'SCOTCH BRITE', 'SCOTCH BRITE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('944', '944', '', 'TELA/MULTIUSOS  MAGITEL CJA/24 5 PZA', '6', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'MAGITEL', 'MAGITEL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('945', '945', '', 'TENDEDERO RACALIN  ', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'RACALIN', 'RACALIN', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('946', '946', '', 'TENDEDERO   ', null, '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('947', '947', '', 'TENDEDERO CON GRAPA 2 HILOS SUPER  PQT/200 ', '1', '0', '0', 'MAREBA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('948', '948', '', 'TENEDOR PASTELERO FANTASY CJA/60 50 PZAS', '1', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'FANTASY', 'FANTASY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('949', '949', '', 'TOALLAS FEMENINAS  C/ALAS NATURELLA CJA/8 10 PZA', '19', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NATURELLA', 'NATURELLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('950', '950', '', 'TOALLAS FEMENINAS AMORE C/ALAS SABA CJA/ 10 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SABA', 'SABA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('951', '951', '', 'TOALLAS FEMENINAS AMORE S/ALAS SABA  CJA/10 8 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SABA ', 'SABA ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('952', '952', '', 'TOALLAS FEMENINAS BUENAS NOCHES SABA CJA/14 8 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SABA', 'SABA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('953', '953', '', 'TOALLAS FEMENINAS C/ALAS ALL DAY CJA/12 8 PZA', '0', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALL DAY', 'ALL DAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('954', '954', '', 'TOALLAS FEMENINAS C/ALAS NATURELLA CJA/4 42 PZA', '3', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NATURELLA', 'NATURELLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('955', '955', '', 'TOALLAS FEMENINAS CONFORT NOCTURNA C/ALAS SABA CJA/10 8 PZA', '16', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'SABA', 'SABA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('956', '956', '', 'TOALLAS FEMENINAS MANZANILLA /NOCTURNA KOTEX CJA/8 10 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOTEX', 'KOTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('957', '957', '', 'TOALLAS FEMENINAS MANZANILLA C/ALAS KOTEX CJA/10 10 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOTEX', 'KOTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('958', '958', '', 'TOALLAS FEMENINAS MANZANILLA S/ALAS KOTEX CJA/10 10 PZA', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOTEX', 'KOTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('959', '959', '', 'TOALLAS FEMENINAS NOCTURNA ALL DAY CJA/12 8 PZA', '0', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALL DAY', 'ALL DAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('960', '960', '', 'TOALLAS FEMENINAS NOCTURNA C/ALAS NATURELLA CJA/10 10 PZA', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NATURELLA', 'NATURELLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('961', '961', '', 'TOALLAS FEMENINAS NOCTURNA C/ALAS NATURELLA PZAA 10 PZA', '8', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NATURELLA', 'NATURELLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('962', '962', '', 'TOALLAS FEMENINAS NOCTURNA C/ALAS UNIKA CJA/8 10 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'UNIKA', 'UNIKA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('963', '963', '', 'TOALLAS FEMENINAS PANTIPROTECTORES KOTEX CJA/14 10 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOTEX', 'KOTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('964', '964', '', 'TOALLAS FEMENINAS S/ALAS ALL DAY CJA/12 8 PZA', '2', '0', '0', 'LA COSTEÑA COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ALL DAY', 'ALL DAY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('965', '965', '', 'TOALLAS FEMENINAS S/ALAS KOTEX CJA/12 10 PZA', '7', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'KOTEX', 'KOTEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('966', '966', '', 'TOALLAS FEMENINAS S/ALAS NATURELLA CJA/10 10 PZA', '10', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'NATURELLA', 'NATURELLA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('967', '967', '', 'TOALLAS FEMENINAS S/ALAS UNIKA CJA/ 8 PZA', '0', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'UNIKA', 'UNIKA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('968', '968', '', 'TOALLITAS HUMEDAS ABSORSEC CJA/24 70 PZA', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'ABSORSEC', 'ABSORSEC', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('969', '969', '', 'TRAMPA PEGAMENTO GOMATTON CJA/ 2 PZA', '0', '0', '0', 'TODO BARATO  ', '', 'Pieza', '16', '0', '', '0.00', 'GOMATTON', 'GOMATTON', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('970', '970', '', 'VAINILLA LOS CARDENALES CJA/ 148 ML', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LOS CARDENALES', 'LOS CARDENALES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('971', '971', '', 'VAINILLA LA ANITA CJA/ 230  ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('972', '972', '', 'VAINILLA LA FAVORITA CJA/12 1 LTS', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA FAVORITA', 'LA FAVORITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('973', '973', '', 'VAINILLA LA LEY CJA/24 145 ML', '1', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA LEY', 'LA LEY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('974', '974', '', 'VASO PLASTICO GELATINERO NUM.10 BOSCO PQT 50 PZA', '2', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('975', '975', '', 'VASO PLASTICO NUM 12 BOSCO CJA/20 50 PZAS', '1', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('976', '976', '', 'VASO PLASTICO NUM 5.5 BOSCO CJA/20 50 PZAS', '5', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('977', '977', '', 'VASO PLASTICO NUM. 10 BUEN HOGAR CJA/20 50 PZAS', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOGAR', 'BUEN HOGAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('978', '978', '', 'VASO PLASTICO NUM. 10 JAGUAR CJA/20 50 PZAS', '2', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('979', '979', '', 'VASO PLASTICO NUM. 16 BOSCO CJA/20 50 PZAS', '3', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('980', '980', '', 'VASO PLASTICO NUM. 16 DART  ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'DART', 'DART', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('981', '981', '', 'VASO PLASTICO NUM. 8 BOSCO CJA/20 50 PZAS', '4', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('982', '982', '', 'VASO PLASTICO NUM.10 BOSCO CJA/20 50 PZAS', '4', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('983', '983', '', 'VASO PLASTICO NUM.14 BOSCO CJA/20 50 PZAS', '3', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('984', '984', '', 'VASO PLASTICO NUM.14 DART PQT 20 PZA', '23', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'DART', 'DART', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('985', '985', '', 'VASO PLASTICO NUM.16 REYMA CJA/40 25 PZAS', '0', '0', '0', 'FERBAT  ', '', 'Pieza', '16', '0', '', '0.00', 'REYMA', 'REYMA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('986', '986', '', 'VASO PLASTICO NUM.5 A JAGUAR CJA/20 50 PZAS', '5', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('987', '987', '', 'VASO PLASTICO NUM.5.5 JAGUAR CJA/20 50 PZAS', '3', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('988', '988', '', 'VASO PLASTICO NUM.6 BOSCO CJA/20 50 PZAS', '8', '0', '0', ' COMA ALSA', '', 'Pieza', '16', '0', '', '0.00', 'BOSCO', 'BOSCO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('989', '989', '', 'VASO PLASTICO NUM.6 JAGUAR CJA/20 50 PZAS', '3', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('990', '990', '', 'VASO PLASTICO NUM.8 BUEN HOGAR CJA/ ', '0', '0', '0', '  SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'BUEN HOGAR', 'BUEN HOGAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('991', '991', '', 'VASO PLASTICO NUM.8 JAGUAR CJA/20 50 PZAS', '5', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'JAGUAR', 'JAGUAR', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('992', '992', '', 'VASO PLASTICO NUM.8 URPRI PQT 25 PZA', '4', '0', '0', 'JAGUAR  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'URPRI', 'URPRI', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('993', '993', '', 'VASO TERMICO NUM 10 CONVERMEX PQT 25 PZA', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('994', '994', '', 'VASO TERMICO NUM.32 CONVERMEX CJA/20 15 PZA', '0', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('995', '995', '', 'VASO TERMICO NUM.32 CONVERMEX PQT 15 PZA', '10', '0', '0', '  ALSA', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('996', '996', '', 'VASO TERMICO NUM.32 DART CAJ/20  20 PZA', '3', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'DART', 'DART', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('997', '997', '', 'VASO TERMICO NUM.32 DART PQT 15 PZA', '8', '0', '0', 'JAGUAR  ', '', 'Pieza', '16', '0', '', '0.00', 'DART', 'DART', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('998', '998', '', 'VASO TERMICO NUM.4 CONVERMEX PQT 15 PZA', '24', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'CONVERMEX', 'CONVERMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('999', '999', '', 'VELA CIRIO 300 LUZ ETERNA CAJ 24 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1000', '1000', '', 'VELA NUM.80 LUZ ETERNA CAJ 6 PZA', '6', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1001', '1001', '', 'VELADORA  7 DIAS SUPER EXTRA LUZ ETERNA CAJ 12 PZA', '6', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1002', '1002', '', 'VELADORA  7 DIAS TRICOLOR FAMA LUZ ETERNA CAJ 12 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1003', '1003', '', 'VELADORA 3 1/2 DIA ARAMO CAJ 12 PZA', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ARAMO', 'ARAMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1004', '1004', '', 'VELADORA 30 HRS ARAMO CAJ 24 PZA', '48', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'ARAMO', 'ARAMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1005', '1005', '', 'VELADORA ANGEL DE LA GUARDA LA GLORIA CAJ 12 PZA', '0', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA GLORIA', 'LA GLORIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1006', '1006', '', 'VELADORA CAFETERO SATURNO LUZ ETERNA CAJ 20 PZA', '8', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1007', '1007', '', 'VELADORA COLORAMA CHICO FAMA LUZ ETERNA CAJ 15 PZA', '9', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1008', '1008', '', 'VELADORA COSMOS AMARILLAS SIN MARCA CAJ 24 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1009', '1009', '', 'VELADORA COSMOS AZUL SIN MARCA CAJ 24 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1010', '1010', '', 'VELADORA COSMOS ROJO SIN MARCA CAJ 24 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1011', '1011', '', 'VELADORA COSMOS VERDE SIN MARCA CAJ 24 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1012', '1012', '', 'VELADORA CUBERO SATURNO LUZ ETERNA CAJ 20 PZA', '5', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1013', '1013', '', 'VELADORA DIVINO NIÑO ROSA  SIN MARCA CAJ 24 PZA', '3', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1014', '1014', '', 'VELADORA LECHERO AZUL FAMA LUZ ETERNA CAJ 20 PZA', '6', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1015', '1015', '', 'VELADORA LIMON FAMA LUZ ETERNA CAJ 20 PZA', '3', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1016', '1016', '', 'VELADORA LIMONCITO LUZ ETERNA CAJ 40 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1017', '1017', '', 'VELADORA LIMONERO SATURNO LUZ ETERNA CAJ 20 PZA', '3', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1018', '1018', '', 'VELADORA MARIANA DIVINO NIÑO LUZ ETERNA CAJ 20 PZA', '5', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1019', '1019', '', 'VELADORA MEDIA SEMANA LUZ ETERNA CAJ 12 PZA', '5', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1020', '1020', '', 'VELADORA MINI DE PLASTICO LUZ ETERNA CAJ 12 PZA', '7', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1021', '1021', '', 'VELADORA MORAS FAMA LUZ ETERNA CAJ 20 PZA', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1022', '1022', '', 'VELADORA MURALLA FAMA LUZ ETERNA CAJ 20 PZA', '3', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1023', '1023', '', 'VELADORA NORMANDIA COPA BLANCA LUZ ETERNA CAJ 20 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1024', '1024', '', 'VELADORA NORMANDIA COPA ROJA FAMA LUZ ETERNA CAJ 20 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1025', '1025', '', 'VELADORA PECERA AZUL SIN MARCA CAJ 24 PZA', '3', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1026', '1026', '', 'VELADORA PECERA VERDE SIN MARCA CAJ 24 PZA', '2', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1027', '1027', '', 'VELADORA QUIMERA LUZ ETERNA CAJ 20 PZA', '5', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1028', '1028', '', 'VELADORA REPUESTO ARAMO CAJ 12 PZA', '17', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'ARAMO', 'ARAMO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1029', '1029', '', 'VELADORA REPUESTO CHICA JESUS LA LUZ CAJ 100 PZA', '4', '0', '0', ' SAHUAYO ', '', 'Pieza', '16', '0', '', '0.00', 'JESUS LA LUZ', 'JESUS LA LUZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1030', '1030', '', 'VELADORA REPUESTO GRANDE JESUS LA LUZ CAJ 40 PZA', '4', '0', '0', ' SAHUAYO ', '', 'Pieza', '16', '0', '', '0.00', 'JESUS LA LUZ', 'JESUS LA LUZ', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1031', '1031', '', 'VELADORA REPUESTO NUM.12 LUZ ETERNA CAJ 40 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1032', '1032', '', 'VELADORA REPUESTO NUM.14 LUZ ETERNA CAJ 40 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1033', '1033', '', 'VELADORA REPUESTO NUM.14 SANTA FE LUZ ETERNA CAJ 100 PZA', '11', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1034', '1034', '', 'VELADORA REPUESTO NUM.21 LUZ ETERNA CAJ 40 PZA', '7', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1035', '1035', '', 'VELADORA REPUESTO NUM.6 SANTA FE LUZ ETERNA CAJ 100 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1036', '1036', '', 'VELADORA ROSITA  SATURNO LUZ ETERNA CAJ 20 PZA', '0', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1037', '1037', '', 'VELADORA ROSITA AZUL LUZ ETERNA CAJ 20 PZA', '7', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1038', '1038', '', 'VELADORA SAN TOÑITO LA GLORIA CAJ 12 PZA', '3', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA GLORIA', 'LA GLORIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1039', '1039', '', 'VELADORA SEMANAL MILENIO LUZ ETERNA CAJ 12 PZA', '4', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1040', '1040', '', 'VELADORA VIRGEN TRICOLOR VASO REGIO SIN MARCA CAJ 24 PZA', '22', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'SIN MARCA', 'SIN MARCA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1041', '1041', '', 'VELADORA VIRGENCITA LA LUPITA LA GLORIA CAJ 12 PZA', '5', '0', '0', ' COMA ', '', 'Pieza', '16', '0', '', '0.00', 'LA GLORIA', 'LA GLORIA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1042', '1042', '', 'VELADORA VOTIVO LUZ ETERNA CAJ 40 PZA', '5', '0', '0', 'BERNES  ', '', 'Pieza', '16', '0', '', '0.00', 'LUZ ETERNA', 'LUZ ETERNA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1043', '1043', '', 'VINAGRE BLANCO LOS.CARDENALES PZA 3.780 LTS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'LOS.CARDENALES', 'LOS.CARDENALES', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1044', '1044', '', 'VINAGRE BLANCO CLEMENTE J CJA/4 3.800 LTS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLEMENTE J', 'CLEMENTE J', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1045', '1045', '', 'VINAGRE BLANCO CLEMENTE J CJA/12 1 LTS', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLEMENTE J', 'CLEMENTE J', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1046', '1046', '', 'VINAGRE BLANCO CLEMENTE J CJA/24 500 ML', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'CLEMENTE J', 'CLEMENTE J', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1047', '1047', '', 'VINAGRE LA COCINERA GARY CJA/4 3.785 LTS', '1', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1048', '1048', '', 'VINAGRE LA COCINERA GARY CJA/20 500 ML', '2', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1049', '1049', '', 'VINAGRE LA COCINERA GARY CJA/12 1 LTS', '4', '0', '0', ' COMA SAHUAYO', '', 'Pieza', '16', '0', '', '0.00', 'GARY', 'GARY', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1050', '1050', '', 'VINAGRE MANZANA LA ANITA CJA/24 500 ML', '0', '0', '0', 'LA ANITA  ', '', 'Pieza', '16', '0', '', '0.00', 'LA ANITA', 'LA ANITA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1058', '1058', '', 'AJONJOLI  KILO ', '1', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1059', '1059', '', 'ALIMENTO GATO CAT CHOISE  SACO 10 KGS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1060', '1060', '', 'ALIMENTO GATO WISKAS  SACO 20 KGS', '1', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1061', '1061', '', 'ALIMENTO PARA PERRO/CACHORRO SPORT  MAN\'S CHOICE SACO 10 KGS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SPORT  MAN\'S CHOICE', 'SPORT  MAN\'S CHOICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1062', '1062', '', 'ALIMENTO PARA PERRO/RES/SACO AZUL SPORT  MAN\'S CHOICE SACO 25 KGS', '9', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SPORT  MAN\'S CHOICE', 'SPORT  MAN\'S CHOICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1063', '1063', '', 'ALIMENTO PARA PERRO/TROZO/SACO AMARILLO SPORT  MAN\'S CHOICE SACO 25 KGS', '10', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'SPORT  MAN\'S CHOICE', 'SPORT  MAN\'S CHOICE', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1064', '1064', '', 'ALMENDRAS  KILO ', '2', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1065', '1065', '', 'ALPISTE  KILO ', '55.2', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1066', '1066', '', 'ARROZ  SACO 50 KGS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1067', '1067', '', 'ARROZ  SACO 25 KGS', '40', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1068', '1068', '', 'AVENA  SACO 20 KGS', '7', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1069', '1069', '', 'AZUCAR ESTÁNDAR  SACO 50 KGS', '24', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1070', '1070', '', 'AZUCAR REFINADA  SACO 50 KGS', '5', '0', '0', 'CORPORATIVO SURESTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1071', '1071', '', 'CACAHUATES   ', '1.5', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1072', '1072', '', 'CANELA EN RAJA  KILO ', '7', '0', '0', 'ALAMILLA YAEL ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1073', '1073', '', 'CANELA MOLIDA   KILO', '4', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1074', '1074', '', 'CEBADA  SACO 25 KGS', '1', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1075', '1075', '', 'CHICHARRONES PAPA MINI CUA  SACO 15 KGS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1076', '1076', '', 'CHICHARRONES PAPA MINI RUE  SACO 15 KGS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1077', '1077', '', 'CHICHARRONES PAPA REJA  SACO 15 KGS', '1', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1078', '1078', '', 'CHICHARRONES TRIGO 10 X10 PALMEX CJA ', '0', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', 'PALMEX', 'PALMEX', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1079', '1079', '', 'CHICHARRONES TRIGO ANILLO  SACO 20 KGS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1080', '1080', '', 'CHICHARRONES TRIGO DONA  SACO 20 KGS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1081', '1081', '', 'CHICHARRONES TRIGO MINI CUA  SACO 20 KGS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1082', '1082', '', 'CHICHARRONES TRIGO MINI RUE  SACO 20 KGS', '4', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1083', '1083', '', 'CHICHARRONES TRIGO OLA  SACO 20 KGS', '3', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1084', '1084', '', 'CHICHARRONES TRIGO PESCADO  SACO 20 KGS', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1085', '1085', '', 'CHICHARRONES TRIGO REJA  SACO 20 KGS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1086', '1086', '', 'CHILE ANCHO  KILO ', '1.5', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1087', '1087', '', 'CHILE GUAJILLO  KILO ', '1', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1088', '1088', '', 'CHILE MOLIDO  KILO ', '2', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1089', '1089', '', 'CHILE PASILLA  KILO ', '4', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1090', '1090', '', 'CHILE PIKIN  KILO ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1091', '1091', '', 'CHILE SECO  KILO ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1092', '1092', '', 'CONTENEDOR DE LITRO   ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1093', '1093', '', 'CONTENEDOR DE MEDIO   ', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1094', '1094', '', 'EMPANIZADO GRANULADO  CAJ/8 8 PZA', '0', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1095', '1095', '', 'ENDULZANTE CANDEREL CAJA 700 PZA', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'CANDEREL', 'CANDEREL', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1096', '1096', '', 'ENDULZANTE  SPLENDA CAJA 600 PZA', '5', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', 'SPLENDA', 'SPLENDA', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1097', '1097', '', 'ENGORDA PAVO  SACO/ ', '2', '0', '0', 'LORGAN  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1098', '1098', '', 'ENGORDA POLLO  SACO/ S', '0', '0', '0', 'LORGAN  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1099', '1099', '', 'FRIJOL A GRANEL  SACO 50 KGS', '12', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1100', '1100', '', 'FRIJOL BAYO  SACO 50 KGS', '1', '0', '0', 'CORPORATIVO SURESTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1101', '1101', '', 'FRIJOL BLANCO  SACO 44.400 KGS', '1', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1102', '1102', '', 'FRIJOL NEGRO EMBOLSADO DE 450 GRANO DE ORO SACO/30 450 KGS', '7', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'GRANO DE ORO', 'GRANO DE ORO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1103', '1103', '', 'FRIJOL NEGRO EMBOLSADO DE 900 GRANO DE ORO SACO/40 900 KGS', '22', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', 'GRANO DE ORO', 'GRANO DE ORO', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1104', '1104', '', 'FRIJOL ROJO   ', '0', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1105', '1105', '', 'FRIJOL ROSITA  SACO/45 45 KGS', '2', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1106', '1106', '', 'GARBANZO GRANDE  SACO 20 KGS', '10', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1107', '1107', '', 'HARINA  SACO 44 KGS', '14', '0', '0', 'COMERCIALIZADORA MAYORISTA DEL GOLFO  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1108', '1108', '', 'HOJAS DE ELOTE  SACO ', '3', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1109', '1109', '', 'INICIO PAVO  SACO 40 KGS', '2', '0', '0', 'LORGAN  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1110', '1110', '', 'INICIO POLLO  SACO 40 KGS', '1', '0', '0', 'LORGAN  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1111', '1111', '', 'JAMAICA  SACO ', '27.7', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1112', '1112', '', 'LENTEJA CHICA  SACO 46.400 KGS', '46.75', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1113', '1113', '', 'LENTEJA GRANDE  SACO 45.600 KGS', '1.125', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1114', '1114', '', 'LUNETAS  SACO 5 KGS', '1', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1115', '1115', '', 'MAIZ PALOMERO  SACO ', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1116', '1116', '', 'MOLE CUBETA   ', '14', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1117', '1117', '', 'PAPEL ENVOLTURA  SACO 50 KGS', '3', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1118', '1118', '', 'PAN MOLIDO  SACO 35 KGS', '2', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1119', '1119', '', 'PEDIGREE MEAL TIME  SACO 20 KGS', '0', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1120', '1120', '', 'PEDIGREE PUPPY  SACO 20 KGS', '3', '0', '0', 'SAMS  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1121', '1121', '', 'PIMIENTA EN GRANO  KILO ', '1.5', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1122', '1122', '', 'PIMIENTA MOLIDA  KILO ', '4', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1123', '1123', '', 'POLEGIA  SACO 25 KGS', '3', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1124', '1124', '', 'POLVO PARA HORNEAR  KILO ', '13', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1125', '1125', '', 'SAGU  SACO 25 KGS', '0', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1126', '1126', '', 'SAL DE 1/2  SACO 50 KGS', '0', '0', '0', 'CORPORATIVO SURESTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1127', '1127', '', 'SAL DE KG  SACO 25 KGS', '12', '0', '0', '  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1128', '1128', '', 'SAL EN GRANO  SACO 25 KGS', '2', '0', '0', 'CORPORATIVO SURESTE  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1129', '1129', '', 'SEMILLA DE GIRASOL   ', '1', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1130', '1130', '', 'SOYA  GRANULADA  SACO ', '0.5', '0', '0', ' YAEL ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');
INSERT INTO `catProductos` VALUES ('1131', '1131', '', 'TRIGO  SACO 22.700 KGS', '1.5', '0', '0', 'ALAMILLA  ', '', 'Pieza', '16', '0', '', '0.00', '', '', '0', '', '2010-11-20 00:00:00', '0', 'admin');

-- ----------------------------
-- Table structure for `catProveedores`
-- ----------------------------
DROP TABLE IF EXISTS `catProveedores`;
CREATE TABLE `catProveedores` (
  `IdProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Direccion` text,
  `Fax` varchar(50) DEFAULT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `RFC` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contacto` text,
  `ciudad` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catProveedores
-- ----------------------------
INSERT INTO `catProveedores` VALUES ('3', 'SAMS', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('4', 'COMA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('5', 'SAHUAYO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('6', 'SURTIDORA DEL ORIENTE', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('7', 'SURTIDORA FARMACEUTICA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('8', 'LA EXTRA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('9', 'LA ANITA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('10', 'HERDEZ', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('11', 'PROALMEX', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('12', 'MEXICANA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('13', 'DESECHABLES MARTIN', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('14', 'OMNILIFE', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('15', 'AKI GRAN MAYOREO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('16', 'ABRAHAM', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('17', 'DON FERNANDO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('18', 'BOLSAS PLASTICAS', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('19', 'BEDA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('20', 'MAREBA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('21', 'MICHEL', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('22', 'KELLOGS', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('23', 'YAEL', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('24', 'YUCALPETEN', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('25', 'ALSA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('26', 'LA COSTEÃ‘A', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('27', 'MARLBORO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('28', 'CORONA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('29', 'JAGUAR', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('30', 'DONDE', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('31', 'GAMESA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('32', 'PROTEINAS Y OLEICO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('33', 'ALAMILLA', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('34', 'JUAN MOO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('35', 'SABRITAS', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('36', 'MADRES DE LA LUZ', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('37', 'TODO BARATO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('38', 'FERBAT', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('39', 'BERNES', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('40', 'CORPORATIVO SURESTE', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('41', 'LORGAN', '', '', '', '', '2011-02-10 00:00:00', '', '', '');
INSERT INTO `catProveedores` VALUES ('42', 'COMERCIALIZADORA MAYORISTA DEL GOLFO', '', '', '', '', '2011-02-10 00:00:00', '', '', '');

-- ----------------------------
-- Table structure for `catUsuarios`
-- ----------------------------
DROP TABLE IF EXISTS `catUsuarios`;
CREATE TABLE `catUsuarios` (
  `iidusuario` int(11) NOT NULL AUTO_INCREMENT,
  `clogin` varchar(64) NOT NULL,
  `cclave` varchar(64) DEFAULT NULL,
  `cnombre` varchar(64) DEFAULT NULL,
  `cacceso` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`iidusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catUsuarios
-- ----------------------------
INSERT INTO `catUsuarios` VALUES ('1', 'mikem', '123', 'Miguel Mota', 'Administrador');
INSERT INTO `catUsuarios` VALUES ('2', 'peraza', '1234', 'peraza', 'Administrador');

-- ----------------------------
-- Table structure for `confConsFactura`
-- ----------------------------
DROP TABLE IF EXISTS `confConsFactura`;
CREATE TABLE `confConsFactura` (
  `ConsFactura` int(11) DEFAULT NULL,
  `ConsNota` int(11) DEFAULT NULL,
  `ConsPago` int(11) DEFAULT NULL,
  `ConsNotaCred` int(11) DEFAULT NULL,
  `ConsOrdenesCompra` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confConsFactura
-- ----------------------------
INSERT INTO `confConsFactura` VALUES ('1', '1', '1', '1', '1');
INSERT INTO `confConsFactura` VALUES (null, null, null, null, '4');

-- ----------------------------
-- Table structure for `confDocsPrint`
-- ----------------------------
DROP TABLE IF EXISTS `confDocsPrint`;
CREATE TABLE `confDocsPrint` (
  `TipoDoc` varchar(50) NOT NULL DEFAULT '',
  `PosNombre` varchar(50) DEFAULT NULL,
  `PosDireccion` varchar(50) DEFAULT NULL,
  `PosCiudad` varchar(50) DEFAULT NULL,
  `PosRFC` varchar(50) DEFAULT NULL,
  `PosNumFact` varchar(50) DEFAULT NULL,
  `PosFecha` varchar(50) DEFAULT NULL,
  `PosCodigo` varchar(50) DEFAULT NULL,
  `PosCantidad` varchar(50) DEFAULT NULL,
  `PosDescripcion` varchar(50) DEFAULT NULL,
  `PosPrecio` varchar(50) DEFAULT NULL,
  `PosTotal` varchar(50) DEFAULT NULL,
  `PosSubtotal` varchar(50) DEFAULT NULL,
  `PosIVA` varchar(50) DEFAULT NULL,
  `PosGTotal` varchar(50) DEFAULT NULL,
  `PosGTotalLetras` varchar(50) DEFAULT NULL,
  `EspacioDetalle` varchar(50) DEFAULT NULL,
  `TamanioLetra` varchar(50) DEFAULT NULL,
  `Leyenda` text,
  `mensaje` varchar(50) DEFAULT NULL,
  `PosCadenaOriginal` varchar(50) DEFAULT NULL,
  `PosSello` varchar(50) DEFAULT NULL,
  `EncabezadoNota` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`TipoDoc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confDocsPrint
-- ----------------------------
INSERT INTO `confDocsPrint` VALUES ('001', '150,173', '147,205', '140,240', '640,173', '710,118', '550,240', '-1,-1', '45,320', '150,320', '530,320', '670,320', '670,900', '670,928', '670,960', '45,910', '12', '7', 'IPC', '....', '-1,-1', '-1,-1', '');
INSERT INTO `confDocsPrint` VALUES ('002', '10,110', '-1,-1', '-1,-1', '-1,-1', '190,130', '5,130', '1,150', '80,150', '120,150', '-1,-1', '230,150', '190,-2', '190,-2', '190,-2', '3,-2', '10', '8', 'AUTOREFACCIONARIA GONZALEZ', 'GRACIAS POR SU COMPRA', '-1,-1', '-1,-1', 'RICARDO ARIEL PERAZA ALEJOS|PEAR720718AW5|CURP PEAR720718HYNRLC02|CALLE 16 X 13 Y 15 NUM 89 B CHUMINOPOLIS YUCATAN 97158|Depto. 3 x 20  C.P 97175|Otra linea mas|Tel 9991671111');
INSERT INTO `confDocsPrint` VALUES ('003', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '15', '7', 'Su empresa', '....', '-1,-1', '-1,-1', '');
INSERT INTO `confDocsPrint` VALUES ('NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', null, null, null);

-- ----------------------------
-- Table structure for `confFacturaElectronica`
-- ----------------------------
DROP TABLE IF EXISTS `confFacturaElectronica`;
CREATE TABLE `confFacturaElectronica` (
  `iidconfsystem` int(11) NOT NULL,
  `Version` varchar(16) DEFAULT NULL,
  `Serie` varchar(256) DEFAULT NULL,
  `Numero_de_Aprobacion` varchar(256) DEFAULT NULL,
  `Anio_Aprobacion` varchar(256) DEFAULT NULL,
  `Tipo_de_Comprobante` varchar(256) DEFAULT NULL,
  `RFC` varchar(256) DEFAULT NULL,
  `Razon_Social` varchar(256) DEFAULT NULL,
  `Calle` varchar(256) DEFAULT NULL,
  `Numero_Exterior` varchar(256) DEFAULT NULL,
  `Numero_Interior` varchar(256) DEFAULT NULL,
  `Colonia` varchar(256) DEFAULT NULL,
  `Localidad` varchar(256) DEFAULT NULL,
  `Referencia` varchar(256) DEFAULT NULL,
  `Municipio` varchar(256) DEFAULT NULL,
  `Estado` varchar(256) DEFAULT NULL,
  `Pais` varchar(256) DEFAULT NULL,
  `Codigo_Postal` varchar(256) DEFAULT NULL,
  `Numero_Certificado` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`iidconfsystem`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confFacturaElectronica
-- ----------------------------
INSERT INTO `confFacturaElectronica` VALUES ('1', '2.0', 'A', '49', '2008', 'ingreso', 'PEAR720718AW5', 'RICARDO ARIEL PERAZA ALEJOS', '29', '329', '329', 'Chuminopolis', 'Merida', '', 'Merida', 'Yucatan', 'Mexico', '97117', '20001000000100000377');

-- ----------------------------
-- Table structure for `confSystem`
-- ----------------------------
DROP TABLE IF EXISTS `confSystem`;
CREATE TABLE `confSystem` (
  `iidconfsystem` int(11) NOT NULL AUTO_INCREMENT,
  `CodTienda` varchar(50) NOT NULL,
  `IVA` varchar(50) DEFAULT NULL,
  `ClienteNotas` varchar(50) DEFAULT NULL,
  `clave` varchar(50) DEFAULT NULL,
  `CopiasFactura` int(11) DEFAULT NULL,
  `UsarIvaPorArtic` int(11) DEFAULT NULL,
  `ModeDocs` int(11) DEFAULT NULL,
  `DesglosarIva` int(11) DEFAULT NULL,
  `UsarFactElec` int(11) DEFAULT '0',
  `UsarExistencia0` int(11) DEFAULT '0',
  PRIMARY KEY (`iidconfsystem`,`CodTienda`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confSystem
-- ----------------------------
INSERT INTO `confSystem` VALUES ('1', '001', '0.16', 'CLIENTE DE MOSTRADOR', null, '1', '1', '1', '1', '0', '1');

-- ----------------------------
-- Table structure for `detConsolidacionFactura`
-- ----------------------------
DROP TABLE IF EXISTS `detConsolidacionFactura`;
CREATE TABLE `detConsolidacionFactura` (
  `iidconsolidacion` int(11) NOT NULL,
  `iidnota` int(11) NOT NULL,
  PRIMARY KEY (`iidconsolidacion`,`iidnota`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detConsolidacionFactura
-- ----------------------------

-- ----------------------------
-- Table structure for `detCorte`
-- ----------------------------
DROP TABLE IF EXISTS `detCorte`;
CREATE TABLE `detCorte` (
  `iidDetCorte` int(11) NOT NULL AUTO_INCREMENT,
  `iidCorte` int(11) NOT NULL,
  `IdFactura` int(11) NOT NULL,
  `cNumero` varchar(50) DEFAULT NULL,
  `dtFecha` datetime DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `esfactura` int(1) NOT NULL,
  PRIMARY KEY (`iidDetCorte`,`iidCorte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detCorte
-- ----------------------------

-- ----------------------------
-- Table structure for `detFactura`
-- ----------------------------
DROP TABLE IF EXISTS `detFactura`;
CREATE TABLE `detFactura` (
  `IdDetFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdFactura` int(11) NOT NULL DEFAULT '0',
  `IdProducto` int(11) NOT NULL DEFAULT '0',
  `PrecioOriginal` float DEFAULT NULL,
  `PrecioDescuento` float DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `PrecioCalculado` float DEFAULT NULL,
  `DescuentoAplicado` float DEFAULT NULL,
  `unidaddeventa` varchar(50) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdDetFactura`,`IdFactura`,`IdProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detFactura
-- ----------------------------

-- ----------------------------
-- Table structure for `detFacturasProv`
-- ----------------------------
DROP TABLE IF EXISTS `detFacturasProv`;
CREATE TABLE `detFacturasProv` (
  `IdDetFacturaProv` int(11) NOT NULL AUTO_INCREMENT,
  `IdProveedor` int(11) NOT NULL,
  `Numero` varchar(50) NOT NULL,
  `Fecha` datetime DEFAULT NULL,
  `TotalFactura` float DEFAULT NULL,
  `Pagado` float DEFAULT NULL,
  `FechaPago` datetime DEFAULT NULL,
  PRIMARY KEY (`IdDetFacturaProv`,`IdProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detFacturasProv
-- ----------------------------

-- ----------------------------
-- Table structure for `detNota`
-- ----------------------------
DROP TABLE IF EXISTS `detNota`;
CREATE TABLE `detNota` (
  `IdDetFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdFactura` int(11) NOT NULL,
  `IdProducto` int(11) DEFAULT NULL,
  `PrecioOriginal` float DEFAULT NULL,
  `PrecioDescuento` float DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `PrecioCalculado` float DEFAULT NULL,
  `DescuentoAplicado` float DEFAULT NULL,
  `unidaddeventa` varchar(50) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdDetFactura`,`IdFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detNota
-- ----------------------------

-- ----------------------------
-- Table structure for `detOrdenesCompra`
-- ----------------------------
DROP TABLE IF EXISTS `detOrdenesCompra`;
CREATE TABLE `detOrdenesCompra` (
  `IdDetOrdenCompra` int(11) NOT NULL AUTO_INCREMENT,
  `IdOrdenCompra` int(11) NOT NULL DEFAULT '0',
  `IdProducto` int(11) NOT NULL DEFAULT '0',
  `Cantidad` float DEFAULT NULL,
  `Importe` float DEFAULT NULL,
  `Iva` float(11,0) DEFAULT NULL,
  PRIMARY KEY (`IdDetOrdenCompra`,`IdOrdenCompra`,`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detOrdenesCompra
-- ----------------------------

-- ----------------------------
-- Table structure for `detPagosFacturas`
-- ----------------------------
DROP TABLE IF EXISTS `detPagosFacturas`;
CREATE TABLE `detPagosFacturas` (
  `IdPago` int(11) NOT NULL AUTO_INCREMENT,
  `esfactura` int(11) NOT NULL DEFAULT '1',
  `IdFactura` int(11) NOT NULL,
  `NumeroPago` varchar(50) DEFAULT NULL,
  `FechaPago` datetime DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `Observaciones` varchar(128) DEFAULT NULL,
  `TipoPago` int(11) DEFAULT NULL,
  `cancelado` int(11) DEFAULT '0',
  `numeronotacred` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdPago`,`esfactura`,`IdFactura`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detPagosFacturas
-- ----------------------------

-- ----------------------------
-- Table structure for `hoja2$_erroresdeimportación`
-- ----------------------------
DROP TABLE IF EXISTS `hoja2$_erroresdeimportación`;
CREATE TABLE `hoja2$_erroresdeimportación` (
  `Campo` varchar(255) DEFAULT NULL,
  `Error` varchar(255) DEFAULT NULL,
  `Fila` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of hoja2$_erroresdeimportación
-- ----------------------------

-- ----------------------------
-- Table structure for `relProductoProveedor`
-- ----------------------------
DROP TABLE IF EXISTS `relProductoProveedor`;
CREATE TABLE `relProductoProveedor` (
  `IdProducto` int(11) NOT NULL,
  `IdProveedor` int(11) NOT NULL,
  PRIMARY KEY (`IdProducto`,`IdProveedor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of relProductoProveedor
-- ----------------------------
INSERT INTO `relProductoProveedor` VALUES ('2', '32');
INSERT INTO `relProductoProveedor` VALUES ('3', '3');
INSERT INTO `relProductoProveedor` VALUES ('3', '4');
INSERT INTO `relProductoProveedor` VALUES ('3', '5');
INSERT INTO `relProductoProveedor` VALUES ('4', '3');
INSERT INTO `relProductoProveedor` VALUES ('4', '4');
INSERT INTO `relProductoProveedor` VALUES ('4', '5');
INSERT INTO `relProductoProveedor` VALUES ('5', '3');
INSERT INTO `relProductoProveedor` VALUES ('5', '4');
INSERT INTO `relProductoProveedor` VALUES ('7', '3');
INSERT INTO `relProductoProveedor` VALUES ('10', '4');
INSERT INTO `relProductoProveedor` VALUES ('11', '4');
INSERT INTO `relProductoProveedor` VALUES ('12', '4');
INSERT INTO `relProductoProveedor` VALUES ('12', '5');
INSERT INTO `relProductoProveedor` VALUES ('13', '4');
INSERT INTO `relProductoProveedor` VALUES ('13', '5');
INSERT INTO `relProductoProveedor` VALUES ('14', '4');
INSERT INTO `relProductoProveedor` VALUES ('14', '5');
INSERT INTO `relProductoProveedor` VALUES ('15', '4');
INSERT INTO `relProductoProveedor` VALUES ('16', '6');
INSERT INTO `relProductoProveedor` VALUES ('16', '7');
INSERT INTO `relProductoProveedor` VALUES ('17', '6');
INSERT INTO `relProductoProveedor` VALUES ('17', '7');
INSERT INTO `relProductoProveedor` VALUES ('18', '8');
INSERT INTO `relProductoProveedor` VALUES ('19', '8');
INSERT INTO `relProductoProveedor` VALUES ('20', '5');
INSERT INTO `relProductoProveedor` VALUES ('21', '5');
INSERT INTO `relProductoProveedor` VALUES ('22', '5');
INSERT INTO `relProductoProveedor` VALUES ('23', '9');
INSERT INTO `relProductoProveedor` VALUES ('24', '9');
INSERT INTO `relProductoProveedor` VALUES ('25', '4');
INSERT INTO `relProductoProveedor` VALUES ('26', '7');
INSERT INTO `relProductoProveedor` VALUES ('27', '7');
INSERT INTO `relProductoProveedor` VALUES ('28', '5');
INSERT INTO `relProductoProveedor` VALUES ('29', '5');
INSERT INTO `relProductoProveedor` VALUES ('30', '5');
INSERT INTO `relProductoProveedor` VALUES ('31', '5');
INSERT INTO `relProductoProveedor` VALUES ('32', '3');
INSERT INTO `relProductoProveedor` VALUES ('33', '3');
INSERT INTO `relProductoProveedor` VALUES ('34', '3');
INSERT INTO `relProductoProveedor` VALUES ('35', '4');
INSERT INTO `relProductoProveedor` VALUES ('35', '5');
INSERT INTO `relProductoProveedor` VALUES ('35', '9');
INSERT INTO `relProductoProveedor` VALUES ('36', '4');
INSERT INTO `relProductoProveedor` VALUES ('36', '5');
INSERT INTO `relProductoProveedor` VALUES ('36', '9');
INSERT INTO `relProductoProveedor` VALUES ('37', '4');
INSERT INTO `relProductoProveedor` VALUES ('37', '5');
INSERT INTO `relProductoProveedor` VALUES ('37', '9');
INSERT INTO `relProductoProveedor` VALUES ('38', '4');
INSERT INTO `relProductoProveedor` VALUES ('38', '5');
INSERT INTO `relProductoProveedor` VALUES ('38', '9');
INSERT INTO `relProductoProveedor` VALUES ('39', '4');
INSERT INTO `relProductoProveedor` VALUES ('39', '5');
INSERT INTO `relProductoProveedor` VALUES ('39', '9');
INSERT INTO `relProductoProveedor` VALUES ('40', '4');
INSERT INTO `relProductoProveedor` VALUES ('40', '5');
INSERT INTO `relProductoProveedor` VALUES ('40', '9');
INSERT INTO `relProductoProveedor` VALUES ('41', '4');
INSERT INTO `relProductoProveedor` VALUES ('41', '5');
INSERT INTO `relProductoProveedor` VALUES ('41', '9');
INSERT INTO `relProductoProveedor` VALUES ('43', '4');
INSERT INTO `relProductoProveedor` VALUES ('43', '5');
INSERT INTO `relProductoProveedor` VALUES ('43', '9');
INSERT INTO `relProductoProveedor` VALUES ('44', '4');
INSERT INTO `relProductoProveedor` VALUES ('44', '5');
INSERT INTO `relProductoProveedor` VALUES ('44', '9');
INSERT INTO `relProductoProveedor` VALUES ('45', '3');
INSERT INTO `relProductoProveedor` VALUES ('46', '6');
INSERT INTO `relProductoProveedor` VALUES ('46', '7');
INSERT INTO `relProductoProveedor` VALUES ('47', '5');
INSERT INTO `relProductoProveedor` VALUES ('48', '5');
INSERT INTO `relProductoProveedor` VALUES ('49', '10');
INSERT INTO `relProductoProveedor` VALUES ('50', '3');
INSERT INTO `relProductoProveedor` VALUES ('50', '4');
INSERT INTO `relProductoProveedor` VALUES ('51', '3');
INSERT INTO `relProductoProveedor` VALUES ('51', '4');
INSERT INTO `relProductoProveedor` VALUES ('51', '5');
INSERT INTO `relProductoProveedor` VALUES ('52', '10');
INSERT INTO `relProductoProveedor` VALUES ('53', '3');
INSERT INTO `relProductoProveedor` VALUES ('53', '4');
INSERT INTO `relProductoProveedor` VALUES ('54', '3');
INSERT INTO `relProductoProveedor` VALUES ('54', '5');
INSERT INTO `relProductoProveedor` VALUES ('55', '3');
INSERT INTO `relProductoProveedor` VALUES ('55', '5');
INSERT INTO `relProductoProveedor` VALUES ('56', '3');
INSERT INTO `relProductoProveedor` VALUES ('57', '4');
INSERT INTO `relProductoProveedor` VALUES ('58', '11');
INSERT INTO `relProductoProveedor` VALUES ('59', '11');
INSERT INTO `relProductoProveedor` VALUES ('60', '11');
INSERT INTO `relProductoProveedor` VALUES ('61', '11');
INSERT INTO `relProductoProveedor` VALUES ('62', '5');
INSERT INTO `relProductoProveedor` VALUES ('63', '12');
INSERT INTO `relProductoProveedor` VALUES ('64', '4');
INSERT INTO `relProductoProveedor` VALUES ('65', '9');
INSERT INTO `relProductoProveedor` VALUES ('66', '12');
INSERT INTO `relProductoProveedor` VALUES ('67', '3');
INSERT INTO `relProductoProveedor` VALUES ('68', '13');
INSERT INTO `relProductoProveedor` VALUES ('69', '5');
INSERT INTO `relProductoProveedor` VALUES ('76', '3');
INSERT INTO `relProductoProveedor` VALUES ('76', '5');
INSERT INTO `relProductoProveedor` VALUES ('78', '4');
INSERT INTO `relProductoProveedor` VALUES ('78', '5');
INSERT INTO `relProductoProveedor` VALUES ('79', '3');
INSERT INTO `relProductoProveedor` VALUES ('80', '3');
INSERT INTO `relProductoProveedor` VALUES ('81', '3');
INSERT INTO `relProductoProveedor` VALUES ('82', '3');
INSERT INTO `relProductoProveedor` VALUES ('83', '10');
INSERT INTO `relProductoProveedor` VALUES ('84', '14');
INSERT INTO `relProductoProveedor` VALUES ('85', '14');
INSERT INTO `relProductoProveedor` VALUES ('86', '11');
INSERT INTO `relProductoProveedor` VALUES ('87', '11');
INSERT INTO `relProductoProveedor` VALUES ('88', '3');
INSERT INTO `relProductoProveedor` VALUES ('88', '11');
INSERT INTO `relProductoProveedor` VALUES ('89', '11');
INSERT INTO `relProductoProveedor` VALUES ('90', '3');
INSERT INTO `relProductoProveedor` VALUES ('90', '11');
INSERT INTO `relProductoProveedor` VALUES ('91', '4');
INSERT INTO `relProductoProveedor` VALUES ('91', '5');
INSERT INTO `relProductoProveedor` VALUES ('91', '15');
INSERT INTO `relProductoProveedor` VALUES ('92', '4');
INSERT INTO `relProductoProveedor` VALUES ('92', '5');
INSERT INTO `relProductoProveedor` VALUES ('93', '3');
INSERT INTO `relProductoProveedor` VALUES ('93', '4');
INSERT INTO `relProductoProveedor` VALUES ('93', '5');
INSERT INTO `relProductoProveedor` VALUES ('94', '4');
INSERT INTO `relProductoProveedor` VALUES ('94', '5');
INSERT INTO `relProductoProveedor` VALUES ('95', '4');
INSERT INTO `relProductoProveedor` VALUES ('95', '5');
INSERT INTO `relProductoProveedor` VALUES ('95', '15');
INSERT INTO `relProductoProveedor` VALUES ('96', '4');
INSERT INTO `relProductoProveedor` VALUES ('96', '5');
INSERT INTO `relProductoProveedor` VALUES ('96', '15');
INSERT INTO `relProductoProveedor` VALUES ('97', '4');
INSERT INTO `relProductoProveedor` VALUES ('97', '5');
INSERT INTO `relProductoProveedor` VALUES ('97', '15');
INSERT INTO `relProductoProveedor` VALUES ('98', '4');
INSERT INTO `relProductoProveedor` VALUES ('98', '5');
INSERT INTO `relProductoProveedor` VALUES ('99', '4');
INSERT INTO `relProductoProveedor` VALUES ('100', '3');
INSERT INTO `relProductoProveedor` VALUES ('100', '4');
INSERT INTO `relProductoProveedor` VALUES ('100', '5');
INSERT INTO `relProductoProveedor` VALUES ('101', '4');
INSERT INTO `relProductoProveedor` VALUES ('101', '5');
INSERT INTO `relProductoProveedor` VALUES ('101', '15');
INSERT INTO `relProductoProveedor` VALUES ('102', '4');
INSERT INTO `relProductoProveedor` VALUES ('102', '5');
INSERT INTO `relProductoProveedor` VALUES ('102', '15');
INSERT INTO `relProductoProveedor` VALUES ('103', '4');
INSERT INTO `relProductoProveedor` VALUES ('103', '5');
INSERT INTO `relProductoProveedor` VALUES ('103', '15');
INSERT INTO `relProductoProveedor` VALUES ('104', '4');
INSERT INTO `relProductoProveedor` VALUES ('104', '5');
INSERT INTO `relProductoProveedor` VALUES ('104', '15');
INSERT INTO `relProductoProveedor` VALUES ('105', '4');
INSERT INTO `relProductoProveedor` VALUES ('105', '5');
INSERT INTO `relProductoProveedor` VALUES ('105', '15');
INSERT INTO `relProductoProveedor` VALUES ('106', '4');
INSERT INTO `relProductoProveedor` VALUES ('106', '5');
INSERT INTO `relProductoProveedor` VALUES ('106', '15');
INSERT INTO `relProductoProveedor` VALUES ('107', '10');
INSERT INTO `relProductoProveedor` VALUES ('108', '3');
INSERT INTO `relProductoProveedor` VALUES ('109', '3');
INSERT INTO `relProductoProveedor` VALUES ('109', '5');
INSERT INTO `relProductoProveedor` VALUES ('109', '16');
INSERT INTO `relProductoProveedor` VALUES ('110', '4');
INSERT INTO `relProductoProveedor` VALUES ('111', '15');
INSERT INTO `relProductoProveedor` VALUES ('112', '15');
INSERT INTO `relProductoProveedor` VALUES ('113', '14');
INSERT INTO `relProductoProveedor` VALUES ('114', '14');
INSERT INTO `relProductoProveedor` VALUES ('115', '14');
INSERT INTO `relProductoProveedor` VALUES ('116', '14');
INSERT INTO `relProductoProveedor` VALUES ('117', '5');
INSERT INTO `relProductoProveedor` VALUES ('118', '5');
INSERT INTO `relProductoProveedor` VALUES ('119', '9');
INSERT INTO `relProductoProveedor` VALUES ('120', '8');
INSERT INTO `relProductoProveedor` VALUES ('122', '7');
INSERT INTO `relProductoProveedor` VALUES ('123', '3');
INSERT INTO `relProductoProveedor` VALUES ('124', '3');
INSERT INTO `relProductoProveedor` VALUES ('125', '3');
INSERT INTO `relProductoProveedor` VALUES ('126', '17');
INSERT INTO `relProductoProveedor` VALUES ('127', '17');
INSERT INTO `relProductoProveedor` VALUES ('128', '17');
INSERT INTO `relProductoProveedor` VALUES ('129', '17');
INSERT INTO `relProductoProveedor` VALUES ('130', '17');
INSERT INTO `relProductoProveedor` VALUES ('131', '17');
INSERT INTO `relProductoProveedor` VALUES ('132', '17');
INSERT INTO `relProductoProveedor` VALUES ('133', '18');
INSERT INTO `relProductoProveedor` VALUES ('134', '18');
INSERT INTO `relProductoProveedor` VALUES ('135', '18');
INSERT INTO `relProductoProveedor` VALUES ('136', '17');
INSERT INTO `relProductoProveedor` VALUES ('137', '17');
INSERT INTO `relProductoProveedor` VALUES ('138', '17');
INSERT INTO `relProductoProveedor` VALUES ('139', '17');
INSERT INTO `relProductoProveedor` VALUES ('140', '17');
INSERT INTO `relProductoProveedor` VALUES ('140', '18');
INSERT INTO `relProductoProveedor` VALUES ('141', '17');
INSERT INTO `relProductoProveedor` VALUES ('141', '18');
INSERT INTO `relProductoProveedor` VALUES ('142', '17');
INSERT INTO `relProductoProveedor` VALUES ('142', '18');
INSERT INTO `relProductoProveedor` VALUES ('143', '17');
INSERT INTO `relProductoProveedor` VALUES ('143', '18');
INSERT INTO `relProductoProveedor` VALUES ('144', '17');
INSERT INTO `relProductoProveedor` VALUES ('144', '18');
INSERT INTO `relProductoProveedor` VALUES ('145', '17');
INSERT INTO `relProductoProveedor` VALUES ('145', '18');
INSERT INTO `relProductoProveedor` VALUES ('146', '17');
INSERT INTO `relProductoProveedor` VALUES ('146', '18');
INSERT INTO `relProductoProveedor` VALUES ('147', '17');
INSERT INTO `relProductoProveedor` VALUES ('147', '18');
INSERT INTO `relProductoProveedor` VALUES ('148', '17');
INSERT INTO `relProductoProveedor` VALUES ('148', '18');
INSERT INTO `relProductoProveedor` VALUES ('149', '17');
INSERT INTO `relProductoProveedor` VALUES ('149', '19');
INSERT INTO `relProductoProveedor` VALUES ('150', '17');
INSERT INTO `relProductoProveedor` VALUES ('150', '19');
INSERT INTO `relProductoProveedor` VALUES ('153', '20');
INSERT INTO `relProductoProveedor` VALUES ('154', '4');
INSERT INTO `relProductoProveedor` VALUES ('154', '5');
INSERT INTO `relProductoProveedor` VALUES ('155', '4');
INSERT INTO `relProductoProveedor` VALUES ('155', '5');
INSERT INTO `relProductoProveedor` VALUES ('156', '4');
INSERT INTO `relProductoProveedor` VALUES ('156', '5');
INSERT INTO `relProductoProveedor` VALUES ('157', '21');
INSERT INTO `relProductoProveedor` VALUES ('158', '4');
INSERT INTO `relProductoProveedor` VALUES ('159', '3');
INSERT INTO `relProductoProveedor` VALUES ('159', '4');
INSERT INTO `relProductoProveedor` VALUES ('160', '3');
INSERT INTO `relProductoProveedor` VALUES ('160', '4');
INSERT INTO `relProductoProveedor` VALUES ('160', '5');
INSERT INTO `relProductoProveedor` VALUES ('161', '3');
INSERT INTO `relProductoProveedor` VALUES ('162', '4');
INSERT INTO `relProductoProveedor` VALUES ('163', '4');
INSERT INTO `relProductoProveedor` VALUES ('164', '4');
INSERT INTO `relProductoProveedor` VALUES ('165', '4');
INSERT INTO `relProductoProveedor` VALUES ('166', '3');
INSERT INTO `relProductoProveedor` VALUES ('166', '4');
INSERT INTO `relProductoProveedor` VALUES ('166', '5');
INSERT INTO `relProductoProveedor` VALUES ('167', '3');
INSERT INTO `relProductoProveedor` VALUES ('167', '4');
INSERT INTO `relProductoProveedor` VALUES ('169', '4');
INSERT INTO `relProductoProveedor` VALUES ('170', '4');
INSERT INTO `relProductoProveedor` VALUES ('171', '4');
INSERT INTO `relProductoProveedor` VALUES ('172', '4');
INSERT INTO `relProductoProveedor` VALUES ('173', '3');
INSERT INTO `relProductoProveedor` VALUES ('174', '3');
INSERT INTO `relProductoProveedor` VALUES ('176', '8');
INSERT INTO `relProductoProveedor` VALUES ('177', '8');
INSERT INTO `relProductoProveedor` VALUES ('178', '3');
INSERT INTO `relProductoProveedor` VALUES ('179', '3');
INSERT INTO `relProductoProveedor` VALUES ('180', '3');
INSERT INTO `relProductoProveedor` VALUES ('181', '20');
INSERT INTO `relProductoProveedor` VALUES ('182', '20');
INSERT INTO `relProductoProveedor` VALUES ('183', '5');
INSERT INTO `relProductoProveedor` VALUES ('184', '3');
INSERT INTO `relProductoProveedor` VALUES ('184', '5');
INSERT INTO `relProductoProveedor` VALUES ('185', '4');
INSERT INTO `relProductoProveedor` VALUES ('186', '4');
INSERT INTO `relProductoProveedor` VALUES ('187', '9');
INSERT INTO `relProductoProveedor` VALUES ('188', '4');
INSERT INTO `relProductoProveedor` VALUES ('189', '4');
INSERT INTO `relProductoProveedor` VALUES ('190', '4');
INSERT INTO `relProductoProveedor` VALUES ('191', '4');
INSERT INTO `relProductoProveedor` VALUES ('192', '21');
INSERT INTO `relProductoProveedor` VALUES ('193', '22');
INSERT INTO `relProductoProveedor` VALUES ('194', '22');
INSERT INTO `relProductoProveedor` VALUES ('195', '4');
INSERT INTO `relProductoProveedor` VALUES ('195', '22');
INSERT INTO `relProductoProveedor` VALUES ('196', '4');
INSERT INTO `relProductoProveedor` VALUES ('196', '22');
INSERT INTO `relProductoProveedor` VALUES ('197', '4');
INSERT INTO `relProductoProveedor` VALUES ('198', '22');
INSERT INTO `relProductoProveedor` VALUES ('199', '4');
INSERT INTO `relProductoProveedor` VALUES ('199', '22');
INSERT INTO `relProductoProveedor` VALUES ('200', '4');
INSERT INTO `relProductoProveedor` VALUES ('200', '22');
INSERT INTO `relProductoProveedor` VALUES ('201', '21');
INSERT INTO `relProductoProveedor` VALUES ('202', '4');
INSERT INTO `relProductoProveedor` VALUES ('203', '4');
INSERT INTO `relProductoProveedor` VALUES ('204', '22');
INSERT INTO `relProductoProveedor` VALUES ('205', '22');
INSERT INTO `relProductoProveedor` VALUES ('206', '22');
INSERT INTO `relProductoProveedor` VALUES ('207', '4');
INSERT INTO `relProductoProveedor` VALUES ('207', '22');
INSERT INTO `relProductoProveedor` VALUES ('208', '4');
INSERT INTO `relProductoProveedor` VALUES ('209', '20');
INSERT INTO `relProductoProveedor` VALUES ('210', '4');
INSERT INTO `relProductoProveedor` VALUES ('210', '5');
INSERT INTO `relProductoProveedor` VALUES ('211', '12');
INSERT INTO `relProductoProveedor` VALUES ('211', '23');
INSERT INTO `relProductoProveedor` VALUES ('212', '10');
INSERT INTO `relProductoProveedor` VALUES ('213', '24');
INSERT INTO `relProductoProveedor` VALUES ('214', '24');
INSERT INTO `relProductoProveedor` VALUES ('215', '24');
INSERT INTO `relProductoProveedor` VALUES ('216', '24');
INSERT INTO `relProductoProveedor` VALUES ('217', '5');
INSERT INTO `relProductoProveedor` VALUES ('218', '25');
INSERT INTO `relProductoProveedor` VALUES ('219', '25');
INSERT INTO `relProductoProveedor` VALUES ('220', '24');
INSERT INTO `relProductoProveedor` VALUES ('221', '4');
INSERT INTO `relProductoProveedor` VALUES ('221', '5');
INSERT INTO `relProductoProveedor` VALUES ('221', '10');
INSERT INTO `relProductoProveedor` VALUES ('222', '4');
INSERT INTO `relProductoProveedor` VALUES ('223', '4');
INSERT INTO `relProductoProveedor` VALUES ('223', '5');
INSERT INTO `relProductoProveedor` VALUES ('224', '10');
INSERT INTO `relProductoProveedor` VALUES ('225', '4');
INSERT INTO `relProductoProveedor` VALUES ('225', '5');
INSERT INTO `relProductoProveedor` VALUES ('226', '4');
INSERT INTO `relProductoProveedor` VALUES ('226', '5');
INSERT INTO `relProductoProveedor` VALUES ('227', '4');
INSERT INTO `relProductoProveedor` VALUES ('227', '5');
INSERT INTO `relProductoProveedor` VALUES ('227', '10');
INSERT INTO `relProductoProveedor` VALUES ('228', '5');
INSERT INTO `relProductoProveedor` VALUES ('228', '10');
INSERT INTO `relProductoProveedor` VALUES ('229', '4');
INSERT INTO `relProductoProveedor` VALUES ('229', '5');
INSERT INTO `relProductoProveedor` VALUES ('229', '26');
INSERT INTO `relProductoProveedor` VALUES ('230', '3');
INSERT INTO `relProductoProveedor` VALUES ('231', '4');
INSERT INTO `relProductoProveedor` VALUES ('231', '5');
INSERT INTO `relProductoProveedor` VALUES ('231', '26');
INSERT INTO `relProductoProveedor` VALUES ('232', '3');
INSERT INTO `relProductoProveedor` VALUES ('233', '4');
INSERT INTO `relProductoProveedor` VALUES ('233', '5');
INSERT INTO `relProductoProveedor` VALUES ('233', '26');
INSERT INTO `relProductoProveedor` VALUES ('234', '3');
INSERT INTO `relProductoProveedor` VALUES ('234', '4');
INSERT INTO `relProductoProveedor` VALUES ('236', '4');
INSERT INTO `relProductoProveedor` VALUES ('236', '5');
INSERT INTO `relProductoProveedor` VALUES ('236', '26');
INSERT INTO `relProductoProveedor` VALUES ('237', '4');
INSERT INTO `relProductoProveedor` VALUES ('237', '5');
INSERT INTO `relProductoProveedor` VALUES ('237', '26');
INSERT INTO `relProductoProveedor` VALUES ('238', '4');
INSERT INTO `relProductoProveedor` VALUES ('238', '5');
INSERT INTO `relProductoProveedor` VALUES ('238', '26');
INSERT INTO `relProductoProveedor` VALUES ('239', '4');
INSERT INTO `relProductoProveedor` VALUES ('239', '5');
INSERT INTO `relProductoProveedor` VALUES ('239', '26');
INSERT INTO `relProductoProveedor` VALUES ('240', '4');
INSERT INTO `relProductoProveedor` VALUES ('241', '4');
INSERT INTO `relProductoProveedor` VALUES ('241', '5');
INSERT INTO `relProductoProveedor` VALUES ('241', '26');
INSERT INTO `relProductoProveedor` VALUES ('243', '4');
INSERT INTO `relProductoProveedor` VALUES ('243', '5');
INSERT INTO `relProductoProveedor` VALUES ('243', '26');
INSERT INTO `relProductoProveedor` VALUES ('244', '3');
INSERT INTO `relProductoProveedor` VALUES ('244', '4');
INSERT INTO `relProductoProveedor` VALUES ('245', '4');
INSERT INTO `relProductoProveedor` VALUES ('245', '5');
INSERT INTO `relProductoProveedor` VALUES ('245', '26');
INSERT INTO `relProductoProveedor` VALUES ('246', '8');
INSERT INTO `relProductoProveedor` VALUES ('247', '8');
INSERT INTO `relProductoProveedor` VALUES ('248', '3');
INSERT INTO `relProductoProveedor` VALUES ('249', '4');
INSERT INTO `relProductoProveedor` VALUES ('249', '5');
INSERT INTO `relProductoProveedor` VALUES ('250', '4');
INSERT INTO `relProductoProveedor` VALUES ('250', '5');
INSERT INTO `relProductoProveedor` VALUES ('251', '3');
INSERT INTO `relProductoProveedor` VALUES ('251', '4');
INSERT INTO `relProductoProveedor` VALUES ('251', '5');
INSERT INTO `relProductoProveedor` VALUES ('252', '4');
INSERT INTO `relProductoProveedor` VALUES ('252', '5');
INSERT INTO `relProductoProveedor` VALUES ('253', '4');
INSERT INTO `relProductoProveedor` VALUES ('253', '5');
INSERT INTO `relProductoProveedor` VALUES ('254', '4');
INSERT INTO `relProductoProveedor` VALUES ('254', '5');
INSERT INTO `relProductoProveedor` VALUES ('255', '4');
INSERT INTO `relProductoProveedor` VALUES ('256', '4');
INSERT INTO `relProductoProveedor` VALUES ('256', '5');
INSERT INTO `relProductoProveedor` VALUES ('257', '4');
INSERT INTO `relProductoProveedor` VALUES ('257', '5');
INSERT INTO `relProductoProveedor` VALUES ('258', '4');
INSERT INTO `relProductoProveedor` VALUES ('259', '3');
INSERT INTO `relProductoProveedor` VALUES ('261', '4');
INSERT INTO `relProductoProveedor` VALUES ('262', '7');
INSERT INTO `relProductoProveedor` VALUES ('270', '27');
INSERT INTO `relProductoProveedor` VALUES ('272', '27');
INSERT INTO `relProductoProveedor` VALUES ('274', '3');
INSERT INTO `relProductoProveedor` VALUES ('274', '4');
INSERT INTO `relProductoProveedor` VALUES ('274', '5');
INSERT INTO `relProductoProveedor` VALUES ('275', '3');
INSERT INTO `relProductoProveedor` VALUES ('276', '4');
INSERT INTO `relProductoProveedor` VALUES ('276', '5');
INSERT INTO `relProductoProveedor` VALUES ('277', '3');
INSERT INTO `relProductoProveedor` VALUES ('277', '4');
INSERT INTO `relProductoProveedor` VALUES ('277', '5');
INSERT INTO `relProductoProveedor` VALUES ('278', '3');
INSERT INTO `relProductoProveedor` VALUES ('278', '4');
INSERT INTO `relProductoProveedor` VALUES ('278', '5');
INSERT INTO `relProductoProveedor` VALUES ('279', '3');
INSERT INTO `relProductoProveedor` VALUES ('279', '5');
INSERT INTO `relProductoProveedor` VALUES ('280', '4');
INSERT INTO `relProductoProveedor` VALUES ('280', '5');
INSERT INTO `relProductoProveedor` VALUES ('281', '4');
INSERT INTO `relProductoProveedor` VALUES ('281', '5');
INSERT INTO `relProductoProveedor` VALUES ('282', '5');
INSERT INTO `relProductoProveedor` VALUES ('283', '5');
INSERT INTO `relProductoProveedor` VALUES ('284', '28');
INSERT INTO `relProductoProveedor` VALUES ('285', '4');
INSERT INTO `relProductoProveedor` VALUES ('285', '5');
INSERT INTO `relProductoProveedor` VALUES ('285', '10');
INSERT INTO `relProductoProveedor` VALUES ('286', '8');
INSERT INTO `relProductoProveedor` VALUES ('287', '4');
INSERT INTO `relProductoProveedor` VALUES ('287', '12');
INSERT INTO `relProductoProveedor` VALUES ('288', '25');
INSERT INTO `relProductoProveedor` VALUES ('289', '25');
INSERT INTO `relProductoProveedor` VALUES ('290', '25');
INSERT INTO `relProductoProveedor` VALUES ('291', '25');
INSERT INTO `relProductoProveedor` VALUES ('291', '29');
INSERT INTO `relProductoProveedor` VALUES ('292', '25');
INSERT INTO `relProductoProveedor` VALUES ('292', '29');
INSERT INTO `relProductoProveedor` VALUES ('293', '29');
INSERT INTO `relProductoProveedor` VALUES ('294', '25');
INSERT INTO `relProductoProveedor` VALUES ('294', '29');
INSERT INTO `relProductoProveedor` VALUES ('295', '25');
INSERT INTO `relProductoProveedor` VALUES ('295', '29');
INSERT INTO `relProductoProveedor` VALUES ('296', '25');
INSERT INTO `relProductoProveedor` VALUES ('296', '29');
INSERT INTO `relProductoProveedor` VALUES ('297', '29');
INSERT INTO `relProductoProveedor` VALUES ('298', '29');
INSERT INTO `relProductoProveedor` VALUES ('299', '29');
INSERT INTO `relProductoProveedor` VALUES ('300', '4');
INSERT INTO `relProductoProveedor` VALUES ('300', '5');
INSERT INTO `relProductoProveedor` VALUES ('302', '3');
INSERT INTO `relProductoProveedor` VALUES ('302', '4');
INSERT INTO `relProductoProveedor` VALUES ('302', '5');
INSERT INTO `relProductoProveedor` VALUES ('303', '3');
INSERT INTO `relProductoProveedor` VALUES ('303', '4');
INSERT INTO `relProductoProveedor` VALUES ('303', '5');
INSERT INTO `relProductoProveedor` VALUES ('304', '3');
INSERT INTO `relProductoProveedor` VALUES ('304', '4');
INSERT INTO `relProductoProveedor` VALUES ('304', '5');
INSERT INTO `relProductoProveedor` VALUES ('305', '4');
INSERT INTO `relProductoProveedor` VALUES ('305', '5');
INSERT INTO `relProductoProveedor` VALUES ('306', '3');
INSERT INTO `relProductoProveedor` VALUES ('306', '4');
INSERT INTO `relProductoProveedor` VALUES ('306', '5');
INSERT INTO `relProductoProveedor` VALUES ('307', '3');
INSERT INTO `relProductoProveedor` VALUES ('307', '4');
INSERT INTO `relProductoProveedor` VALUES ('307', '5');
INSERT INTO `relProductoProveedor` VALUES ('308', '4');
INSERT INTO `relProductoProveedor` VALUES ('308', '5');
INSERT INTO `relProductoProveedor` VALUES ('309', '4');
INSERT INTO `relProductoProveedor` VALUES ('309', '5');
INSERT INTO `relProductoProveedor` VALUES ('310', '4');
INSERT INTO `relProductoProveedor` VALUES ('310', '5');
INSERT INTO `relProductoProveedor` VALUES ('312', '4');
INSERT INTO `relProductoProveedor` VALUES ('312', '5');
INSERT INTO `relProductoProveedor` VALUES ('313', '4');
INSERT INTO `relProductoProveedor` VALUES ('313', '5');
INSERT INTO `relProductoProveedor` VALUES ('314', '4');
INSERT INTO `relProductoProveedor` VALUES ('314', '5');
INSERT INTO `relProductoProveedor` VALUES ('315', '4');
INSERT INTO `relProductoProveedor` VALUES ('315', '5');
INSERT INTO `relProductoProveedor` VALUES ('316', '4');
INSERT INTO `relProductoProveedor` VALUES ('316', '5');
INSERT INTO `relProductoProveedor` VALUES ('317', '4');
INSERT INTO `relProductoProveedor` VALUES ('317', '5');
INSERT INTO `relProductoProveedor` VALUES ('318', '5');
INSERT INTO `relProductoProveedor` VALUES ('320', '5');
INSERT INTO `relProductoProveedor` VALUES ('321', '29');
INSERT INTO `relProductoProveedor` VALUES ('322', '5');
INSERT INTO `relProductoProveedor` VALUES ('339', '20');
INSERT INTO `relProductoProveedor` VALUES ('340', '3');
INSERT INTO `relProductoProveedor` VALUES ('340', '4');
INSERT INTO `relProductoProveedor` VALUES ('340', '5');
INSERT INTO `relProductoProveedor` VALUES ('341', '3');
INSERT INTO `relProductoProveedor` VALUES ('341', '4');
INSERT INTO `relProductoProveedor` VALUES ('341', '5');
INSERT INTO `relProductoProveedor` VALUES ('342', '3');
INSERT INTO `relProductoProveedor` VALUES ('342', '4');
INSERT INTO `relProductoProveedor` VALUES ('342', '5');
INSERT INTO `relProductoProveedor` VALUES ('343', '3');
INSERT INTO `relProductoProveedor` VALUES ('343', '4');
INSERT INTO `relProductoProveedor` VALUES ('343', '5');
INSERT INTO `relProductoProveedor` VALUES ('344', '3');
INSERT INTO `relProductoProveedor` VALUES ('344', '4');
INSERT INTO `relProductoProveedor` VALUES ('344', '5');
INSERT INTO `relProductoProveedor` VALUES ('345', '3');
INSERT INTO `relProductoProveedor` VALUES ('345', '4');
INSERT INTO `relProductoProveedor` VALUES ('345', '5');
INSERT INTO `relProductoProveedor` VALUES ('346', '3');
INSERT INTO `relProductoProveedor` VALUES ('346', '4');
INSERT INTO `relProductoProveedor` VALUES ('346', '5');
INSERT INTO `relProductoProveedor` VALUES ('347', '3');
INSERT INTO `relProductoProveedor` VALUES ('347', '4');
INSERT INTO `relProductoProveedor` VALUES ('347', '5');
INSERT INTO `relProductoProveedor` VALUES ('348', '3');
INSERT INTO `relProductoProveedor` VALUES ('348', '28');
INSERT INTO `relProductoProveedor` VALUES ('349', '3');
INSERT INTO `relProductoProveedor` VALUES ('349', '28');
INSERT INTO `relProductoProveedor` VALUES ('350', '3');
INSERT INTO `relProductoProveedor` VALUES ('350', '28');
INSERT INTO `relProductoProveedor` VALUES ('351', '28');
INSERT INTO `relProductoProveedor` VALUES ('352', '3');
INSERT INTO `relProductoProveedor` VALUES ('352', '28');
INSERT INTO `relProductoProveedor` VALUES ('353', '3');
INSERT INTO `relProductoProveedor` VALUES ('353', '4');
INSERT INTO `relProductoProveedor` VALUES ('353', '5');
INSERT INTO `relProductoProveedor` VALUES ('354', '4');
INSERT INTO `relProductoProveedor` VALUES ('354', '5');
INSERT INTO `relProductoProveedor` VALUES ('355', '28');
INSERT INTO `relProductoProveedor` VALUES ('356', '28');
INSERT INTO `relProductoProveedor` VALUES ('357', '3');
INSERT INTO `relProductoProveedor` VALUES ('357', '4');
INSERT INTO `relProductoProveedor` VALUES ('357', '5');
INSERT INTO `relProductoProveedor` VALUES ('358', '3');
INSERT INTO `relProductoProveedor` VALUES ('358', '4');
INSERT INTO `relProductoProveedor` VALUES ('358', '5');
INSERT INTO `relProductoProveedor` VALUES ('359', '3');
INSERT INTO `relProductoProveedor` VALUES ('359', '4');
INSERT INTO `relProductoProveedor` VALUES ('359', '5');
INSERT INTO `relProductoProveedor` VALUES ('360', '4');
INSERT INTO `relProductoProveedor` VALUES ('360', '5');
INSERT INTO `relProductoProveedor` VALUES ('361', '3');
INSERT INTO `relProductoProveedor` VALUES ('361', '4');
INSERT INTO `relProductoProveedor` VALUES ('361', '5');
INSERT INTO `relProductoProveedor` VALUES ('362', '3');
INSERT INTO `relProductoProveedor` VALUES ('362', '4');
INSERT INTO `relProductoProveedor` VALUES ('362', '5');
INSERT INTO `relProductoProveedor` VALUES ('363', '3');
INSERT INTO `relProductoProveedor` VALUES ('363', '4');
INSERT INTO `relProductoProveedor` VALUES ('363', '5');
INSERT INTO `relProductoProveedor` VALUES ('364', '4');
INSERT INTO `relProductoProveedor` VALUES ('364', '5');
INSERT INTO `relProductoProveedor` VALUES ('365', '3');
INSERT INTO `relProductoProveedor` VALUES ('365', '4');
INSERT INTO `relProductoProveedor` VALUES ('365', '5');
INSERT INTO `relProductoProveedor` VALUES ('366', '3');
INSERT INTO `relProductoProveedor` VALUES ('366', '4');
INSERT INTO `relProductoProveedor` VALUES ('366', '5');
INSERT INTO `relProductoProveedor` VALUES ('367', '4');
INSERT INTO `relProductoProveedor` VALUES ('367', '5');
INSERT INTO `relProductoProveedor` VALUES ('368', '4');
INSERT INTO `relProductoProveedor` VALUES ('368', '5');
INSERT INTO `relProductoProveedor` VALUES ('369', '4');
INSERT INTO `relProductoProveedor` VALUES ('369', '5');
INSERT INTO `relProductoProveedor` VALUES ('370', '4');
INSERT INTO `relProductoProveedor` VALUES ('370', '5');
INSERT INTO `relProductoProveedor` VALUES ('371', '4');
INSERT INTO `relProductoProveedor` VALUES ('371', '5');
INSERT INTO `relProductoProveedor` VALUES ('372', '4');
INSERT INTO `relProductoProveedor` VALUES ('372', '5');
INSERT INTO `relProductoProveedor` VALUES ('373', '4');
INSERT INTO `relProductoProveedor` VALUES ('373', '5');
INSERT INTO `relProductoProveedor` VALUES ('374', '21');
INSERT INTO `relProductoProveedor` VALUES ('376', '3');
INSERT INTO `relProductoProveedor` VALUES ('377', '4');
INSERT INTO `relProductoProveedor` VALUES ('377', '5');
INSERT INTO `relProductoProveedor` VALUES ('378', '4');
INSERT INTO `relProductoProveedor` VALUES ('378', '5');
INSERT INTO `relProductoProveedor` VALUES ('378', '10');
INSERT INTO `relProductoProveedor` VALUES ('379', '4');
INSERT INTO `relProductoProveedor` VALUES ('379', '5');
INSERT INTO `relProductoProveedor` VALUES ('379', '10');
INSERT INTO `relProductoProveedor` VALUES ('380', '22');
INSERT INTO `relProductoProveedor` VALUES ('381', '22');
INSERT INTO `relProductoProveedor` VALUES ('382', '30');
INSERT INTO `relProductoProveedor` VALUES ('383', '30');
INSERT INTO `relProductoProveedor` VALUES ('385', '4');
INSERT INTO `relProductoProveedor` VALUES ('386', '3');
INSERT INTO `relProductoProveedor` VALUES ('387', '3');
INSERT INTO `relProductoProveedor` VALUES ('388', '10');
INSERT INTO `relProductoProveedor` VALUES ('389', '20');
INSERT INTO `relProductoProveedor` VALUES ('390', '20');
INSERT INTO `relProductoProveedor` VALUES ('391', '20');
INSERT INTO `relProductoProveedor` VALUES ('392', '3');
INSERT INTO `relProductoProveedor` VALUES ('392', '4');
INSERT INTO `relProductoProveedor` VALUES ('392', '5');
INSERT INTO `relProductoProveedor` VALUES ('393', '9');
INSERT INTO `relProductoProveedor` VALUES ('394', '4');
INSERT INTO `relProductoProveedor` VALUES ('395', '4');
INSERT INTO `relProductoProveedor` VALUES ('396', '4');
INSERT INTO `relProductoProveedor` VALUES ('397', '8');
INSERT INTO `relProductoProveedor` VALUES ('399', '4');
INSERT INTO `relProductoProveedor` VALUES ('399', '5');
INSERT INTO `relProductoProveedor` VALUES ('400', '4');
INSERT INTO `relProductoProveedor` VALUES ('400', '5');
INSERT INTO `relProductoProveedor` VALUES ('401', '4');
INSERT INTO `relProductoProveedor` VALUES ('401', '5');
INSERT INTO `relProductoProveedor` VALUES ('404', '20');
INSERT INTO `relProductoProveedor` VALUES ('405', '3');
INSERT INTO `relProductoProveedor` VALUES ('406', '20');
INSERT INTO `relProductoProveedor` VALUES ('407', '20');
INSERT INTO `relProductoProveedor` VALUES ('409', '20');
INSERT INTO `relProductoProveedor` VALUES ('410', '20');
INSERT INTO `relProductoProveedor` VALUES ('411', '4');
INSERT INTO `relProductoProveedor` VALUES ('412', '4');
INSERT INTO `relProductoProveedor` VALUES ('413', '3');
INSERT INTO `relProductoProveedor` VALUES ('413', '4');
INSERT INTO `relProductoProveedor` VALUES ('413', '5');
INSERT INTO `relProductoProveedor` VALUES ('414', '3');
INSERT INTO `relProductoProveedor` VALUES ('414', '4');
INSERT INTO `relProductoProveedor` VALUES ('414', '5');
INSERT INTO `relProductoProveedor` VALUES ('415', '3');
INSERT INTO `relProductoProveedor` VALUES ('415', '4');
INSERT INTO `relProductoProveedor` VALUES ('415', '5');
INSERT INTO `relProductoProveedor` VALUES ('416', '3');
INSERT INTO `relProductoProveedor` VALUES ('416', '4');
INSERT INTO `relProductoProveedor` VALUES ('416', '5');
INSERT INTO `relProductoProveedor` VALUES ('417', '3');
INSERT INTO `relProductoProveedor` VALUES ('417', '4');
INSERT INTO `relProductoProveedor` VALUES ('417', '5');
INSERT INTO `relProductoProveedor` VALUES ('418', '4');
INSERT INTO `relProductoProveedor` VALUES ('418', '5');
INSERT INTO `relProductoProveedor` VALUES ('419', '4');
INSERT INTO `relProductoProveedor` VALUES ('419', '5');
INSERT INTO `relProductoProveedor` VALUES ('420', '3');
INSERT INTO `relProductoProveedor` VALUES ('421', '5');
INSERT INTO `relProductoProveedor` VALUES ('422', '5');
INSERT INTO `relProductoProveedor` VALUES ('423', '5');
INSERT INTO `relProductoProveedor` VALUES ('425', '5');
INSERT INTO `relProductoProveedor` VALUES ('426', '5');
INSERT INTO `relProductoProveedor` VALUES ('427', '5');
INSERT INTO `relProductoProveedor` VALUES ('428', '5');
INSERT INTO `relProductoProveedor` VALUES ('430', '20');
INSERT INTO `relProductoProveedor` VALUES ('431', '6');
INSERT INTO `relProductoProveedor` VALUES ('432', '6');
INSERT INTO `relProductoProveedor` VALUES ('433', '26');
INSERT INTO `relProductoProveedor` VALUES ('434', '4');
INSERT INTO `relProductoProveedor` VALUES ('434', '5');
INSERT INTO `relProductoProveedor` VALUES ('434', '26');
INSERT INTO `relProductoProveedor` VALUES ('435', '4');
INSERT INTO `relProductoProveedor` VALUES ('435', '5');
INSERT INTO `relProductoProveedor` VALUES ('436', '4');
INSERT INTO `relProductoProveedor` VALUES ('436', '5');
INSERT INTO `relProductoProveedor` VALUES ('437', '3');
INSERT INTO `relProductoProveedor` VALUES ('437', '5');
INSERT INTO `relProductoProveedor` VALUES ('437', '16');
INSERT INTO `relProductoProveedor` VALUES ('438', '4');
INSERT INTO `relProductoProveedor` VALUES ('438', '5');
INSERT INTO `relProductoProveedor` VALUES ('438', '26');
INSERT INTO `relProductoProveedor` VALUES ('439', '4');
INSERT INTO `relProductoProveedor` VALUES ('439', '5');
INSERT INTO `relProductoProveedor` VALUES ('439', '26');
INSERT INTO `relProductoProveedor` VALUES ('440', '4');
INSERT INTO `relProductoProveedor` VALUES ('440', '5');
INSERT INTO `relProductoProveedor` VALUES ('440', '26');
INSERT INTO `relProductoProveedor` VALUES ('441', '4');
INSERT INTO `relProductoProveedor` VALUES ('441', '5');
INSERT INTO `relProductoProveedor` VALUES ('441', '26');
INSERT INTO `relProductoProveedor` VALUES ('442', '4');
INSERT INTO `relProductoProveedor` VALUES ('442', '5');
INSERT INTO `relProductoProveedor` VALUES ('442', '26');
INSERT INTO `relProductoProveedor` VALUES ('443', '4');
INSERT INTO `relProductoProveedor` VALUES ('443', '5');
INSERT INTO `relProductoProveedor` VALUES ('443', '26');
INSERT INTO `relProductoProveedor` VALUES ('444', '26');
INSERT INTO `relProductoProveedor` VALUES ('445', '30');
INSERT INTO `relProductoProveedor` VALUES ('446', '31');
INSERT INTO `relProductoProveedor` VALUES ('447', '31');
INSERT INTO `relProductoProveedor` VALUES ('448', '30');
INSERT INTO `relProductoProveedor` VALUES ('449', '30');
INSERT INTO `relProductoProveedor` VALUES ('450', '30');
INSERT INTO `relProductoProveedor` VALUES ('451', '30');
INSERT INTO `relProductoProveedor` VALUES ('452', '30');
INSERT INTO `relProductoProveedor` VALUES ('453', '30');
INSERT INTO `relProductoProveedor` VALUES ('454', '30');
INSERT INTO `relProductoProveedor` VALUES ('455', '30');
INSERT INTO `relProductoProveedor` VALUES ('456', '30');
INSERT INTO `relProductoProveedor` VALUES ('457', '30');
INSERT INTO `relProductoProveedor` VALUES ('458', '30');
INSERT INTO `relProductoProveedor` VALUES ('459', '30');
INSERT INTO `relProductoProveedor` VALUES ('460', '31');
INSERT INTO `relProductoProveedor` VALUES ('461', '30');
INSERT INTO `relProductoProveedor` VALUES ('462', '30');
INSERT INTO `relProductoProveedor` VALUES ('463', '30');
INSERT INTO `relProductoProveedor` VALUES ('464', '30');
INSERT INTO `relProductoProveedor` VALUES ('465', '30');
INSERT INTO `relProductoProveedor` VALUES ('466', '30');
INSERT INTO `relProductoProveedor` VALUES ('467', '30');
INSERT INTO `relProductoProveedor` VALUES ('468', '30');
INSERT INTO `relProductoProveedor` VALUES ('469', '30');
INSERT INTO `relProductoProveedor` VALUES ('470', '30');
INSERT INTO `relProductoProveedor` VALUES ('471', '30');
INSERT INTO `relProductoProveedor` VALUES ('472', '31');
INSERT INTO `relProductoProveedor` VALUES ('473', '30');
INSERT INTO `relProductoProveedor` VALUES ('474', '30');
INSERT INTO `relProductoProveedor` VALUES ('475', '30');
INSERT INTO `relProductoProveedor` VALUES ('476', '22');
INSERT INTO `relProductoProveedor` VALUES ('477', '31');
INSERT INTO `relProductoProveedor` VALUES ('478', '30');
INSERT INTO `relProductoProveedor` VALUES ('479', '30');
INSERT INTO `relProductoProveedor` VALUES ('480', '30');
INSERT INTO `relProductoProveedor` VALUES ('481', '30');
INSERT INTO `relProductoProveedor` VALUES ('482', '5');
INSERT INTO `relProductoProveedor` VALUES ('482', '9');
INSERT INTO `relProductoProveedor` VALUES ('483', '5');
INSERT INTO `relProductoProveedor` VALUES ('483', '9');
INSERT INTO `relProductoProveedor` VALUES ('484', '5');
INSERT INTO `relProductoProveedor` VALUES ('484', '9');
INSERT INTO `relProductoProveedor` VALUES ('485', '9');
INSERT INTO `relProductoProveedor` VALUES ('486', '9');
INSERT INTO `relProductoProveedor` VALUES ('487', '9');
INSERT INTO `relProductoProveedor` VALUES ('489', '5');
INSERT INTO `relProductoProveedor` VALUES ('489', '9');
INSERT INTO `relProductoProveedor` VALUES ('490', '4');
INSERT INTO `relProductoProveedor` VALUES ('490', '5');
INSERT INTO `relProductoProveedor` VALUES ('491', '4');
INSERT INTO `relProductoProveedor` VALUES ('491', '5');
INSERT INTO `relProductoProveedor` VALUES ('492', '4');
INSERT INTO `relProductoProveedor` VALUES ('492', '5');
INSERT INTO `relProductoProveedor` VALUES ('493', '3');
INSERT INTO `relProductoProveedor` VALUES ('493', '4');
INSERT INTO `relProductoProveedor` VALUES ('494', '4');
INSERT INTO `relProductoProveedor` VALUES ('495', '6');
INSERT INTO `relProductoProveedor` VALUES ('496', '6');
INSERT INTO `relProductoProveedor` VALUES ('503', '4');
INSERT INTO `relProductoProveedor` VALUES ('503', '5');
INSERT INTO `relProductoProveedor` VALUES ('504', '4');
INSERT INTO `relProductoProveedor` VALUES ('504', '5');
INSERT INTO `relProductoProveedor` VALUES ('505', '4');
INSERT INTO `relProductoProveedor` VALUES ('506', '5');
INSERT INTO `relProductoProveedor` VALUES ('507', '4');
INSERT INTO `relProductoProveedor` VALUES ('508', '4');
INSERT INTO `relProductoProveedor` VALUES ('509', '4');
INSERT INTO `relProductoProveedor` VALUES ('510', '4');
INSERT INTO `relProductoProveedor` VALUES ('511', '5');
INSERT INTO `relProductoProveedor` VALUES ('512', '5');
INSERT INTO `relProductoProveedor` VALUES ('513', '5');
INSERT INTO `relProductoProveedor` VALUES ('514', '3');
INSERT INTO `relProductoProveedor` VALUES ('515', '4');
INSERT INTO `relProductoProveedor` VALUES ('516', '4');
INSERT INTO `relProductoProveedor` VALUES ('518', '3');
INSERT INTO `relProductoProveedor` VALUES ('520', '3');
INSERT INTO `relProductoProveedor` VALUES ('521', '3');
INSERT INTO `relProductoProveedor` VALUES ('523', '3');
INSERT INTO `relProductoProveedor` VALUES ('524', '4');
INSERT INTO `relProductoProveedor` VALUES ('524', '5');
INSERT INTO `relProductoProveedor` VALUES ('525', '3');
INSERT INTO `relProductoProveedor` VALUES ('525', '4');
INSERT INTO `relProductoProveedor` VALUES ('526', '4');
INSERT INTO `relProductoProveedor` VALUES ('527', '28');
INSERT INTO `relProductoProveedor` VALUES ('528', '28');
INSERT INTO `relProductoProveedor` VALUES ('529', '28');
INSERT INTO `relProductoProveedor` VALUES ('530', '28');
INSERT INTO `relProductoProveedor` VALUES ('531', '3');
INSERT INTO `relProductoProveedor` VALUES ('531', '4');
INSERT INTO `relProductoProveedor` VALUES ('533', '5');
INSERT INTO `relProductoProveedor` VALUES ('533', '28');
INSERT INTO `relProductoProveedor` VALUES ('534', '28');
INSERT INTO `relProductoProveedor` VALUES ('535', '3');
INSERT INTO `relProductoProveedor` VALUES ('536', '3');
INSERT INTO `relProductoProveedor` VALUES ('536', '4');
INSERT INTO `relProductoProveedor` VALUES ('538', '28');
INSERT INTO `relProductoProveedor` VALUES ('539', '28');
INSERT INTO `relProductoProveedor` VALUES ('541', '28');
INSERT INTO `relProductoProveedor` VALUES ('542', '28');
INSERT INTO `relProductoProveedor` VALUES ('543', '4');
INSERT INTO `relProductoProveedor` VALUES ('544', '3');
INSERT INTO `relProductoProveedor` VALUES ('545', '3');
INSERT INTO `relProductoProveedor` VALUES ('546', '3');
INSERT INTO `relProductoProveedor` VALUES ('546', '4');
INSERT INTO `relProductoProveedor` VALUES ('547', '3');
INSERT INTO `relProductoProveedor` VALUES ('547', '4');
INSERT INTO `relProductoProveedor` VALUES ('548', '28');
INSERT INTO `relProductoProveedor` VALUES ('549', '4');
INSERT INTO `relProductoProveedor` VALUES ('549', '5');
INSERT INTO `relProductoProveedor` VALUES ('549', '32');
INSERT INTO `relProductoProveedor` VALUES ('550', '4');
INSERT INTO `relProductoProveedor` VALUES ('550', '5');
INSERT INTO `relProductoProveedor` VALUES ('550', '32');
INSERT INTO `relProductoProveedor` VALUES ('551', '28');
INSERT INTO `relProductoProveedor` VALUES ('552', '28');
INSERT INTO `relProductoProveedor` VALUES ('553', '4');
INSERT INTO `relProductoProveedor` VALUES ('553', '5');
INSERT INTO `relProductoProveedor` VALUES ('554', '4');
INSERT INTO `relProductoProveedor` VALUES ('554', '5');
INSERT INTO `relProductoProveedor` VALUES ('556', '4');
INSERT INTO `relProductoProveedor` VALUES ('556', '5');
INSERT INTO `relProductoProveedor` VALUES ('557', '5');
INSERT INTO `relProductoProveedor` VALUES ('557', '28');
INSERT INTO `relProductoProveedor` VALUES ('558', '5');
INSERT INTO `relProductoProveedor` VALUES ('558', '28');
INSERT INTO `relProductoProveedor` VALUES ('559', '5');
INSERT INTO `relProductoProveedor` VALUES ('559', '28');
INSERT INTO `relProductoProveedor` VALUES ('560', '4');
INSERT INTO `relProductoProveedor` VALUES ('560', '5');
INSERT INTO `relProductoProveedor` VALUES ('561', '4');
INSERT INTO `relProductoProveedor` VALUES ('561', '5');
INSERT INTO `relProductoProveedor` VALUES ('562', '5');
INSERT INTO `relProductoProveedor` VALUES ('562', '28');
INSERT INTO `relProductoProveedor` VALUES ('563', '4');
INSERT INTO `relProductoProveedor` VALUES ('563', '5');
INSERT INTO `relProductoProveedor` VALUES ('563', '32');
INSERT INTO `relProductoProveedor` VALUES ('564', '4');
INSERT INTO `relProductoProveedor` VALUES ('564', '5');
INSERT INTO `relProductoProveedor` VALUES ('564', '32');
INSERT INTO `relProductoProveedor` VALUES ('565', '4');
INSERT INTO `relProductoProveedor` VALUES ('565', '5');
INSERT INTO `relProductoProveedor` VALUES ('565', '32');
INSERT INTO `relProductoProveedor` VALUES ('566', '3');
INSERT INTO `relProductoProveedor` VALUES ('566', '4');
INSERT INTO `relProductoProveedor` VALUES ('566', '5');
INSERT INTO `relProductoProveedor` VALUES ('567', '28');
INSERT INTO `relProductoProveedor` VALUES ('568', '4');
INSERT INTO `relProductoProveedor` VALUES ('568', '5');
INSERT INTO `relProductoProveedor` VALUES ('568', '32');
INSERT INTO `relProductoProveedor` VALUES ('569', '3');
INSERT INTO `relProductoProveedor` VALUES ('572', '3');
INSERT INTO `relProductoProveedor` VALUES ('574', '3');
INSERT INTO `relProductoProveedor` VALUES ('576', '3');
INSERT INTO `relProductoProveedor` VALUES ('577', '3');
INSERT INTO `relProductoProveedor` VALUES ('579', '3');
INSERT INTO `relProductoProveedor` VALUES ('581', '3');
INSERT INTO `relProductoProveedor` VALUES ('584', '3');
INSERT INTO `relProductoProveedor` VALUES ('584', '4');
INSERT INTO `relProductoProveedor` VALUES ('584', '5');
INSERT INTO `relProductoProveedor` VALUES ('585', '3');
INSERT INTO `relProductoProveedor` VALUES ('585', '4');
INSERT INTO `relProductoProveedor` VALUES ('585', '5');
INSERT INTO `relProductoProveedor` VALUES ('586', '15');
INSERT INTO `relProductoProveedor` VALUES ('587', '5');
INSERT INTO `relProductoProveedor` VALUES ('587', '15');
INSERT INTO `relProductoProveedor` VALUES ('588', '16');
INSERT INTO `relProductoProveedor` VALUES ('589', '4');
INSERT INTO `relProductoProveedor` VALUES ('590', '4');
INSERT INTO `relProductoProveedor` VALUES ('591', '4');
INSERT INTO `relProductoProveedor` VALUES ('592', '4');
INSERT INTO `relProductoProveedor` VALUES ('593', '4');
INSERT INTO `relProductoProveedor` VALUES ('593', '5');
INSERT INTO `relProductoProveedor` VALUES ('594', '3');
INSERT INTO `relProductoProveedor` VALUES ('594', '4');
INSERT INTO `relProductoProveedor` VALUES ('595', '4');
INSERT INTO `relProductoProveedor` VALUES ('596', '3');
INSERT INTO `relProductoProveedor` VALUES ('596', '4');
INSERT INTO `relProductoProveedor` VALUES ('596', '5');
INSERT INTO `relProductoProveedor` VALUES ('597', '3');
INSERT INTO `relProductoProveedor` VALUES ('598', '4');
INSERT INTO `relProductoProveedor` VALUES ('599', '4');
INSERT INTO `relProductoProveedor` VALUES ('599', '5');
INSERT INTO `relProductoProveedor` VALUES ('600', '3');
INSERT INTO `relProductoProveedor` VALUES ('600', '4');
INSERT INTO `relProductoProveedor` VALUES ('601', '3');
INSERT INTO `relProductoProveedor` VALUES ('602', '3');
INSERT INTO `relProductoProveedor` VALUES ('602', '4');
INSERT INTO `relProductoProveedor` VALUES ('603', '4');
INSERT INTO `relProductoProveedor` VALUES ('605', '4');
INSERT INTO `relProductoProveedor` VALUES ('606', '4');
INSERT INTO `relProductoProveedor` VALUES ('607', '3');
INSERT INTO `relProductoProveedor` VALUES ('607', '4');
INSERT INTO `relProductoProveedor` VALUES ('608', '4');
INSERT INTO `relProductoProveedor` VALUES ('608', '5');
INSERT INTO `relProductoProveedor` VALUES ('609', '4');
INSERT INTO `relProductoProveedor` VALUES ('609', '5');
INSERT INTO `relProductoProveedor` VALUES ('610', '4');
INSERT INTO `relProductoProveedor` VALUES ('611', '4');
INSERT INTO `relProductoProveedor` VALUES ('611', '5');
INSERT INTO `relProductoProveedor` VALUES ('612', '4');
INSERT INTO `relProductoProveedor` VALUES ('612', '5');
INSERT INTO `relProductoProveedor` VALUES ('613', '4');
INSERT INTO `relProductoProveedor` VALUES ('614', '4');
INSERT INTO `relProductoProveedor` VALUES ('615', '3');
INSERT INTO `relProductoProveedor` VALUES ('615', '4');
INSERT INTO `relProductoProveedor` VALUES ('615', '5');
INSERT INTO `relProductoProveedor` VALUES ('619', '3');
INSERT INTO `relProductoProveedor` VALUES ('621', '3');
INSERT INTO `relProductoProveedor` VALUES ('622', '4');
INSERT INTO `relProductoProveedor` VALUES ('622', '5');
INSERT INTO `relProductoProveedor` VALUES ('623', '5');
INSERT INTO `relProductoProveedor` VALUES ('624', '5');
INSERT INTO `relProductoProveedor` VALUES ('625', '5');
INSERT INTO `relProductoProveedor` VALUES ('626', '4');
INSERT INTO `relProductoProveedor` VALUES ('626', '5');
INSERT INTO `relProductoProveedor` VALUES ('627', '4');
INSERT INTO `relProductoProveedor` VALUES ('627', '5');
INSERT INTO `relProductoProveedor` VALUES ('628', '5');
INSERT INTO `relProductoProveedor` VALUES ('629', '4');
INSERT INTO `relProductoProveedor` VALUES ('629', '5');
INSERT INTO `relProductoProveedor` VALUES ('630', '4');
INSERT INTO `relProductoProveedor` VALUES ('630', '5');
INSERT INTO `relProductoProveedor` VALUES ('631', '4');
INSERT INTO `relProductoProveedor` VALUES ('631', '5');
INSERT INTO `relProductoProveedor` VALUES ('632', '4');
INSERT INTO `relProductoProveedor` VALUES ('632', '5');
INSERT INTO `relProductoProveedor` VALUES ('633', '4');
INSERT INTO `relProductoProveedor` VALUES ('633', '5');
INSERT INTO `relProductoProveedor` VALUES ('634', '4');
INSERT INTO `relProductoProveedor` VALUES ('634', '5');
INSERT INTO `relProductoProveedor` VALUES ('635', '5');
INSERT INTO `relProductoProveedor` VALUES ('636', '4');
INSERT INTO `relProductoProveedor` VALUES ('636', '5');
INSERT INTO `relProductoProveedor` VALUES ('637', '4');
INSERT INTO `relProductoProveedor` VALUES ('637', '5');
INSERT INTO `relProductoProveedor` VALUES ('638', '4');
INSERT INTO `relProductoProveedor` VALUES ('638', '5');
INSERT INTO `relProductoProveedor` VALUES ('639', '4');
INSERT INTO `relProductoProveedor` VALUES ('639', '5');
INSERT INTO `relProductoProveedor` VALUES ('640', '3');
INSERT INTO `relProductoProveedor` VALUES ('640', '4');
INSERT INTO `relProductoProveedor` VALUES ('640', '5');
INSERT INTO `relProductoProveedor` VALUES ('641', '3');
INSERT INTO `relProductoProveedor` VALUES ('641', '4');
INSERT INTO `relProductoProveedor` VALUES ('641', '5');
INSERT INTO `relProductoProveedor` VALUES ('642', '3');
INSERT INTO `relProductoProveedor` VALUES ('642', '4');
INSERT INTO `relProductoProveedor` VALUES ('642', '5');
INSERT INTO `relProductoProveedor` VALUES ('643', '5');
INSERT INTO `relProductoProveedor` VALUES ('644', '5');
INSERT INTO `relProductoProveedor` VALUES ('644', '6');
INSERT INTO `relProductoProveedor` VALUES ('644', '7');
INSERT INTO `relProductoProveedor` VALUES ('645', '4');
INSERT INTO `relProductoProveedor` VALUES ('645', '5');
INSERT INTO `relProductoProveedor` VALUES ('646', '5');
INSERT INTO `relProductoProveedor` VALUES ('647', '5');
INSERT INTO `relProductoProveedor` VALUES ('648', '4');
INSERT INTO `relProductoProveedor` VALUES ('649', '4');
INSERT INTO `relProductoProveedor` VALUES ('650', '5');
INSERT INTO `relProductoProveedor` VALUES ('651', '5');
INSERT INTO `relProductoProveedor` VALUES ('652', '5');
INSERT INTO `relProductoProveedor` VALUES ('653', '5');
INSERT INTO `relProductoProveedor` VALUES ('654', '5');
INSERT INTO `relProductoProveedor` VALUES ('655', '5');
INSERT INTO `relProductoProveedor` VALUES ('656', '5');
INSERT INTO `relProductoProveedor` VALUES ('657', '4');
INSERT INTO `relProductoProveedor` VALUES ('659', '4');
INSERT INTO `relProductoProveedor` VALUES ('660', '4');
INSERT INTO `relProductoProveedor` VALUES ('661', '10');
INSERT INTO `relProductoProveedor` VALUES ('662', '9');
INSERT INTO `relProductoProveedor` VALUES ('663', '3');
INSERT INTO `relProductoProveedor` VALUES ('663', '4');
INSERT INTO `relProductoProveedor` VALUES ('664', '3');
INSERT INTO `relProductoProveedor` VALUES ('664', '4');
INSERT INTO `relProductoProveedor` VALUES ('665', '3');
INSERT INTO `relProductoProveedor` VALUES ('665', '4');
INSERT INTO `relProductoProveedor` VALUES ('666', '4');
INSERT INTO `relProductoProveedor` VALUES ('667', '4');
INSERT INTO `relProductoProveedor` VALUES ('668', '4');
INSERT INTO `relProductoProveedor` VALUES ('669', '4');
INSERT INTO `relProductoProveedor` VALUES ('670', '4');
INSERT INTO `relProductoProveedor` VALUES ('672', '4');
INSERT INTO `relProductoProveedor` VALUES ('672', '5');
INSERT INTO `relProductoProveedor` VALUES ('673', '7');
INSERT INTO `relProductoProveedor` VALUES ('674', '7');
INSERT INTO `relProductoProveedor` VALUES ('675', '3');
INSERT INTO `relProductoProveedor` VALUES ('675', '4');
INSERT INTO `relProductoProveedor` VALUES ('675', '5');
INSERT INTO `relProductoProveedor` VALUES ('676', '33');
INSERT INTO `relProductoProveedor` VALUES ('677', '3');
INSERT INTO `relProductoProveedor` VALUES ('677', '4');
INSERT INTO `relProductoProveedor` VALUES ('677', '5');
INSERT INTO `relProductoProveedor` VALUES ('679', '6');
INSERT INTO `relProductoProveedor` VALUES ('682', '6');
INSERT INTO `relProductoProveedor` VALUES ('683', '3');
INSERT INTO `relProductoProveedor` VALUES ('684', '13');
INSERT INTO `relProductoProveedor` VALUES ('685', '13');
INSERT INTO `relProductoProveedor` VALUES ('686', '13');
INSERT INTO `relProductoProveedor` VALUES ('691', '13');
INSERT INTO `relProductoProveedor` VALUES ('692', '13');
INSERT INTO `relProductoProveedor` VALUES ('693', '13');
INSERT INTO `relProductoProveedor` VALUES ('694', '21');
INSERT INTO `relProductoProveedor` VALUES ('695', '3');
INSERT INTO `relProductoProveedor` VALUES ('697', '5');
INSERT INTO `relProductoProveedor` VALUES ('698', '4');
INSERT INTO `relProductoProveedor` VALUES ('698', '5');
INSERT INTO `relProductoProveedor` VALUES ('699', '4');
INSERT INTO `relProductoProveedor` VALUES ('699', '5');
INSERT INTO `relProductoProveedor` VALUES ('700', '4');
INSERT INTO `relProductoProveedor` VALUES ('700', '5');
INSERT INTO `relProductoProveedor` VALUES ('701', '4');
INSERT INTO `relProductoProveedor` VALUES ('701', '5');
INSERT INTO `relProductoProveedor` VALUES ('702', '4');
INSERT INTO `relProductoProveedor` VALUES ('702', '5');
INSERT INTO `relProductoProveedor` VALUES ('703', '5');
INSERT INTO `relProductoProveedor` VALUES ('704', '4');
INSERT INTO `relProductoProveedor` VALUES ('704', '5');
INSERT INTO `relProductoProveedor` VALUES ('705', '4');
INSERT INTO `relProductoProveedor` VALUES ('705', '5');
INSERT INTO `relProductoProveedor` VALUES ('706', '4');
INSERT INTO `relProductoProveedor` VALUES ('706', '5');
INSERT INTO `relProductoProveedor` VALUES ('707', '4');
INSERT INTO `relProductoProveedor` VALUES ('707', '5');
INSERT INTO `relProductoProveedor` VALUES ('708', '4');
INSERT INTO `relProductoProveedor` VALUES ('708', '5');
INSERT INTO `relProductoProveedor` VALUES ('709', '4');
INSERT INTO `relProductoProveedor` VALUES ('709', '5');
INSERT INTO `relProductoProveedor` VALUES ('710', '4');
INSERT INTO `relProductoProveedor` VALUES ('710', '5');
INSERT INTO `relProductoProveedor` VALUES ('711', '4');
INSERT INTO `relProductoProveedor` VALUES ('711', '5');
INSERT INTO `relProductoProveedor` VALUES ('712', '5');
INSERT INTO `relProductoProveedor` VALUES ('713', '4');
INSERT INTO `relProductoProveedor` VALUES ('713', '5');
INSERT INTO `relProductoProveedor` VALUES ('714', '4');
INSERT INTO `relProductoProveedor` VALUES ('714', '5');
INSERT INTO `relProductoProveedor` VALUES ('715', '4');
INSERT INTO `relProductoProveedor` VALUES ('715', '5');
INSERT INTO `relProductoProveedor` VALUES ('716', '4');
INSERT INTO `relProductoProveedor` VALUES ('716', '5');
INSERT INTO `relProductoProveedor` VALUES ('717', '4');
INSERT INTO `relProductoProveedor` VALUES ('717', '5');
INSERT INTO `relProductoProveedor` VALUES ('718', '4');
INSERT INTO `relProductoProveedor` VALUES ('718', '5');
INSERT INTO `relProductoProveedor` VALUES ('719', '3');
INSERT INTO `relProductoProveedor` VALUES ('720', '3');
INSERT INTO `relProductoProveedor` VALUES ('721', '3');
INSERT INTO `relProductoProveedor` VALUES ('721', '4');
INSERT INTO `relProductoProveedor` VALUES ('722', '3');
INSERT INTO `relProductoProveedor` VALUES ('723', '3');
INSERT INTO `relProductoProveedor` VALUES ('724', '3');
INSERT INTO `relProductoProveedor` VALUES ('725', '3');
INSERT INTO `relProductoProveedor` VALUES ('726', '13');
INSERT INTO `relProductoProveedor` VALUES ('726', '34');
INSERT INTO `relProductoProveedor` VALUES ('727', '13');
INSERT INTO `relProductoProveedor` VALUES ('728', '5');
INSERT INTO `relProductoProveedor` VALUES ('729', '5');
INSERT INTO `relProductoProveedor` VALUES ('730', '3');
INSERT INTO `relProductoProveedor` VALUES ('731', '3');
INSERT INTO `relProductoProveedor` VALUES ('732', '3');
INSERT INTO `relProductoProveedor` VALUES ('733', '3');
INSERT INTO `relProductoProveedor` VALUES ('733', '4');
INSERT INTO `relProductoProveedor` VALUES ('733', '5');
INSERT INTO `relProductoProveedor` VALUES ('734', '3');
INSERT INTO `relProductoProveedor` VALUES ('734', '5');
INSERT INTO `relProductoProveedor` VALUES ('735', '5');
INSERT INTO `relProductoProveedor` VALUES ('737', '5');
INSERT INTO `relProductoProveedor` VALUES ('738', '4');
INSERT INTO `relProductoProveedor` VALUES ('738', '5');
INSERT INTO `relProductoProveedor` VALUES ('739', '4');
INSERT INTO `relProductoProveedor` VALUES ('739', '5');
INSERT INTO `relProductoProveedor` VALUES ('741', '6');
INSERT INTO `relProductoProveedor` VALUES ('742', '3');
INSERT INTO `relProductoProveedor` VALUES ('742', '5');
INSERT INTO `relProductoProveedor` VALUES ('743', '30');
INSERT INTO `relProductoProveedor` VALUES ('744', '30');
INSERT INTO `relProductoProveedor` VALUES ('745', '5');
INSERT INTO `relProductoProveedor` VALUES ('746', '3');
INSERT INTO `relProductoProveedor` VALUES ('746', '5');
INSERT INTO `relProductoProveedor` VALUES ('747', '5');
INSERT INTO `relProductoProveedor` VALUES ('748', '5');
INSERT INTO `relProductoProveedor` VALUES ('749', '30');
INSERT INTO `relProductoProveedor` VALUES ('750', '30');
INSERT INTO `relProductoProveedor` VALUES ('751', '30');
INSERT INTO `relProductoProveedor` VALUES ('752', '3');
INSERT INTO `relProductoProveedor` VALUES ('752', '5');
INSERT INTO `relProductoProveedor` VALUES ('753', '30');
INSERT INTO `relProductoProveedor` VALUES ('754', '3');
INSERT INTO `relProductoProveedor` VALUES ('754', '5');
INSERT INTO `relProductoProveedor` VALUES ('756', '3');
INSERT INTO `relProductoProveedor` VALUES ('756', '5');
INSERT INTO `relProductoProveedor` VALUES ('757', '5');
INSERT INTO `relProductoProveedor` VALUES ('758', '9');
INSERT INTO `relProductoProveedor` VALUES ('759', '5');
INSERT INTO `relProductoProveedor` VALUES ('760', '9');
INSERT INTO `relProductoProveedor` VALUES ('761', '5');
INSERT INTO `relProductoProveedor` VALUES ('762', '9');
INSERT INTO `relProductoProveedor` VALUES ('763', '3');
INSERT INTO `relProductoProveedor` VALUES ('763', '5');
INSERT INTO `relProductoProveedor` VALUES ('764', '8');
INSERT INTO `relProductoProveedor` VALUES ('766', '4');
INSERT INTO `relProductoProveedor` VALUES ('766', '5');
INSERT INTO `relProductoProveedor` VALUES ('766', '26');
INSERT INTO `relProductoProveedor` VALUES ('767', '3');
INSERT INTO `relProductoProveedor` VALUES ('768', '20');
INSERT INTO `relProductoProveedor` VALUES ('769', '4');
INSERT INTO `relProductoProveedor` VALUES ('769', '10');
INSERT INTO `relProductoProveedor` VALUES ('771', '4');
INSERT INTO `relProductoProveedor` VALUES ('772', '4');
INSERT INTO `relProductoProveedor` VALUES ('773', '25');
INSERT INTO `relProductoProveedor` VALUES ('774', '25');
INSERT INTO `relProductoProveedor` VALUES ('775', '25');
INSERT INTO `relProductoProveedor` VALUES ('776', '7');
INSERT INTO `relProductoProveedor` VALUES ('777', '3');
INSERT INTO `relProductoProveedor` VALUES ('778', '3');
INSERT INTO `relProductoProveedor` VALUES ('779', '3');
INSERT INTO `relProductoProveedor` VALUES ('779', '4');
INSERT INTO `relProductoProveedor` VALUES ('779', '5');
INSERT INTO `relProductoProveedor` VALUES ('780', '10');
INSERT INTO `relProductoProveedor` VALUES ('781', '3');
INSERT INTO `relProductoProveedor` VALUES ('781', '16');
INSERT INTO `relProductoProveedor` VALUES ('782', '5');
INSERT INTO `relProductoProveedor` VALUES ('782', '26');
INSERT INTO `relProductoProveedor` VALUES ('784', '4');
INSERT INTO `relProductoProveedor` VALUES ('784', '5');
INSERT INTO `relProductoProveedor` VALUES ('785', '4');
INSERT INTO `relProductoProveedor` VALUES ('785', '5');
INSERT INTO `relProductoProveedor` VALUES ('788', '3');
INSERT INTO `relProductoProveedor` VALUES ('789', '3');
INSERT INTO `relProductoProveedor` VALUES ('790', '3');
INSERT INTO `relProductoProveedor` VALUES ('790', '4');
INSERT INTO `relProductoProveedor` VALUES ('790', '5');
INSERT INTO `relProductoProveedor` VALUES ('791', '35');
INSERT INTO `relProductoProveedor` VALUES ('797', '3');
INSERT INTO `relProductoProveedor` VALUES ('798', '3');
INSERT INTO `relProductoProveedor` VALUES ('799', '9');
INSERT INTO `relProductoProveedor` VALUES ('800', '9');
INSERT INTO `relProductoProveedor` VALUES ('801', '9');
INSERT INTO `relProductoProveedor` VALUES ('802', '8');
INSERT INTO `relProductoProveedor` VALUES ('803', '8');
INSERT INTO `relProductoProveedor` VALUES ('804', '8');
INSERT INTO `relProductoProveedor` VALUES ('805', '9');
INSERT INTO `relProductoProveedor` VALUES ('806', '3');
INSERT INTO `relProductoProveedor` VALUES ('807', '9');
INSERT INTO `relProductoProveedor` VALUES ('808', '3');
INSERT INTO `relProductoProveedor` VALUES ('809', '4');
INSERT INTO `relProductoProveedor` VALUES ('809', '10');
INSERT INTO `relProductoProveedor` VALUES ('810', '4');
INSERT INTO `relProductoProveedor` VALUES ('810', '10');
INSERT INTO `relProductoProveedor` VALUES ('811', '3');
INSERT INTO `relProductoProveedor` VALUES ('812', '4');
INSERT INTO `relProductoProveedor` VALUES ('812', '5');
INSERT INTO `relProductoProveedor` VALUES ('813', '4');
INSERT INTO `relProductoProveedor` VALUES ('813', '5');
INSERT INTO `relProductoProveedor` VALUES ('814', '10');
INSERT INTO `relProductoProveedor` VALUES ('815', '3');
INSERT INTO `relProductoProveedor` VALUES ('816', '23');
INSERT INTO `relProductoProveedor` VALUES ('817', '23');
INSERT INTO `relProductoProveedor` VALUES ('818', '9');
INSERT INTO `relProductoProveedor` VALUES ('819', '9');
INSERT INTO `relProductoProveedor` VALUES ('821', '4');
INSERT INTO `relProductoProveedor` VALUES ('822', '9');
INSERT INTO `relProductoProveedor` VALUES ('823', '4');
INSERT INTO `relProductoProveedor` VALUES ('824', '9');
INSERT INTO `relProductoProveedor` VALUES ('825', '3');
INSERT INTO `relProductoProveedor` VALUES ('826', '3');
INSERT INTO `relProductoProveedor` VALUES ('827', '4');
INSERT INTO `relProductoProveedor` VALUES ('827', '5');
INSERT INTO `relProductoProveedor` VALUES ('828', '3');
INSERT INTO `relProductoProveedor` VALUES ('830', '10');
INSERT INTO `relProductoProveedor` VALUES ('831', '10');
INSERT INTO `relProductoProveedor` VALUES ('832', '4');
INSERT INTO `relProductoProveedor` VALUES ('832', '5');
INSERT INTO `relProductoProveedor` VALUES ('832', '10');
INSERT INTO `relProductoProveedor` VALUES ('833', '4');
INSERT INTO `relProductoProveedor` VALUES ('833', '5');
INSERT INTO `relProductoProveedor` VALUES ('834', '4');
INSERT INTO `relProductoProveedor` VALUES ('838', '4');
INSERT INTO `relProductoProveedor` VALUES ('839', '5');
INSERT INTO `relProductoProveedor` VALUES ('840', '3');
INSERT INTO `relProductoProveedor` VALUES ('840', '5');
INSERT INTO `relProductoProveedor` VALUES ('841', '4');
INSERT INTO `relProductoProveedor` VALUES ('841', '5');
INSERT INTO `relProductoProveedor` VALUES ('842', '5');
INSERT INTO `relProductoProveedor` VALUES ('843', '5');
INSERT INTO `relProductoProveedor` VALUES ('844', '3');
INSERT INTO `relProductoProveedor` VALUES ('845', '5');
INSERT INTO `relProductoProveedor` VALUES ('846', '4');
INSERT INTO `relProductoProveedor` VALUES ('846', '5');
INSERT INTO `relProductoProveedor` VALUES ('847', '4');
INSERT INTO `relProductoProveedor` VALUES ('847', '5');
INSERT INTO `relProductoProveedor` VALUES ('849', '4');
INSERT INTO `relProductoProveedor` VALUES ('849', '5');
INSERT INTO `relProductoProveedor` VALUES ('850', '4');
INSERT INTO `relProductoProveedor` VALUES ('850', '5');
INSERT INTO `relProductoProveedor` VALUES ('852', '3');
INSERT INTO `relProductoProveedor` VALUES ('852', '4');
INSERT INTO `relProductoProveedor` VALUES ('852', '5');
INSERT INTO `relProductoProveedor` VALUES ('854', '4');
INSERT INTO `relProductoProveedor` VALUES ('854', '5');
INSERT INTO `relProductoProveedor` VALUES ('855', '4');
INSERT INTO `relProductoProveedor` VALUES ('855', '5');
INSERT INTO `relProductoProveedor` VALUES ('856', '4');
INSERT INTO `relProductoProveedor` VALUES ('856', '5');
INSERT INTO `relProductoProveedor` VALUES ('857', '4');
INSERT INTO `relProductoProveedor` VALUES ('857', '5');
INSERT INTO `relProductoProveedor` VALUES ('858', '4');
INSERT INTO `relProductoProveedor` VALUES ('858', '5');
INSERT INTO `relProductoProveedor` VALUES ('859', '4');
INSERT INTO `relProductoProveedor` VALUES ('859', '5');
INSERT INTO `relProductoProveedor` VALUES ('860', '4');
INSERT INTO `relProductoProveedor` VALUES ('860', '5');
INSERT INTO `relProductoProveedor` VALUES ('861', '4');
INSERT INTO `relProductoProveedor` VALUES ('861', '5');
INSERT INTO `relProductoProveedor` VALUES ('862', '4');
INSERT INTO `relProductoProveedor` VALUES ('862', '5');
INSERT INTO `relProductoProveedor` VALUES ('863', '4');
INSERT INTO `relProductoProveedor` VALUES ('863', '5');
INSERT INTO `relProductoProveedor` VALUES ('864', '4');
INSERT INTO `relProductoProveedor` VALUES ('864', '5');
INSERT INTO `relProductoProveedor` VALUES ('865', '4');
INSERT INTO `relProductoProveedor` VALUES ('865', '5');
INSERT INTO `relProductoProveedor` VALUES ('866', '4');
INSERT INTO `relProductoProveedor` VALUES ('866', '5');
INSERT INTO `relProductoProveedor` VALUES ('867', '4');
INSERT INTO `relProductoProveedor` VALUES ('867', '5');
INSERT INTO `relProductoProveedor` VALUES ('868', '4');
INSERT INTO `relProductoProveedor` VALUES ('868', '5');
INSERT INTO `relProductoProveedor` VALUES ('869', '4');
INSERT INTO `relProductoProveedor` VALUES ('869', '5');
INSERT INTO `relProductoProveedor` VALUES ('870', '4');
INSERT INTO `relProductoProveedor` VALUES ('870', '5');
INSERT INTO `relProductoProveedor` VALUES ('871', '4');
INSERT INTO `relProductoProveedor` VALUES ('871', '5');
INSERT INTO `relProductoProveedor` VALUES ('872', '4');
INSERT INTO `relProductoProveedor` VALUES ('872', '5');
INSERT INTO `relProductoProveedor` VALUES ('873', '4');
INSERT INTO `relProductoProveedor` VALUES ('873', '5');
INSERT INTO `relProductoProveedor` VALUES ('874', '4');
INSERT INTO `relProductoProveedor` VALUES ('874', '5');
INSERT INTO `relProductoProveedor` VALUES ('875', '4');
INSERT INTO `relProductoProveedor` VALUES ('875', '5');
INSERT INTO `relProductoProveedor` VALUES ('876', '4');
INSERT INTO `relProductoProveedor` VALUES ('876', '5');
INSERT INTO `relProductoProveedor` VALUES ('881', '3');
INSERT INTO `relProductoProveedor` VALUES ('889', '4');
INSERT INTO `relProductoProveedor` VALUES ('889', '5');
INSERT INTO `relProductoProveedor` VALUES ('890', '4');
INSERT INTO `relProductoProveedor` VALUES ('890', '5');
INSERT INTO `relProductoProveedor` VALUES ('891', '4');
INSERT INTO `relProductoProveedor` VALUES ('891', '5');
INSERT INTO `relProductoProveedor` VALUES ('892', '4');
INSERT INTO `relProductoProveedor` VALUES ('892', '5');
INSERT INTO `relProductoProveedor` VALUES ('893', '4');
INSERT INTO `relProductoProveedor` VALUES ('893', '5');
INSERT INTO `relProductoProveedor` VALUES ('894', '4');
INSERT INTO `relProductoProveedor` VALUES ('894', '5');
INSERT INTO `relProductoProveedor` VALUES ('895', '4');
INSERT INTO `relProductoProveedor` VALUES ('895', '5');
INSERT INTO `relProductoProveedor` VALUES ('896', '4');
INSERT INTO `relProductoProveedor` VALUES ('896', '5');
INSERT INTO `relProductoProveedor` VALUES ('897', '4');
INSERT INTO `relProductoProveedor` VALUES ('897', '5');
INSERT INTO `relProductoProveedor` VALUES ('898', '4');
INSERT INTO `relProductoProveedor` VALUES ('898', '5');
INSERT INTO `relProductoProveedor` VALUES ('899', '4');
INSERT INTO `relProductoProveedor` VALUES ('899', '5');
INSERT INTO `relProductoProveedor` VALUES ('900', '4');
INSERT INTO `relProductoProveedor` VALUES ('900', '5');
INSERT INTO `relProductoProveedor` VALUES ('901', '3');
INSERT INTO `relProductoProveedor` VALUES ('901', '4');
INSERT INTO `relProductoProveedor` VALUES ('901', '5');
INSERT INTO `relProductoProveedor` VALUES ('902', '3');
INSERT INTO `relProductoProveedor` VALUES ('902', '4');
INSERT INTO `relProductoProveedor` VALUES ('902', '5');
INSERT INTO `relProductoProveedor` VALUES ('903', '3');
INSERT INTO `relProductoProveedor` VALUES ('903', '4');
INSERT INTO `relProductoProveedor` VALUES ('903', '5');
INSERT INTO `relProductoProveedor` VALUES ('904', '4');
INSERT INTO `relProductoProveedor` VALUES ('904', '5');
INSERT INTO `relProductoProveedor` VALUES ('905', '4');
INSERT INTO `relProductoProveedor` VALUES ('905', '5');
INSERT INTO `relProductoProveedor` VALUES ('906', '3');
INSERT INTO `relProductoProveedor` VALUES ('906', '4');
INSERT INTO `relProductoProveedor` VALUES ('906', '5');
INSERT INTO `relProductoProveedor` VALUES ('907', '4');
INSERT INTO `relProductoProveedor` VALUES ('907', '5');
INSERT INTO `relProductoProveedor` VALUES ('908', '4');
INSERT INTO `relProductoProveedor` VALUES ('908', '5');
INSERT INTO `relProductoProveedor` VALUES ('909', '14');
INSERT INTO `relProductoProveedor` VALUES ('910', '14');
INSERT INTO `relProductoProveedor` VALUES ('911', '14');
INSERT INTO `relProductoProveedor` VALUES ('912', '14');
INSERT INTO `relProductoProveedor` VALUES ('913', '14');
INSERT INTO `relProductoProveedor` VALUES ('914', '14');
INSERT INTO `relProductoProveedor` VALUES ('915', '14');
INSERT INTO `relProductoProveedor` VALUES ('916', '14');
INSERT INTO `relProductoProveedor` VALUES ('917', '14');
INSERT INTO `relProductoProveedor` VALUES ('918', '14');
INSERT INTO `relProductoProveedor` VALUES ('919', '14');
INSERT INTO `relProductoProveedor` VALUES ('920', '14');
INSERT INTO `relProductoProveedor` VALUES ('921', '14');
INSERT INTO `relProductoProveedor` VALUES ('922', '14');
INSERT INTO `relProductoProveedor` VALUES ('923', '14');
INSERT INTO `relProductoProveedor` VALUES ('924', '14');
INSERT INTO `relProductoProveedor` VALUES ('925', '14');
INSERT INTO `relProductoProveedor` VALUES ('926', '14');
INSERT INTO `relProductoProveedor` VALUES ('927', '3');
INSERT INTO `relProductoProveedor` VALUES ('928', '3');
INSERT INTO `relProductoProveedor` VALUES ('929', '36');
INSERT INTO `relProductoProveedor` VALUES ('930', '4');
INSERT INTO `relProductoProveedor` VALUES ('931', '4');
INSERT INTO `relProductoProveedor` VALUES ('933', '4');
INSERT INTO `relProductoProveedor` VALUES ('934', '5');
INSERT INTO `relProductoProveedor` VALUES ('935', '4');
INSERT INTO `relProductoProveedor` VALUES ('935', '5');
INSERT INTO `relProductoProveedor` VALUES ('936', '5');
INSERT INTO `relProductoProveedor` VALUES ('937', '4');
INSERT INTO `relProductoProveedor` VALUES ('937', '5');
INSERT INTO `relProductoProveedor` VALUES ('938', '4');
INSERT INTO `relProductoProveedor` VALUES ('939', '4');
INSERT INTO `relProductoProveedor` VALUES ('940', '4');
INSERT INTO `relProductoProveedor` VALUES ('941', '25');
INSERT INTO `relProductoProveedor` VALUES ('942', '25');
INSERT INTO `relProductoProveedor` VALUES ('942', '29');
INSERT INTO `relProductoProveedor` VALUES ('943', '4');
INSERT INTO `relProductoProveedor` VALUES ('944', '4');
INSERT INTO `relProductoProveedor` VALUES ('947', '20');
INSERT INTO `relProductoProveedor` VALUES ('948', '25');
INSERT INTO `relProductoProveedor` VALUES ('949', '4');
INSERT INTO `relProductoProveedor` VALUES ('949', '5');
INSERT INTO `relProductoProveedor` VALUES ('950', '4');
INSERT INTO `relProductoProveedor` VALUES ('950', '5');
INSERT INTO `relProductoProveedor` VALUES ('951', '4');
INSERT INTO `relProductoProveedor` VALUES ('951', '5');
INSERT INTO `relProductoProveedor` VALUES ('952', '4');
INSERT INTO `relProductoProveedor` VALUES ('952', '5');
INSERT INTO `relProductoProveedor` VALUES ('953', '4');
INSERT INTO `relProductoProveedor` VALUES ('953', '5');
INSERT INTO `relProductoProveedor` VALUES ('953', '26');
INSERT INTO `relProductoProveedor` VALUES ('954', '4');
INSERT INTO `relProductoProveedor` VALUES ('954', '5');
INSERT INTO `relProductoProveedor` VALUES ('955', '4');
INSERT INTO `relProductoProveedor` VALUES ('955', '5');
INSERT INTO `relProductoProveedor` VALUES ('956', '4');
INSERT INTO `relProductoProveedor` VALUES ('956', '5');
INSERT INTO `relProductoProveedor` VALUES ('957', '4');
INSERT INTO `relProductoProveedor` VALUES ('957', '5');
INSERT INTO `relProductoProveedor` VALUES ('958', '4');
INSERT INTO `relProductoProveedor` VALUES ('958', '5');
INSERT INTO `relProductoProveedor` VALUES ('959', '4');
INSERT INTO `relProductoProveedor` VALUES ('959', '5');
INSERT INTO `relProductoProveedor` VALUES ('959', '26');
INSERT INTO `relProductoProveedor` VALUES ('960', '4');
INSERT INTO `relProductoProveedor` VALUES ('960', '5');
INSERT INTO `relProductoProveedor` VALUES ('961', '4');
INSERT INTO `relProductoProveedor` VALUES ('961', '5');
INSERT INTO `relProductoProveedor` VALUES ('962', '4');
INSERT INTO `relProductoProveedor` VALUES ('962', '5');
INSERT INTO `relProductoProveedor` VALUES ('963', '4');
INSERT INTO `relProductoProveedor` VALUES ('963', '5');
INSERT INTO `relProductoProveedor` VALUES ('964', '4');
INSERT INTO `relProductoProveedor` VALUES ('964', '5');
INSERT INTO `relProductoProveedor` VALUES ('964', '26');
INSERT INTO `relProductoProveedor` VALUES ('965', '4');
INSERT INTO `relProductoProveedor` VALUES ('965', '5');
INSERT INTO `relProductoProveedor` VALUES ('966', '4');
INSERT INTO `relProductoProveedor` VALUES ('966', '5');
INSERT INTO `relProductoProveedor` VALUES ('967', '4');
INSERT INTO `relProductoProveedor` VALUES ('967', '5');
INSERT INTO `relProductoProveedor` VALUES ('968', '4');
INSERT INTO `relProductoProveedor` VALUES ('968', '5');
INSERT INTO `relProductoProveedor` VALUES ('969', '37');
INSERT INTO `relProductoProveedor` VALUES ('971', '9');
INSERT INTO `relProductoProveedor` VALUES ('972', '4');
INSERT INTO `relProductoProveedor` VALUES ('973', '4');
INSERT INTO `relProductoProveedor` VALUES ('974', '4');
INSERT INTO `relProductoProveedor` VALUES ('974', '25');
INSERT INTO `relProductoProveedor` VALUES ('975', '4');
INSERT INTO `relProductoProveedor` VALUES ('975', '25');
INSERT INTO `relProductoProveedor` VALUES ('976', '4');
INSERT INTO `relProductoProveedor` VALUES ('976', '25');
INSERT INTO `relProductoProveedor` VALUES ('977', '5');
INSERT INTO `relProductoProveedor` VALUES ('978', '29');
INSERT INTO `relProductoProveedor` VALUES ('979', '4');
INSERT INTO `relProductoProveedor` VALUES ('979', '25');
INSERT INTO `relProductoProveedor` VALUES ('981', '4');
INSERT INTO `relProductoProveedor` VALUES ('981', '25');
INSERT INTO `relProductoProveedor` VALUES ('982', '4');
INSERT INTO `relProductoProveedor` VALUES ('982', '25');
INSERT INTO `relProductoProveedor` VALUES ('983', '4');
INSERT INTO `relProductoProveedor` VALUES ('983', '25');
INSERT INTO `relProductoProveedor` VALUES ('984', '29');
INSERT INTO `relProductoProveedor` VALUES ('985', '38');
INSERT INTO `relProductoProveedor` VALUES ('986', '29');
INSERT INTO `relProductoProveedor` VALUES ('987', '29');
INSERT INTO `relProductoProveedor` VALUES ('988', '4');
INSERT INTO `relProductoProveedor` VALUES ('988', '25');
INSERT INTO `relProductoProveedor` VALUES ('989', '29');
INSERT INTO `relProductoProveedor` VALUES ('990', '5');
INSERT INTO `relProductoProveedor` VALUES ('991', '29');
INSERT INTO `relProductoProveedor` VALUES ('992', '25');
INSERT INTO `relProductoProveedor` VALUES ('992', '29');
INSERT INTO `relProductoProveedor` VALUES ('994', '25');
INSERT INTO `relProductoProveedor` VALUES ('995', '25');
INSERT INTO `relProductoProveedor` VALUES ('996', '29');
INSERT INTO `relProductoProveedor` VALUES ('997', '29');
INSERT INTO `relProductoProveedor` VALUES ('999', '39');
INSERT INTO `relProductoProveedor` VALUES ('1000', '39');
INSERT INTO `relProductoProveedor` VALUES ('1001', '39');
INSERT INTO `relProductoProveedor` VALUES ('1002', '39');
INSERT INTO `relProductoProveedor` VALUES ('1003', '3');
INSERT INTO `relProductoProveedor` VALUES ('1004', '3');
INSERT INTO `relProductoProveedor` VALUES ('1005', '4');
INSERT INTO `relProductoProveedor` VALUES ('1006', '39');
INSERT INTO `relProductoProveedor` VALUES ('1007', '39');
INSERT INTO `relProductoProveedor` VALUES ('1008', '39');
INSERT INTO `relProductoProveedor` VALUES ('1009', '39');
INSERT INTO `relProductoProveedor` VALUES ('1010', '39');
INSERT INTO `relProductoProveedor` VALUES ('1011', '39');
INSERT INTO `relProductoProveedor` VALUES ('1012', '39');
INSERT INTO `relProductoProveedor` VALUES ('1013', '39');
INSERT INTO `relProductoProveedor` VALUES ('1014', '39');
INSERT INTO `relProductoProveedor` VALUES ('1015', '39');
INSERT INTO `relProductoProveedor` VALUES ('1016', '39');
INSERT INTO `relProductoProveedor` VALUES ('1017', '39');
INSERT INTO `relProductoProveedor` VALUES ('1018', '39');
INSERT INTO `relProductoProveedor` VALUES ('1019', '39');
INSERT INTO `relProductoProveedor` VALUES ('1020', '39');
INSERT INTO `relProductoProveedor` VALUES ('1022', '39');
INSERT INTO `relProductoProveedor` VALUES ('1023', '39');
INSERT INTO `relProductoProveedor` VALUES ('1024', '39');
INSERT INTO `relProductoProveedor` VALUES ('1025', '39');
INSERT INTO `relProductoProveedor` VALUES ('1026', '39');
INSERT INTO `relProductoProveedor` VALUES ('1027', '39');
INSERT INTO `relProductoProveedor` VALUES ('1029', '5');
INSERT INTO `relProductoProveedor` VALUES ('1030', '5');
INSERT INTO `relProductoProveedor` VALUES ('1031', '39');
INSERT INTO `relProductoProveedor` VALUES ('1032', '39');
INSERT INTO `relProductoProveedor` VALUES ('1033', '39');
INSERT INTO `relProductoProveedor` VALUES ('1034', '39');
INSERT INTO `relProductoProveedor` VALUES ('1035', '39');
INSERT INTO `relProductoProveedor` VALUES ('1036', '39');
INSERT INTO `relProductoProveedor` VALUES ('1037', '39');
INSERT INTO `relProductoProveedor` VALUES ('1038', '4');
INSERT INTO `relProductoProveedor` VALUES ('1039', '39');
INSERT INTO `relProductoProveedor` VALUES ('1040', '39');
INSERT INTO `relProductoProveedor` VALUES ('1041', '4');
INSERT INTO `relProductoProveedor` VALUES ('1042', '39');
INSERT INTO `relProductoProveedor` VALUES ('1044', '4');
INSERT INTO `relProductoProveedor` VALUES ('1044', '5');
INSERT INTO `relProductoProveedor` VALUES ('1045', '4');
INSERT INTO `relProductoProveedor` VALUES ('1045', '5');
INSERT INTO `relProductoProveedor` VALUES ('1046', '4');
INSERT INTO `relProductoProveedor` VALUES ('1046', '5');
INSERT INTO `relProductoProveedor` VALUES ('1047', '4');
INSERT INTO `relProductoProveedor` VALUES ('1047', '5');
INSERT INTO `relProductoProveedor` VALUES ('1048', '4');
INSERT INTO `relProductoProveedor` VALUES ('1048', '5');
INSERT INTO `relProductoProveedor` VALUES ('1049', '4');
INSERT INTO `relProductoProveedor` VALUES ('1049', '5');
INSERT INTO `relProductoProveedor` VALUES ('1050', '9');
INSERT INTO `relProductoProveedor` VALUES ('1058', '33');
INSERT INTO `relProductoProveedor` VALUES ('1060', '3');
INSERT INTO `relProductoProveedor` VALUES ('1064', '33');
INSERT INTO `relProductoProveedor` VALUES ('1065', '33');
INSERT INTO `relProductoProveedor` VALUES ('1068', '33');
INSERT INTO `relProductoProveedor` VALUES ('1070', '40');
INSERT INTO `relProductoProveedor` VALUES ('1072', '23');
INSERT INTO `relProductoProveedor` VALUES ('1072', '33');
INSERT INTO `relProductoProveedor` VALUES ('1073', '33');
INSERT INTO `relProductoProveedor` VALUES ('1074', '33');
INSERT INTO `relProductoProveedor` VALUES ('1078', '23');
INSERT INTO `relProductoProveedor` VALUES ('1086', '33');
INSERT INTO `relProductoProveedor` VALUES ('1087', '33');
INSERT INTO `relProductoProveedor` VALUES ('1088', '33');
INSERT INTO `relProductoProveedor` VALUES ('1089', '33');
INSERT INTO `relProductoProveedor` VALUES ('1095', '3');
INSERT INTO `relProductoProveedor` VALUES ('1096', '3');
INSERT INTO `relProductoProveedor` VALUES ('1097', '41');
INSERT INTO `relProductoProveedor` VALUES ('1098', '41');
INSERT INTO `relProductoProveedor` VALUES ('1100', '40');
INSERT INTO `relProductoProveedor` VALUES ('1101', '33');
INSERT INTO `relProductoProveedor` VALUES ('1104', '33');
INSERT INTO `relProductoProveedor` VALUES ('1105', '23');
INSERT INTO `relProductoProveedor` VALUES ('1106', '33');
INSERT INTO `relProductoProveedor` VALUES ('1107', '42');
INSERT INTO `relProductoProveedor` VALUES ('1108', '33');
INSERT INTO `relProductoProveedor` VALUES ('1109', '41');
INSERT INTO `relProductoProveedor` VALUES ('1110', '41');
INSERT INTO `relProductoProveedor` VALUES ('1111', '33');
INSERT INTO `relProductoProveedor` VALUES ('1112', '33');
INSERT INTO `relProductoProveedor` VALUES ('1113', '33');
INSERT INTO `relProductoProveedor` VALUES ('1114', '23');
INSERT INTO `relProductoProveedor` VALUES ('1116', '33');
INSERT INTO `relProductoProveedor` VALUES ('1117', '33');
INSERT INTO `relProductoProveedor` VALUES ('1119', '3');
INSERT INTO `relProductoProveedor` VALUES ('1120', '3');
INSERT INTO `relProductoProveedor` VALUES ('1121', '33');
INSERT INTO `relProductoProveedor` VALUES ('1122', '33');
INSERT INTO `relProductoProveedor` VALUES ('1123', '33');
INSERT INTO `relProductoProveedor` VALUES ('1124', '33');
INSERT INTO `relProductoProveedor` VALUES ('1125', '33');
INSERT INTO `relProductoProveedor` VALUES ('1126', '40');
INSERT INTO `relProductoProveedor` VALUES ('1128', '40');
INSERT INTO `relProductoProveedor` VALUES ('1129', '33');
INSERT INTO `relProductoProveedor` VALUES ('1130', '23');
INSERT INTO `relProductoProveedor` VALUES ('1131', '33');
