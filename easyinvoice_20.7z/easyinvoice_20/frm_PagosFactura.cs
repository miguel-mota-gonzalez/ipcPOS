using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
    public partial class frm_PagosFactura : Form
    {
    	
    	public int m_KeyFactura = -1;
    	public string m_ClientName = "";
        public int m_idCliente = -1;
    	private System.Data.DataSet m_dataset;
    	private System.Windows.Forms.BindingSource mp_bs = new BindingSource();

        // SVM Nov2010, ahora tambien aplican pagos para notas de venta
        public bool m_bool_EsNota = false;
        private string m_string_tablemovs = "catFacturas";

        public frm_PagosFactura()
        {
            InitializeComponent();
        }
        
        private void frmPagosFactura_Load(object sender, System.EventArgs e)
        {
            if (this.m_bool_EsNota)
            {
                this.Text = "Detalle de pagos de la nota";
                this.lbl_numero.Text = "N�mero de Nota:";
                this.m_string_tablemovs = "catNotas";
            }
        	this.FillDataSet();
        	this.LoadInvoiceData();
        }
        
        private void FillDataSet()
        {
            try
            {
                string lesfactura="1";
                if(this.m_bool_EsNota)
                    lesfactura="0";

                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "SELECT * FROM detPagosFacturas WHERE cancelado=0 AND esfactura=" + lesfactura  + " AND IdFactura = " + this.m_KeyFactura.ToString();
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "pagos";
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;       
                
                 this.dataGridView1.Columns[0].Visible = false;
                 this.dataGridView1.Columns["esfactura"].Visible = false;
                 this.dataGridView1.Columns["IdFactura"].Visible = false;
                 this.dataGridView1.Columns["Observaciones"].Visible = false;
                 this.dataGridView1.Columns["TipoPago"].Visible = false;
                 this.dataGridView1.Columns["cancelado"].Visible = false;

                 this.dataGridView1.Columns["numeronotacred"].HeaderText="Nota de Cr�dito"; 

            }
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }        	
        }
        
        private void LoadInvoiceData()
        {
        	
        	System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
        	
        	try
        	{
                l_conn.ConnectionString = frm_Main.mps_strconnection;
	        	
	            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
	            l_cmd.Connection = l_conn;
                l_cmd.CommandText = "SELECT * FROM " + this.m_string_tablemovs + " WHERE idFactura = " + this.m_KeyFactura.ToString();
	            
	            l_conn.Open();
	            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
	            
	            if(l_reader.Read())
	            {
	            	//Nombre del cliente...
	            	this.lbl_cliente.Text = "Cliente : " + this.m_ClientName;
                    this.m_idCliente = Convert.ToInt32(l_reader["idcliente"]);
	            	
	            	//N�mero de factura
                    if (this.m_bool_EsNota)
                        this.lbl_numero.Text = "Nota n�mero : " + l_reader["NumeroFactura"].ToString();
                    else
	            	    this.lbl_numero.Text = "Factura n�mero : " + l_reader["NumeroFactura"].ToString();
	            	
	            	//Fecha
	            	this.lbl_fecha.Text = "Emitida el " + Convert.ToDateTime(l_reader["Fecha"]).ToLongDateString();
	            	
	            	//Total
	            	this.lbl_total.Text = ("Total : " + System.String.Format("{0:C}",Convert.ToDouble( l_reader["Total"] )));
	            	
	            	double l_pagos = 0.0;
	            	
	            	//Pagos
	            	foreach(System.Data.DataRow l_row in this.m_dataset.Tables[0].Rows)
	            	{
	            		l_pagos += Convert.ToDouble( l_row["Cantidad"] );
	            	}
	            	this.lbl_pagado.Text = ("Total pagado : " + System.String.Format("{0:C}",l_pagos));
	            	
	            	double l_adeudo = Convert.ToDouble( l_reader["Total"] ) - l_pagos;
	            	
	            	//Adeudo
	            	this.lbl_adeudo.Text = ("Adeudo : " + System.String.Format("{0:C}",l_adeudo));
	            	
	            }
            	
        	}
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }        
            finally
            {
            	if(l_conn.State == System.Data.ConnectionState.Open)
            		l_conn.Close();
            }
            
        }
        
        private void frm_PagosFactura_KeyDown(object sender, KeyEventArgs e)
        {
        	switch(e.KeyCode)
        	{
        	case Keys.F2:
        			this.ll_agregar_LinkClicked(sender,null);
        			break;
        	case Keys.F3:
                    this.ll_eliminar_LinkClicked(sender, null);
        			break;
        	case Keys.Escape:
        			this.Close();
        			break;        			
        	}
        }
        
        private void ll_agregar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
           System.Data.Odbc.OdbcTransaction l_trans = null;
           string lesfactura = "1";
           if (this.m_bool_EsNota)
               lesfactura = "0";

           try
	       {

                l_conn.ConnectionString = frm_Main.mps_strconnection;
                l_conn.Open();

            	frm_nuevopago l_frm = new frm_nuevopago();
                l_frm.Folio = this.GetNumPago(false, l_conn, null);
                l_frm.idCliente = this.m_idCliente;
                l_conn.Close();
            	if(l_frm.ShowDialog() == DialogResult.OK)
            	{
                    l_conn.Open();
                   // l_trans = l_conn.BeginTransaction();
                    l_trans = l_conn.BeginTransaction(System.Data.IsolationLevel.Serializable);
	        	    double l_cantidad = Convert.ToDouble(l_frm.txtCantidad.Text);
	                			
	        		if(MessageBox.Show("�Confirma que desea agregar el pago de $" + l_cantidad + "?","Confirmaci�n", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
	        		{	        		
		        	    //Agregar pago a la factura...
                        System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				        l_cmd.Connection = l_conn;
                        l_cmd.Transaction = l_trans;
                        l_cmd.CommandText = "INSERT INTO detPagosFacturas (esfactura,IdFactura,NumeroPago,FechaPago,Cantidad,Observaciones,TipoPago,numeronotacred) VALUES(?,?,?,?,?,?,?,?)";
				            
	        			////////////////////////////////////
                        System.Data.Odbc.OdbcParameter l_p0 = new System.Data.Odbc.OdbcParameter("@esfactura", System.Data.Odbc.OdbcType.Int);
                        l_p0.Value = Convert.ToInt32(lesfactura);
                        l_cmd.Parameters.Add(l_p0);

			            System.Data.Odbc.OdbcParameter l_p1 = new System.Data.Odbc.OdbcParameter("@IdFactura", System.Data.Odbc.OdbcType.Int);
			            l_p1.Value = this.m_KeyFactura;
			            l_cmd.Parameters.Add(l_p1);

                        System.Data.Odbc.OdbcParameter l_pnum = new System.Data.Odbc.OdbcParameter("@NumeroPago", System.Data.Odbc.OdbcType.VarChar);
                        l_pnum.Value = this.GetNumPago(true, l_conn, l_trans);
                        l_cmd.Parameters.Add(l_pnum);

                        System.Data.Odbc.OdbcParameter l_p2 = new System.Data.Odbc.OdbcParameter("@FechaPago", System.Data.Odbc.OdbcType.DateTime);
                        l_p2.Value = l_frm.dtFecha.Value;    //System.DateTime.Now;
			            l_cmd.Parameters.Add(l_p2);

                        System.Data.Odbc.OdbcParameter l_p3 = new System.Data.Odbc.OdbcParameter("@Cantidad", System.Data.Odbc.OdbcType.Double);
			            l_p3.Value = System.Math.Round(l_cantidad,2);
			            l_cmd.Parameters.Add(l_p3);

                        System.Data.Odbc.OdbcParameter l_p4 = new System.Data.Odbc.OdbcParameter("@Observaciones", System.Data.Odbc.OdbcType.VarChar);
                        l_p4.Value = l_frm.txtConcepto.Text;   //"";
			            l_cmd.Parameters.Add(l_p4);

                        System.Data.Odbc.OdbcParameter l_ptp = new System.Data.Odbc.OdbcParameter("@TipoPago", System.Data.Odbc.OdbcType.Int);
                        // Tipo de pago: 0 efectivo, 1 nota de credito
                        if (l_frm.radioButton1.Checked )
                            l_ptp.Value = 0;
                        else
                            l_ptp.Value = 1;
                        l_cmd.Parameters.Add(l_ptp);

                        System.Data.Odbc.OdbcParameter l_pnc = new System.Data.Odbc.OdbcParameter("@numeronotacred", System.Data.Odbc.OdbcType.Int);
                        // Tipo de pago: 0 efectivo, 1 nota de credito
                        if (l_frm.NumeroNotaCred > 0)
                            l_pnc.Value = l_frm.NumeroNotaCred;
                        else
                            l_pnc.Value = System.DBNull.Value ;
                        l_cmd.Parameters.Add(l_pnc);
                        ////////////////////////////////////

                        if (l_cmd.ExecuteNonQuery() > 0)
                        {
                            if (l_frm.NumeroNotaCred > 0)
                            {
                                System.Data.Odbc.OdbcCommand l_cmd_nc = new System.Data.Odbc.OdbcCommand();
                                l_cmd_nc.Connection = l_conn;
                                l_cmd_nc.Transaction = l_trans;
                                l_cmd_nc.CommandText = "UPDATE catnotascred SET estatus=1 WHERE numeronotacred=" + l_frm.NumeroNotaCred.ToString();
                                l_cmd_nc.ExecuteNonQuery();
                            }
                            save_pago_caja(l_conn, l_trans, l_frm.dtFecha.Value, System.Math.Round(l_cantidad, 2), this.lbl_numero.Text);
                        }

                        l_trans.Commit();
	        	    }	        			
	            	
        		}
                l_frm = null;
           }
           catch (System.Data.OleDb.OleDbException ex)
           {
               if (l_trans != null)
                   l_trans.Rollback();
               MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
           }
           catch (System.Exception ex)
           {
               if (l_trans != null)
                   l_trans.Rollback();
               MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
           }
           finally
           {
               if (l_conn.State == System.Data.ConnectionState.Open)
                   l_conn.Close();

               this.FillDataSet();
               this.LoadInvoiceData();
           }
        	
        }

        private System.String GetNumPago(bool p_increase, System.Data.Odbc.OdbcConnection pConn, System.Data.Odbc.OdbcTransaction pTrans)
        {
            System.Data.Odbc.OdbcCommand l_getnum;
            System.Data.Odbc.OdbcCommand l_increase;

            l_getnum = new System.Data.Odbc.OdbcCommand();

            l_getnum.Connection = pConn;
            l_getnum.CommandText = "SELECT consPago FROM confConsFactura;";

            l_getnum.Transaction = pTrans;
            System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();

            l_reader.Read();

            System.String l_numero = l_reader.GetInt32(0).ToString();

            l_reader.Close();

            if (p_increase)
            {
                l_increase = new System.Data.Odbc.OdbcCommand();
                l_increase.Connection = pConn;
                l_increase.Transaction = pTrans;
                l_increase.CommandText = "UPDATE confConsFactura SET consPago = consPago + 1;";
                l_increase.ExecuteNonQuery();
            }

            return l_numero;
        }
        
        private void ll_eliminar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        	if(this.dataGridView1.SelectedRows.Count == 0)
        	{
        		System.Windows.Forms.MessageBox.Show("Seleccione un pago de la lista para poder cancelarlo","Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        		return;
        	}
        	
        	System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcTransaction l_trans = null;
    		try
    		{    			    			
    			if(MessageBox.Show("�Confirma que desea cancelar el pago?","Confirmaci�n", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
    			{	        		
        			//Eliminar un pago...
                    l_conn.ConnectionString = frm_Main.mps_strconnection;
		        	
		            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
		            l_cmd.Connection = l_conn;
                    //l_cmd.CommandText = "DELETE FROM " + this.m_string_tablepagos + " WHERE IdPago = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    l_cmd.CommandText = "UPDATE detPagosFacturas SET cancelado=1 WHERE IdPago = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
		            
		            l_conn.Open();
                    //l_trans = l_conn.BeginTransaction();
                    l_trans = l_conn.BeginTransaction(System.Data.IsolationLevel.Serializable);
                    l_cmd.Transaction = l_trans;

                    if (l_cmd.ExecuteNonQuery() > 0)
                    {
                        save_pago_caja(l_conn, l_trans, DateTime.Now , -1 * Convert.ToDouble(this.dataGridView1.SelectedRows[0].Cells["Cantidad"].Value), this.lbl_numero.Text);
                    }

                    l_trans.Commit();

    			}	        			
    			
    		}
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }        
            finally
            {
            	if(l_conn.State == System.Data.ConnectionState.Open)
            		l_conn.Close();
            	
            	this.FillDataSet();
            	this.LoadInvoiceData();
            }        	
        	
        }

        private void save_pago_caja(System.Data.Odbc.OdbcConnection conn, System.Data.Odbc.OdbcTransaction trans, DateTime dtfecha, Double iimporte, string observaciones)
        {
            try
            {

                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = conn;
                l_inc.Transaction = trans;

                //Almacenar el movimiento de caja
                l_inc.CommandText = "INSERT INTO catCaja (dtfecha,iimporte,clogin,entrada,observaciones) VALUES(?,?,?,?,?);";

                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", dtfecha );
                l_inc.Parameters.AddWithValue("@iimporte",System.Math.Round(iimporte,2));
                l_inc.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                l_inc.Parameters.AddWithValue("@entrada", 1);
                l_inc.Parameters.AddWithValue("@observaciones", observaciones);

                l_inc.ExecuteNonQuery();

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error agregando pago a caja:" + ee.Message , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmd_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
