﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
CREATE TABLE `catPorte` (
  `idPorte` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `idalmacenorigen` int(6) unsigned NOT NULL,
  `dtFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `formapago` varchar(32) NOT NULL,
  `condpago` varchar(32) NOT NULL,
  `moneda` varchar(32) NOT NULL,
  `valordeclarado` varchar(32) NOT NULL,
  `usoCFDI` varchar(128) NOT NULL,
  `metodopago` varchar(32) NOT NULL,
  `tipo` varchar(32) NOT NULL,
  `poliza` varchar(128) NOT NULL,
  `observaciones` varchar(1024) NOT NULL,
  PRIMARY KEY (`idPorte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `detPorte` (
  `iddetporte` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `idporte` int(6) unsigned NOT NULL,
  `idpedidoweb` int(6) unsigned NOT NULL,
  `idpedido` int(6) unsigned NOT NULL,
  PRIMARY KEY (`iddetporte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE catPorte
ADD COLUMN asguradora VARCHAR(256) AFTER poliza;
*/

namespace EasyInvoice
{
    public partial class frmEditarPorte : Form
    {
        public bool mNuevo = false;
        public int mIdEditar = -1;

        private System.Data.Odbc.OdbcConnection m_conn;
        public frmEditarPorte()
        {
            InitializeComponent();

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
        }

        private void frmEditarPorte_Load(object sender, EventArgs e)
        {
            int idAlmacen = -1;
            string codigoChofer = "";
            string codigoVehiculo = "";

            this.dgPedidosWeb.Columns.Add("Num Pedido", "Num Pedido");
            this.dgPedidosWeb.Columns.Add("Num Pedido Web", "Num Pedido Web");
            this.dgPedidosWeb.Columns.Add("Almacen", "Almacen");
            this.dgPedidosWeb.Columns.Add("Fecha", "Fecha");
            this.dgPedidosWeb.Columns.Add("Observaciones", "Observaciones");

            if (!this.mNuevo) {
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

                l_cmd.Connection = this.m_conn;
                l_cmd.CommandText = "select * from catPorte where idPorte = " + this.mIdEditar.ToString();

                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

                if (l_reader.Read()) {
                    //this.cmbAlmacenOrigen.Text = l_reader.GetInt32(1).ToString();
                    idAlmacen = l_reader.GetInt32(1);
                    this.dateTimePicker1.Value = l_reader.GetDateTime(2);
                    this.cmbFormaDePago.Text = l_reader.GetString(3);
                    this.cmbCondDePago.Text = l_reader.GetString(4);
                    this.txtMoneda.Text = l_reader.GetString(5);
                    this.txtValorDeclarado.Text = l_reader.GetString(6);
                    this.cmbUsoFDI.Text = l_reader.GetString(7);
                    this.cmbMetodoDePago.Text = l_reader.GetString(8);
                    this.txtTipo.Text = l_reader.GetString(9);
                   
                    this.cmbAseguradora.Text = l_reader.GetString(11);
                    // 11 aseguradora
                    codigoChofer = l_reader.GetString(13);
                    codigoVehiculo = l_reader.GetString(14);
                    this.txtObservaciones.Text = l_reader.GetString(15);
                }

                l_reader.Close();

                //--------------
                System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();

                l_cmd1.Connection = this.m_conn;
                l_cmd1.CommandText = "select dp.idpedido,dp.idpedidoweb,cw.idAlmacenOrig,cw.Fecha,cw.Observaciones from detPorte dp inner join catPedidosWeb cw on dp.idpedidoweb=cw.idPedidoWeb and idPorte = " + this.mIdEditar.ToString();

                System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();


                while (l_reader1.Read()) {
                    object[] newVal = {
                                    l_reader1.GetInt32(0),
                                    l_reader1.GetInt32(1),
                                    l_reader1.GetInt32(2),
                                    l_reader1.GetDateTime(3),
                                    l_reader1.GetString(4) };
                    this.dgPedidosWeb.Rows.Add(newVal);
                }

                l_reader1.Close();
                this.m_conn.Close();
            }

            this.cmbAlmacenOrigen.Enabled = this.mNuevo;
            this.dateTimePicker1.Enabled = this.mNuevo;
            //this.txtFormaDePago.Enabled = this.mNuevo;
            this.cmbFormaDePago.Enabled = this.mNuevo;
            this.cmbCondDePago.Enabled = this.mNuevo;
            this.txtMoneda.Enabled = this.mNuevo;
            this.txtValorDeclarado.Enabled = this.mNuevo;
            this.cmbUsoFDI.Enabled = this.mNuevo;
            this.cmbMetodoDePago.Enabled = this.mNuevo;
            this.txtTipo.Enabled = this.mNuevo;
            
            this.txtObservaciones.Enabled = this.mNuevo;
            this.cmdGuardar.Enabled = this.mNuevo;
            this.dgPedidosWeb.AllowUserToDeleteRows = this.mNuevo;
            this.groupBox1.Enabled = this.mNuevo;
            this.cmbChofer.Enabled = this.mNuevo;
            this.cmbVehiculos.Enabled = this.mNuevo;
            this.cmbAseguradora.Enabled = this.mNuevo;

            cargarComboAlmacenes(idAlmacen);
            cargarComboChofer(codigoChofer);
            cargarComboVehiculos(codigoVehiculo);
        }

        private void cargarComboChofer(string choferEditar)
        {
            int idPosisionAlmacen = -1;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "select cCodigo, cNombre from catChofer";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            int i = 0;
            while (l_reader.Read())
            {
                string codigo = l_reader.GetString(0);
                string textoA = codigo + " - " + l_reader.GetString(1);

                //System.Console.WriteLine(textoA);
                if (choferEditar== codigo)
                    idPosisionAlmacen = i;

                this.cmbChofer.Items.Insert(i++, textoA);
            }

            l_reader.Close();
            this.m_conn.Close();

            if (this.mNuevo)
                this.cmbChofer.SelectedIndex = 0;
            else
                this.cmbChofer.SelectedIndex = idPosisionAlmacen;
        }

        private void cargarComboVehiculos(string vehiculoEditar)
        {
            int idPosisionAlmacen = -1;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "select cCodigo,cNombre from catVehiculos";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            int i = 0;
            while (l_reader.Read())
            {
                string codigo = l_reader.GetString(0);
                string textoA = codigo + " - " + l_reader.GetString(1);

                //System.Console.WriteLine(textoA);
                if (vehiculoEditar==codigo)
                    idPosisionAlmacen = i;

                this.cmbVehiculos.Items.Insert(i++, textoA);
            }

            l_reader.Close();
            this.m_conn.Close();

            if (this.mNuevo)
                this.cmbVehiculos.SelectedIndex = 0;
            else
                this.cmbVehiculos.SelectedIndex = idPosisionAlmacen;
        }

        private void cargarComboAlmacenes(int idAlmacenEditar) {
            int idPosisionAlmacen = -1;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "select IdAlmacen, Descripcion from catAlmacenes";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            int i = 0;
            while (l_reader.Read())
            {
                int idAlmacen = l_reader.GetInt32(0);
                string textoA = idAlmacen.ToString() + " - " + l_reader.GetString(1);

                //System.Console.WriteLine(textoA);
                if (idAlmacenEditar == idAlmacen)
                    idPosisionAlmacen = i;

                this.cmbAlmacenOrigen.Items.Insert(i++, textoA);
            }

            l_reader.Close();
            this.m_conn.Close();

            if (this.mNuevo)
                this.cmbAlmacenOrigen.SelectedIndex = 0;
            else
                this.cmbAlmacenOrigen.SelectedIndex = idPosisionAlmacen;
        }

        private void cmdAgregarPedido_Click(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "select idPedidoWeb, idAlmacenOrig, Fecha, Observaciones, idPedido from catPedidosWeb where idPedido = " + this.txtNumeroDePedidoBuscar.Text;

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            if (l_reader.Read()) {
                bool lFound = false;

                for (int i = 0; i < this.dgPedidosWeb.Rows.Count; i++){
                    if (l_reader.GetInt32(4) == Convert.ToInt32(this.dgPedidosWeb.Rows[i].Cells[0].Value)) {
                        lFound = true;
                        break;
                    }
                }

                if (lFound == false)
                {
                    object[] newVal = { l_reader.GetInt32(4),
                                    l_reader.GetInt32(0),
                                    l_reader.GetInt32(1),
                                    l_reader.GetDateTime(2),
                                    l_reader.GetString(3) };
                    this.dgPedidosWeb.Rows.Add(newVal);
                }
                this.txtNumeroDePedidoBuscar.SelectAll();
            }

            l_reader.Close();
            this.m_conn.Close();
        }

        private void txtNumeroDePedidoBuscar_Enter(object sender, EventArgs e)
        {
            this.txtNumeroDePedidoBuscar.SelectAll();
        }

        private void txtNumeroDePedidoBuscar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) {
                cmdAgregarPedido_Click(null, null);
            }
        }

        private void txtNumeroDePedidoBuscar_MouseDown(object sender, MouseEventArgs e)
        {
            this.txtNumeroDePedidoBuscar.SelectAll();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdGuardar_Click(object sender, EventArgs e)
        {
            if (this.cmbAlmacenOrigen.Text.Trim() != "" &&
                this.cmbFormaDePago.Text.Trim() != "" &&
                this.cmbCondDePago.Text.Trim() != "" &&
                this.txtMoneda.Text.Trim() != "" &&
                this.txtValorDeclarado.Text.Trim() != "" &&
                this.cmbUsoFDI.Text.Trim() != "" &&
                this.cmbMetodoDePago.Text.Trim() != "" &&
                this.txtTipo.Text.Trim() != "" &&
                this.dgPedidosWeb.Rows.Count>0){


                if (MessageBox.Show("Confirma que desea generar la carta porte? ** UNA VEZ CREADA YA NO PUEDE MODIFICARSE **",
                    "Atención!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes){

                    //----------------------------
                    // Llenar los datos...
                    try
                    {
                        this.m_conn.Open();

                        System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                        l_cmd.Connection = this.m_conn;

                        l_cmd.CommandText = "INSERT INTO catPorte(idalmacenorigen,dtFecha,formapago,condpago,moneda,valordeclarado,usoCFDI,metodopago,tipo,asguradora,estado,cChofer,cVehiculo,observaciones) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@idalmacenorigen", Convert.ToInt32(this.cmbAlmacenOrigen.Text.Split('-')[0].Trim()));
                        l_cmd.Parameters.AddWithValue("@dtFecha", this.dateTimePicker1.Value);
                        l_cmd.Parameters.AddWithValue("@formapago", this.cmbFormaDePago.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@condpago", this.cmbCondDePago.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@moneda", this.txtMoneda.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@valordeclarado", this.txtValorDeclarado.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@usoCFDI", this.cmbUsoFDI.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@metodopago", this.cmbMetodoDePago.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@tipo", this.txtTipo.Text.Trim());
                       
                        l_cmd.Parameters.AddWithValue("@poliza", this.cmbAseguradora.Text.Trim());
                        l_cmd.Parameters.AddWithValue("@estado", 1);
                        l_cmd.Parameters.AddWithValue("@idalmacenorigen", (this.cmbChofer.Text.Split('-')[0].Trim()));
                        l_cmd.Parameters.AddWithValue("@idalmacenorigen", (this.cmbVehiculos.Text.Split('-')[0].Trim()));
                        l_cmd.Parameters.AddWithValue("@observaciones", this.txtObservaciones.Text.Trim());

                        l_cmd.ExecuteNonQuery();

                        System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();
                        l_cmd1.Connection = this.m_conn;
                        l_cmd1.CommandText = "SELECT LAST_INSERT_ID() AS LastId;";

                        System.Data.Odbc.OdbcDataReader l_reader = l_cmd1.ExecuteReader();

                        if (l_reader.Read())
                        {
                            int lastID = l_reader.GetInt32(0);
                            l_reader.Close();

                            // Insertar el detalle...
                            for (int i = 0; i < this.dgPedidosWeb.Rows.Count; i++)
                            {
                                System.Data.Odbc.OdbcCommand l_cmd2 = new System.Data.Odbc.OdbcCommand();
                                l_cmd2.Connection = this.m_conn;

                                l_cmd2.CommandText = "INSERT INTO detPorte(idporte, idpedidoweb, idpedido) VALUES (?,?,?)";
                                l_cmd2.Parameters.Clear();
                                l_cmd2.Parameters.AddWithValue("@idporte", lastID);
                                l_cmd2.Parameters.AddWithValue("@idpedidoweb", this.dgPedidosWeb.Rows[i].Cells[1].Value);
                                l_cmd2.Parameters.AddWithValue("@idpedido", this.dgPedidosWeb.Rows[i].Cells[0].Value);

                                l_cmd2.ExecuteNonQuery();
                            }

                            MessageBox.Show("Porte # " + lastID.ToString() + " creado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message, "Error guardando", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.DialogResult = DialogResult.Cancel;
                    }
                    finally
                    {
                        if (this.m_conn.State == System.Data.ConnectionState.Open)
                            this.m_conn.Close();

                        if (this.DialogResult == DialogResult.OK)
                            this.Close();
                    }
                }
                //----------------------------------------------------
            }
            else {
                MessageBox.Show("Es necesario capturar la información", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.cmbAlmacenOrigen.Focus();
            }
        }

        private void cmbAseguradora_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbFormaDePago_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
