using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_listaprovadd : Form
    {
		
		public int mIdProducto = -1;
		public  System.Collections.Generic.List<int> mProveedoresSeleccionados = new System.Collections.Generic.List<int>();
		public  System.Collections.Generic.List<string> mProveedoresSeleccionadosName = new System.Collections.Generic.List<string>();
		private System.Collections.Generic.SortedList<string,int> mpProveedores = new System.Collections.Generic.SortedList<string, int>();
		
        public frm_listaprovadd()
        {
            InitializeComponent();
        }

        public void FillDataSet()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
			
			this.mProveedoresSeleccionados.Clear();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "select cp.IdProveedor,cp.Nombre,rpp.IdProducto from catProveedores cp left outer join relProductoProveedor rpp on cp.IdProveedor = rpp.IdProveedor and rpp.IdProducto = " + this.mIdProducto.ToString() + " order by IdProducto desc,Nombre;";

                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                while (lReader.Read())
                {
					bool lChecked = false;
					
					this.mpProveedores.Add( lReader["Nombre"].ToString() , Convert.ToInt32( lReader["IdProveedor"] ) );
					
					if( lReader["IdProducto"] != DBNull.Value )
						lChecked = true;
					
                   this.lbLista.Items.Add(lReader["Nombre"],lChecked);
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void frm_listaprovadd_Load(object sender, EventArgs e)
        {
            this.FillDataSet();
        }

        private void cmdClose_Click(object sender, EventArgs e)
        {
			this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void cmdAceptar_Click(object sender, EventArgs e)
        {
			this.mProveedoresSeleccionados.Clear();
			
			foreach(object lItem in this.lbLista.CheckedItems)
			{
				//System.Console.WriteLine( lItem.ToString() );
				this.mProveedoresSeleccionadosName.Add( lItem.ToString() );
				this.mProveedoresSeleccionados.Add( this.mpProveedores[lItem.ToString()]);
			}
			
			this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
