﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
    public partial class frm_arqueo : Form
    {
        private System.Data.Odbc.OdbcConnection m_conn;
        public DateTime fecha;

        public frm_arqueo()
        {
            InitializeComponent();

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            //this.LoadDocPositions();
            fecha = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day );
            //fecha = new DateTime(2010, 11, 25);
        }

        private void cmd_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void getDepositos()
        {
            System.Text.StringBuilder  mess= new StringBuilder();
            try
            {
                object res;
                Decimal dDepositos = 0, dNC = 0, dPagos=0, dPagosProvs=0, dFacs = 0, dNotas=0, dRetiros = 0;

                this.m_conn.Open();
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;

                //Depositos
                l_inc.CommandText = "SELECT SUM(iimporte) FROM catCaja WHERE dtfecha>=? and dtfecha<?  AND entrada=1;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dDepositos = Convert.ToDecimal(res);

                //facturas
                l_inc.CommandText = "SELECT SUM(Total) FROM catFacturas WHERE fecha>=? and fecha<? AND cancelada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dFacs = Convert.ToDecimal(res);

                //notas de venta
                l_inc.CommandText = "SELECT SUM(Total) FROM catNotas WHERE fecha>=? and fecha<? AND cancelada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dNotas = Convert.ToDecimal(res);

                // retiros
                l_inc.CommandText = "SELECT SUM(iimporte) FROM catCaja WHERE dtfecha>=? and dtfecha<?  AND entrada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dRetiros = Math.Abs(Convert.ToDecimal(res));

                // pagos de clientes
                l_inc.CommandText = "SELECT SUM(cantidad) FROM detPagosFacturas WHERE fechapago>=? and fechapago<? AND cancelado=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dPagos = Convert.ToDecimal(res);

                // notas de credito
                l_inc.CommandText = "SELECT SUM(total) FROM catnotascred WHERE fecha>=? and fecha<? AND cancelada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dNC = Convert.ToDecimal(res);

                // pagos a proveedores
                l_inc.CommandText = "SELECT SUM(pagado) FROM catFacturasProv WHERE fechapago>=? and fechapago<?;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@fecha1", fecha);
                l_inc.Parameters.AddWithValue("@fecha2", fecha.AddDays(1));
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dPagosProvs = Convert.ToDecimal(res);

                mess.Append("RESUMEN DE MOVIMIENTOS DEL ");
                mess.AppendLine(fecha.ToString("dd/MM/yyyy"));
                mess.AppendLine();
                mess.AppendLine("DEPOSITOS:         " + dDepositos.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("FACTURAS:          " + dFacs.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("NOTAS:             " + dNotas.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("PAGOS DE CLIENTES: " + dPagos.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("RETIROS:           " + dRetiros.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("NOTAS DE CREDITO:  " + dNC.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("PAGOS A PROVEEDS.: " + dPagosProvs.ToString("###,###,##0.00").PadLeft(16));
                mess.AppendLine("----------------------------------------");
                mess.AppendLine("TOTAL:             " + (dDepositos + dNotas + dFacs + dPagos - dRetiros - dNC - dPagosProvs).ToString("###,###,##0.00").PadLeft(16));
//Deposito:              +
//Notas:                 +
//Facturas:              +
//Abonos (notas y fact)  +
//Retiros:               -
//Notas Credito:         -
//Pagos proveedores:     -
//TOTAL:                suma    boton imprimir

            }
            catch (Exception ee)
            {
                mess= new StringBuilder();
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

            this.txt_arqueo.Text = mess.ToString();
        }

        ////////////////////////////////////////////////     
        #region Posiciones de la factura...
        int mp_int_PosNombreX = 0;
        int mp_int_PosNombreY = 0;

        int mp_int_PosDireccionX = 0;
        int mp_int_PosDireccionY = 0;

        int mp_int_PosCiudadX = 0;
        int mp_int_PosCiudadY = 0;

        int mp_int_PosRFCX = 0;
        int mp_int_PosRFCY = 0;

        int mp_int_PosNumFactX = 0;
        int mp_int_PosNumFactY = 0;

        int mp_int_PosFechaX = 0;
        int mp_int_PosFechaY = 0;

        int mp_int_PosCodigoX = 0;
        int mp_int_PosCodigoY = 0;

        int mp_int_PosCantidadX = 0;
        int mp_int_PosCantidadY = 0;

        int mp_int_PosDescripcionX = 0;
        int mp_int_PosDescripcionY = 0;

        int mp_int_PosPrecioX = 0;
        int mp_int_PosPrecioY = 0;

        int mp_int_PosTotalX = 0;
        int mp_int_PosTotalY = 0;

        int mp_int_PosSubTotalX = 0;
        int mp_int_PosSubTotalY = 0;

        int mp_int_PosIVAX = 0;
        int mp_int_PosIVAY = 0;

        int mp_int_PosGTotalX = 0;
        int mp_int_PosGTotalY = 0;

        int mp_int_PosGTotalLetrasX = 0;
        int mp_int_PosGTotalLetrasY = 0;

        int mp_int_EspacioDetalle = 0;
        int mp_int_TamanioLetra = 0;

        string mp_string_Leyenda = "";

        #endregion


        private void LoadDocPositions()
        {
            try
            {

                this.m_conn.ConnectionString = frm_Main.mps_strconnection;


                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand(); ;

                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '003'";


                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

                if (l_reader.Read())
                {
                    string[] l_temp = new string[2];

                    //PosNombre					
                    l_temp = l_reader["PosNombre"].ToString().Split(',');
                    this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);

                    //PosDireccion
                    l_temp = l_reader["PosDireccion"].ToString().Split(',');
                    this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);

                    //PosCiudad
                    l_temp = l_reader["PosCiudad"].ToString().Split(',');
                    this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);

                    //PosRFC
                    l_temp = l_reader["PosRFC"].ToString().Split(',');
                    this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);

                    //PosNumFact
                    l_temp = l_reader["PosNumFact"].ToString().Split(',');
                    this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);

                    //PosFecha
                    l_temp = l_reader["PosFecha"].ToString().Split(',');
                    this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);

                    //PosCodigo
                    l_temp = l_reader["PosCodigo"].ToString().Split(',');
                    this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);

                    //PosCantidad
                    l_temp = l_reader["PosCantidad"].ToString().Split(',');
                    this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);

                    //PosDescripcion
                    l_temp = l_reader["PosDescripcion"].ToString().Split(',');
                    this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);

                    //PosPrecio
                    l_temp = l_reader["PosPrecio"].ToString().Split(',');
                    this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);

                    //PosTotal
                    l_temp = l_reader["PosTotal"].ToString().Split(',');
                    this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);

                    //PosSubtotal
                    l_temp = l_reader["PosSubtotal"].ToString().Split(',');
                    this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);

                    //PosIVA
                    l_temp = l_reader["PosIVA"].ToString().Split(',');
                    this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);

                    //PosGTotal
                    l_temp = l_reader["PosGTotal"].ToString().Split(',');
                    this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);

                    //PosGTotalLetras
                    l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
                    this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);

                    //EspacioDetalle
                    this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());

                    //TamanioLetra
                    this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());

                    //Leyenda
                    this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                }

                l_reader.Close();

            }
            catch (OleDbException ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

        }


        //private void mp_pdarqueo_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        //{
        //    int l_ypos = 140;						
        //    System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
        //    System.Drawing.Font l_fonth = new Font("Arial", this.mp_int_TamanioLetra + 2, FontStyle.Bold);
        //    System.Drawing.Font l_fonth1 = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Bold | FontStyle.Italic);
        //    System.Drawing.Font l_font = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Regular);    
         
        //    System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

        //    l_cmd.Connection = this.m_conn;
        //    l_cmd.CommandText = "SELECT catarqueo.*,catUsuarios.cnombre as nombre_usuario FROM catarqueo INNER JOIN catUsuarios ON catarqueo.cusuario = catUsuarios.clogin WHERE catarqueo.iidarqueo = " + this.mp_idarqueo.ToString();

        //    this.m_conn.Open();
        //    System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();


        //    e.Graphics.DrawString("arqueo de Caja", l_fonth, l_brush, 350, 50);

        //    if (l_reader.Read())
        //    {
        //        e.Graphics.DrawString("arqueo de caja realizado el " + l_reader["dtFecha"].ToString() + " por el usuario : " + l_reader["nombre_usuario"].ToString(), l_fonth1, l_brush, 15, 70);
        //        e.Graphics.DrawString("Total " + System.String.Format("{0:C}", l_reader["Total"]), l_fonth1, l_brush, 15, 85);   			 
        //    }

        //    l_reader.Close();

        //    e.Graphics.DrawString("Numero", l_fonth1, l_brush, 15, 110);
        //    e.Graphics.DrawString("Fecha", l_fonth1, l_brush, 100, 110);
        //    e.Graphics.DrawString("Nota o Factura", l_fonth1, l_brush, 250, 110);
        //    e.Graphics.DrawString("Total", l_fonth1, l_brush, 450, 110);

        //    e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, 125, 835, 125);

        //    //Imprimir el detalle
        //    l_cmd = new System.Data.Odbc.OdbcCommand();

        //    l_cmd.Connection = this.m_conn;
        //    l_cmd.CommandText = "SELECT * FROM detarqueo WHERE iidarqueo = " + this.mp_idarqueo.ToString() + " AND iidDetarqueo > " + this.mp_iiddetarqueo.ToString();
            
        //    l_reader = l_cmd.ExecuteReader();

        //    int k = 0;
        //    int curdoc=-1;
        //    while (l_reader.Read())
        //    {
        //        e.Graphics.DrawString(l_reader["cNumero"].ToString(), l_font, l_brush, 15, l_ypos);
        //        e.Graphics.DrawString(System.Convert.ToDateTime(l_reader["dtFecha"]).ToString(), l_font, l_brush, 100, l_ypos);
        //        curdoc = Convert.ToInt32(l_reader["esfactura"]);
        //        switch (curdoc)
        //        {
        //            case 1:
        //                e.Graphics.DrawString( "Factura" , l_font, l_brush, 250, l_ypos);
        //                break;
        //            case 0:
        //                e.Graphics.DrawString( "Nota", l_font, l_brush, 250, l_ypos);
        //                break;
        //            case 2:
        //                e.Graphics.DrawString("Pago/Abono", l_font, l_brush, 250, l_ypos);
        //                break;
        //        }
        //        //e.Graphics.DrawString( (Convert.ToBoolean(l_reader["esfactura"]) ? "Factura" : "Nota") , l_font, l_brush, 250, l_ypos);

        //        e.Graphics.DrawString(System.String.Format("{0:C}", l_reader["Total"]), l_font, l_brush, 450, l_ypos);

        //        this.mp_totalrep += Convert.ToDouble(l_reader["Total"]);
        //        this.mp_idarqueo = Convert.ToInt32(l_reader["iidDetarqueo"]);

        //        l_ypos += this.mp_int_EspacioDetalle;
        //        k++;

        //        if (k == 60)
        //        {
        //            e.HasMorePages = true;
        //            return;
        //        }					

        //    }

        //    l_reader.Close();
        //    this.m_conn.Close();

        //    e.HasMorePages = false;
        //    e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);

        //    l_ypos += this.mp_int_TamanioLetra;

        //    e.Graphics.DrawString(System.String.Format("{0:C}", this.mp_totalrep), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);

        //    this.mp_iiddetarqueo = 0;
        //    this.mp_totalrep = 0;

        //}

        private void frm_arqueo_Load(object sender, EventArgs e)
        {
            this.getDepositos();
        }

    }
}
