/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:41 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of clsAcceso.
	/// </summary>
	public partial class clsAcceso : Form
	{        
        public string mp_permiso = "Caja";
        public string mp_usuario = "";
		private System.Data.Odbc.OdbcConnection m_conn;
        private System.Collections.SortedList sl_Usuarios = new System.Collections.SortedList();
        private string strLastLogged;
        public int mp_idAlmacen = 0;
        public string mp_strAlmacen = "";
		
		public clsAcceso()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
			
		}

        private void clsAcceso_Load(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;

            if (frm_Main.m_RunConfiguration != 1)
                l_cmd.CommandText = "SELECT clogin,cclave,cacceso,catUsuarios.idAlmacen,catAlmacenes.Descripcion FROM catUsuarios left join catAlmacenes on catUsuarios.idAlmacen=catAlmacenes.idAlmacen where catUsuarios.clogin not like '-%';";
            else
                l_cmd.CommandText = "SELECT clogin,cclave,cacceso,catUsuariosG.idAlmacen,catAlmacenes.Descripcion FROM catUsuariosG left join catAlmacenes on catUsuariosG.idAlmacen=catAlmacenes.idAlmacen where catUsuariosG.clogin not like '-%';";

            //l_cmd.Parameters.AddWithValue("@clogin", this.txt_usuario.Text.Replace("=", "").Replace(">", "").Replace("<", ""));
            //l_cmd.Parameters.AddWithValue("@cclave", this.txt_acceso.Text.Replace("=", "").Replace(">", "").Replace("<", ""));

			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            this.cmb_usuario.Items.Clear();
            while(l_reader.Read() )
            {
                string[] str1 = new string[4];
                this.cmb_usuario.Items.Add(l_reader[0]);
                str1[0] = (string)l_reader[1];
                str1[1] = (string)l_reader[2];
                if (l_reader[3] == System.DBNull.Value)  // si no se tienen almacenes maneja todo como 0
                {
                    str1[2] = "0";
                }
                else
                {
                    str1[2] = ((int)l_reader[3]).ToString();
                }
                if (l_reader[4] == System.DBNull.Value) // descripcion del almacen
                {
                    str1[3] = "";
                }
                else
                {
                    str1[3] = (string)l_reader[4];
                }
                 sl_Usuarios.Add(l_reader[0], str1);
            }

            l_reader.Close();
            this.m_conn.Close();

            //Selecciona ultimo usuario logeado
            this.strLastLogged="";
            //object l_objrg = Microsoft.Win32.Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\EasyInvoice","User","");
			object l_objrg = null;
            if (l_objrg != null)
            {
                strLastLogged = (string)l_objrg;
                this.cmb_usuario.Text = strLastLogged; 
            }

            this.cmb_usuario.Focus(); 
        }

		
		void Cmd_okClick(object sender, EventArgs e)
		{
/*			
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT clogin,cclave,cacceso FROM catUsuarios where clogin = ?;";

            l_cmd.Parameters.AddWithValue("@clogin", this.txt_usuario.Text.Replace("=", "").Replace(">", "").Replace("<", ""));
            //l_cmd.Parameters.AddWithValue("@cclave", this.txt_acceso.Text.Replace("=", "").Replace(">", "").Replace("<", ""));

			this.m_conn.Open(); 
			System.Data.OleDb.OleDbDataReader l_reader = l_cmd.ExecuteReader();

            if (l_reader.Read() == false)
            {
                l_reader.Close();
                this.m_conn.Close();
                this.lbl_clave.Text = "Acceso denegado";
                this.DialogResult = DialogResult.Cancel;
                return;
            }

            this.mp_usuario = l_reader["clogin"].ToString();
            this.mp_permiso = l_reader["cacceso"].ToString();
			string l_pwd = l_reader["cclave"].ToString().ToUpper();
			System.Text.StringBuilder l_pwdb = new System.Text.StringBuilder();

			l_reader.Close();
			this.m_conn.Close();  
*/
            string key = "";
            key= this.cmb_usuario.Text.Trim();
            if (!sl_Usuarios.Contains(key))
                return;

            this.mp_usuario = key;
            string[] str1 = (string[])sl_Usuarios[key];
            this.mp_permiso = str1[1];
            this.mp_idAlmacen = Convert.ToInt32(str1[2]);
            this.mp_strAlmacen = str1[3];
            string l_pwd = str1[0].ToUpper();
            System.Text.StringBuilder l_pwdb = new System.Text.StringBuilder();

			
			if( l_pwd.Trim() == "" )
			{
				this.DialogResult = DialogResult.OK;
			}
			else
			{
                string l_char;
                l_char = txt_acceso.Text.Trim().ToUpper();

                /*
				foreach(char l_char in this.txt_acceso.Text.Trim().ToUpper())
				{
					switch(l_char)
					{
						case 'A':
							l_pwdb.Append('1');
							break;
						case 'E':
							l_pwdb.Append('2');
							break;
						case 'I':
							l_pwdb.Append('3');
							break;
						case '0':
							l_pwdb.Append('4');
							break;
						case 'U':
							l_pwdb.Append('5');
							break;	
						case 'J':
							l_pwdb.Append('6');
							break;	
						case 'N':
							l_pwdb.Append('7');
							break;	
						case 'S':
							l_pwdb.Append('8');
							break;	
						case 'M':
							l_pwdb.Append('9');
							break;								
						default:
							l_pwdb.Append(l_char);
							break;
					}
				}
                */
                l_pwdb.Append(l_char);
                if (l_pwd.Trim().ToUpper() == l_pwdb.ToString() && this.mp_permiso != "Caja")
                {
                    //if (this.cmb_usuario.Text.Trim() != strLastLogged)
                    //    Microsoft.Win32.Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\EasyInvoice", "User", this.cmb_usuario.Text.Trim());

                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    this.lbl_clave.Text = "Acceso denegado";
                    this.DialogResult = DialogResult.Cancel;
                }
												
			}
									
			this.Close();
		}
		
		void Txt_accesoKeyPress(object sender, KeyPressEventArgs e)
		{
			
		}
		
		void Txt_accesoKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Enter )
			{
				this.Cmd_okClick(sender, null);
			}
		}

        private void txt_usuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.txt_acceso.Focus();
            }
        }

	}
}
