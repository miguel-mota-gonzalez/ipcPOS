using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_pedidosprv.
	/// </summary>
	public class frm_pedidosprv : System.Windows.Forms.Form
    {
        
        //private System.Data.DataSet m_dataset;
        public System.Int32 m_KeyRecord;
        private IContainer components;
        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();

        //public Int32 p_Result;
        //public Int32 p_currentId;
        private ComboBox cmb_Productos;
        private Label label3;
        public TextBox txtCantidad;
        private Label label4;
        private Label lbl_Pieza;
        private Button cmd_Agregar;
        private Button cmd_Borrar;
        private Button cmd_Save;
        private DataGridView dataGridView2;

        private SortedList sl_ProdsProvs = new SortedList();
        //System.Collections.Generic.List<int> idProvs = new System.Collections.Generic.List<int>();
        private System.Data.DataSet m_detail = new System.Data.DataSet();
        public TextBox txtPrecioUnit;
        private Label label6;
        private LinkLabel lnk_proveedores;
        private TextBox txt_proveedores;

        private Int32 p_keyprov=0;

        private System.Data.Odbc.OdbcConnection OdbcConnection1 = new System.Data.Odbc.OdbcConnection();

		public frm_pedidosprv()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_pedidosprv));
            this.cmb_Productos = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Pieza = new System.Windows.Forms.Label();
            this.cmd_Agregar = new System.Windows.Forms.Button();
            this.cmd_Borrar = new System.Windows.Forms.Button();
            this.cmd_Save = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtPrecioUnit = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lnk_proveedores = new System.Windows.Forms.LinkLabel();
            this.txt_proveedores = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // cmb_Productos
            // 
            this.cmb_Productos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Productos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Productos.Location = new System.Drawing.Point(80, 38);
            this.cmb_Productos.Name = "cmb_Productos";
            this.cmb_Productos.Size = new System.Drawing.Size(392, 24);
            this.cmb_Productos.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Producto";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidad.ForeColor = System.Drawing.Color.Blue;
            this.txtCantidad.Location = new System.Drawing.Point(557, 38);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(71, 22);
            this.txtCantidad.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(489, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Cantidad";
            // 
            // lbl_Pieza
            // 
            this.lbl_Pieza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pieza.Location = new System.Drawing.Point(554, 70);
            this.lbl_Pieza.Name = "lbl_Pieza";
            this.lbl_Pieza.Size = new System.Drawing.Size(118, 16);
            this.lbl_Pieza.TabIndex = 8;
            // 
            // cmd_Agregar
            // 
            this.cmd_Agregar.Location = new System.Drawing.Point(692, 67);
            this.cmd_Agregar.Name = "cmd_Agregar";
            this.cmd_Agregar.Size = new System.Drawing.Size(104, 23);
            this.cmd_Agregar.TabIndex = 9;
            this.cmd_Agregar.Text = "&Agregar";
            this.cmd_Agregar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Agregar.Click += new System.EventHandler(this.cmd_Agregar_Click);
            // 
            // cmd_Borrar
            // 
            this.cmd_Borrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmd_Borrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_Borrar.Location = new System.Drawing.Point(15, 284);
            this.cmd_Borrar.Name = "cmd_Borrar";
            this.cmd_Borrar.Size = new System.Drawing.Size(124, 23);
            this.cmd_Borrar.TabIndex = 11;
            this.cmd_Borrar.Text = "&Eliminar";
            this.cmd_Borrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Borrar.Click += new System.EventHandler(this.cmd_Borrar_Click);
            // 
            // cmd_Save
            // 
            this.cmd_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_Save.Location = new System.Drawing.Point(579, 284);
            this.cmd_Save.Name = "cmd_Save";
            this.cmd_Save.Size = new System.Drawing.Size(217, 23);
            this.cmd_Save.TabIndex = 13;
            this.cmd_Save.Text = "&Generar ordenes de compra";
            this.cmd_Save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Save.Click += new System.EventHandler(this.cmd_Save_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Silver;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 96);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(807, 182);
            this.dataGridView2.TabIndex = 10;
            // 
            // txtPrecioUnit
            // 
            this.txtPrecioUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioUnit.ForeColor = System.Drawing.Color.Blue;
            this.txtPrecioUnit.Location = new System.Drawing.Point(725, 38);
            this.txtPrecioUnit.Name = "txtPrecioUnit";
            this.txtPrecioUnit.Size = new System.Drawing.Size(71, 22);
            this.txtPrecioUnit.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(643, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Precio Unit.";
            // 
            // lnk_proveedores
            // 
            this.lnk_proveedores.AutoSize = true;
            this.lnk_proveedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_proveedores.Location = new System.Drawing.Point(12, 9);
            this.lnk_proveedores.Name = "lnk_proveedores";
            this.lnk_proveedores.Size = new System.Drawing.Size(87, 16);
            this.lnk_proveedores.TabIndex = 0;
            this.lnk_proveedores.TabStop = true;
            this.lnk_proveedores.Text = "Proveedores";
            this.lnk_proveedores.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_proveedores_LinkClicked);
            // 
            // txt_proveedores
            // 
            this.txt_proveedores.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_proveedores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_proveedores.Location = new System.Drawing.Point(117, 9);
            this.txt_proveedores.Name = "txt_proveedores";
            this.txt_proveedores.ReadOnly = true;
            this.txt_proveedores.Size = new System.Drawing.Size(679, 20);
            this.txt_proveedores.TabIndex = 1;
            // 
            // frm_pedidosprv
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(808, 308);
            this.Controls.Add(this.lnk_proveedores);
            this.Controls.Add(this.txt_proveedores);
            this.Controls.Add(this.txtPrecioUnit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.cmd_Agregar);
            this.Controls.Add(this.cmd_Borrar);
            this.Controls.Add(this.cmd_Save);
            this.Controls.Add(this.lbl_Pieza);
            this.Controls.Add(this.cmb_Productos);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.label4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_pedidosprv";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Levantamiento de Pedidos";
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_pedidosprv_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
            DataColumn[] keys = new DataColumn[2];
            this.m_detail.Tables.Add("detail");
            this.m_detail.Tables[0].Columns.Add("idProducto");
            this.m_detail.Tables[0].Columns.Add("Codigo");
            this.m_detail.Tables[0].Columns.Add("Descripcion");
            this.m_detail.Tables[0].Columns.Add("idProveedor");
            this.m_detail.Tables[0].Columns.Add("Proveedor");
            this.m_detail.Tables[0].Columns.Add("Cantidad",Type.GetType("System.Double"));
            this.m_detail.Tables[0].Columns.Add("PrecioUnit", Type.GetType("System.Double"));
            keys[0] = this.m_detail.Tables[0].Columns["idProducto"];
            keys[1] = this.m_detail.Tables[0].Columns["idProveedor"];
            this.m_detail.Tables[0].PrimaryKey = keys;
            this.dataGridView2.DataSource = this.m_detail.Tables[0];

            this.dataGridView2.Columns[0].Visible = false;
            this.dataGridView2.Columns[3].Visible = false;

            this.dataGridView2.Columns[1].Width = 100;
            this.dataGridView2.Columns[2].Width = 240;
            this.dataGridView2.Columns[5].Width = 80;
            this.dataGridView2.Columns[5].DefaultCellStyle.Format = "###,##0.00";
            this.dataGridView2.Columns[6].Width = 100;
            this.dataGridView2.Columns[6].DefaultCellStyle.Format = "###,##0.00";

            if (frm_Main.mp_idAlmacen > 0)
                this.Text = this.Text + " - " + frm_Main.mp_strAlmacen; 

		}

        private void frm_pedidosprv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if(MessageBox.Show("Desea salir?","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                    this.Close();
            }
        }

        private void FillProductosFromProveedor()
        {
            SortedList sl = new SortedList();
            string ky;
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "select rpp.idProducto, cp.CodigoProd, cp.Descripcion from relProductoProveedor rpp  inner join catProductos cp on rpp.IdProducto = cp.IdProducto where rpp.IdProveedor = " + this.p_keyprov.ToString();

                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                sl_ProdsProvs.Clear();
                this.cmb_Productos.Items.Clear(); 
                while (lReader.Read())
                {
                    ky = lReader["Descripcion"].ToString();
                    if (!sl_ProdsProvs.Contains(ky))
                    {
                        sl_ProdsProvs.Add(ky, lReader["idProducto"].ToString() + "�" + lReader["CodigoProd"].ToString());
                        this.cmb_Productos.Items.Add(ky);
                    }
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == System.Data.ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void AddProveedorProducto(int idProducto, int idProveedor)
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction lTransaction = null;

            try
            {

                if (idProducto <= 0)
                    return;

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();
                
                // checa si no ya esta asignado
                object res;
                string idProvs="";
                System.Data.Odbc.OdbcCommand lCmd1 = new System.Data.Odbc.OdbcCommand();
                lCmd1.Connection = lConn;
                lCmd1.CommandText = "SELECT IdProducto FROM relProductoProveedor WHERE IdProducto = " + idProducto.ToString() + " AND IdProveedor = " + idProveedor.ToString();
                res = lCmd1.ExecuteScalar();
                if (res!=null)
                { 
                    if (lConn.State == ConnectionState.Open)
                        lConn.Close();
                    return;
                }

                idProvs = "";
                lCmd1.CommandText = "SELECT IdProveedor FROM relProductoProveedor WHERE IdProducto = " + idProducto.ToString();
                System.Data.Odbc.OdbcDataReader lReader = lCmd1.ExecuteReader();

                while (lReader.Read())
                {
                    idProvs += Convert.ToString(lReader[0]) + " ";
                }
                idProvs += idProveedor.ToString();
                lReader.Close();

                lTransaction = lConn.BeginTransaction();

                lCmd.Connection = lConn;
                lCmd.Transaction = lTransaction;
                lCmd.CommandText = "INSERT INTO relProductoProveedor(IdProducto,IdProveedor) VALUES(" + idProducto.ToString() + "," + idProveedor.ToString() + ");";
                lCmd.ExecuteNonQuery();

                lCmd.CommandText = "UPDATE catProductos SET Proveedores = '" + idProvs + "' WHERE IdProducto = " + idProducto.ToString() + ";";
                lCmd.ExecuteNonQuery();

                lTransaction.Commit();

            }
            catch (System.Exception ex)
            {
                if (lTransaction != null)
                    lTransaction.Rollback();

                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void cmd_Agregar_Click(object sender, EventArgs e)
        {
            if (this.cmb_Productos.SelectedIndex < 0)
            {
                MessageBox.Show("Seleccione el producto antes de agregar el pedido" , "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                this.cmb_Productos.Focus();
                return;
            }
            if (!frm_config.IsNumeric(this.txtCantidad.Text))
            {
                MessageBox.Show("Dato inv�lido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtCantidad.Focus();
                return;
            }
            if (!frm_config.IsNumeric(this.txtPrecioUnit.Text))
            {
                MessageBox.Show("Dato inv�lido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtPrecioUnit.Focus();
                return;
            }

            if (!sl_ProdsProvs.ContainsKey(this.cmb_Productos.Text))
            {
                MessageBox.Show("Producto invalido para el proveedor indicado", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.cmb_Productos.Focus();
                return;
            }

            DataRow row;
            // idProducto�CodigoProd
            string[] vals = sl_ProdsProvs[this.cmb_Productos.Text].ToString().Split("�".ToCharArray());
            object[] keys = new object[2];
            keys[0]=vals[0];
            keys[1] = this.p_keyprov;
            row = this.m_detail.Tables[0].Rows.Find(keys);
            if (row == null)
            {
                row = this.m_detail.Tables[0].NewRow();
                row["idProducto"] = keys[0];
                row["idProveedor"] = keys[1];
                row["Codigo"] = vals[1];
                row["Descripcion"] = this.cmb_Productos.Text;
                row["Proveedor"] = this.txt_proveedores.Text;
                row["Cantidad"] = this.txtCantidad.Text;
                row["PrecioUnit"] = this.txtPrecioUnit.Text;
                this.m_detail.Tables[0].Rows.Add(row);
            }
            else
            {
                row["Cantidad"] = this.txtCantidad.Text;
                row["PrecioUnit"] = this.txtPrecioUnit.Text;
            }
            this.m_detail.Tables[0].AcceptChanges();
        }

        private void cmd_Borrar_Click(object sender, EventArgs e)
        {
            if(this.dataGridView2.SelectedRows.Count>0)
            {
                foreach(DataGridViewRow dgRow in this.dataGridView2.SelectedRows)
                {
                    this.dataGridView2.Rows.Remove(dgRow);
                }
            }   
        }

        private void cmd_Save_Click(object sender, EventArgs e)
        {
            this.MakeOrdenesCompra();
            this.m_detail.Tables[0].Rows.Clear();
        }


        private void MakeOrdenesCompra()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction lTransaction = null;

            if (this.m_detail.Tables[0].Rows.Count <= 0)
                return;

            SortedList sl = new SortedList();
            string str1;
            int id;
            foreach( DataRow row in this.m_detail.Tables[0].Rows)
            {
                str1 = Convert.ToString(row["idProducto"]) + "~" + Convert.ToString(row["Cantidad"]) + "~" + Convert.ToString(row["PrecioUnit"]);
                id=Convert.ToInt32(row["idProveedor"]);
                if(sl.Contains(id))
                {
                    ((System.Collections.Generic.List<string>)sl[id]).Add(str1);
                }
                else
                {
                    System.Collections.Generic.List<string> det = new System.Collections.Generic.List<string>();
                    det.Add(str1);
                    sl.Add(id,det);
                }
            }


            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                // checa si no ya esta asignado
                int consec;
                DateTime dt;
                System.Data.Odbc.OdbcCommand lCmd1 = new System.Data.Odbc.OdbcCommand();
                lCmd1.Connection = lConn;
                lCmd1.CommandText = "SELECT ConsOrdenesCompra FROM confConsFactura";
                consec = Convert.ToInt32(lCmd1.ExecuteScalar());

                foreach( int idProv in sl.Keys)
                {
                    lCmd = new System.Data.Odbc.OdbcCommand();
                    dt=System.DateTime.Now;
                    lTransaction = lConn.BeginTransaction();

                    lCmd.Connection = lConn;
                    lCmd.Transaction = lTransaction;
                    lCmd.CommandText = "INSERT INTO catOrdenesCompra (IdProveedor,NumeroOrdenCompra,Fecha,NumProductos,Subtotal,Total,usuario,estatus) VALUES (?,?,?,?,?,?,?,?);";
                    lCmd.Parameters.AddWithValue("@IdProveedor",idProv);
                    lCmd.Parameters.AddWithValue("@NumeroOrdenCompra", consec);
                    lCmd.Parameters.AddWithValue("@Fecha", dt);
                    lCmd.Parameters.AddWithValue("@NumProductos", ((System.Collections.Generic.List<string>)sl[idProv]).Count);
                    lCmd.Parameters.AddWithValue("@Subtotal", 0);
                    lCmd.Parameters.AddWithValue("@Total", 0);
                    lCmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                    lCmd.Parameters.AddWithValue("@estatus", 'P');
                    lCmd.ExecuteNonQuery();

                    lCmd.Parameters.Clear();
                    lCmd.Transaction = lTransaction;
                    lCmd.CommandText = "SELECT IdOrdenCompra FROM catOrdenesCompra WHERE NumeroOrdenCompra=? AND IdProveedor=? AND Fecha=?;";
                    lCmd.Parameters.AddWithValue("@NumeroOrdenCompra", consec);
                    lCmd.Parameters.AddWithValue("@IdProveedor", idProv);
                    lCmd.Parameters.AddWithValue("@Fecha", dt);
                    id=Convert.ToInt32(lCmd.ExecuteScalar());

                    foreach(string str2 in ((System.Collections.Generic.List<string>)sl[idProv]))
                    {
                        string[] strs = str2.Split('~');
                        lCmd = new System.Data.Odbc.OdbcCommand();
                        lCmd.Connection = lConn;
                        lCmd.Parameters.Clear();
                        lCmd.Transaction = lTransaction;
                        lCmd.CommandText = "INSERT INTO detOrdenesCompra (IdOrdenCompra,IdProducto,Cantidad,Importe,Iva) VALUES (?,?,?,?,?);";
                        lCmd.Parameters.AddWithValue("@IdOrdenCompra", id);
                        lCmd.Parameters.AddWithValue("@IdProducto", strs[0]);
                        lCmd.Parameters.AddWithValue("@Cantidad", Convert.ToDouble(strs[1]));
                        lCmd.Parameters.AddWithValue("@Importe", System.Math.Round(Convert.ToDouble(strs[2]),2));
                        lCmd.Parameters.AddWithValue("@Iva", 0);
                        lCmd.ExecuteNonQuery();
                    }

                    lTransaction.Commit();
                    lCmd = null;
                    consec+=1;
                }

                lCmd1.Parameters.Clear();
                lCmd1.CommandText = "UPDATE confConsFactura SET ConsOrdenesCompra = ?;";
                lCmd1.Parameters.AddWithValue("@ConsOrdenesCompra", consec);
                lCmd1.ExecuteNonQuery();

				MessageBox.Show("La orden de compra se genero exitosamente","Informacion",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                if (lTransaction != null)
                    lTransaction.Rollback();

                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        ////- Pedidos: Generar CSV (excel) general y por proveedor ligado al prod (no tomar en cuenta pto reorden=0)
        ////  con codigoprod,codigo,descripcion, unidad (pza, caja. etc.),cantidad(ptmo maximo-existencia),orden(consecutivo), precio(0) 
        //private void cmd_makefiles_Click(object sender, EventArgs e)
        //{
        //    System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
        //    System.Data.Odbc.OdbcDataReader l_reader = null;

        //    if (this.m_dataset.Tables[0].Rows.Count <= 0)
        //        return;

        //    try
        //    {
        //        int id=0;
        //        string fileProv;
        //        System.Text.StringBuilder sb;
        //        foreach (string myFile in System.IO.Directory.GetFiles(".\\", "PEDIDOS-*.csv"))
        //        {
        //            System.IO.File.Delete(myFile);
        //        }
        //        System.IO.StreamWriter swGen = new System.IO.StreamWriter(".\\PEDIDOS-General.csv",false);
        //        System.IO.StreamWriter swProv;
                
        //        lConn.ConnectionString = frm_Main.mps_strconnection;
        //        lConn.Open();
                
        //        foreach( DataRow row in this.m_dataset.Tables[0].Rows)
        //        {

        //            //IdProducto,CodigoProd,Codigo,Descripcion,Existencia,PtoReorden,UnidadVenta,Observaciones
        //            l_reader = this.LeeArticuloyExistencias(Convert.ToInt32(row["idProducto"]), lConn);
        //            if(l_reader != null)
        //            {
        //                if (Convert.ToInt32(l_reader["PtoReorden"]) > 0)
        //                {
        //                    id += 1;
        //                    sb = new System.Text.StringBuilder();
        //                    sb.Append(l_reader["CodigoProd"]);
        //                    sb.Append(",");
        //                    sb.Append(l_reader["Codigo"]);
        //                    sb.Append(",");
        //                    sb.Append(l_reader["Descripcion"]);
        //                    sb.Append(",");
        //                    sb.Append(l_reader["UnidadVenta"]);
        //                    sb.Append(",");
        //                    sb.Append(l_reader["Marca"]);
        //                    sb.Append(",");
        //                    try
        //                    {
        //                        sb.Append((Convert.ToDecimal(l_reader["PtoMaximo"]) - Convert.ToDecimal(l_reader["Existencia"])).ToString("######0.00"));
        //                    }
        //                    catch
        //                    {
        //                        sb.Append("0.00");
        //                    }
        //                    sb.Append(",");
        //                    sb.Append(id);
        //                    sb.Append(",0");
        //                    sb.Append(",");
        //                    sb.Append(l_reader["Observaciones"]);

        //                    swGen.WriteLine(sb.ToString());

        //                    System.Data.Odbc.OdbcDataReader l_readerProvs = this.LeeProveedoresArticulo(Convert.ToInt32(row["idProducto"]), lConn);
        //                    while (l_readerProvs.Read())
        //                    {
        //                        fileProv = l_readerProvs["Nombre"].ToString().Trim();
        //                        try
        //                        {
        //                            swProv = new System.IO.StreamWriter(".\\PEDIDOS-" + fileProv + ".csv", true);
        //                            swProv.WriteLine(sb.ToString());
        //                            swProv.Close();
        //                        }
        //                        catch (Exception ex1)
        //                        {
        //                            MessageBox.Show("Error al generar archivo " + fileProv + " : " + ex1.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                        }
        //                    }
        //                    l_readerProvs.Close();
        //                }
        //                l_reader.Close();
        //            }

        //        }
        //        swGen.Close();
        //        MessageBox.Show("Se generaron los archivos exitosamente", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //    catch (System.Exception ex)
        //    {
        //        MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    finally
        //    {
        //        if (lConn.State == ConnectionState.Open)
        //        {
        //            lConn.Close();
        //        }
        //    }
        //}

        //private System.Data.Odbc.OdbcDataReader LeeArticuloyExistencias(System.Int32 pkey, System.Data.Odbc.OdbcConnection l_conn)
        //{
        //    //Buscar el articulo...
        //    System.Data.Odbc.OdbcDataReader l_reader=null;
        //    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
        //    l_recid.Connection = l_conn;
        //    try
        //    {
        //        if (frm_Main.mp_idAlmacen <= 0)
        //        {
        //            l_recid.CommandText = "SELECT * FROM catProductos WHERE IdProducto = ?;";
        //            l_recid.Parameters.AddWithValue("@IdProducto", pkey);
        //        }
        //        else
        //        {
        //            l_recid.CommandText = "SELECT catExistencias.*,catProductos.CodigoProd, catProductos.Codigo, catProductos.Descripcion, catProductos.UnidadVenta, catProductos.Marca, catProductos.Observaciones  FROM catProductos LEFT JOIN catExistencias ON catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=? WHERE catExistencias.idProducto=?;";
        //            l_recid.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
        //            l_recid.Parameters.AddWithValue("@IdProducto", pkey);
        //        }

        //        l_reader = l_recid.ExecuteReader();

        //        if (l_reader.Read() == false)
        //        {
        //            l_reader.Close();
        //            l_reader = null;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    return l_reader;
        //}

        //private System.Data.Odbc.OdbcDataReader LeeProveedoresArticulo(System.Int32 pkey, System.Data.Odbc.OdbcConnection l_conn)
        //{
        //    //Buscar el articulo...
        //    System.Data.Odbc.OdbcDataReader l_reader = null;
        //    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
        //    l_recid.Connection = l_conn;
        //    try
        //    {
        //        l_recid.CommandText = "SELECT catProveedores.Nombre FROM catProveedores left join relProductoProveedor on catProveedores.idProveedor=relProductoProveedor.idProveedor WHERE relProductoProveedor.IdProducto=?;";
        //        l_recid.Parameters.AddWithValue("@IdProducto", pkey);

        //        l_reader = l_recid.ExecuteReader();

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    return l_reader;
        //}

        private void lnk_proveedores_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.m_detail.Tables[0].Rows.Count > 0)
            {
                if (MessageBox.Show("Ya existen registros a grabar para el proveedor actual, si continua se perderan los registros agregados. Desea continuar e iniciar con el nuevo proveedor?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }

            frm_ProveedoresList l_frmProveedores = new frm_ProveedoresList();
            l_frmProveedores.m_KeyRecord = -1;            
            l_frmProveedores.cmd_nuevo.Enabled = false; 
            l_frmProveedores.ShowDialog(this);

            if (this.p_keyprov == l_frmProveedores.m_KeyRecord)
                return;

            this.p_keyprov = l_frmProveedores.m_KeyRecord;
            if(l_frmProveedores.m_KeyRecord!=-1)
            {
                this.txt_proveedores.Text = l_frmProveedores.m_provName;
                this.FillProductosFromProveedor();
            }
            else
            {
                this.txt_proveedores.Text = "";
                this.cmb_Productos.Items.Clear();
            }

            if (txtCantidad.Text == "")
                txtCantidad.Text = "1.00";
            if (txtPrecioUnit.Text == "")
                txtPrecioUnit.Text = "0.00";
            this.m_detail.Tables[0].Rows.Clear();

        }

      /////////////////////////////////////////////////////////////////////////
      }

}
