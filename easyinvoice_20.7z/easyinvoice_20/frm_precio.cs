﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 3/2/2008
 * Time: 1:13 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_precio.
	/// </summary>
	public partial class frm_precio : Form
	{
		public frm_precio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Cmd_okClick(object sender, EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
		}
		
		void Txt_precioKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Enter )
				this.Cmd_okClick(sender,null);
		}
	}
}
