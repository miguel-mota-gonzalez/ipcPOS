﻿/*
 * Created by SharpDevelop.
 * User: juan.mota
 * Date: 30/04/2007
 * Time: 12:55 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class frm_facturasprov : System.Windows.Forms.Form
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_facturasprov));
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.label1 = new System.Windows.Forms.Label();
			this.cmd_cerrar = new System.Windows.Forms.Button();
			this.ll_eliminar = new System.Windows.Forms.LinkLabel();
			this.ll_modificar = new System.Windows.Forms.LinkLabel();
			this.ll_agregar = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView1
			// 
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.AllowUserToDeleteRows = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
			this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.SteelBlue;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Blue;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
			this.dataGridView1.Location = new System.Drawing.Point(13, 41);
			this.dataGridView1.MultiSelect = false;
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.RowHeadersVisible = false;
			this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView1.Size = new System.Drawing.Size(553, 275);
			this.dataGridView1.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(13, 13);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(35, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "label1";
			// 
			// cmd_cerrar
			// 
			this.cmd_cerrar.Image = ((System.Drawing.Image)(resources.GetObject("cmd_cerrar.Image")));
			this.cmd_cerrar.Location = new System.Drawing.Point(490, 340);
			this.cmd_cerrar.Name = "cmd_cerrar";
			this.cmd_cerrar.Size = new System.Drawing.Size(75, 23);
			this.cmd_cerrar.TabIndex = 4;
			this.cmd_cerrar.Text = "Cerrar";
			this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.cmd_cerrar.UseVisualStyleBackColor = true;
			this.cmd_cerrar.Click += new System.EventHandler(this.cmd_cerrar_Click);
			// 
			// ll_eliminar
			// 
			this.ll_eliminar.AutoSize = true;
			this.ll_eliminar.Location = new System.Drawing.Point(462, 319);
			this.ll_eliminar.Name = "ll_eliminar";
			this.ll_eliminar.Size = new System.Drawing.Size(106, 13);
			this.ll_eliminar.TabIndex = 3;
			this.ll_eliminar.TabStop = true;
			this.ll_eliminar.Text = "Eliminar factura {Del}";
			this.ll_eliminar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_eliminar_LinkClicked);
			// 
			// ll_modificar
			// 
			this.ll_modificar.AutoSize = true;
			this.ll_modificar.Location = new System.Drawing.Point(277, 319);
			this.ll_modificar.Name = "ll_modificar";
			this.ll_modificar.Size = new System.Drawing.Size(161, 13);
			this.ll_modificar.TabIndex = 2;
			this.ll_modificar.TabStop = true;
			this.ll_modificar.Text = "Modificar la catidad pagada {F3}";
			this.ll_modificar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_modificar_LinkClicked);
			// 
			// ll_agregar
			// 
			this.ll_agregar.AutoSize = true;
			this.ll_agregar.Location = new System.Drawing.Point(136, 319);
			this.ll_agregar.Name = "ll_agregar";
			this.ll_agregar.Size = new System.Drawing.Size(103, 13);
			this.ll_agregar.TabIndex = 1;
			this.ll_agregar.TabStop = true;
			this.ll_agregar.Text = "Agregar factura {F2}";
			this.ll_agregar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_agregar_LinkClicked);
			// 
			// frm_facturasprov
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(578, 375);
			this.Controls.Add(this.ll_agregar);
			this.Controls.Add(this.ll_modificar);
			this.Controls.Add(this.ll_eliminar);
			this.Controls.Add(this.cmd_cerrar);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.dataGridView1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frm_facturasprov";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Facturas del proveedor";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_facturasprov_KeyDown);
			this.Load += new System.EventHandler(this.frm_facturasprov_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

        private System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmd_cerrar;
        private System.Windows.Forms.LinkLabel ll_eliminar;
        private System.Windows.Forms.LinkLabel ll_modificar;
        private System.Windows.Forms.LinkLabel ll_agregar;
				
	}
}
