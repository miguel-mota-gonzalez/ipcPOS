using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_ordenescompralist.
	/// </summary>
	public class frm_ordenescompralist : System.Windows.Forms.Form
    {
		private System.Data.DataSet m_dataset;
        public System.Int32 m_KeyRecord;
		
		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private DataGridView dataGridView1;

        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        private ToolBar toolBar1;
        private ToolBarButton toolBarButton1;
        private ToolBarButton toolBarButton3;
        private ToolBarButton toolBarButton2;
        private ToolBarButton toolBarButton4;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private ComboBox cmb_criterios;
        private TextBox txt_criterio;
        private DateTimePicker dateTimePicker1;
        private ToolBarButton toolBarButton5;
        private ToolStripMenuItem imprimirToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem enviToolStripMenuItem;
        private IContainer components;

		public frm_ordenescompralist()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//			
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_ordenescompralist));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolBar1 = new System.Windows.Forms.ToolBar();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_criterios = new System.Windows.Forms.ComboBox();
            this.txt_criterio = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // printDocument1
            // 
            this.printDocument1.DocumentName = "Factura";
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Silver;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(1, 55);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(807, 414);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView1_KeyDown);
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem,
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem,
            this.imprimirToolStripMenuItem,
            this.enviToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(195, 100);
            // 
            // cancelarLaFacturaSeleccionadaToolStripMenuItem
            // 
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem.Name = "cancelarLaFacturaSeleccionadaToolStripMenuItem";
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem.Text = "Cancelar";
            this.cancelarLaFacturaSeleccionadaToolStripMenuItem.Click += new System.EventHandler(this.CancelarLaFacturaSeleccionadaToolStripMenuItemClick);
            // 
            // reactivarLaFacturaSeleccionadaToolStripMenuItem
            // 
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem.Name = "reactivarLaFacturaSeleccionadaToolStripMenuItem";
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem.Text = "Reactivar";
            this.reactivarLaFacturaSeleccionadaToolStripMenuItem.Click += new System.EventHandler(this.ReactivarLaFacturaSeleccionadaToolStripMenuItemClick);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // enviToolStripMenuItem
            // 
            this.enviToolStripMenuItem.Name = "enviToolStripMenuItem";
            this.enviToolStripMenuItem.Size = new System.Drawing.Size(194, 24);
            this.enviToolStripMenuItem.Text = "Enviar por Correo";
            // 
            // toolBar1
            // 
            this.toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.toolBarButton1,
            this.toolBarButton3,
            this.toolBarButton5,
            this.toolBarButton2,
            this.toolBarButton4});
            this.toolBar1.DropDownArrows = true;
            this.toolBar1.ImageList = this.imageList1;
            this.toolBar1.Location = new System.Drawing.Point(0, 0);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.ShowToolTips = true;
            this.toolBar1.Size = new System.Drawing.Size(808, 53);
            this.toolBar1.TabIndex = 6;
            this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.ImageIndex = 0;
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Text = "Ver";
            this.toolBarButton1.ToolTipText = "Presione este bot�n para visualizar la factura seleccionada...";
            this.toolBarButton1.Visible = false;
            // 
            // toolBarButton3
            // 
            this.toolBarButton3.ImageIndex = 1;
            this.toolBarButton3.Name = "toolBarButton3";
            this.toolBarButton3.Text = "Actualizar";
            this.toolBarButton3.ToolTipText = "Actualizar la lista...";
            // 
            // toolBarButton5
            // 
            this.toolBarButton5.ImageIndex = 3;
            this.toolBarButton5.Name = "toolBarButton5";
            this.toolBarButton5.Text = "Ver Pagos";
            this.toolBarButton5.ToolTipText = "Visualizar los pagos relacionados a esta factura";
            this.toolBarButton5.Visible = false;
            // 
            // toolBarButton2
            // 
            this.toolBarButton2.ImageIndex = 2;
            this.toolBarButton2.Name = "toolBarButton2";
            this.toolBarButton2.Text = "Cerrar";
            this.toolBarButton2.ToolTipText = "Presione este bot�n para cerrar esta ventana...";
            // 
            // toolBarButton4
            // 
            this.toolBarButton4.Name = "toolBarButton4";
            this.toolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Drafts.ico");
            this.imageList1.Images.SetKeyName(1, "refresh.ico");
            this.imageList1.Images.SetKeyName(2, "exit.ico");
            this.imageList1.Images.SetKeyName(3, "IB-app-formatterMoney_48-256.ico");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(272, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(560, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 19);
            this.label2.TabIndex = 19;
            this.label2.Text = "criterio:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(311, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 19);
            this.label1.TabIndex = 18;
            this.label1.Text = "Buscar por";
            // 
            // cmb_criterios
            // 
            this.cmb_criterios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_criterios.Location = new System.Drawing.Point(397, 14);
            this.cmb_criterios.Name = "cmb_criterios";
            this.cmb_criterios.Size = new System.Drawing.Size(145, 24);
            this.cmb_criterios.TabIndex = 17;
            this.cmb_criterios.SelectionChangeCommitted += new System.EventHandler(this.cmb_criterios_SelectionChangeCommitted);
            this.cmb_criterios.TextChanged += new System.EventHandler(this.cmb_criterios_TextChanged);
            // 
            // txt_criterio
            // 
            this.txt_criterio.Location = new System.Drawing.Point(628, 14);
            this.txt_criterio.Name = "txt_criterio";
            this.txt_criterio.Size = new System.Drawing.Size(278, 22);
            this.txt_criterio.TabIndex = 0;
            this.txt_criterio.TextChanged += new System.EventHandler(this.txt_criterio_TextChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(628, 13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(278, 22);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.Visible = false;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // frm_ordenescompralist
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.ClientSize = new System.Drawing.Size(808, 470);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_criterios);
            this.Controls.Add(this.txt_criterio);
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_ordenescompralist";
            this.Text = "Lista de Ordenes de Compra";
            this.Activated += new System.EventHandler(this.frm_ordenescompralist_Activated);
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_ordenescompralist_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.ToolStripMenuItem reactivarLaFacturaSeleccionadaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem cancelarLaFacturaSeleccionadaToolStripMenuItem;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		#endregion

        bool filled = false;

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
		}

        private void frm_ordenescompralist_Activated(object sender, System.EventArgs e)
        {
            if (filled)
                return;

            filled = true;

            this.FillDataset();

            foreach (System.Data.DataColumn l_col in m_dataset.Tables[0].Columns)
            {
                if (l_col.DataType.Name == "String")
                    this.cmb_criterios.Items.Add(l_col.ColumnName);
            }

            this.cmb_criterios.Items.Add("Fecha");
            this.cmb_criterios.Items.Add("Posteriores a la Fecha...");
            this.cmb_criterios.Text = "NumeroFactura";


        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
            try
            {            	
            	if (this.cmb_criterios.Text == "Fecha")
                	this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " >= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 00:00:00# AND [" + this.cmb_criterios.Text + "] <= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 23:59:59#";
            	else
            		this.mp_bs.Filter = "[Fecha]" + " >= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 00:00:00#";

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            } 
            
        }

        private void cmb_criterios_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (this.cmb_criterios.Text == "Fecha" || this.cmb_criterios.Text == "Posteriores a la Fecha...")
            {
                this.txt_criterio.Visible = false;
                this.dateTimePicker1.Visible = true;               
                this.dateTimePicker1.Focus();
                this.dateTimePicker1_ValueChanged(sender, e);
            }
            else
            {                
                this.txt_criterio.Visible = true;
                this.dateTimePicker1.Visible = false;
                this.txt_criterio.Focus();
                this.txt_criterio_TextChanged(sender, e);
            }
        }

        private void cmb_criterios_TextChanged(object sender, EventArgs e)
        {
        }        

        private void txt_criterio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }
        }

		public void FillDataset()	
		{
            try
            {
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "SELECT catOrdenesCompra.IdOrdenCompra, catOrdenesCompra.NumeroOrdenCompra, catOrdenesCompra.Fecha, catProveedores.Nombre, catOrdenesCompra.NumProductos, catOrdenesCompra.Estatus FROM catOrdenesCompra LEFT OUTER JOIN catProveedores ON catOrdenesCompra.IdProveedor = catProveedores.IdProveedor ORDER BY catOrdenesCompra.Fecha DESC;";
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "OrdenesCompra";

                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }	
		}


        private string GetEncabezadoNota()
		{
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '002';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            string l_result = l_reader["EncabezadoNota"].ToString();

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
		}
       
		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			
		}

        
        private int DesglosarIVA()
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            int l_result = Convert.ToInt32(l_reader["DesglosarIva"]);

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
        }

		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 

            string l_retval = "";

            clsUtils.cUtils l_utils = new clsUtils.cUtils();

            if (Convert.ToDouble(l_num) < 1)
                l_retval = "CERO PESOS " + l_utils.Transforma(l_num);
            else
                l_retval = l_utils.Transforma(l_num);

            return l_retval;

		}

        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {
            
            switch (e.Button.Text)
            {
                case "Ver":
                    /*
                    this.printPreviewDialog1.WindowState = FormWindowState.Maximized;
                    this.printPreviewDialog1.ShowDialog();
                    */
                    break;
                case "Actualizar":
                    this.FillDataset();
                    break;
                case "Ver Pagos":
                    /*
                    if (this.dataGridView1.SelectedRows.Count < 1)
                        break;

                    if (Convert.ToBoolean(this.dataGridView1.SelectedRows[0].Cells[4].Value) == true)
                    {
                        frm_PagosFactura l_frm = new frm_PagosFactura();
                        l_frm.m_bool_EsNota = this.m_notas;
                        l_frm.m_KeyFactura = Convert.ToInt32( this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString() );
                        l_frm.m_ClientName = this.dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                        l_frm.ShowDialog();
                    }
                    else
                    {
                        if (this.m_notas)
                            MessageBox.Show("Esta no es una nota de venta de cr�dito. Solo hay pagos relacionados a las notas de venta de cr�dito.", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        else
                            MessageBox.Show("Esta no es una factura de cr�dito. Solo hay pagos relacionados a las facturas de cr�dito.", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    */
                    break;
                case "Cerrar":
                    this.Close();
                    break;

            }

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.ImprimirOrdenCompra();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Enter)
            {
                this.ImprimirOrdenCompra();
            }
            
        }

        private void ImprimirOrdenCompra()
        {
            int idOrdenCompra;
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                idOrdenCompra = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                #if ES_UNIX 					
                    // CODIGO PARA MIKE   <======================== OJO,    MIGUEL MOTA ACA!!

                #else
                object lInstance;
                try
                {
                    if (System.IO.File.Exists(".\\EASYREPORTS.DLL"))
                    {
                        object ret;
                        object[] parms = new object[1];
                        System.Reflection.MethodInfo MethodInf;
                        System.Reflection.Assembly lAssembly;
                        Type lType;

                        lAssembly = System.Reflection.Assembly.Load("EASYREPORTS");
                        lType = lAssembly.GetType("EasyReports.ReportAdmin");

                        lInstance = Activator.CreateInstance(lType);

                        MethodInf = lType.GetMethod("setConnectionString");
                        parms[0] = frm_Main.mps_strconnection;
                        ret = MethodInf.Invoke(lInstance, parms);

                        MethodInf = lType.GetMethod("setReportOption");
                        parms[0] = 1;
                        ret = MethodInf.Invoke(lInstance, parms);

                        MethodInf = lType.GetMethod("invokeReport");
                        object[] parmsrep = new object[1];
                        parmsrep[0] = idOrdenCompra;
                        parms[0] = parmsrep;
                        ret = MethodInf.Invoke(lInstance, parms);

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    lInstance=null;
                }
                #endif
            }
        }

        private void frm_ordenescompralist_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }
 
/*
        ////////////////////////////////////////////////     
        //Posiciones de la factura...
		int mp_int_PosNombreX = 0;        
		int mp_int_PosNombreY = 0;        
	
		int mp_int_PosDireccionX = 0;        
		int mp_int_PosDireccionY = 0;        

		int mp_int_PosCiudadX = 0;        
		int mp_int_PosCiudadY = 0;        

		int mp_int_PosRFCX = 0;        
		int mp_int_PosRFCY = 0;        

		int mp_int_PosNumFactX = 0;        
		int mp_int_PosNumFactY = 0;        

		int mp_int_PosFechaX = 0;        
		int mp_int_PosFechaY = 0;        
		
		int mp_int_PosCodigoX = 0;        
		int mp_int_PosCodigoY = 0;        

		int mp_int_PosCantidadX = 0;        
		int mp_int_PosCantidadY = 0;        

		int mp_int_PosDescripcionX = 0;        
		int mp_int_PosDescripcionY = 0;        

		int mp_int_PosPrecioX = 0;        
		int mp_int_PosPrecioY = 0;        
		
		int mp_int_PosTotalX = 0;        
		int mp_int_PosTotalY = 0;        
		
		int mp_int_PosSubTotalX = 0;        
		int mp_int_PosSubTotalY = 0;        
		
		int mp_int_PosIVAX = 0;        
		int mp_int_PosIVAY = 0;        

		int mp_int_PosGTotalX = 0;        
		int mp_int_PosGTotalY = 0;

        int mp_int_PosCadenaOriginalX = 0;
        int mp_int_PosCadenaOriginalY = 0;

        int mp_int_PosSelloX = 0;
        int mp_int_PosSelloY = 0; 

		int mp_int_PosGTotalLetrasX = 0;        
		int mp_int_PosGTotalLetrasY = 0;        
		
		int mp_int_EspacioDetalle = 0;
		int mp_int_TamanioLetra = 0;		
		
		string mp_string_Leyenda = "";
        string mp_string_mensaje = "";
*/		
		System.Data.Odbc.OdbcConnection m_conn = new System.Data.Odbc.OdbcConnection();
		
		private void LoadDocPositions()
		{
			
		}
				
		void CancelarLaFacturaSeleccionadaToolStripMenuItemClick(object sender, EventArgs e)
		{				
			if( this.dataGridView1.SelectedRows.Count > 0)
			{												
				
				if( System.Convert.ToString(this.dataGridView1.SelectedRows[0].Cells[5].Value) == "C" )
				{
					MessageBox.Show( "La Orden de Compra ya est� cancelada", "EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Information );
					return;
				}
				
				if(MessageBox.Show( "� Confirma que desea CANCELAR la Orden de Compra { " + 
				                    this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString() + ", " +
				                    this.dataGridView1.SelectedRows[0].Cells[2].Value.ToString() + ", " +
				                    this.dataGridView1.SelectedRows[0].Cells[3].Value.ToString() + " } ?",
				                    "Importante", MessageBoxButtons.YesNo, MessageBoxIcon.Warning ) == DialogResult.Yes )
				{		
					//Cancelar...
					
	                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                    l_conn.ConnectionString = frm_Main.mps_strconnection;

	                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();	                
	                
	                l_conn.Open();
	                
	                l_cmd.Connection = l_conn;
                    l_cmd.CommandText = "UPDATE catOrdenesCompra SET estatus = 'C' WHERE IdOrdenCompra = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
	                l_cmd.CommandType = System.Data.CommandType.Text;
	                
	                l_cmd.ExecuteNonQuery();	             
	                
	                this.dataGridView1.SelectedRows[0].Cells[5].Value = "C";
	                
	                l_conn.Close();	                	                
	                
				}				
			}
			else
			{
				MessageBox.Show( "Seleccione una Orden de Compra" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
			}
		}
		
		void ReactivarLaFacturaSeleccionadaToolStripMenuItemClick(object sender, EventArgs e)
		{
			
			if( this.dataGridView1.SelectedRows.Count > 0)
			{				
												
				if( System.Convert.ToString(this.dataGridView1.SelectedRows[0].Cells[5].Value) != "C" )
				{
					MessageBox.Show( "La Orden de Compra ya est� activa", "EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Information );
					return;
				}
				
				if(MessageBox.Show( "� Confirma que desea REACTIVAR la Orden de Compra { " + 
				                    this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString() + ", " +
				                    this.dataGridView1.SelectedRows[0].Cells[2].Value.ToString() + ", " +
				                    this.dataGridView1.SelectedRows[0].Cells[3].Value.ToString() + " } ?",
				                    "Importante", MessageBoxButtons.YesNo, MessageBoxIcon.Warning ) == DialogResult.Yes )
				{
					//Reactivar...
					
	                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                    l_conn.ConnectionString = frm_Main.mps_strconnection;

	                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();	                
	                
	                l_conn.Open();
	                
	                l_cmd.Connection = l_conn;
                    l_cmd.CommandText = "UPDATE catOrdenesCompra SET estatus = 'P' WHERE IdOrdenCompra = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
	                l_cmd.CommandType = System.Data.CommandType.Text;
	                
	                l_cmd.ExecuteNonQuery();	  
	                
	                this.dataGridView1.SelectedRows[0].Cells[5].Value = "P";
	                
	                l_conn.Close();						
					
				}				
			}
			else
			{
				MessageBox.Show( "Seleccione una Orden de Compra" , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
			}			
		}

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ImprimirOrdenCompra();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
