using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
    /// <summary>
    /// Summary description for frm_productos.
    /// </summary>
    public class frm_productos : System.Windows.Forms.Form
    {
        private System.Data.Odbc.OdbcConnection m_conn;
        private System.Data.Odbc.OdbcDataAdapter m_da;
        private System.Data.Odbc.OdbcCommand m_select;
        private System.Data.DataSet m_dataset;
        private System.Int32 m_KeyRecord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button cmd_Borrar;
        private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_cerrar;
        private System.Windows.Forms.TextBox txt_codigoProd;
        private System.Windows.Forms.TextBox txt_descripcion;
        private System.Windows.Forms.TextBox txt_existencia;
        private System.Windows.Forms.TextBox txt_proveedor;
        private System.Windows.Forms.TextBox txt_cliente;
        private System.Windows.Forms.TextBox txt_proveedores;
        private ImageList imageList1;
        private Label label8;
        private TextBox txt_unidadv;
        private Label label10;
        private TextBox txt_codigo;
        private Label label12;
        private TextBox txt_marca;
        private Label label13;
        private TextBox txt_observs;
        private Label label14;
        private TextBox txt_utilidad;
        private Button cmd_familia;
        private Label label15;
        private TextBox txt_linea;
        private Label label16;
        private ComboBox cmb_familia;
        private IContainer components;
        private Label lbl_preciomasiva;
        private Label label18;

        public frm_productoslist frm_ProdPrin = null;
        private LinkLabel lnk_proveedores;
        private Label lbl_IDs_Provs;
        private TextBox txt_preciomasiva;
        private DataGridView dataGridView1;
        private Label label19;

        System.Collections.SortedList sl = new System.Collections.SortedList();
        private TextBox txt_ubicacion;
        private TextBox txt_reorden;
        private TextBox txt_ptomax;
        private System.Data.DataSet dsAlmacenes = new System.Data.DataSet();
        private Label label7;
        private TextBox txt_empaque;
        private SortedList slAlmacenes = null;
        private SortedList slAlmacenesRepl = null;
        // SVM jul-2012  valores iniciales de precio para historico
        private double mp_precio_proveedor = 0;
        private CheckBox chkIeps;
        private Panel pnlIEPS;
        private Label label11;
        private TextBox txtPrecioIeps;
        private Label lblPorcIeps;
        private TextBox txtPorcIeps;
        private double mp_preciomasiva = 0;
        private DataGridView dataGridView2;
        private Label label17;
        private TextBox txtPrecioUnico;
        private Label label20;
        private CheckBox chkPrecioUnico;
        private bool cambiarionPrecio = false;

        public frm_productos()
        {
            this.m_KeyRecord = -1;
            InitializeComponent();
        }

        public frm_productos(System.Int32 p_KeyRecord)
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            //
            this.m_KeyRecord = p_KeyRecord;
        }

        public bool m_IsModified = false;
        public bool mp_Loading = false;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_productos));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txt_codigoProd = new System.Windows.Forms.TextBox();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.txt_existencia = new System.Windows.Forms.TextBox();
            this.txt_proveedor = new System.Windows.Forms.TextBox();
            this.txt_cliente = new System.Windows.Forms.TextBox();
            this.txt_proveedores = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.txt_unidadv = new System.Windows.Forms.TextBox();
            this.txt_iva = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_marca = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_observs = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_utilidad = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_linea = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmb_familia = new System.Windows.Forms.ComboBox();
            this.lbl_preciomasiva = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lnk_proveedores = new System.Windows.Forms.LinkLabel();
            this.cmd_familia = new System.Windows.Forms.Button();
            this.cmd_Borrar = new System.Windows.Forms.Button();
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_cerrar = new System.Windows.Forms.Button();
            this.lbl_IDs_Provs = new System.Windows.Forms.Label();
            this.txt_preciomasiva = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label19 = new System.Windows.Forms.Label();
            this.txt_ubicacion = new System.Windows.Forms.TextBox();
            this.txt_reorden = new System.Windows.Forms.TextBox();
            this.txt_ptomax = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_empaque = new System.Windows.Forms.TextBox();
            this.chkIeps = new System.Windows.Forms.CheckBox();
            this.pnlIEPS = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPrecioIeps = new System.Windows.Forms.TextBox();
            this.lblPorcIeps = new System.Windows.Forms.Label();
            this.txtPorcIeps = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPrecioUnico = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.chkPrecioUnico = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.pnlIEPS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_codigoProd
            // 
            this.txt_codigoProd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_codigoProd.Location = new System.Drawing.Point(120, 10);
            this.txt_codigoProd.Name = "txt_codigoProd";
            this.txt_codigoProd.Size = new System.Drawing.Size(128, 20);
            this.txt_codigoProd.TabIndex = 1;
            this.txt_codigoProd.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_descripcion.Location = new System.Drawing.Point(120, 36);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.Size = new System.Drawing.Size(428, 20);
            this.txt_descripcion.TabIndex = 5;
            this.txt_descripcion.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_existencia
            // 
            this.txt_existencia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_existencia.Location = new System.Drawing.Point(120, 62);
            this.txt_existencia.Name = "txt_existencia";
            this.txt_existencia.Size = new System.Drawing.Size(78, 20);
            this.txt_existencia.TabIndex = 7;
            this.txt_existencia.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_proveedor
            // 
            this.txt_proveedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_proveedor.Location = new System.Drawing.Point(120, 88);
            this.txt_proveedor.Name = "txt_proveedor";
            this.txt_proveedor.Size = new System.Drawing.Size(120, 20);
            this.txt_proveedor.TabIndex = 11;
            this.txt_proveedor.TextChanged += new System.EventHandler(this.txtCalc_TextChanged);
            // 
            // txt_cliente
            // 
            this.txt_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cliente.Location = new System.Drawing.Point(120, 140);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(120, 20);
            this.txt_cliente.TabIndex = 17;
            this.txt_cliente.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_proveedores
            // 
            this.txt_proveedores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_proveedores.Location = new System.Drawing.Point(120, 481);
            this.txt_proveedores.Multiline = true;
            this.txt_proveedores.Name = "txt_proveedores";
            this.txt_proveedores.ReadOnly = true;
            this.txt_proveedores.Size = new System.Drawing.Size(428, 35);
            this.txt_proveedores.TabIndex = 32;
            this.txt_proveedores.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Descripcion";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(16, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Existencia";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(16, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "Precio proveedor";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(16, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 16);
            this.label5.TabIndex = 16;
            this.label5.Text = "Precio Utilidad";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 489);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 16);
            this.label6.TabIndex = 29;
            this.label6.Text = "Proveedores";
            this.label6.Visible = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "delete2.ico");
            this.imageList1.Images.SetKeyName(1, "disk_blue.ico");
            this.imageList1.Images.SetKeyName(2, "exit.ico");
            this.imageList1.Images.SetKeyName(3, "carpeta.ico");
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(324, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Unidad de venta";
            // 
            // txt_unidadv
            // 
            this.txt_unidadv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_unidadv.Location = new System.Drawing.Point(428, 62);
            this.txt_unidadv.Name = "txt_unidadv";
            this.txt_unidadv.ReadOnly = true;
            this.txt_unidadv.Size = new System.Drawing.Size(120, 20);
            this.txt_unidadv.TabIndex = 9;
            this.txt_unidadv.Text = "PZA";
            this.txt_unidadv.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_iva
            // 
            this.txt_iva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_iva.Location = new System.Drawing.Point(120, 114);
            this.txt_iva.Name = "txt_iva";
            this.txt_iva.ReadOnly = true;
            this.txt_iva.Size = new System.Drawing.Size(120, 20);
            this.txt_iva.TabIndex = 13;
            this.txt_iva.Text = "16";
            this.txt_iva.TextChanged += new System.EventHandler(this.txtCalc_TextChanged);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(16, 116);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 16);
            this.label9.TabIndex = 12;
            this.label9.Text = "% IVA";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(285, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Codigo de Barras";
            // 
            // txt_codigo
            // 
            this.txt_codigo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_codigo.Location = new System.Drawing.Point(388, 10);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(160, 20);
            this.txt_codigo.TabIndex = 3;
            this.txt_codigo.TextChanged += new System.EventHandler(this.txt_TextChanged);
            this.txt_codigo.Leave += new System.EventHandler(this.txt_codigo_Leave);
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(250, 431);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 16);
            this.label12.TabIndex = 24;
            this.label12.Text = "Marca";
            // 
            // txt_marca
            // 
            this.txt_marca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_marca.Location = new System.Drawing.Point(292, 429);
            this.txt_marca.Name = "txt_marca";
            this.txt_marca.Size = new System.Drawing.Size(120, 20);
            this.txt_marca.TabIndex = 25;
            this.txt_marca.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(16, 524);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 32);
            this.label13.TabIndex = 34;
            this.label13.Text = "Observaciones Generales";
            // 
            // txt_observs
            // 
            this.txt_observs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_observs.Location = new System.Drawing.Point(120, 522);
            this.txt_observs.Multiline = true;
            this.txt_observs.Name = "txt_observs";
            this.txt_observs.Size = new System.Drawing.Size(428, 35);
            this.txt_observs.TabIndex = 35;
            this.txt_observs.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(324, 116);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 16);
            this.label14.TabIndex = 14;
            this.label14.Text = "% Utilidad";
            // 
            // txt_utilidad
            // 
            this.txt_utilidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_utilidad.Location = new System.Drawing.Point(428, 114);
            this.txt_utilidad.Name = "txt_utilidad";
            this.txt_utilidad.Size = new System.Drawing.Size(120, 20);
            this.txt_utilidad.TabIndex = 15;
            this.txt_utilidad.TextChanged += new System.EventHandler(this.txtCalc_TextChanged);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(16, 431);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 16);
            this.label15.TabIndex = 22;
            this.label15.Text = "Linea";
            // 
            // txt_linea
            // 
            this.txt_linea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_linea.Location = new System.Drawing.Point(120, 429);
            this.txt_linea.Name = "txt_linea";
            this.txt_linea.Size = new System.Drawing.Size(120, 20);
            this.txt_linea.TabIndex = 24;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(16, 457);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 16);
            this.label16.TabIndex = 28;
            this.label16.Text = "Familia";
            // 
            // cmb_familia
            // 
            this.cmb_familia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_familia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_familia.FormattingEnabled = true;
            this.cmb_familia.Location = new System.Drawing.Point(120, 454);
            this.cmb_familia.Name = "cmb_familia";
            this.cmb_familia.Size = new System.Drawing.Size(350, 21);
            this.cmb_familia.TabIndex = 29;
            // 
            // lbl_preciomasiva
            // 
            this.lbl_preciomasiva.Location = new System.Drawing.Point(324, 142);
            this.lbl_preciomasiva.Name = "lbl_preciomasiva";
            this.lbl_preciomasiva.Size = new System.Drawing.Size(153, 16);
            this.lbl_preciomasiva.TabIndex = 18;
            this.lbl_preciomasiva.Text = "Precio al cliente";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(16, 587);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(435, 23);
            this.label18.TabIndex = 39;
            this.label18.Text = "...";
            // 
            // lnk_proveedores
            // 
            this.lnk_proveedores.AutoSize = true;
            this.lnk_proveedores.Location = new System.Drawing.Point(16, 489);
            this.lnk_proveedores.Name = "lnk_proveedores";
            this.lnk_proveedores.Size = new System.Drawing.Size(67, 13);
            this.lnk_proveedores.TabIndex = 31;
            this.lnk_proveedores.TabStop = true;
            this.lnk_proveedores.Text = "Proveedores";
            this.lnk_proveedores.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_proveedores_LinkClicked);
            // 
            // cmd_familia
            // 
            this.cmd_familia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cmd_familia.ImageIndex = 3;
            this.cmd_familia.ImageList = this.imageList1;
            this.cmd_familia.Location = new System.Drawing.Point(476, 452);
            this.cmd_familia.Name = "cmd_familia";
            this.cmd_familia.Size = new System.Drawing.Size(72, 23);
            this.cmd_familia.TabIndex = 30;
            this.cmd_familia.Text = "&Familia";
            this.cmd_familia.Click += new System.EventHandler(this.cmd_familia_Click);
            // 
            // cmd_Borrar
            // 
            this.cmd_Borrar.ImageKey = "delete2.ico";
            this.cmd_Borrar.ImageList = this.imageList1;
            this.cmd_Borrar.Location = new System.Drawing.Point(421, 565);
            this.cmd_Borrar.Name = "cmd_Borrar";
            this.cmd_Borrar.Size = new System.Drawing.Size(127, 23);
            this.cmd_Borrar.TabIndex = 19;
            this.cmd_Borrar.Text = "&Eliminar Registro";
            this.cmd_Borrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Borrar.Visible = false;
            this.cmd_Borrar.Click += new System.EventHandler(this.cmd_Borrar_Click);
            // 
            // cmd_save
            // 
            this.cmd_save.ImageKey = "disk_blue.ico";
            this.cmd_save.ImageList = this.imageList1;
            this.cmd_save.Location = new System.Drawing.Point(554, 565);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(116, 23);
            this.cmd_save.TabIndex = 36;
            this.cmd_save.Text = "&Guardar y cerrar";
            this.cmd_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_cerrar
            // 
            this.cmd_cerrar.ImageKey = "exit.ico";
            this.cmd_cerrar.ImageList = this.imageList1;
            this.cmd_cerrar.Location = new System.Drawing.Point(679, 565);
            this.cmd_cerrar.Name = "cmd_cerrar";
            this.cmd_cerrar.Size = new System.Drawing.Size(75, 23);
            this.cmd_cerrar.TabIndex = 37;
            this.cmd_cerrar.Text = "&Cerrar";
            this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_cerrar.Click += new System.EventHandler(this.cmd_cerrar_Click);
            // 
            // lbl_IDs_Provs
            // 
            this.lbl_IDs_Provs.Location = new System.Drawing.Point(16, 505);
            this.lbl_IDs_Provs.Name = "lbl_IDs_Provs";
            this.lbl_IDs_Provs.Size = new System.Drawing.Size(100, 16);
            this.lbl_IDs_Provs.TabIndex = 33;
            this.lbl_IDs_Provs.Text = "idProvs";
            this.lbl_IDs_Provs.Visible = false;
            // 
            // txt_preciomasiva
            // 
            this.txt_preciomasiva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_preciomasiva.Location = new System.Drawing.Point(428, 140);
            this.txt_preciomasiva.Name = "txt_preciomasiva";
            this.txt_preciomasiva.Size = new System.Drawing.Size(120, 20);
            this.txt_preciomasiva.TabIndex = 19;
            this.txt_preciomasiva.TextChanged += new System.EventHandler(this.txt_preciomasiva_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Location = new System.Drawing.Point(19, 308);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridView1.Size = new System.Drawing.Size(739, 114);
            this.dataGridView1.TabIndex = 23;
            this.dataGridView1.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView1_CellBeginEdit);
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(16, 289);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(224, 16);
            this.label19.TabIndex = 20;
            this.label19.Text = "Informaci�n de almacenamiento";
            // 
            // txt_ubicacion
            // 
            this.txt_ubicacion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ubicacion.Location = new System.Drawing.Point(288, 287);
            this.txt_ubicacion.Name = "txt_ubicacion";
            this.txt_ubicacion.Size = new System.Drawing.Size(46, 20);
            this.txt_ubicacion.TabIndex = 38;
            this.txt_ubicacion.Visible = false;
            // 
            // txt_reorden
            // 
            this.txt_reorden.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_reorden.Location = new System.Drawing.Point(340, 287);
            this.txt_reorden.Name = "txt_reorden";
            this.txt_reorden.Size = new System.Drawing.Size(46, 20);
            this.txt_reorden.TabIndex = 39;
            this.txt_reorden.Visible = false;
            // 
            // txt_ptomax
            // 
            this.txt_ptomax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ptomax.Location = new System.Drawing.Point(388, 287);
            this.txt_ptomax.Name = "txt_ptomax";
            this.txt_ptomax.Size = new System.Drawing.Size(46, 20);
            this.txt_ptomax.TabIndex = 40;
            this.txt_ptomax.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(425, 431);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Empaque";
            // 
            // txt_empaque
            // 
            this.txt_empaque.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_empaque.Location = new System.Drawing.Point(488, 429);
            this.txt_empaque.Name = "txt_empaque";
            this.txt_empaque.ReadOnly = true;
            this.txt_empaque.Size = new System.Drawing.Size(60, 20);
            this.txt_empaque.TabIndex = 27;
            this.txt_empaque.Text = "12";
            // 
            // chkIeps
            // 
            this.chkIeps.AutoSize = true;
            this.chkIeps.Location = new System.Drawing.Point(327, 89);
            this.chkIeps.Name = "chkIeps";
            this.chkIeps.Size = new System.Drawing.Size(82, 17);
            this.chkIeps.TabIndex = 12;
            this.chkIeps.Text = "Aplica IEPS";
            this.chkIeps.UseVisualStyleBackColor = true;
            this.chkIeps.Visible = false;
            this.chkIeps.CheckedChanged += new System.EventHandler(this.chkIeps_CheckedChanged);
            // 
            // pnlIEPS
            // 
            this.pnlIEPS.Controls.Add(this.label11);
            this.pnlIEPS.Controls.Add(this.txtPrecioIeps);
            this.pnlIEPS.Controls.Add(this.lblPorcIeps);
            this.pnlIEPS.Controls.Add(this.txtPorcIeps);
            this.pnlIEPS.Location = new System.Drawing.Point(13, 111);
            this.pnlIEPS.Name = "pnlIEPS";
            this.pnlIEPS.Size = new System.Drawing.Size(545, 30);
            this.pnlIEPS.TabIndex = 13;
            this.pnlIEPS.Visible = false;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(311, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 16);
            this.label11.TabIndex = 18;
            this.label11.Text = "Precio Ieps";
            // 
            // txtPrecioIeps
            // 
            this.txtPrecioIeps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrecioIeps.Location = new System.Drawing.Point(415, 5);
            this.txtPrecioIeps.Name = "txtPrecioIeps";
            this.txtPrecioIeps.ReadOnly = true;
            this.txtPrecioIeps.Size = new System.Drawing.Size(120, 20);
            this.txtPrecioIeps.TabIndex = 19;
            // 
            // lblPorcIeps
            // 
            this.lblPorcIeps.Location = new System.Drawing.Point(3, 7);
            this.lblPorcIeps.Name = "lblPorcIeps";
            this.lblPorcIeps.Size = new System.Drawing.Size(100, 16);
            this.lblPorcIeps.TabIndex = 16;
            this.lblPorcIeps.Text = "% IEPS";
            // 
            // txtPorcIeps
            // 
            this.txtPorcIeps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPorcIeps.Location = new System.Drawing.Point(107, 5);
            this.txtPorcIeps.Name = "txtPorcIeps";
            this.txtPorcIeps.Size = new System.Drawing.Size(120, 20);
            this.txtPorcIeps.TabIndex = 17;
            this.txtPorcIeps.TextChanged += new System.EventHandler(this.txtCalc_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.RoyalBlue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dataGridView2.Location = new System.Drawing.Point(19, 184);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(739, 97);
            this.dataGridView2.TabIndex = 22;
            this.dataGridView2.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridView2_CellBeginEdit);
            this.dataGridView2.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEndEdit);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(16, 167);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(224, 16);
            this.label17.TabIndex = 43;
            this.label17.Text = "Precios por tienda";
            // 
            // txtPrecioUnico
            // 
            this.txtPrecioUnico.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrecioUnico.Location = new System.Drawing.Point(638, 138);
            this.txtPrecioUnico.Name = "txtPrecioUnico";
            this.txtPrecioUnico.Size = new System.Drawing.Size(120, 20);
            this.txtPrecioUnico.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(571, 142);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 19);
            this.label20.TabIndex = 45;
            this.label20.Text = "Precio �nico";
            // 
            // chkPrecioUnico
            // 
            this.chkPrecioUnico.AutoSize = true;
            this.chkPrecioUnico.Location = new System.Drawing.Point(638, 111);
            this.chkPrecioUnico.Name = "chkPrecioUnico";
            this.chkPrecioUnico.Size = new System.Drawing.Size(109, 17);
            this.chkPrecioUnico.TabIndex = 20;
            this.chkPrecioUnico.Text = "Usar precio �nico";
            this.chkPrecioUnico.UseVisualStyleBackColor = true;
            // 
            // frm_productos
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(771, 615);
            this.Controls.Add(this.chkPrecioUnico);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtPrecioUnico);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.chkIeps);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_empaque);
            this.Controls.Add(this.txt_ptomax);
            this.Controls.Add(this.txt_reorden);
            this.Controls.Add(this.txt_ubicacion);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_preciomasiva);
            this.Controls.Add(this.lbl_IDs_Provs);
            this.Controls.Add(this.lnk_proveedores);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_preciomasiva);
            this.Controls.Add(this.cmb_familia);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_linea);
            this.Controls.Add(this.cmd_familia);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_utilidad);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_observs);
            this.Controls.Add(this.txt_marca);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_iva);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_unidadv);
            this.Controls.Add(this.cmd_Borrar);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.cmd_cerrar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_proveedores);
            this.Controls.Add(this.txt_cliente);
            this.Controls.Add(this.txt_proveedor);
            this.Controls.Add(this.txt_existencia);
            this.Controls.Add(this.txt_descripcion);
            this.Controls.Add(this.txt_codigoProd);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pnlIEPS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frm_productos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Producto";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_Clientes_FormClosing);
            this.Load += new System.EventHandler(this.frm_productos_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_Clientes_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.pnlIEPS.ResumeLayout(false);
            this.pnlIEPS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.TextBox txt_iva;
        private System.Windows.Forms.Label label9;
        #endregion

        /*
insert into relProductoLocacion
select IdProducto, 101, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 102, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 103, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 104, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 105, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 106, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 107, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 108, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 109, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 110, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos;
insert into relProductoLocacion
select IdProducto, 111, PorcUtilidad, PrecioalCliente, 1, NOW(), NULL from catProductos; 
         
CREATE TABLE relProductoLocacion(
  IdProducto int(11) unsigned NOT NULL,
  IdLocacion int(11) unsigned NOT NULL,
  porcentaje float NOT NULL,
  precio float NOT NULL,
  activo tinyint(4) NOT NULL,
  fechaCreado timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  fechaBaja timestamp NULL,
  PRIMARY KEY (IdProducto, IdLocacion)
);
         */

        private void InicializarGridPrecios()
        {
            System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();

            l_cmd1.Connection = this.m_conn;
            this.m_conn.Open();

            System.Text.StringBuilder pctg = new System.Text.StringBuilder();
            System.Text.StringBuilder prc = new System.Text.StringBuilder();

            System.Collections.Generic.Dictionary<string, bool> permitirEdicion = new System.Collections.Generic.Dictionary<string, bool>();

            if (this.m_KeyRecord == -1)
            {
                l_cmd1.CommandText = "select cl.id, fl.editarPrecio from catLocacion cl inner join confLocacion fl on cl.id = fl.IdLocacion and cl.dtFechaBaja is null;";

                //this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();

                bool first = true;
                this.dataGridView2.Columns.Add("0", "-");
                while (l_reader1.Read())
                {
                    this.dataGridView2.Columns.Add(l_reader1.GetInt32(0).ToString(), l_reader1.GetInt32(0).ToString());
                    permitirEdicion.Add(l_reader1.GetInt32(0).ToString(), l_reader1.GetBoolean(1));

                    if (first)
                    {
                        first = false;
                        pctg.Append("%,");
                        prc.Append("$,");
                    }
                    else
                    {
                        pctg.Append(',');
                        prc.Append(',');
                    }

                    pctg.Append("0");
                    prc.Append("0");
                }

                l_reader1.Close();
            }
            else
            {
                l_cmd1.CommandText = "select r.IdLocacion, r.porcentaje, r.precio, fl.editarPrecio from relProductoLocacion r inner join confLocacion fl on r.IdLocacion = fl.IdLocacion where r.idProducto = " + this.m_KeyRecord.ToString() + ";";

                //this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();

                bool first = true;
                this.dataGridView2.Columns.Add("0", "-");
                while (l_reader1.Read())
                {
                    this.dataGridView2.Columns.Add(l_reader1.GetInt32(0).ToString(), l_reader1.GetInt32(0).ToString());
                    permitirEdicion.Add(l_reader1.GetInt32(0).ToString(), l_reader1.GetBoolean(3));

                    if (first)
                    {
                        first = false;
                        pctg.Append("%,");
                        prc.Append("$,");
                    }
                    else
                    {
                        pctg.Append(',');
                        prc.Append(',');
                    }

                    pctg.Append(l_reader1.GetFloat(1).ToString());

                    double tmp1 = Convert.ToDouble(l_reader1.GetFloat(2));
                    double tmp2 = (1.00 + Convert.ToDouble(this.txt_iva.Text) / 100.00);
                    double tmp3 = System.Math.Round(tmp1 * tmp2, 2);

                    prc.Append(tmp3.ToString());
                }

                l_reader1.Close();
            }

            this.dataGridView2.Rows.Add(pctg.ToString().Split(','));
            this.dataGridView2.Rows.Add(prc.ToString().Split(','));

            // Adjust columns size
            for (int i = 0; i < this.dataGridView2.Columns.Count; i++)
            {
                this.dataGridView2.Columns[i].Width = 55;
                if (permitirEdicion.ContainsKey(this.dataGridView2.Columns[i].HeaderText) && 
                    !permitirEdicion[this.dataGridView2.Columns[i].HeaderText])
                {
                    this.dataGridView2.Rows[0].Cells[i].Style.BackColor = System.Drawing.Color.LightGray;
                    this.dataGridView2.Rows[1].Cells[i].Style.BackColor = System.Drawing.Color.LightGray;
                }
            }

            this.m_conn.Close();
        }

        private void InicializarPrecioUnico()
        {
            if (this.m_KeyRecord == -1)
            {
                this.chkPrecioUnico.Checked = false;
                this.txtPrecioUnico.Text = "0.00";
                return;
            }

            System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();

            l_cmd1.Connection = this.m_conn;
            l_cmd1.CommandText = "select usarPrecioUnico, precioUnico from confProducto where idProducto = " + this.m_KeyRecord.ToString() + ";";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();

            if (l_reader1.Read())
            {
                this.chkPrecioUnico.Checked = l_reader1.GetBoolean(0);
                this.txtPrecioUnico.Text = l_reader1.GetFloat(1).ToString();
            }

            l_reader1.Close();
            this.m_conn.Close();
        }

        private void frm_productos_Load(object sender, System.EventArgs e)
        {

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            if (frm_Main.m_RunConfiguration != 1)
            {
                this.dataGridView2.Enabled = false;
                this.chkPrecioUnico.Enabled = false;
                this.txtPrecioUnico.Enabled = false;
            }
            else
            {
                InicializarGridPrecios();
                InicializarPrecioUnico();
            }

            this.m_conn.Open();

            this.m_select = new System.Data.Odbc.OdbcCommand();
            this.m_select.Connection = this.m_conn;

            if (frm_ProdPrin != null)
            {
                frm_ProdPrin.p_Result = 0;
                frm_ProdPrin.p_currentId = -1;
            }

            if (sl.Count == 0)
            {
                this.m_select.CommandText = "SELECT * FROM catFamilias order by codigo;";
                System.Data.Odbc.OdbcDataReader l_rdr = this.m_select.ExecuteReader();
                sl.Add("0", "No asignado");
                this.cmb_familia.Items.Add(sl["0"].ToString());
                while (l_rdr.Read())
                {
                    sl.Add(l_rdr["idFamilia"].ToString(), l_rdr["descripcion"].ToString());
                    this.cmb_familia.Items.Add(l_rdr["descripcion"].ToString());
                }
                l_rdr.Close();

            }

            if (this.m_KeyRecord != -1)
                this.m_select.CommandText = "Select * From catProductos where idproducto = " + this.m_KeyRecord.ToString() + ";";
            else
                this.m_select.CommandText = "Select * From catProductos where idproducto = 1;";

            this.m_da = new System.Data.Odbc.OdbcDataAdapter();
            this.m_da.SelectCommand = this.m_select;
            this.m_dataset = new System.Data.DataSet();
            this.m_da.Fill(this.m_dataset);

            if (this.m_KeyRecord == -1)
            {
                this.txt_reorden.Text = "0.0";
                this.txt_ptomax.Text = "0.0";
                this.txt_existencia.Text = "0.0";
                this.txtPorcIeps.Text = "0.0";
                this.txt_existencia.Enabled = false;
                this.FillDataGridViewAlmacenes();
                this.mp_Loading = false;
                return;
            }
            else
            {
                // Nov 27 2017 - centro de distribucion activa existencia
                if (frm_Main.m_RunConfiguration != 1)
                    this.txt_existencia.Enabled = false;
            }

            //this.cmd_Borrar.Visible = true; 
            this.FillData();

            if (this.m_conn.State == System.Data.ConnectionState.Open)
                this.m_conn.Close();

            //Oct 2017 : Sync version
            if (frm_Main.m_RunConfiguration != 1)
            {
                this.Enabled = false;
            }
            // Oct 2020 habilita edicion productos this.Enabled = true;
        }

        public string ListaProveedores(ref string strIDProvs)
        {
            string lRetVal = "";
            string lRetValIds = "";
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "select rpp.idProveedor, cp.Nombre from relProductoProveedor rpp  inner join catProveedores cp on rpp.IdProveedor = cp.IdProveedor where rpp.IdProducto = " + this.m_KeyRecord.ToString();

                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                while (lReader.Read())
                {
                    //this.lbProveedores.Items.Add(lReader["Nombre"]);
                    if (lRetVal == "")
                    {
                        lRetVal = lReader["Nombre"].ToString();
                        lRetValIds = lReader["idProveedor"].ToString();
                    }
                    else
                    {
                        lRetVal = lRetVal + " " + lReader["Nombre"].ToString();
                        lRetValIds = lRetValIds + " " + lReader["idProveedor"].ToString();
                    }
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == System.Data.ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
            strIDProvs = lRetValIds;
            return lRetVal;
        }


        private void FillData()
        {
            int idPadre = 0;
            string idProvs = "";
            this.mp_Loading = true;
            this.txt_codigo.Text = this.m_dataset.Tables[0].Rows[0]["Codigo"].ToString();
            this.txt_descripcion.Text = this.m_dataset.Tables[0].Rows[0]["Descripcion"].ToString();
            this.txt_existencia.Text = this.m_dataset.Tables[0].Rows[0]["Existencia"].ToString();
            this.txt_proveedor.Text = this.m_dataset.Tables[0].Rows[0]["PrecioProveedor"].ToString();
            this.txt_cliente.Text = this.m_dataset.Tables[0].Rows[0]["PrecioalCliente"].ToString();
            //this.txt_proveedores.Text = this.m_dataset.Tables[0].Rows[0]["Proveedores"].ToString();  
            this.txt_proveedores.Text = this.ListaProveedores(ref idProvs);
            this.lbl_IDs_Provs.Text = idProvs;
            this.txt_ubicacion.Text = this.m_dataset.Tables[0].Rows[0]["Ubicacion"].ToString();
            this.txt_unidadv.Text = this.m_dataset.Tables[0].Rows[0]["UnidadVenta"].ToString();
            this.txt_iva.Text = this.m_dataset.Tables[0].Rows[0]["iva"].ToString();
            //svm nov2009
            this.txt_codigoProd.Text = this.m_dataset.Tables[0].Rows[0]["Codigoprod"].ToString();
            this.txt_reorden.Text = this.m_dataset.Tables[0].Rows[0]["PtoReorden"].ToString();

            if (this.m_dataset.Tables[0].Rows[0]["PtoMaximo"].ToString() != "")
                this.txt_ptomax.Text = this.m_dataset.Tables[0].Rows[0]["PtoMaximo"].ToString();
            else
                this.txt_ptomax.Text = "0";

            //SVM Abr2015
            object obj1 = this.m_dataset.Tables[0].Rows[0]["porcieps"];
            if (obj1 == System.DBNull.Value)
            {
                this.chkIeps.Checked = false;
                this.txtPorcIeps.Text = "0.0";
                this.txtPrecioIeps.Text = this.txt_proveedor.Text;
            }
            else
            {
                Double pieps = Convert.ToDouble(obj1);
                this.chkIeps.Checked = (pieps > 0);
                this.txtPorcIeps.Text = Convert.ToString(pieps);
                this.txtPrecioIeps.Text = System.Math.Round(Convert.ToDouble(this.txt_proveedor.Text) * (1 + Convert.ToDouble(this.txtPorcIeps.Text) / 100), 2).ToString();
            }

            this.txt_utilidad.Text = this.m_dataset.Tables[0].Rows[0]["PorcUtilidad"].ToString();
            this.txt_marca.Text = this.m_dataset.Tables[0].Rows[0]["Marca"].ToString();
            this.txt_linea.Text = this.m_dataset.Tables[0].Rows[0]["Linea"].ToString();
            this.txt_observs.Text = this.m_dataset.Tables[0].Rows[0]["Observaciones"].ToString();
            if (this.m_dataset.Tables[0].Rows[0]["idFamilia"].ToString().Length > 0)
                if (IsNumeric(this.txt_cliente.Text) && IsNumeric(this.txt_iva.Text))
                {
                    double tmp1 = Convert.ToDouble(this.m_dataset.Tables[0].Rows[0]["PrecioAlCliente"]);
                    double tmp2 = (1.00 + Convert.ToDouble(this.txt_iva.Text) / 100.00);
                    double tmp3 = System.Math.Round(tmp1 * tmp2, 2);

                    this.txt_preciomasiva.Text = string.Format("{0}", tmp3);

                    //this.txt_preciomasiva.Text = System.Math.Round(Convert.ToDouble(this.m_dataset.Tables[0].Rows[0]["PrecioAlCliente"]) * (1 + Convert.ToDouble(this.txt_iva.Text) / 100), 2).ToString();

                    //this.txt_preciomasiva.Text = System.Math.Round(Convert.ToDouble(this.txtPrecioIeps.Text) * (1 + Convert.ToDouble(this.txt_iva.Text) / 100), 2).ToString();
                    //this.txt_preciomasiva.Text = System.Math.Round(Convert.ToDouble(this.txt_cliente.Text) * (1 + Convert.ToDouble(this.txt_iva.Text) / 100), 2).ToString();
                }
            if (IsNumeric(this.m_dataset.Tables[0].Rows[0]["idFamilia"].ToString()))
                idPadre = Convert.ToInt32(this.m_dataset.Tables[0].Rows[0]["idFamilia"].ToString());
            if (idPadre > 0)
            {
                if (sl.ContainsKey(idPadre.ToString()))
                    this.cmb_familia.Text = sl[idPadre.ToString()].ToString();
                else
                    this.cmb_familia.SelectedIndex = 0;
            }
            else
                this.cmb_familia.SelectedIndex = 0;

            if (this.txt_existencia.Text.Length == 0)
                this.txt_existencia.Text = "0";
            if (this.txt_iva.Text.Length == 0)
                this.txt_iva.Text = "0";
            if (this.txt_reorden.Text.Length == 0)
                this.txt_reorden.Text = "0";
            if (this.txt_utilidad.Text.Length == 0)
                this.txt_utilidad.Text = "0";

            this.label18.Text = "Ult. Mod. " + this.m_dataset.Tables[0].Rows[0]["dtRegModificado"].ToString() + " " + this.m_dataset.Tables[0].Rows[0]["UsuarioModif"].ToString();

            // svm may2012
            if (this.m_dataset.Tables[0].Rows[0]["empaque"].ToString() != "")
                this.txt_empaque.Text = this.m_dataset.Tables[0].Rows[0]["empaque"].ToString();
            else
                this.txt_empaque.Text = "0";
            // SVM jul2012
            if (!Double.TryParse(this.txt_proveedor.Text, out mp_precio_proveedor))
                mp_precio_proveedor = 0;
            if (!Double.TryParse(this.txt_preciomasiva.Text, out mp_preciomasiva))
                mp_preciomasiva = 0;

            this.FillDataGridViewAlmacenes();

            this.mp_Loading = false;
        }

        private void FillDataGridViewAlmacenes()
        {
            if (this.dsAlmacenes.Tables.Count <= 0)
            {
                // crea tabla temporal del grid
                this.dsAlmacenes.Tables.Add("Almacenes");
                this.dsAlmacenes.Tables[0].Columns.Add("idAlmacen");
                this.dsAlmacenes.Tables[0].Columns.Add("Almacen");
                this.dsAlmacenes.Tables[0].Columns.Add("Ubicacion");
                this.dsAlmacenes.Tables[0].Columns.Add("Minimo", Type.GetType("System.Double"));
                this.dsAlmacenes.Tables[0].Columns.Add("Maximo", Type.GetType("System.Double"));
                this.dsAlmacenes.Tables[0].Columns.Add("Existencia", Type.GetType("System.Double"));
            }
            else
            {
                this.dsAlmacenes.Tables[0].Rows.Clear();

            }

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            l_conn.ConnectionString = frm_Main.mps_strconnection;
            l_cmd.Connection = l_conn;
            try
            {
                l_conn.Open();

                if (slAlmacenes == null)
                {
                    //lee catalogo almacenes
                    slAlmacenes = new System.Collections.SortedList();
                    l_cmd.CommandText = "SELECT IdAlmacen, Descripcion FROM catAlmacenes where IdAlmacen = 1 or IdAlmacen = 2;";
                    System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                    while (l_rdr.Read())
                    {
                        slAlmacenes.Add(l_rdr["IdAlmacen"].ToString(), l_rdr["Descripcion"].ToString());
                    }
                    if (slAlmacenes.Count <= 0)
                    {
                        slAlmacenes.Add("0", "General");
                    }
                    l_rdr.Close();
                }

                SortedList slExistencias = new SortedList();
                object[] vals = new object[4];
                if (this.m_KeyRecord > 0)
                {
                    //carga datos del producto de existencias por almacen
                    l_cmd.CommandText = "SELECT * FROM catExistencias WHERE IdProducto=" + this.m_KeyRecord.ToString() + ";";
                    System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                    while (l_rdr.Read())
                    {
                        vals = new object[4];
                        vals[0] = l_rdr["Ubicacion"];
                        vals[1] = l_rdr["PtoReorden"];
                        vals[2] = l_rdr["PtoMaximo"];
                        vals[3] = l_rdr["Existencia"];
                        slExistencias.Add(l_rdr["IdAlmacen"].ToString(), vals);
                    }
                    l_rdr.Close();
                }

                //procede a llenar el dataset del grid
                foreach (string ky in slAlmacenes.Keys)
                {
                    System.Data.DataRow dr = this.dsAlmacenes.Tables[0].NewRow();
                    dr["idAlmacen"] = ky;
                    dr["Almacen"] = slAlmacenes[ky];
                    if (slExistencias.ContainsKey(ky))
                    {
                        //si encontro existencias
                        vals = (object[])slExistencias[ky];
                        dr["Ubicacion"] = vals[0].ToString();
                        dr["Minimo"] = Convert.ToDouble(vals[1]);
                        dr["Maximo"] = Convert.ToDouble(vals[2]);
                        dr["Existencia"] = Convert.ToDouble(vals[3]);
                    }
                    else
                    {
                        if (ky == "0")
                        {
                            //solo es "0" cuando no es multialmancen
                            dr["Ubicacion"] = this.txt_ubicacion.Text;
                            dr["Minimo"] = Convert.ToDouble(this.txt_reorden.Text);
                            dr["Maximo"] = Convert.ToDouble(this.txt_ptomax.Text);
                            dr["Existencia"] = Convert.ToDouble(this.txt_existencia.Text);
                        }
                        else
                        {
                            //no existe registro de existencias en el almacen, carga valores vacios
                            dr["Ubicacion"] = "";
                            dr["Minimo"] = 0.0;
                            dr["Maximo"] = 0.0;
                            dr["Existencia"] = 0.0;
                        }
                    }
                    this.dsAlmacenes.Tables[0].Rows.Add(dr);
                }

                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }

            this.dataGridView1.DataSource = this.dsAlmacenes.Tables[0];
            this.dataGridView1.Columns[0].Visible = false;
            this.dataGridView1.Columns[1].Width = 140;
            this.dataGridView1.Columns[1].ReadOnly = true;
            this.dataGridView1.Columns[2].Width = 200;
            this.dataGridView1.Columns[3].Width = 80;
            this.dataGridView1.Columns[4].Width = 80;
            this.dataGridView1.Columns[5].Width = 80;
            this.dataGridView1.Columns[3].DefaultCellStyle.Format = "#####0.00";
            this.dataGridView1.Columns[4].DefaultCellStyle.Format = "#####0.00";
            this.dataGridView1.Columns[5].DefaultCellStyle.Format = "#####0.00";
            this.dataGridView1.Columns[5].ReadOnly = (this.m_KeyRecord > 0);
        }


        private void cmd_cerrar_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void cmd_save_Click(object sender, System.EventArgs e)
        {
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction l_trans = null;

            int idPadre = 0;
            int l_KeyRecord = this.m_KeyRecord;
            Boolean ok = true;

            if (this.dsAlmacenes.Tables[0].Rows.Count == 0)
            {
                MessageBox.Show("Es necesario capturar la existencia", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //validaciones
            if (sl.ContainsValue(this.cmb_familia.Text))
                idPadre = Convert.ToInt32(sl.GetKey(sl.IndexOfValue(this.cmb_familia.Text)));

            if (this.txt_codigo.Text.Trim() == "" || this.txt_descripcion.Text.Trim() == "" || this.txt_proveedor.Text.Trim() == "" || this.txt_cliente.Text.Trim() == "" || this.txt_codigoProd.Text.Trim() == "")
            {
                if (this.m_KeyRecord != -1)
                    MessageBox.Show("Debe capturar el c�digo, c�digo barras, la descripci�n y los precios del producto. NO SE HA ACTUALIZADO EL REGISTRO.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Debe capturar el c�digo, c�digo barras, la descripci�n y los precios del producto. NO SE HA AGREGADO EL REGISTRO.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!IsNumeric(this.txt_existencia.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_existencia.Focus();
                return;
            }

            if (!IsNumeric(this.txt_proveedor.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_proveedor.Focus();
                return;
            }
            if (!IsNumeric(this.txt_iva.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_iva.Focus();
                return;
            }
            if (!IsNumeric(this.txt_utilidad.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_utilidad.Focus();
                return;
            }
            if (!IsNumeric(this.txt_empaque.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_empaque.Focus();
                return;
            }

            if (!IsNumeric(this.txtPorcIeps.Text))
            {
                this.txtPorcIeps.Text = "0.0";
            }

            bool itIsANewRecord = (this.m_KeyRecord == -1 ? true : false);
            try
            {
                if (this.m_conn.State != System.Data.ConnectionState.Open)
                    this.m_conn.Open();
                l_trans = this.m_conn.BeginTransaction();
                l_update.Connection = this.m_conn;
                l_update.Transaction = l_trans;

                System.Data.DataRow rw = this.dsAlmacenes.Tables[0].Rows[0];
                this.txt_ubicacion.Text = rw[2].ToString();
                this.txt_reorden.Text = rw[3].ToString();
                this.txt_ptomax.Text = rw[4].ToString();

                Double pieps = Convert.ToDouble(this.txtPorcIeps.Text);
                // salvar el maestro de articulos
                if (this.m_KeyRecord != -1)
                {
                    //actualizar
                    l_update.CommandText = "UPDATE catProductos SET CodigoProd=?,Codigo=?," +
                        "Descripcion=?,Existencia=?,PtoReorden=?," +
                        "PrecioProveedor=?,iva=?,PorcUtilidad=?," +
                        "PrecioalCliente=?,Ubicacion=?,UnidadVenta=?," +
                        "Marca=?,Linea=?,Proveedores=?,Observaciones=?,idFamilia=?,dtRegModificado = ?,PtoMaximo = ?,empaque = ?,UsuarioModif = ? " +
                        ",ieps=?,porcieps=? " +
                        "WHERE IdProducto=?;";

                    l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                    l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                    l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);
                    l_update.Parameters.AddWithValue("@Existencia", this.txt_existencia.Text);
                    l_update.Parameters.AddWithValue("@PtoReorden", this.txt_reorden.Text);
                    l_update.Parameters.AddWithValue("@PrecioProveedor", this.txt_proveedor.Text);
                    l_update.Parameters.AddWithValue("@iva", this.txt_iva.Text);
                    l_update.Parameters.AddWithValue("@PorcUtilidad", this.txt_utilidad.Text);
                    l_update.Parameters.AddWithValue("@PrecioalCliente", this.txt_cliente.Text);
                    l_update.Parameters.AddWithValue("@Ubicacion", this.txt_ubicacion.Text);
                    l_update.Parameters.AddWithValue("@UnidadVenta", this.txt_unidadv.Text);
                    l_update.Parameters.AddWithValue("@Marca", this.txt_marca.Text);
                    l_update.Parameters.AddWithValue("@Linea", this.txt_linea.Text);
                    l_update.Parameters.AddWithValue("@Proveedores", this.lbl_IDs_Provs.Text);  // this.txt_proveedores.Text);
                    l_update.Parameters.AddWithValue("@Observaciones", this.txt_observs.Text);
                    l_update.Parameters.AddWithValue("@idFamilia", idPadre.ToString());
                    l_update.Parameters.AddWithValue("@dtRegModificado", DateTime.Now);
                    l_update.Parameters.AddWithValue("@PtoMaximo", this.txt_ptomax.Text);
                    l_update.Parameters.AddWithValue("@empaque", this.txt_empaque.Text);
                    l_update.Parameters.AddWithValue("@UsuarioModif", frm_Main.mps_usuario);

                    l_update.Parameters.AddWithValue("@ieps", (pieps > 0));
                    l_update.Parameters.AddWithValue("@porcieps", pieps);

                    l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord.ToString());

                    l_update.ExecuteNonQuery();

                    this.m_IsModified = false;

                    if (frm_ProdPrin != null)
                    {
                        frm_ProdPrin.p_Result = 1;
                        frm_ProdPrin.p_currentId = this.m_KeyRecord;
                    }

                }
                else
                {
                    //agregar
                    l_update.CommandText = "INSERT INTO catProductos(CodigoProd,Codigo,Descripcion,Existencia,PtoReorden,PrecioProveedor," +
                        "iva,PorcUtilidad,PrecioalCliente,Ubicacion,UnidadVenta,Marca,Linea,Proveedores,Observaciones,idFamilia,dtRegModificado,PtoMaximo,empaque,UsuarioModif,ieps,porcieps) " +
                        "VALUES (?,?,?,?,?,?," +
                        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                    l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                    l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                    l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);
                    l_update.Parameters.AddWithValue("@Existencia", this.txt_existencia.Text);
                    l_update.Parameters.AddWithValue("@PtoReorden", this.txt_reorden.Text);
                    l_update.Parameters.AddWithValue("@PrecioProveedor", this.txt_proveedor.Text);
                    l_update.Parameters.AddWithValue("@iva", this.txt_iva.Text);
                    l_update.Parameters.AddWithValue("@PorcUtilidad", this.txt_utilidad.Text);
                    l_update.Parameters.AddWithValue("@PrecioalCliente", this.txt_cliente.Text);
                    l_update.Parameters.AddWithValue("@Ubicacion", this.txt_ubicacion.Text);
                    l_update.Parameters.AddWithValue("@UnidadVenta", this.txt_unidadv.Text);
                    l_update.Parameters.AddWithValue("@Marca", this.txt_marca.Text);
                    l_update.Parameters.AddWithValue("@Linea", this.txt_linea.Text);
                    l_update.Parameters.AddWithValue("@Proveedores", this.lbl_IDs_Provs.Text);  // this.txt_proveedores.Text);
                    l_update.Parameters.AddWithValue("@Observaciones", this.txt_observs.Text);
                    l_update.Parameters.AddWithValue("@idFamilia", idPadre);
                    l_update.Parameters.AddWithValue("@dtRegModificado", DateTime.Now);
                    l_update.Parameters.AddWithValue("@PtoMaximo", this.txt_ptomax.Text);
                    l_update.Parameters.AddWithValue("@empaque", this.txt_empaque.Text);
                    l_update.Parameters.AddWithValue("@UsuarioModif", frm_Main.mps_usuario);

                    l_update.Parameters.AddWithValue("@ieps", (pieps > 0));
                    l_update.Parameters.AddWithValue("@porcieps", pieps);

                    l_update.ExecuteNonQuery();

                    //Almacenar la entrada
                    l_update.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,clogin,entrada,observaciones,idAlmacen) VALUES(?,?,?,?,?,?,?,?);";

                    l_update.Parameters.Clear();
                    l_update.Parameters.AddWithValue("@ccodigo", this.txt_codigo.Text);
                    l_update.Parameters.AddWithValue("@dtfecha", Convert.ToDateTime(System.DateTime.Now.ToString()));
                    l_update.Parameters.AddWithValue("@cdescripcion", this.txt_descripcion.Text);
                    l_update.Parameters.AddWithValue("@icantidad", this.txt_existencia.Text);
                    l_update.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                    l_update.Parameters.AddWithValue("@entrada", 1);
                    l_update.Parameters.AddWithValue("@observaciones", "");
                    l_update.Parameters.AddWithValue("@idAlmacen", frm_Main.mp_idAlmacen);
                    l_update.ExecuteNonQuery();

                    this.m_IsModified = false;

                    if (frm_ProdPrin != null)
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "SELECT IdProducto from catProductos WHERE CodigoProd=? AND Codigo=? AND Descripcion=?;";
                        l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                        l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                        l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);

                        frm_ProdPrin.p_Result = 1;
                        frm_ProdPrin.p_currentId = (Int32)l_update.ExecuteScalar();
                        this.m_KeyRecord = frm_ProdPrin.p_currentId;
                    }

                }

                if (frm_Main.m_RunConfiguration != 1)
                {
                    // Nothing to do here....
                }
                else
                {
                    guardarPrecios(itIsANewRecord, ref l_trans);
                    guardarPrecioUnico(itIsANewRecord, ref l_trans);
                }

                //actualizar existencias x almacen
                object idprod;
                foreach (System.Data.DataRow row in this.dsAlmacenes.Tables[0].Rows)
                {
                    idprod = null;
                    if (l_KeyRecord != -1)
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "SELECT IdProducto from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                        l_update.Parameters.AddWithValue("@IdProducto", l_KeyRecord);
                        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                        idprod = l_update.ExecuteScalar();
                    }
                    if (idprod == null)
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "INSERT INTO catExistencias (IdProducto,idAlmacen,Existencia,Ubicacion,PtoReorden,PtoMaximo) VALUES (?,?,?,?,?,?);";
                        l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord);
                        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                        l_update.Parameters.AddWithValue("@Existencia", row[5]);
                        l_update.Parameters.AddWithValue("@Ubicacion", row[2]);
                        l_update.Parameters.AddWithValue("@PtoReorden", row[3]);
                        l_update.Parameters.AddWithValue("@PtoMaximo", row[4]);
                    }
                    else
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "UPDATE catExistencias SET Ubicacion=?,PtoReorden=?,PtoMaximo=? WHERE IdProducto=? AND idAlmacen=?;";
                        l_update.Parameters.AddWithValue("@Ubicacion", row[2]);
                        l_update.Parameters.AddWithValue("@PtoReorden", row[3]);
                        l_update.Parameters.AddWithValue("@PtoMaximo", row[4]);
                        l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord);
                        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                    }
                    l_update.ExecuteNonQuery();
                }

                // SVM jul2012  checa si debe guardar historicos
                string mess = "";

                string observs = "";
                if (l_KeyRecord != -1)
                {
                    if (this.mp_precio_proveedor != Convert.ToDouble(this.txt_proveedor.Text))
                        mess = "Precio Proveedor";
                    if (this.mp_preciomasiva != Convert.ToDouble(this.txt_preciomasiva.Text))
                    {
                        if (mess.Length > 0)
                            mess += ", ";
                        mess += "Precio al cliente";
                    }
                    if (mess.Length > 0)
                    {
                        // si no es nuevo y hubo cambios pide observaciones
                        frm_historico frmHist = new frm_historico();
                        frmHist.lbl_table.Text = "Catalogo de Productos";
                        frmHist.lbl_cambios.Text = mess;
                        frmHist.ShowDialog(this);
                        observs = frm_historico.observs;
                    }
                }
                else
                {
                    observs = "NVO REC";
                }
                mess = "";
                if (ok && ((this.mp_precio_proveedor != Convert.ToDouble(this.txt_proveedor.Text)) || (l_KeyRecord == -1)))
                {
                    ok = Save_Historico_Prod(this.m_KeyRecord, "PRECPRV", Convert.ToDouble(this.txt_proveedor.Text), this.mp_precio_proveedor, observs, this.m_conn, l_trans, out mess);
                }

                if (ok && ((this.mp_preciomasiva != Convert.ToDouble(this.txt_preciomasiva.Text)) || (l_KeyRecord == -1)))
                {
                    ok = Save_Historico_Prod(this.m_KeyRecord, "PRECCLI", Convert.ToDouble(this.txt_preciomasiva.Text), this.mp_preciomasiva, observs, this.m_conn, l_trans, out mess);
                }

                if (ok)
                {
                    l_trans.Commit();

                    if (!string.IsNullOrEmpty(EasyInvoice.frm_Main.mps_strconnectionRepl) && l_KeyRecord <= 0)
                    {
                        if (this.m_KeyRecord <= 0)
                        {
                            l_update.Parameters.Clear();
                            l_update.CommandText = "SELECT IdProducto from catProductos WHERE CodigoProd=? AND Codigo=? AND Descripcion=?;";
                            l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                            l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                            l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);

                            this.m_KeyRecord = (Int32)l_update.ExecuteScalar();
                        }
                        this.SaveProductoReplica();
                    }
                }
                else
                {
                    MessageBox.Show("Error al guardar historico. " + mess, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
                if (ok)
                    this.Close();
            }

        }

        private void SaveProductoReplica()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction l_trans = null;
            l_conn.ConnectionString = EasyInvoice.frm_Main.mps_strconnectionRepl;

            int idPadre = 0;
            int m_keyrecord = -1;
            Boolean ok = true;

            if (slAlmacenesRepl == null)
                this.FillAlmacenesReplica();

            //validaciones
            if (sl.ContainsValue(this.cmb_familia.Text))
                idPadre = Convert.ToInt32(sl.GetKey(sl.IndexOfValue(this.cmb_familia.Text)));

            try
            {
                if (l_conn.State != System.Data.ConnectionState.Open)
                    l_conn.Open();
                l_update.Connection = l_conn;

                l_update.CommandText = "SELECT idProducto FROM catProductos WHERE idProducto=?;";
                l_update.Parameters.AddWithValue("@idProducto", this.m_KeyRecord);
                object obj = l_update.ExecuteScalar();
                if (obj == null)
                    m_keyrecord = -1;
                else
                    m_keyrecord = Convert.ToInt32(obj);

                // salvar el maestro de articulos
                if (m_keyrecord != -1)
                {
                    //////actualizar
                    ////l_update.CommandText = "UPDATE catProductos SET CodigoProd=?,Codigo=?," +
                    ////    "Descripcion=?,PtoReorden=?," +
                    ////    "PrecioProveedor=?,iva=?,PorcUtilidad=?," +
                    ////    "PrecioalCliente=?,Ubicacion=?,UnidadVenta=?," +
                    ////    "Marca=?,Linea=?,Proveedores=?,Observaciones=?,idFamilia=?,dtRegModificado = ?,PtoMaximo = ?,empaque = ?,UsuarioModif = ? " +
                    ////    "WHERE IdProducto=?;";

                    ////l_update.Parameters.Clear();
                    ////l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                    ////l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                    ////l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);
                    //////l_update.Parameters.AddWithValue("@Existencia", this.txt_existencia.Text);
                    ////l_update.Parameters.AddWithValue("@PtoReorden", this.txt_reorden.Text);
                    ////l_update.Parameters.AddWithValue("@PrecioProveedor", this.txt_proveedor.Text);
                    ////l_update.Parameters.AddWithValue("@iva", this.txt_iva.Text);
                    ////l_update.Parameters.AddWithValue("@PorcUtilidad", this.txt_utilidad.Text);
                    ////l_update.Parameters.AddWithValue("@PrecioalCliente", this.txt_cliente.Text);
                    ////l_update.Parameters.AddWithValue("@Ubicacion", this.txt_ubicacion.Text);
                    ////l_update.Parameters.AddWithValue("@UnidadVenta", this.txt_unidadv.Text);
                    ////l_update.Parameters.AddWithValue("@Marca", this.txt_marca.Text);
                    ////l_update.Parameters.AddWithValue("@Linea", this.txt_linea.Text);
                    ////l_update.Parameters.AddWithValue("@Proveedores", this.lbl_IDs_Provs.Text);  // this.txt_proveedores.Text);
                    ////l_update.Parameters.AddWithValue("@Observaciones", this.txt_observs.Text);
                    ////l_update.Parameters.AddWithValue("@idFamilia", idPadre.ToString());
                    ////l_update.Parameters.AddWithValue("@dtRegModificado", DateTime.Now);
                    ////l_update.Parameters.AddWithValue("@PtoMaximo", this.txt_ptomax.Text);
                    ////l_update.Parameters.AddWithValue("@empaque", this.txt_empaque.Text);
                    ////l_update.Parameters.AddWithValue("@UsuarioModif", frm_Main.mps_usuario);

                    ////l_update.Parameters.AddWithValue("@IdProducto", m_keyrecord.ToString());

                    ////l_update.ExecuteNonQuery();

                }
                else
                {
                    l_trans = l_conn.BeginTransaction();
                    l_update.Transaction = l_trans;

                    //agregar
                    l_update.CommandText = "INSERT INTO catProductos(idProducto,CodigoProd,Codigo,Descripcion,Existencia,PtoReorden,PrecioProveedor," +
                        "iva,PorcUtilidad,PrecioalCliente,Ubicacion,UnidadVenta,Marca,Linea,Proveedores,Observaciones,idFamilia,dtRegModificado,PtoMaximo,empaque,UsuarioModif,ieps,porcieps) " +
                        "VALUES (?,?,?,?,?,?,?," +
                        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                    l_update.Parameters.Clear();
                    l_update.Parameters.AddWithValue("@idProducto", this.m_KeyRecord);
                    l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                    l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                    l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);
                    //l_update.Parameters.AddWithValue("@Existencia", this.txt_existencia.Text);
                    l_update.Parameters.AddWithValue("@Existencia", 0);
                    l_update.Parameters.AddWithValue("@PtoReorden", this.txt_reorden.Text);
                    l_update.Parameters.AddWithValue("@PrecioProveedor", this.txt_proveedor.Text);
                    l_update.Parameters.AddWithValue("@iva", this.txt_iva.Text);
                    l_update.Parameters.AddWithValue("@PorcUtilidad", this.txt_utilidad.Text);
                    l_update.Parameters.AddWithValue("@PrecioalCliente", this.txt_cliente.Text);
                    l_update.Parameters.AddWithValue("@Ubicacion", this.txt_ubicacion.Text);
                    l_update.Parameters.AddWithValue("@UnidadVenta", this.txt_unidadv.Text);
                    l_update.Parameters.AddWithValue("@Marca", this.txt_marca.Text);
                    l_update.Parameters.AddWithValue("@Linea", this.txt_linea.Text);
                    l_update.Parameters.AddWithValue("@Proveedores", this.lbl_IDs_Provs.Text);  // this.txt_proveedores.Text);
                    l_update.Parameters.AddWithValue("@Observaciones", this.txt_observs.Text);
                    l_update.Parameters.AddWithValue("@idFamilia", idPadre);
                    l_update.Parameters.AddWithValue("@dtRegModificado", DateTime.Now);
                    l_update.Parameters.AddWithValue("@PtoMaximo", this.txt_ptomax.Text);
                    l_update.Parameters.AddWithValue("@empaque", this.txt_empaque.Text);
                    l_update.Parameters.AddWithValue("@UsuarioModif", frm_Main.mps_usuario);

                    Double pieps = 0;
                    Double.TryParse(this.txtPorcIeps.Text, out pieps);
                    l_update.Parameters.AddWithValue("@ieps", (pieps > 0));
                    l_update.Parameters.AddWithValue("@porcieps", pieps);

                    l_update.ExecuteNonQuery();

                    foreach (String ky in slAlmacenesRepl.Keys)
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "INSERT INTO catExistencias (IdProducto,idAlmacen,Existencia,Ubicacion,PtoReorden,PtoMaximo) VALUES (?,?,?,?,?,?);";
                        l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord);
                        l_update.Parameters.AddWithValue("@IdAlmacen", ky);
                        l_update.Parameters.AddWithValue("@Existencia", 0);
                        l_update.Parameters.AddWithValue("@Ubicacion", "");
                        l_update.Parameters.AddWithValue("@PtoReorden", 0);
                        l_update.Parameters.AddWithValue("@PtoMaximo", 0);
                        l_update.ExecuteNonQuery();
                    }
                    l_trans.Commit();

                    ////Almacenar la entrada
                    //l_update.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,clogin,entrada,observaciones,idAlmacen) VALUES(?,?,?,?,?,?,?,?);";

                    //l_update.Parameters.Clear();
                    //l_update.Parameters.AddWithValue("@ccodigo", this.txt_codigo.Text);
                    //l_update.Parameters.AddWithValue("@dtfecha", Convert.ToDateTime(System.DateTime.Now.ToString()));
                    //l_update.Parameters.AddWithValue("@cdescripcion", this.txt_descripcion.Text);
                    //l_update.Parameters.AddWithValue("@icantidad", this.txt_existencia.Text);
                    //l_update.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                    //l_update.Parameters.AddWithValue("@entrada", 1);
                    //l_update.Parameters.AddWithValue("@observaciones", "");
                    //l_update.Parameters.AddWithValue("@idAlmacen", frm_Main.mp_idAlmacen);
                    //l_update.ExecuteNonQuery();

                    //this.m_IsModified = false;

                    //if (frm_ProdPrin != null)
                    //{
                    //    l_update.Parameters.Clear();
                    //    l_update.CommandText = "SELECT IdProducto from catProductos WHERE CodigoProd=? AND Codigo=? AND Descripcion=?;";
                    //    l_update.Parameters.AddWithValue("@CodigoProd", this.txt_codigoProd.Text);
                    //    l_update.Parameters.AddWithValue("@Codigo", this.txt_codigo.Text);
                    //    l_update.Parameters.AddWithValue("@Descripcion", this.txt_descripcion.Text);

                    //    frm_ProdPrin.p_Result = 1;
                    //    frm_ProdPrin.p_currentId = (Int32)l_update.ExecuteScalar();
                    //    this.m_KeyRecord = frm_ProdPrin.p_currentId;
                    //}

                }

                ////actualizar existencias x almacen
                //object idprod;
                //foreach (System.Data.DataRow row in this.dsAlmacenes.Tables[0].Rows)
                //{
                //    idprod = null;
                //    if (l_KeyRecord != -1)
                //    {
                //        l_update.Parameters.Clear();
                //        l_update.CommandText = "SELECT IdProducto from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                //        l_update.Parameters.AddWithValue("@IdProducto", l_KeyRecord);
                //        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                //        idprod = l_update.ExecuteScalar();
                //    }
                //    if (idprod == null)
                //    {
                //        l_update.Parameters.Clear();
                //        l_update.CommandText = "INSERT INTO catExistencias (IdProducto,idAlmacen,Existencia,Ubicacion,PtoReorden,PtoMaximo) VALUES (?,?,?,?,?,?);";
                //        l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord);
                //        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                //        l_update.Parameters.AddWithValue("@Existencia", row[5]);
                //        l_update.Parameters.AddWithValue("@Ubicacion", row[2]);
                //        l_update.Parameters.AddWithValue("@PtoReorden", row[3]);
                //        l_update.Parameters.AddWithValue("@PtoMaximo", row[4]);
                //    }
                //    else
                //    {
                //        l_update.Parameters.Clear();
                //        l_update.CommandText = "UPDATE catExistencias SET Ubicacion=?,PtoReorden=?,PtoMaximo=? WHERE IdProducto=? AND idAlmacen=?;";
                //        l_update.Parameters.AddWithValue("@Ubicacion", row[2]);
                //        l_update.Parameters.AddWithValue("@PtoReorden", row[3]);
                //        l_update.Parameters.AddWithValue("@PtoMaximo", row[4]);
                //        l_update.Parameters.AddWithValue("@IdProducto", this.m_KeyRecord);
                //        l_update.Parameters.AddWithValue("@IdAlmacen", row[0]);
                //    }
                //    l_update.ExecuteNonQuery();
                //}

                //// SVM jul2012  checa si debe guardar historicos
                //string mess = "";

                //string observs = "";
                //if (l_KeyRecord != -1)
                //{
                //    if (this.mp_precio_proveedor != Convert.ToDouble(this.txt_proveedor.Text))
                //        mess = "Precio Proveedor";
                //    if (this.mp_preciomasiva != Convert.ToDouble(this.txt_preciomasiva.Text))
                //    {
                //        if (mess.Length > 0)
                //            mess += ", ";
                //        mess += "Precio al cliente";
                //    }
                //    if (mess.Length > 0)
                //    {
                //        // si no es nuevo y hubo cambios pide observaciones
                //        frm_historico frmHist = new frm_historico();
                //        frmHist.lbl_table.Text = "Catalogo de Productos";
                //        frmHist.lbl_cambios.Text = mess;
                //        frmHist.ShowDialog(this);
                //        observs = frm_historico.observs;
                //    }
                //}
                //else
                //{
                //    observs = "NVO REC";
                //}
                //mess = "";
                //if (ok && ((this.mp_precio_proveedor != Convert.ToDouble(this.txt_proveedor.Text)) || (l_KeyRecord == -1)))
                //{
                //    ok = Save_Historico_Prod(this.m_KeyRecord, "PRECPRV", Convert.ToDouble(this.txt_proveedor.Text), this.mp_precio_proveedor, observs, this.m_conn, l_trans, out mess);
                //}

                //if (ok && ((this.mp_preciomasiva != Convert.ToDouble(this.txt_preciomasiva.Text)) || (l_KeyRecord == -1)))
                //{
                //    ok = Save_Historico_Prod(this.m_KeyRecord, "PRECCLI", Convert.ToDouble(this.txt_preciomasiva.Text), this.mp_preciomasiva, observs, this.m_conn, l_trans, out mess);
                //}

                //if (ok)
                //    l_trans.Commit();
                //else
                //    MessageBox.Show("Error al guardar historico repl. " + mess, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro  repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();

                l_conn.Dispose();
                l_conn = null;
            }

        }

        private void FillAlmacenesReplica()
        {
            if (slAlmacenesRepl != null)
                return;

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            l_conn.ConnectionString = EasyInvoice.frm_Main.mps_strconnectionRepl;
            l_cmd.Connection = l_conn;
            try
            {
                l_conn.Open();

                if (slAlmacenesRepl == null)
                {
                    //lee catalogo almacenes
                    slAlmacenesRepl = new System.Collections.SortedList();
                    l_cmd.CommandText = "SELECT IdAlmacen, Descripcion FROM catAlmacenes;";
                    System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                    while (l_rdr.Read())
                    {
                        slAlmacenesRepl.Add(l_rdr["IdAlmacen"].ToString(), l_rdr["Descripcion"].ToString());
                    }
                    //if (slAlmacenesRepl.Count <= 0)
                    //{
                    //    slAlmacenesRepl.Add("0", "General");
                    //}
                    l_rdr.Close();
                }


                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }

        }



        public static Boolean Save_Existencias_Almacen(string ccodigo, decimal cantidad, System.Data.Odbc.OdbcConnection p_conn, out string errMess)
        {
            return frm_productos.Save_Existencias_Almacen(ccodigo, cantidad, p_conn, null, out errMess);
        }

        public static Boolean Save_Existencias_Almacen(string ccodigo, decimal cantidad, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, out string errMess)
        {
            // obtiene el id del producto
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            object id = null;
            int idProducto;
            errMess = "";
            try
            {
                if (p_conn.State != System.Data.ConnectionState.Open)
                    p_conn.Open();

                l_update.Connection = p_conn;
                if (p_trans != null)
                    l_update.Transaction = p_trans;

                l_update.CommandText = "SELECT IdProducto from catProductos WHERE codigo=?;";
                l_update.Parameters.AddWithValue("@codigo", ccodigo);
                id = l_update.ExecuteScalar();
            }
            catch (System.Exception ex)
            {
                if (p_trans != null)
                    p_trans.Rollback();
                errMess = ex.Message;
            }

            if (id != null)
            {
                idProducto = (int)id;
                return frm_productos.Save_Existencias_Almacen(idProducto, cantidad, p_conn, p_trans, out errMess);
            }
            else
            {
                return false;
            }
        }

        public static Boolean Save_Existencias_Almacen(int idProducto, decimal cantidad, System.Data.Odbc.OdbcConnection p_conn, out string errMess)
        {
            return frm_productos.Save_Existencias_Almacen(idProducto, cantidad, p_conn, null, out errMess);
        }

        public static Boolean Save_Existencias_Almacen(int idProducto, decimal cantidad, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, out string errMess)
        {
            return frm_productos.Save_Existencias_Almacen(frm_Main.mp_idAlmacen, idProducto, cantidad, p_conn, p_trans, out errMess);
        }

        public static Boolean Save_Existencias_Almacen(int idAlmacen, int idProducto, decimal cantidad, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, out string errMess)
        {
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            Boolean ok = false;
            object existen;
            errMess = "";
            try
            {
                if (p_conn.State != System.Data.ConnectionState.Open)
                    p_conn.Open();

                l_update.Connection = p_conn;
                l_update.CommandTimeout = 300;
                if (p_trans != null)
                    l_update.Transaction = p_trans;

                existen = null;

                l_update.CommandText = "SELECT Existencia from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                l_update.Parameters.AddWithValue("@IdProducto", idProducto);
                l_update.Parameters.AddWithValue("@IdAlmacen", idAlmacen);
                existen = l_update.ExecuteScalar();

                if (existen == null)
                {
                    l_update.Parameters.Clear();
                    l_update.CommandText = "INSERT INTO catExistencias (IdProducto,idAlmacen,Existencia,Ubicacion,PtoReorden,PtoMaximo) VALUES (?,?,?,?,?,?);";
                    l_update.Parameters.AddWithValue("@IdProducto", idProducto);
                    l_update.Parameters.AddWithValue("@IdAlmacen", idAlmacen);
                    l_update.Parameters.AddWithValue("@Existencia", cantidad);
                    l_update.Parameters.AddWithValue("@Ubicacion", "");
                    l_update.Parameters.AddWithValue("@PtoReorden", 0.0);
                    l_update.Parameters.AddWithValue("@PtoMaximo", 0.0);
                }
                else
                {
                    l_update.Parameters.Clear();
                    l_update.CommandText = "UPDATE catExistencias SET Existencia=Existencia+? WHERE IdProducto=? AND idAlmacen=?;";
                    l_update.Parameters.AddWithValue("@Existencia", cantidad);
                    l_update.Parameters.AddWithValue("@IdProducto", idProducto);
                    l_update.Parameters.AddWithValue("@IdAlmacen", idAlmacen);
                }
                l_update.ExecuteNonQuery();
                ok = true;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                if (p_trans != null)
                    p_trans.Rollback();
                errMess = ex.Message;
            }
            catch (System.Exception ex)
            {
                ok = false;
                if (p_trans != null)
                    p_trans.Rollback();
                errMess = ex.Message;
            }
            finally
            {
            }
            return ok;
        }

        public static Boolean Save_Historico_Prod(int idProducto, string Tipo, object nuevo_valor, object antiguo_valor, string Observs, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, out string errMess)
        {
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            Boolean ok = false;
            errMess = "";
            try
            {
                if (p_conn.State != System.Data.ConnectionState.Open)
                    p_conn.Open();

                l_update.Connection = p_conn;
                if (p_trans != null)
                    l_update.Transaction = p_trans;

                l_update.Parameters.Clear();
                l_update.CommandText = "INSERT INTO catHistorico (Tabla, Id, Tipo, NvoValor, AntValor, Observaciones,dtRegModificado,UsuarioModif) VALUES (?,?,?,?,?,?,?,?);";
                l_update.Parameters.AddWithValue("@Tabla", "catproductos");
                l_update.Parameters.AddWithValue("@Id", idProducto);
                l_update.Parameters.AddWithValue("@Tipo", Tipo);
                l_update.Parameters.AddWithValue("@NvoValor", nuevo_valor);
                l_update.Parameters.AddWithValue("@AntValor", antiguo_valor);
                l_update.Parameters.AddWithValue("@Observaciones", Observs);
                l_update.Parameters.AddWithValue("@dtRegModificado", System.DateTime.Now);
                l_update.Parameters.AddWithValue("@UsuarioModif", frm_Main.mps_usuario);
                l_update.ExecuteNonQuery();
                ok = true;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                if (p_trans != null)
                    p_trans.Rollback();
                errMess = ex.Message;
            }
            catch (System.Exception ex)
            {
                ok = false;
                if (p_trans != null)
                    p_trans.Rollback();
                errMess = ex.Message;
            }
            finally
            {
            }
            return ok;
        }

        public static bool IsNumeric(String str)
        {
            if (str == null)
                return false;
            if (str.Length == 0)
                return false;
            try
            {
                double x = Convert.ToDouble(str);
                return true;
            }
            catch
            {
                return false;
            }

        }

        private void cmd_Borrar_Click(object sender, System.EventArgs e)
        {
            /*
            System.Data.Odbc.OdbcCommand l_delete = new System.Data.Odbc.OdbcCommand();

			if( MessageBox.Show("Esta a punto de eliminar este registro �Confirma que desea continuar?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;
			
            try
            {
            	this.m_conn.Open();
            	
				l_delete.Connection = this.m_conn;
				l_delete.CommandText = "delete from catProductos where idProducto = ?;";
				l_delete.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@idProducto",this.m_KeyRecord )  );           
				
				l_delete.ExecuteNonQuery();

                this.m_IsModified = false;
                if(frm_ProdPrin != null)
                {
                    frm_ProdPrin.p_Result = 1;
                    frm_ProdPrin.p_currentId = -1;
                }

				this.Close(); 
            }
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}            
				*/

        }

        private void frm_Clientes_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    this.cmd_save_Click(sender, e);
                    break;
                case Keys.Escape:
                    if (this.Enabled)
                    {
                        if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            this.Close();
                    }
                    else
                    {
                        this.Close();
                    }
                    break;
                case Keys.F2:
                    this.cmd_save_Click(sender, e);
                    break;
            }

        }

        private void txt_TextChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;


        }

        private void txtCalc_TextChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
            this.cambiarionPrecio = false;
            this.CalculaPrecioFinal();
        }


        private void txt_preciomasiva_TextChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
            this.cambiarionPrecio = true;
            this.CalculaPrecioFinal(true);
        }


        private void frm_Clientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.m_IsModified == true)
            {
                switch (MessageBox.Show("Ha modificado informaci�n en esta ventana �Desea guardar los datos antes de cerrar?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        this.cmd_save_Click(sender, e);
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
            if (this.m_conn.State == System.Data.ConnectionState.Open)
                this.m_conn.Close();
        }

        private void CalculaPrecioFinal()
        {
            this.CalculaPrecioFinal(false);
        }

        private void actualizrGridConPrecioTotal()
        {
            DataGridViewRow pctg = null;
            DataGridViewRow pcs = null;

            if (this.dataGridView2.Rows[0].Cells[0].Value.ToString() == "%")
            {
                pctg = this.dataGridView2.Rows[0];
                pcs = this.dataGridView2.Rows[1];
            }
            else
            {
                pctg = this.dataGridView2.Rows[1];
                pcs = this.dataGridView2.Rows[0];
            }

            for (int i = 1; i < this.dataGridView2.Columns.Count; i++)
            {
                pctg.Cells[i].Value = txt_utilidad.Text;
                pcs.Cells[i].Value = txt_preciomasiva.Text;
            }
        }

        private void CalculaPrecioFinal(Boolean calculaUtilidad)
        {
            double resul = 0;
            string prec;
            if (this.chkIeps.Checked)
            {
                if (IsNumeric(this.txtPorcIeps.Text))
                    prec = this.txtPorcIeps.Text;
                else
                    prec = "0.0";

                this.txtPrecioIeps.Text = System.Math.Round(Convert.ToDouble(this.txt_proveedor.Text) * (1 + Convert.ToDouble(prec) / 100), 2).ToString();
                prec = this.txtPrecioIeps.Text;
            }
            else
                prec = this.txt_proveedor.Text;

            if (calculaUtilidad)
            {
                this.mp_Loading = true;

                //preciomasiva = precio_final * (1+iva/100)
                //precio_final = preciomasiva / (1+iva/100)
                if (!IsNumeric(this.txt_preciomasiva.Text) || !IsNumeric(this.txt_iva.Text))
                    resul = 0;
                else
                    resul = Convert.ToDouble(this.txt_preciomasiva.Text) / (1 + Convert.ToDouble(this.txt_iva.Text) / 100);

                //this.txt_cliente.Text = System.Math.Round(resul, 2).ToString();
                this.txt_cliente.Text = resul.ToString();

                //precio final = precio prooveedor * (1+(portanje utilizad/100))
                //precio final / precio prooveedor = 1+(portanje utilizad/100)
                //portanje utilizad = (precio final / precio prooveedor - 1)*100
                if (!IsNumeric(prec) || !IsNumeric(this.txt_cliente.Text))
                    resul = 0;
                else
                    resul = (Convert.ToDouble(this.txt_cliente.Text) / Convert.ToDouble(prec) - 1) * 100;

                //this.txt_utilidad.Text = System.Math.Round(resul, 2).ToString();
                this.txt_utilidad.Text = resul.ToString();

                this.mp_Loading = false;

                actualizrGridConPrecioTotal();
                return;
            }

            this.mp_Loading = true;
            try
            {
                if (!IsNumeric(prec) || !IsNumeric(this.txt_utilidad.Text))
                {
                    this.mp_Loading = false;
                    return;
                }
                //precio_final = precio prooveedor * 1.portanje utilizad 
                //=  10 * 1.20 
                resul = Convert.ToDouble(prec) * (1 + Convert.ToDouble(this.txt_utilidad.Text) / 100);   // *(1 + Convert.ToDouble(this.txt_iva.Text) / 100);
            }
            catch
            {
                resul = 0;
            }

            //this.txt_cliente.Text = System.Math.Round(resul, 2).ToString();
            this.txt_cliente.Text = resul.ToString();

            // preciomasiva = precio_final * 1.iva
            if (IsNumeric(this.txt_iva.Text))
                this.txt_preciomasiva.Text = System.Math.Round(resul * (1 + Convert.ToDouble(this.txt_iva.Text) / 100), 2).ToString();
            else
                this.txt_preciomasiva.Text = "0";
            this.mp_Loading = false;

            // Todo : update precios grid
            actualizrGridConPrecioTotal();
        }

        private void cmd_familia_Click(object sender, EventArgs e)
        {
            frm_familias_tree frm = new frm_familias_tree();
            frm.frmproductos = this;
            frm.ShowDialog();
        }

        public void SetFamilia(String strFamilia)
        {
            this.cmb_familia.Text = strFamilia;
        }

        private void lnk_proveedores_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string idProvs = "";

            if (this.m_KeyRecord == -1)
            {
                MessageBox.Show("Guarde primero los datos del nuevo producto antes de asignarle proveedores", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            frm_ProductosProv lFrm = new frm_ProductosProv();
            lFrm.mIdProducto = this.m_KeyRecord;
            lFrm.FillDataSet();
            lFrm.ShowDialog();

            this.txt_proveedores.Text = this.ListaProveedores(ref idProvs);
            this.lbl_IDs_Provs.Text = idProvs;
            ///////////////////////////////////////////////////////////////

            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "UPDATE catProductos SET Proveedores = ? WHERE IdProducto = " + this.m_KeyRecord.ToString();

                lCmd.Parameters.AddWithValue("@Proveedores", this.lbl_IDs_Provs.Text);

                lCmd.ExecuteNonQuery();

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                if (lConn.State == System.Data.ConnectionState.Open)
                {
                    lConn.Close();
                }
            }

            //Actualizar la lista de proveedores...

        }
        // SVM Sep2015 - Un usuario solo puede editar el almacen al q pertenece
        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (this.dsAlmacenes.Tables.Count <= 0)
                return;
            if (Convert.ToInt32(this.dataGridView1.Rows[e.RowIndex].Cells["idAlmacen"].Value) != frm_Main.mp_idAlmacen)
                e.Cancel = true;
        }


        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            double sum = 0;
            if (e.ColumnIndex == 5)
            {
                foreach (DataGridViewRow rw in this.dataGridView1.Rows)
                {
                    sum += (double)rw.Cells["Existencia"].Value;
                }
                this.txt_existencia.Text = sum.ToString("#####0.00");

            }
        }

        private void chkIeps_CheckedChanged(object sender, EventArgs e)
        {
            int y = 30;
            if (chkIeps.Checked)
            {
                label9.Top += y;
                txt_iva.Top += y;
                label14.Top += y;
                txt_utilidad.Top += y;

                label5.Top += y;
                txt_cliente.Top += y;
                lbl_preciomasiva.Top += y;
                txt_preciomasiva.Top += y;

                label19.Top += y;
                dataGridView1.Top += y;
                dataGridView1.Height -= y;
            }
            else
            {
                label9.Top -= y;
                txt_iva.Top -= y;
                label14.Top -= y;
                txt_utilidad.Top -= y;

                label5.Top -= y;
                txt_cliente.Top -= y;
                lbl_preciomasiva.Top -= y;
                txt_preciomasiva.Top -= y;

                label19.Top -= y;
                dataGridView1.Top -= y;
                dataGridView1.Height += y;

            }
            pnlIEPS.Visible = chkIeps.Checked;

            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
            this.CalculaPrecioFinal();

        }

        private void txt_codigo_Leave(object sender, EventArgs e)
        {
            string lRetVal = "";
            string lRetValIds = "";
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;

                lCmd.CommandText = "select catProductos.codigo as vcodigo,  catProductos.descripcion as vdescripcion from catProductos where catProductos.codigo = '" + this.txt_codigo.Text + "';";
                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                while (lReader.Read())
                {
                    //this.lbProveedores.Items.Add(lReader["Nombre"]);

                    if (lReader["vcodigo"].ToString() != "")
                    {

                        MessageBox.Show("Codigo ya existe  : " + lReader["vcodigo"].ToString() + "-" + lReader["vdescripcion"].ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == System.Data.ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void guardarPrecios(bool isNew, ref System.Data.Odbc.OdbcTransaction p_trans)
        {
            DataGridViewRow pctgRow = null;
            DataGridViewRow prcRow = null;

            if (this.dataGridView2.Rows[0].Cells[0].Value.ToString() == "%")
            {
                pctgRow = this.dataGridView2.Rows[0];
                prcRow = this.dataGridView2.Rows[1];
            }
            else
            {
                pctgRow = this.dataGridView2.Rows[1];
                prcRow = this.dataGridView2.Rows[0];
            }

            System.Collections.Generic.List<string> consultas = new System.Collections.Generic.List<string>();
            for (int i = 1; i < this.dataGridView2.Columns.Count; i++)
            {
                if (!IsNumeric(pctgRow.Cells[i].Value.ToString()) || !IsNumeric(prcRow.Cells[i].Value.ToString()))
                {
                    MessageBox.Show("Valor incorrecto para la tienda " + this.dataGridView2.Columns[i].HeaderText,
                                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                double tmp1 = System.Convert.ToDouble(prcRow.Cells[i].Value.ToString());
                double iva = (Convert.ToDouble(this.txt_iva.Text) / 100.00);
                tmp1 = (tmp1 / (1.00 + iva));

                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                if (isNew)
                {
                    sb.Append("insert into relProductoLocacion(IdProducto, IdLocacion, porcentaje, precio, activo, fechaCreado, fechaBaja) values(");
                    sb.Append(this.m_KeyRecord.ToString());
                    sb.Append(",");
                    sb.Append(this.dataGridView2.Columns[i].HeaderText);
                    sb.Append(",");
                    sb.Append(pctgRow.Cells[i].Value.ToString());
                    sb.Append(",");
                    sb.Append(tmp1.ToString());
                    sb.Append(",1,NOW(),NULL);");
                }
                else
                {
                    //sb.Append("update relProductoLocacion set porcentaje = ?, precio = ? where IdProducto = ? and IdLocacion = ?;");
                    sb.Append("update relProductoLocacion set porcentaje = ");
                    sb.Append(pctgRow.Cells[i].Value.ToString());
                    sb.Append(", precio = ");
                    sb.Append(tmp1.ToString());
                    sb.Append(", fechaCreado = NOW() where IdProducto = ");
                    sb.Append(this.m_KeyRecord.ToString());
                    sb.Append(" and IdLocacion = ");
                    sb.Append(this.dataGridView2.Columns[i].HeaderText);
                    sb.Append(";");
                }

                consultas.Add(sb.ToString());
            }

            for (int i = 0; i < consultas.Count; i++)
            {
                System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
                l_update.Connection = this.m_conn;
                l_update.Transaction = p_trans;
                l_update.CommandText = consultas[i];
                l_update.ExecuteNonQuery();
                l_update.Dispose();

                //System.Diagnostics.Debug.WriteLine(consultas[i]);
            }
        }


        private void guardarPrecioUnico(bool isNew, ref System.Data.Odbc.OdbcTransaction p_trans)
        {
            if (!IsNumeric(txtPrecioUnico.Text))
            {
                MessageBox.Show("El valor para el precio �nico es incorrecto.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double tmp1 = System.Convert.ToDouble(txtPrecioUnico.Text);
            //double iva = Convert.ToDouble(this.txt_iva.Text);
            //tmp1 = (tmp1/(1.00+iva));

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (isNew)
            {
                sb.Append("insert into confProducto(IdProducto, usarPrecioUnico, precioUnico) values(");
                sb.Append(this.m_KeyRecord.ToString());
                sb.Append(", 0, ");
                sb.Append(tmp1.ToString());
                sb.Append(");");
            }
            else
            {
                sb.Append("update confProducto set usarPrecioUnico = ");
                sb.Append((this.chkPrecioUnico.Checked ? "1" : "0"));
                sb.Append(", precioUnico = ");
                sb.Append(tmp1.ToString());
                sb.Append(" where IdProducto = ");
                sb.Append(this.m_KeyRecord.ToString());
                sb.Append(";");
            }

            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            l_update.Connection = this.m_conn;
            l_update.Transaction = p_trans;
            l_update.CommandText = sb.ToString();
            l_update.ExecuteNonQuery();
            l_update.Dispose();

            //System.Diagnostics.Debug.WriteLine(sb.ToString());
        }

        private void dataGridView2_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            string idLocacion = this.dataGridView2.Columns[e.ColumnIndex].HeaderText;

            
            System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();

            l_cmd1.Connection = this.m_conn;
            l_cmd1.CommandText = "select editarPrecio from confLocacion where IdLocacion = " + idLocacion + ";";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();

            if (l_reader1.Read())
            {
                e.Cancel = !l_reader1.GetBoolean(0);
            }

            l_reader1.Close();
            this.m_conn.Close();
            

            System.Diagnostics.Debug.WriteLine("dataGridView2_CellBeginEdit");
        }
        private void dataGridView2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow pctg = null;
            DataGridViewRow pcs = null;

            if (!IsNumeric(this.dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()))
            {
                return;
            }

            if (this.dataGridView2.Rows[0].Cells[0].Value.ToString() == "%")
            {
                pctg = this.dataGridView2.Rows[0];
                pcs = this.dataGridView2.Rows[1];
            }
            else
            {
                pctg = this.dataGridView2.Rows[1];
                pcs = this.dataGridView2.Rows[0];
            }

            if (this.dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString() == "%")
            {
                // changed pctg
                double precioAlCliente = System.Convert.ToDouble(this.txt_proveedor.Text);
                double p = System.Convert.ToDouble(this.dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
                double factor = (1.00+(p/100.00));
                double iva = (1.00+(Convert.ToDouble(this.txt_iva.Text) / 100.00));
                double tmp = (precioAlCliente*factor*iva);
                pcs.Cells[e.ColumnIndex].Value= System.Math.Round(tmp,2).ToString();
            }
            else 
            {
                // changed price
                double precioAlCliente = System.Convert.ToDouble(this.txt_proveedor.Text);
                double price = System.Convert.ToDouble(this.dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value);
                double iva = (1.00 + (Convert.ToDouble(this.txt_iva.Text) / 100.00));
                price = price / iva;
                double targetPctg = price/precioAlCliente; 
                targetPctg = (targetPctg - 1) * 100.00;
                pctg.Cells[e.ColumnIndex].Value = System.Math.Round(targetPctg,2).ToString();
            }

            System.Diagnostics.Debug.WriteLine("dataGridView2_CellEndEdit");
        }
    }
}



