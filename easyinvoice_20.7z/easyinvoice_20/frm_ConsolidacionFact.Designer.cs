namespace EasyInvoice
{
    partial class frm_ConsolidacionFact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_ConsolidacionFact));
            this.lbListaFacturas = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdCliente = new System.Windows.Forms.Button();
            this.cmdConsolidar = new System.Windows.Forms.Button();
            this.cmdRemover = new System.Windows.Forms.Button();
            this.cmdCerrar = new System.Windows.Forms.Button();
            this.chkEsCredito = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lbListaFacturas
            // 
            this.lbListaFacturas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbListaFacturas.FormattingEnabled = true;
            this.lbListaFacturas.Location = new System.Drawing.Point(13, 35);
            this.lbListaFacturas.Name = "lbListaFacturas";
            this.lbListaFacturas.Size = new System.Drawing.Size(539, 212);
            this.lbListaFacturas.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Notas Seleccionadas.";
            // 
            // cmdCliente
            // 
            this.cmdCliente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmdCliente.Location = new System.Drawing.Point(16, 253);
            this.cmdCliente.Name = "cmdCliente";
            this.cmdCliente.Size = new System.Drawing.Size(110, 22);
            this.cmdCliente.TabIndex = 2;
            this.cmdCliente.Text = "Seleccionar Cliente";
            this.cmdCliente.UseVisualStyleBackColor = true;
            this.cmdCliente.Click += new System.EventHandler(this.cmdCliente_Click);
            // 
            // cmdConsolidar
            // 
            this.cmdConsolidar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdConsolidar.Location = new System.Drawing.Point(394, 253);
            this.cmdConsolidar.Name = "cmdConsolidar";
            this.cmdConsolidar.Size = new System.Drawing.Size(109, 29);
            this.cmdConsolidar.TabIndex = 3;
            this.cmdConsolidar.Text = "Consolidar";
            this.cmdConsolidar.UseVisualStyleBackColor = true;
            this.cmdConsolidar.Click += new System.EventHandler(this.cmdConsolidar_Click);
            // 
            // cmdRemover
            // 
            this.cmdRemover.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdRemover.Location = new System.Drawing.Point(219, 253);
            this.cmdRemover.Name = "cmdRemover";
            this.cmdRemover.Size = new System.Drawing.Size(109, 22);
            this.cmdRemover.TabIndex = 4;
            this.cmdRemover.Text = "Remover Nota";
            this.cmdRemover.UseVisualStyleBackColor = true;
            this.cmdRemover.Click += new System.EventHandler(this.cmdRemover_Click);
            // 
            // cmdCerrar
            // 
            this.cmdCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCerrar.Location = new System.Drawing.Point(478, 294);
            this.cmdCerrar.Name = "cmdCerrar";
            this.cmdCerrar.Size = new System.Drawing.Size(75, 23);
            this.cmdCerrar.TabIndex = 5;
            this.cmdCerrar.Text = "Cerrar";
            this.cmdCerrar.UseVisualStyleBackColor = true;
            this.cmdCerrar.Click += new System.EventHandler(this.cmdCerrar_Click);
            // 
            // chkEsCredito
            // 
            this.chkEsCredito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkEsCredito.AutoSize = true;
            this.chkEsCredito.Location = new System.Drawing.Point(16, 294);
            this.chkEsCredito.Name = "chkEsCredito";
            this.chkEsCredito.Size = new System.Drawing.Size(59, 17);
            this.chkEsCredito.TabIndex = 6;
            this.chkEsCredito.Text = "Credito";
            this.chkEsCredito.UseVisualStyleBackColor = true;
            // 
            // frm_ConsolidacionFact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(565, 323);
            this.Controls.Add(this.chkEsCredito);
            this.Controls.Add(this.cmdCerrar);
            this.Controls.Add(this.cmdRemover);
            this.Controls.Add(this.cmdConsolidar);
            this.Controls.Add(this.cmdCliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbListaFacturas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_ConsolidacionFact";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Consolidacion de Notas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbListaFacturas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdCliente;
        private System.Windows.Forms.Button cmdConsolidar;
        private System.Windows.Forms.Button cmdRemover;
        private System.Windows.Forms.Button cmdCerrar;
        private System.Windows.Forms.CheckBox chkEsCredito;
    }
}