﻿namespace EasyInvoice
{
    partial class frmEditarPorte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMoneda = new System.Windows.Forms.TextBox();
            this.txtValorDeclarado = new System.Windows.Forms.TextBox();
            this.txtTipo = new System.Windows.Forms.TextBox();
            this.txtObservaciones = new System.Windows.Forms.TextBox();
            this.dgPedidosWeb = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.cmdGuardar = new System.Windows.Forms.Button();
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmdAgregarPedido = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtNumeroDePedidoBuscar = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cmbFormaDePago = new System.Windows.Forms.ComboBox();
            this.cmbMetodoDePago = new System.Windows.Forms.ComboBox();
            this.cmbUsoFDI = new System.Windows.Forms.ComboBox();
            this.cmbAlmacenOrigen = new System.Windows.Forms.ComboBox();
            this.cmbCondDePago = new System.Windows.Forms.ComboBox();
            this.cmbChofer = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbVehiculos = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbAseguradora = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgPedidosWeb)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Almacen Origen";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 47);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Fecha";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Forma de pago";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 111);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cond. de pago";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 143);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Moneda";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 175);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Valor declarado";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 212);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Uso CFDI";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 247);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Método de pago";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(493, 16);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Tipo";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(493, 174);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Póliza";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(493, 52);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 16);
            this.label11.TabIndex = 10;
            this.label11.Text = "Observaciones";
            // 
            // txtMoneda
            // 
            this.txtMoneda.Location = new System.Drawing.Point(156, 134);
            this.txtMoneda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMoneda.Name = "txtMoneda";
            this.txtMoneda.Size = new System.Drawing.Size(328, 22);
            this.txtMoneda.TabIndex = 15;
            this.txtMoneda.Text = "MXN";
            // 
            // txtValorDeclarado
            // 
            this.txtValorDeclarado.Location = new System.Drawing.Point(156, 166);
            this.txtValorDeclarado.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorDeclarado.Name = "txtValorDeclarado";
            this.txtValorDeclarado.Size = new System.Drawing.Size(328, 22);
            this.txtValorDeclarado.TabIndex = 16;
            // 
            // txtTipo
            // 
            this.txtTipo.Location = new System.Drawing.Point(609, 7);
            this.txtTipo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTipo.Name = "txtTipo";
            this.txtTipo.Size = new System.Drawing.Size(389, 22);
            this.txtTipo.TabIndex = 19;
            // 
            // txtObservaciones
            // 
            this.txtObservaciones.Location = new System.Drawing.Point(609, 43);
            this.txtObservaciones.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtObservaciones.Name = "txtObservaciones";
            this.txtObservaciones.Size = new System.Drawing.Size(389, 22);
            this.txtObservaciones.TabIndex = 20;
            // 
            // dgPedidosWeb
            // 
            this.dgPedidosWeb.AllowUserToAddRows = false;
            this.dgPedidosWeb.AllowUserToResizeColumns = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgPedidosWeb.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgPedidosWeb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgPedidosWeb.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPedidosWeb.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgPedidosWeb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPedidosWeb.Location = new System.Drawing.Point(41, 326);
            this.dgPedidosWeb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgPedidosWeb.Name = "dgPedidosWeb";
            this.dgPedidosWeb.ReadOnly = true;
            this.dgPedidosWeb.RowHeadersVisible = false;
            this.dgPedidosWeb.RowHeadersWidth = 51;
            this.dgPedidosWeb.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPedidosWeb.Size = new System.Drawing.Size(959, 239);
            this.dgPedidosWeb.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(39, 297);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 16);
            this.label12.TabIndex = 23;
            this.label12.Text = "Pedidos Agregados :";
            // 
            // cmdGuardar
            // 
            this.cmdGuardar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdGuardar.Location = new System.Drawing.Point(792, 567);
            this.cmdGuardar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdGuardar.Name = "cmdGuardar";
            this.cmdGuardar.Size = new System.Drawing.Size(100, 28);
            this.cmdGuardar.TabIndex = 28;
            this.cmdGuardar.Text = "Guardar";
            this.cmdGuardar.UseVisualStyleBackColor = true;
            this.cmdGuardar.Click += new System.EventHandler(this.cmdGuardar_Click);
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdCancelar.Location = new System.Drawing.Point(900, 567);
            this.cmdCancelar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(100, 28);
            this.cmdCancelar.TabIndex = 29;
            this.cmdCancelar.Text = "Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            this.cmdCancelar.Click += new System.EventHandler(this.cmdCancelar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmdAgregarPedido);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtNumeroDePedidoBuscar);
            this.groupBox1.Location = new System.Drawing.Point(609, 228);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(391, 90);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            // 
            // cmdAgregarPedido
            // 
            this.cmdAgregarPedido.Location = new System.Drawing.Point(267, 42);
            this.cmdAgregarPedido.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmdAgregarPedido.Name = "cmdAgregarPedido";
            this.cmdAgregarPedido.Size = new System.Drawing.Size(100, 28);
            this.cmdAgregarPedido.TabIndex = 1;
            this.cmdAgregarPedido.Text = "Agregar";
            this.cmdAgregarPedido.UseVisualStyleBackColor = true;
            this.cmdAgregarPedido.Click += new System.EventHandler(this.cmdAgregarPedido_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 20);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "Número de pedido";
            // 
            // txtNumeroDePedidoBuscar
            // 
            this.txtNumeroDePedidoBuscar.Location = new System.Drawing.Point(20, 44);
            this.txtNumeroDePedidoBuscar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNumeroDePedidoBuscar.Name = "txtNumeroDePedidoBuscar";
            this.txtNumeroDePedidoBuscar.Size = new System.Drawing.Size(224, 22);
            this.txtNumeroDePedidoBuscar.TabIndex = 0;
            this.txtNumeroDePedidoBuscar.Enter += new System.EventHandler(this.txtNumeroDePedidoBuscar_Enter);
            this.txtNumeroDePedidoBuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroDePedidoBuscar_KeyPress);
            this.txtNumeroDePedidoBuscar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtNumeroDePedidoBuscar_MouseDown);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(156, 39);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(328, 22);
            this.dateTimePicker1.TabIndex = 12;
            // 
            // cmbFormaDePago
            // 
            this.cmbFormaDePago.FormattingEnabled = true;
            this.cmbFormaDePago.Items.AddRange(new object[] {
            "N/A",
            "EFECTIVO",
            "CHEQUE",
            "TRANSFERENCIA",
            "TARJETA"});
            this.cmbFormaDePago.Location = new System.Drawing.Point(156, 68);
            this.cmbFormaDePago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFormaDePago.Name = "cmbFormaDePago";
            this.cmbFormaDePago.Size = new System.Drawing.Size(329, 24);
            this.cmbFormaDePago.TabIndex = 13;
            this.cmbFormaDePago.SelectedIndexChanged += new System.EventHandler(this.cmbFormaDePago_SelectedIndexChanged);
            // 
            // cmbMetodoDePago
            // 
            this.cmbMetodoDePago.FormattingEnabled = true;
            this.cmbMetodoDePago.Items.AddRange(new object[] {
            "N/A",
            "METODO 1"});
            this.cmbMetodoDePago.Location = new System.Drawing.Point(156, 244);
            this.cmbMetodoDePago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbMetodoDePago.Name = "cmbMetodoDePago";
            this.cmbMetodoDePago.Size = new System.Drawing.Size(329, 24);
            this.cmbMetodoDePago.TabIndex = 18;
            // 
            // cmbUsoFDI
            // 
            this.cmbUsoFDI.FormattingEnabled = true;
            this.cmbUsoFDI.Items.AddRange(new object[] {
            "N/A",
            "TRASLADO"});
            this.cmbUsoFDI.Location = new System.Drawing.Point(156, 202);
            this.cmbUsoFDI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbUsoFDI.Name = "cmbUsoFDI";
            this.cmbUsoFDI.Size = new System.Drawing.Size(329, 24);
            this.cmbUsoFDI.TabIndex = 17;
            // 
            // cmbAlmacenOrigen
            // 
            this.cmbAlmacenOrigen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAlmacenOrigen.FormattingEnabled = true;
            this.cmbAlmacenOrigen.Location = new System.Drawing.Point(156, 6);
            this.cmbAlmacenOrigen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbAlmacenOrigen.Name = "cmbAlmacenOrigen";
            this.cmbAlmacenOrigen.Size = new System.Drawing.Size(328, 24);
            this.cmbAlmacenOrigen.TabIndex = 11;
            // 
            // cmbCondDePago
            // 
            this.cmbCondDePago.FormattingEnabled = true;
            this.cmbCondDePago.Items.AddRange(new object[] {
            "N/A",
            "COND DE PAGO 1",
            "COND DE PAGO 2"});
            this.cmbCondDePago.Location = new System.Drawing.Point(156, 98);
            this.cmbCondDePago.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbCondDePago.Name = "cmbCondDePago";
            this.cmbCondDePago.Size = new System.Drawing.Size(328, 24);
            this.cmbCondDePago.TabIndex = 14;
            // 
            // cmbChofer
            // 
            this.cmbChofer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChofer.FormattingEnabled = true;
            this.cmbChofer.Location = new System.Drawing.Point(609, 78);
            this.cmbChofer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbChofer.Name = "cmbChofer";
            this.cmbChofer.Size = new System.Drawing.Size(389, 24);
            this.cmbChofer.TabIndex = 21;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(493, 86);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 16);
            this.label14.TabIndex = 27;
            this.label14.Text = "Chofer";
            // 
            // cmbVehiculos
            // 
            this.cmbVehiculos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVehiculos.FormattingEnabled = true;
            this.cmbVehiculos.Location = new System.Drawing.Point(609, 111);
            this.cmbVehiculos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbVehiculos.Name = "cmbVehiculos";
            this.cmbVehiculos.Size = new System.Drawing.Size(389, 24);
            this.cmbVehiculos.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(491, 119);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 16);
            this.label15.TabIndex = 29;
            this.label15.Text = "Vehiculo";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(493, 199);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 16);
            this.label16.TabIndex = 30;
            this.label16.Text = "Aseguradora";
            // 
            // cmbAseguradora
            // 
            this.cmbAseguradora.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAseguradora.FormattingEnabled = true;
            this.cmbAseguradora.Items.AddRange(new object[] {
            "AXXA SEGUROS S.A. DE C.V. POLIZA CSA789550800",
            "GENERAL DE SEGUROS S.A.B POLIZA 8/721/27569",
            "GENERAL DE SEGUROS S.A.B POLIZA 8/721/27570"});
            this.cmbAseguradora.Location = new System.Drawing.Point(609, 196);
            this.cmbAseguradora.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbAseguradora.Name = "cmbAseguradora";
            this.cmbAseguradora.Size = new System.Drawing.Size(389, 24);
            this.cmbAseguradora.TabIndex = 24;
            this.cmbAseguradora.SelectedIndexChanged += new System.EventHandler(this.cmbAseguradora_SelectedIndexChanged);
            // 
            // frmEditarPorte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 610);
            this.Controls.Add(this.cmbAseguradora);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cmbVehiculos);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cmbChofer);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cmbCondDePago);
            this.Controls.Add(this.cmbAlmacenOrigen);
            this.Controls.Add(this.cmbUsoFDI);
            this.Controls.Add(this.cmbMetodoDePago);
            this.Controls.Add(this.cmbFormaDePago);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmdCancelar);
            this.Controls.Add(this.cmdGuardar);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dgPedidosWeb);
            this.Controls.Add(this.txtObservaciones);
            this.Controls.Add(this.txtTipo);
            this.Controls.Add(this.txtValorDeclarado);
            this.Controls.Add(this.txtMoneda);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmEditarPorte";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Porte";
            this.Load += new System.EventHandler(this.frmEditarPorte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgPedidosWeb)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMoneda;
        private System.Windows.Forms.TextBox txtValorDeclarado;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.TextBox txtObservaciones;
        private System.Windows.Forms.DataGridView dgPedidosWeb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button cmdGuardar;
        private System.Windows.Forms.Button cmdCancelar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdAgregarPedido;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtNumeroDePedidoBuscar;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cmbFormaDePago;
        private System.Windows.Forms.ComboBox cmbMetodoDePago;
        private System.Windows.Forms.ComboBox cmbUsoFDI;
        private System.Windows.Forms.ComboBox cmbAlmacenOrigen;
        private System.Windows.Forms.ComboBox cmbCondDePago;
        private System.Windows.Forms.ComboBox cmbChofer;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbVehiculos;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbAseguradora;
    }
}