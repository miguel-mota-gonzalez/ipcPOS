using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.OleDb;
using clsFactElectronica;
using System.Configuration;


namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_factura.
	/// </summary>
	public class frm_notascred : System.Windows.Forms.Form
	{

		//private System.Data.DataSet m_detail = new System.Data.DataSet();    
		private System.Int32 m_idclient; 
		private System.String m_ciudad;
		private System.String m_tel;
		private System.DateTime m_now;
		private System.String m_numNC;
	
		//private System.Double m_subtotal=0;
		//private System.Double m_total=0;
        //private System.String m_cadena_original = "";
        //private System.String m_sello = "";

		private System.Data.Odbc.OdbcConnection m_conn;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txt_dir;
		private System.Windows.Forms.TextBox txt_rfc;
		private System.Windows.Forms.TextBox txt_nombre;
		private System.Windows.Forms.Label lbl_direccion;
		private System.Windows.Forms.Label lbl_rfc;
        private System.Windows.Forms.Label lbl_Nombre;
		//private System.Double m_curprice;
        //private System.Double m_orprice;
		private System.Drawing.Printing.PrintDocument printdoc;
		private System.Windows.Forms.PrintPreviewDialog printpw;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txt_numfact;
        private LinkLabel ll_buscar;
        private LinkLabel ll_nuevo;
        private LinkLabel ll_generar;
        private LinkLabel ll_cancelar;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

        //private string m_lastvalid_code = "";
        private Label label4;
        private Label label6;
        private TextBox txt_subtotal;
        private TextBox txt_total;
        private TextBox txt_concepto;
        private Label label7;
        private DateTimePicker dateTimePicker1;
        private Label label1;

        private int mp_iva_to_store = 15;
		
		public frm_notascred()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_idclient = -1;
			this.txt_subtotal.Text = "0.0";
            this.txt_total.Text = "0.0";
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_notascred));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ll_buscar = new System.Windows.Forms.LinkLabel();
            this.ll_nuevo = new System.Windows.Forms.LinkLabel();
            this.txt_numfact = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_rfc = new System.Windows.Forms.TextBox();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.lbl_rfc = new System.Windows.Forms.Label();
            this.lbl_Nombre = new System.Windows.Forms.Label();
            this.printdoc = new System.Drawing.Printing.PrintDocument();
            this.printpw = new System.Windows.Forms.PrintPreviewDialog();
            this.ll_generar = new System.Windows.Forms.LinkLabel();
            this.ll_cancelar = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_subtotal = new System.Windows.Forms.TextBox();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.txt_concepto = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.ll_buscar);
            this.groupBox1.Controls.Add(this.ll_nuevo);
            this.groupBox1.Controls.Add(this.txt_numfact);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_dir);
            this.groupBox1.Controls.Add(this.txt_rfc);
            this.groupBox1.Controls.Add(this.txt_nombre);
            this.groupBox1.Controls.Add(this.lbl_direccion);
            this.groupBox1.Controls.Add(this.lbl_rfc);
            this.groupBox1.Controls.Add(this.lbl_Nombre);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(8, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(913, 144);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cliente";
            // 
            // ll_buscar
            // 
            this.ll_buscar.AutoSize = true;
            this.ll_buscar.Location = new System.Drawing.Point(620, 104);
            this.ll_buscar.Name = "ll_buscar";
            this.ll_buscar.Size = new System.Drawing.Size(238, 13);
            this.ll_buscar.TabIndex = 9;
            this.ll_buscar.TabStop = true;
            this.ll_buscar.Text = "Buscar un cliente dado de alta en el sistema {F7}";
            this.ll_buscar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_buscar_LinkClicked);
            // 
            // ll_nuevo
            // 
            this.ll_nuevo.AutoSize = true;
            this.ll_nuevo.Location = new System.Drawing.Point(620, 76);
            this.ll_nuevo.Name = "ll_nuevo";
            this.ll_nuevo.Size = new System.Drawing.Size(198, 13);
            this.ll_nuevo.TabIndex = 8;
            this.ll_nuevo.TabStop = true;
            this.ll_nuevo.Text = "Agregar un nuevo cliente al sistema {F6}";
            this.ll_nuevo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_nuevo_LinkClicked);
            // 
            // txt_numfact
            // 
            this.txt_numfact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_numfact.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_numfact.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numfact.Location = new System.Drawing.Point(759, 24);
            this.txt_numfact.Name = "txt_numfact";
            this.txt_numfact.Size = new System.Drawing.Size(136, 17);
            this.txt_numfact.TabIndex = 3;
            this.txt_numfact.Text = "0000";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(577, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(181, 23);
            this.label8.TabIndex = 2;
            this.label8.Text = "Numero de  Nota de Cred.";
            // 
            // txt_dir
            // 
            this.txt_dir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_dir.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_dir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dir.Location = new System.Drawing.Point(87, 88);
            this.txt_dir.Multiline = true;
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.ReadOnly = true;
            this.txt_dir.Size = new System.Drawing.Size(484, 40);
            this.txt_dir.TabIndex = 7;
            // 
            // txt_rfc
            // 
            this.txt_rfc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_rfc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_rfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rfc.Location = new System.Drawing.Point(87, 56);
            this.txt_rfc.Name = "txt_rfc";
            this.txt_rfc.ReadOnly = true;
            this.txt_rfc.Size = new System.Drawing.Size(484, 17);
            this.txt_rfc.TabIndex = 5;
            // 
            // txt_nombre
            // 
            this.txt_nombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_nombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(87, 24);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.ReadOnly = true;
            this.txt_nombre.Size = new System.Drawing.Size(484, 17);
            this.txt_nombre.TabIndex = 1;
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(15, 88);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(72, 16);
            this.lbl_direccion.TabIndex = 6;
            this.lbl_direccion.Text = "Direccion";
            // 
            // lbl_rfc
            // 
            this.lbl_rfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rfc.Location = new System.Drawing.Point(15, 56);
            this.lbl_rfc.Name = "lbl_rfc";
            this.lbl_rfc.Size = new System.Drawing.Size(72, 16);
            this.lbl_rfc.TabIndex = 4;
            this.lbl_rfc.Text = "RFC";
            // 
            // lbl_Nombre
            // 
            this.lbl_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nombre.Location = new System.Drawing.Point(15, 24);
            this.lbl_Nombre.Name = "lbl_Nombre";
            this.lbl_Nombre.Size = new System.Drawing.Size(72, 16);
            this.lbl_Nombre.TabIndex = 0;
            this.lbl_Nombre.Text = "Nombre";
            // 
            // printdoc
            // 
            this.printdoc.DocumentName = "Factura";
            this.printdoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printdoc_PrintPage);
            // 
            // printpw
            // 
            this.printpw.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printpw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printpw.ClientSize = new System.Drawing.Size(400, 300);
            this.printpw.Document = this.printdoc;
            this.printpw.Enabled = true;
            this.printpw.Icon = ((System.Drawing.Icon)(resources.GetObject("printpw.Icon")));
            this.printpw.Name = "printpw";
            this.printpw.Visible = false;
            // 
            // ll_generar
            // 
            this.ll_generar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ll_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ll_generar.Location = new System.Drawing.Point(284, 292);
            this.ll_generar.Name = "ll_generar";
            this.ll_generar.Size = new System.Drawing.Size(349, 17);
            this.ll_generar.TabIndex = 9;
            this.ll_generar.TabStop = true;
            this.ll_generar.Text = "<< GENERAR LA NOTA DE CR�DITO >> {F10}";
            this.ll_generar.Visible = false;
            this.ll_generar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_generar_LinkClicked);
            // 
            // ll_cancelar
            // 
            this.ll_cancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ll_cancelar.AutoSize = true;
            this.ll_cancelar.Location = new System.Drawing.Point(645, 292);
            this.ll_cancelar.Name = "ll_cancelar";
            this.ll_cancelar.Size = new System.Drawing.Size(281, 13);
            this.ll_cancelar.TabIndex = 10;
            this.ll_cancelar.TabStop = true;
            this.ll_cancelar.Text = "Cerrar esta ventana y descartar esta nota de cr�dito {Esc}";
            this.ll_cancelar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_cancelar_LinkClicked);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "SubTotal";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(260, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Total + IVA";
            // 
            // txt_subtotal
            // 
            this.txt_subtotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt_subtotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_subtotal.Enabled = false;
            this.txt_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_subtotal.Location = new System.Drawing.Point(95, 223);
            this.txt_subtotal.Name = "txt_subtotal";
            this.txt_subtotal.ReadOnly = true;
            this.txt_subtotal.Size = new System.Drawing.Size(126, 17);
            this.txt_subtotal.TabIndex = 6;
            this.txt_subtotal.Text = "0";
            // 
            // txt_total
            // 
            this.txt_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.Location = new System.Drawing.Point(360, 220);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(145, 24);
            this.txt_total.TabIndex = 8;
            this.txt_total.Text = "0";
            this.txt_total.Validated += new System.EventHandler(this.txt_total_Validated);
            this.txt_total.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_total_KeyDown);
            // 
            // txt_concepto
            // 
            this.txt_concepto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_concepto.Location = new System.Drawing.Point(95, 190);
            this.txt_concepto.Name = "txt_concepto";
            this.txt_concepto.Size = new System.Drawing.Size(826, 24);
            this.txt_concepto.TabIndex = 4;
            this.txt_concepto.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_conceptoKeyDown);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(15, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 19);
            this.label7.TabIndex = 3;
            this.label7.Text = "Concepto";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(95, 164);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(98, 20);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.Value = new System.DateTime(2011, 1, 30, 19, 31, 40, 0);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Fecha";
            // 
            // frm_notascred
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 319);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.ll_cancelar);
            this.Controls.Add(this.ll_generar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_concepto);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_subtotal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_notascred";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Nueva Nota de Cr�dito";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_notascred_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_notascred_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
		#endregion

		private void cmd_nuevo_Click(object sender, System.EventArgs e)
		{
			frm_Clientes l_frm = new frm_Clientes(); 
			l_frm.ShowDialog(); 	
		
			if(l_frm.m_KeyRecord!=-1)
			{
				System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",l_frm.m_KeyRecord )  );
				this.m_idclient = l_frm.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);

                //////////////////
                this.mpRfcCliente = l_reader["RFC"].ToString();
                this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
                this.mpCalleCliente = l_reader["Calle"].ToString();
                this.mpNumeroExtCliente = l_reader["Numero"].ToString();
                this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
                this.mpColoniaCliente = l_reader["Colonia"].ToString();
                this.mpLocalidadCliente = l_reader["ciudad"].ToString();
                this.mpReferenciaCliente = l_reader["Referencia"].ToString();
                this.mpMunicipioCliente = l_reader["Municipio"].ToString();
                this.mpEstadoCliente = l_reader["Estado"].ToString();
                this.mpPaisCliente = l_reader["Pais"].ToString();
                this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
                //////////////////

				l_reader.Close();
				this.m_conn.Close();

			}

		}

		private void frm_notascred_Load(object sender, System.EventArgs e)
		{			 
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            
            this.LoadSystemValues();                        

			this.txt_numfact.Text = "";
            this.m_conn.Open();
 
            //Poner el cliente de mostrador como el cliente actual...
            System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
			l_recid.Connection = this.m_conn;
			l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
			l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",1 )  );
			this.m_idclient = 1;

			System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

			l_reader.Read(); 

			this.txt_nombre.Text = l_reader.GetString(1); 
			this.txt_dir.Text = l_reader.GetString(2); 
			this.txt_rfc.Text = l_reader.GetString(5);   
			this.m_ciudad = l_reader.GetString(9);   
			this.m_tel = l_reader.GetString(4);

            //////////////////
            this.mpRfcCliente = l_reader["RFC"].ToString();
            this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
            this.mpCalleCliente = l_reader["Calle"].ToString();
            this.mpNumeroExtCliente = l_reader["Numero"].ToString();
            this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
            this.mpColoniaCliente = l_reader["Colonia"].ToString();
            this.mpLocalidadCliente = l_reader["ciudad"].ToString();
            this.mpReferenciaCliente = l_reader["Referencia"].ToString();
            this.mpMunicipioCliente = l_reader["Municipio"].ToString();
            this.mpEstadoCliente = l_reader["Estado"].ToString();
            this.mpPaisCliente = l_reader["Pais"].ToString();
            this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
            //////////////////

			l_reader.Close();
			this.m_conn.Close();  
            
			this.txt_concepto.Focus();

            this.SetVisibleCore(true);

		}

        string mpRfcCliente = "";
        string mpRazonSocialCliente = "";
        string mpCalleCliente = "";
        string mpNumeroExtCliente = "";
        string mpNumeroIntCliente = "";
        string mpColoniaCliente = "";
        string mpLocalidadCliente = "";
        string mpReferenciaCliente = "";
        string mpMunicipioCliente = "";
        string mpEstadoCliente = "";
        string mpPaisCliente = "";
        string mpCodigoPostalCliente = "";

		private void cmd_buscar_Click(object sender, System.EventArgs e)
		{
            frm_ClientsList l_frmClientes = new frm_ClientsList();
			l_frmClientes.cmd_nuevo.Enabled = false;            
            l_frmClientes.mp_toolbar.Buttons[1].Enabled = false;
            
            l_frmClientes.mp_criteriousar = "";
			
            l_frmClientes.ShowDialog(); 

			if(l_frmClientes.m_KeyRecord!=-1)
			{
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",l_frmClientes.m_KeyRecord )  );
				this.m_idclient = l_frmClientes.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);   

                //////////////////
                this.mpRfcCliente = l_reader["RFC"].ToString();
                this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
                this.mpCalleCliente = l_reader["Calle"].ToString();
                this.mpNumeroExtCliente = l_reader["Numero"].ToString();
                this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
                this.mpColoniaCliente = l_reader["Colonia"].ToString();
                this.mpLocalidadCliente = l_reader["ciudad"].ToString();
                this.mpReferenciaCliente = l_reader["Referencia"].ToString();
                this.mpMunicipioCliente = l_reader["Municipio"].ToString();
                this.mpEstadoCliente = l_reader["Estado"].ToString();
                this.mpPaisCliente = l_reader["Pais"].ToString();
                this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
                //////////////////

				l_reader.Close();
				this.m_conn.Close();  

			}

		}

		private void cdm_cerrar_Click(object sender, System.EventArgs e)
		{
			this.Close(); 
		}

		private System.String GetNumNC(bool p_increase,System.Data.Odbc.OdbcConnection pConn,System.Data.Odbc.OdbcTransaction pTrans)
		{
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcCommand l_increase;
  
			l_getnum = new System.Data.Odbc.OdbcCommand();
 
			l_getnum.Connection = pConn;
			l_getnum.CommandText = "SELECT consNotaCred FROM confConsFactura;";

			l_getnum.Transaction = pTrans;
			System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();   

			l_reader.Read();
 
			System.String l_numero = l_reader.GetInt32(0).ToString();  

			l_reader.Close();

            if (p_increase == true)
            {
                l_increase = new System.Data.Odbc.OdbcCommand();
                l_increase.Connection = this.m_conn;
                l_increase.Transaction = pTrans;
                l_increase.CommandText = "UPDATE confConsFactura SET consNotaCred = consNotaCred + 1;";
                l_increase.ExecuteNonQuery();
            }

			//this.m_conn.Close();
  
			return l_numero;
		}

		private void cmd_generar_Click(object sender, System.EventArgs e)
		{
            //frm_cambio l_cambio = new frm_cambio();
            //l_cambio.m_total = this.m_total;
            //l_cambio.ShowDialog();

            if (this.m_idclient <= 0)
            {
                MessageBox.Show("Debe asignar un cliente a la notaq de cr�dito!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (this.txt_concepto.Text.Length<=0)
            {
                MessageBox.Show("Indique un concepto para la nota de cr�dito!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (Convert.ToDouble(this.txt_total.Text) < 0.0)
            {
                MessageBox.Show("Total inv�lido!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else
            {
                this.CalculSubtotal();
            }
            if (Convert.ToDouble(this.txt_subtotal.Text) < 0.0)
            {
                MessageBox.Show("Subtotal inv�lido!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.LoadData();

            clsFactElectronica.clsFactElec lFE = new clsFactElectronica.clsFactElec();
			
			if(ConfigurationSettings.AppSettings["os"] != null)
			{
				//MessageBox.Show( ConfigurationSettings.AppSettings["os"] );
				lFE.mLinux = ConfigurationSettings.AppSettings["os"] == "linux" ? true : false;
			}
				
			//if(lFE.mLinux == false)
			//	MessageBox.Show("No es linux");
			
            System.Collections.Generic.List<string> lDetailDataArr = new System.Collections.Generic.List<string>();

			//Insertar la factura nueva....
			System.Data.Odbc.OdbcCommand l_insertf = new System.Data.Odbc.OdbcCommand();
			System.Data.Odbc.OdbcCommand l_getf = new System.Data.Odbc.OdbcCommand();
			//System.Data.Odbc.OdbcCommand l_insertd;
			//System.Int32 l_keyf;
			//System.Int32 i;
			System.String l_numfac = "";

			if( MessageBox.Show("�Confirma que desea generar la nota de cr�dito?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;				

            System.Data.Odbc.OdbcTransaction l_trans = null;

            try
            {
				
                this.m_conn.Open();
                l_trans = this.m_conn.BeginTransaction();			
				
				l_numfac = GetNumNC(true,this.m_conn,l_trans);		
				this.m_numNC = l_numfac;				

                this.ll_generar.Visible = false;

                this.m_now = System.DateTime.Now;

                l_insertf.Connection = this.m_conn;
                l_insertf.CommandText = "INSERT INTO catnotascred(IdCliente,NumeroNotaCred,Fecha,Concepto,SubTotal,Total,usuario,estatus,Cancelada,usuarioventa) VALUES(?,?,?,?,?,?,?,?,?,?);";

				
                System.Data.Odbc.OdbcParameter l_p1 = new System.Data.Odbc.OdbcParameter("@IdCliente", System.Data.Odbc.OdbcType.Int);
                l_p1.Value = this.m_idclient;
                l_insertf.Parameters.Add(l_p1);

                System.Data.Odbc.OdbcParameter l_p2 = new System.Data.Odbc.OdbcParameter("@NumeroNotaCred", System.Data.Odbc.OdbcType.VarChar);
                l_p2.Value = l_numfac;
                l_insertf.Parameters.Add(l_p2);

                System.Data.Odbc.OdbcParameter l_p3 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
                l_p3.Value = this.dateTimePicker1.Value;
                l_insertf.Parameters.Add(l_p3);

                System.Data.Odbc.OdbcParameter l_p4 = new System.Data.Odbc.OdbcParameter("@Concepto", System.Data.Odbc.OdbcType.VarChar );
                l_p4.Value = this.txt_concepto.Text;
                l_insertf.Parameters.Add(l_p4);

                System.Data.Odbc.OdbcParameter l_p5 = new System.Data.Odbc.OdbcParameter("@SubTotal", System.Data.Odbc.OdbcType.Double);
                l_p5.Value = this.txt_subtotal.Text;
                l_insertf.Parameters.Add(l_p5);

                System.Data.Odbc.OdbcParameter l_p6 = new System.Data.Odbc.OdbcParameter("@Total", System.Data.Odbc.OdbcType.Double);
                l_p6.Value = this.txt_total.Text;
                l_insertf.Parameters.Add(l_p6);

                System.Data.Odbc.OdbcParameter l_p7_ = new System.Data.Odbc.OdbcParameter("@usuario", System.Data.Odbc.OdbcType.VarChar);
                l_p7_.Value = frm_Main.mps_usuario;
                l_insertf.Parameters.Add(l_p7_);

                // campo para indicar si una Nc ya se asigno o no: 0 no asignada, 1 asignado a un pago
                System.Data.Odbc.OdbcParameter l_p8_ = new System.Data.Odbc.OdbcParameter("@estatus", System.Data.Odbc.OdbcType.Int);
                l_p8_.Value = 0;
                l_insertf.Parameters.Add(l_p8_);

                System.Data.Odbc.OdbcParameter l_p9_ = new System.Data.Odbc.OdbcParameter("@Cancelada",System.Data.Odbc.OdbcType.Int );
                l_p9_.Value = 0;
                l_insertf.Parameters.Add(l_p9_);

                System.Data.Odbc.OdbcParameter l_p10_ = new System.Data.Odbc.OdbcParameter("@usuarioventa",/*OleDbType.VarWChar*/System.Data.Odbc.OdbcType.VarChar);
                l_p10_.Value = frm_Main.mps_usuario;
                l_insertf.Parameters.Add(l_p10_);
				
                //this.m_conn.Open();
                //l_trans = this.m_conn.BeginTransaction();

				l_insertf.Transaction = l_trans;
				l_insertf.ExecuteNonQuery();                
				
				l_getf.Connection = this.m_conn;
                l_getf.Transaction = l_trans;
 /*               
                l_getf.CommandText = "SELECT idNotaCredito FROM catNotasCred WHERE IdCliente=? and NumeroNotaCred = ? and Fecha = ? and Concepto = ?;";

                System.Data.Odbc.OdbcParameter l_p7 = new System.Data.Odbc.OdbcParameter("@IdCliente", System.Data.Odbc.OdbcType.Int);
                l_p7.Value = this.m_idclient;
                l_getf.Parameters.Add(l_p7);

                System.Data.Odbc.OdbcParameter l_p8 = new System.Data.Odbc.OdbcParameter("@NumeroNotaCred", System.Data.Odbc.OdbcType.VarChar);
                l_p8.Value = l_numfac;
                l_getf.Parameters.Add(l_p8);

                System.Data.Odbc.OdbcParameter l_p9 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
                l_p9.Value = this.m_now;
                l_getf.Parameters.Add(l_p9);

                System.Data.Odbc.OdbcParameter l_p10 = new System.Data.Odbc.OdbcParameter("@Concepto", System.Data.Odbc.OdbcType.VarChar);
                l_p10.Value = this.txt_concepto.Text;
                l_getf.Parameters.Add(l_p10);


                l_getf.Transaction = l_trans;
                l_keyf = (System.Int32)l_getf.ExecuteScalar();
 */               
	                //////////////////////////////////////////////////////////////////
	                //Almacenar la cadena original y el sello
					/*
					string lFecha = DateTime.Now.Year.ToString() + "-" + ( DateTime.Now.Month.ToString().Length == 2 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString() );
					lFecha += "-" + ( DateTime.Now.Day.ToString().Length == 2 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString() );
					lFecha += "T" + ( DateTime.Now.Hour.ToString().Length == 2 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString() );
					lFecha += ":" + ( DateTime.Now.Minute.ToString().Length == 2 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString() );
					lFecha += ":" + ( DateTime.Now.Second.ToString().Length == 2 ? DateTime.Now.Second.ToString() : "0" + DateTime.Now.Second.ToString() );
					
	                string lCadenaOriginal = lFE.GenerarCadenaOriginal(this.mConfFact, l_numfac, lFecha,
	                    "UNA SOLA EXIBICION",
	                    string.Format("{0:0.00}", Math.Round(this.m_subtotal, 2)),
	                    string.Format("{0:0.00}", Math.Round(lDescuento, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total, 2)),
	                    this.mpRfcCliente,
	                    this.mpRazonSocialCliente,
	                    this.mpCalleCliente,
	                    this.mpNumeroExtCliente,
	                    this.mpNumeroIntCliente,
	                    this.mpColoniaCliente,
	                    this.mpLocalidadCliente,
	                    this.mpReferenciaCliente,
	                    this.mpMunicipioCliente,
	                    this.mpEstadoCliente,
	                    this.mpPaisCliente,
	                    this.mpCodigoPostalCliente,
	                    string.Format("{0:0.00}", Math.Round(this.mp_IVA*100, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total - this.m_subtotal, 2)),
	                    lDetailDataArr);
	
	                //this.mp_IVA
	                lFE.mOpenSSLPath = ConfigurationSettings.AppSettings["opensslpath"];
					
					string lKeyFile = "";
					try
					{
						lKeyFile = System.IO.File.ReadAllText("keyfile.txt").Trim();
					}
					catch(Exception ex)
					{
						throw new Exception("Es necesario importar el archivo llave de facturacion electronica antes de generar una factura.");						
					}
	                string lSello = lFE.GenerarSello(lCadenaOriginal, lKeyFile);
	
	                //Actualizar la factura
	                System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
	                lConn.ConnectionString = frm_Main.mps_strconnection;
	
	                System.Data.Odbc.OdbcCommand lCmdEND = new System.Data.Odbc.OdbcCommand();
	                lCmdEND.Connection = this.m_conn;
	                lCmdEND.Transaction = l_trans;
	                lCmdEND.CommandText = "UPDATE catFacturas SET cadenaoriginal = ?,sello = ? where IdFactura = ?";
	
	                lCmdEND.Parameters.AddWithValue("@cadenaoriginal", lCadenaOriginal);
	                lCmdEND.Parameters.AddWithValue("@sello", lSello);
	                lCmdEND.Parameters.AddWithValue("@IdFactura", l_keyf);
	
	                lCmdEND.ExecuteNonQuery();
	
	                this.m_cadena_original = lCadenaOriginal;
	                this.m_sello = lSello;
	                */
	                //////////////////////////////////////////////////////////////////

                l_trans.Commit();
                
            }
            catch (Exception ee)
            {
                if (l_trans != null)
                    l_trans.Rollback();
                MessageBox.Show(ee.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {                

                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();

            }

			this.Close(); 

		}

        private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();

        private void LoadData()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

            lConn.Open();
            System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

            if (lReader.Read())
            {
                this.mConfFact.Version = lReader["Version"].ToString();
                this.mConfFact.Serie = lReader["Serie"].ToString();
                this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
                this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
                this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
                this.mConfFact.RFC = lReader["RFC"].ToString();
                this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
                this.mConfFact.Calle = lReader["Calle"].ToString();
                this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
                this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
                this.mConfFact.Colonia = lReader["Colonia"].ToString();
                this.mConfFact.Localidad = lReader["Localidad"].ToString();
                this.mConfFact.Referencia = lReader["Referencia"].ToString();
                this.mConfFact.Municipio = lReader["Municipio"].ToString();
                this.mConfFact.Estado = lReader["Estado"].ToString();
                this.mConfFact.Pais = lReader["Pais"].ToString();
                this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
            }

            lConn.Close();
        }

/*
		private int GetCopiasFactura()
		{
			int l_copias = 1;
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;            
			l_cmd.CommandText = "SELECT CopiasFactura FROM confSystem;";		
 
			try
			{
			this.m_conn.Open();
			l_copias = (int)l_cmd.ExecuteScalar();
			
			this.m_conn.Close();
			}
			catch
			{
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}

			return l_copias;			
		}
		
		private void ImprimirFactura()
		{
            try
            {
                //this.printpw.WindowState = FormWindowState.Maximized;

                if (MessageBox.Show("�Desea imprimir ahora?", "Imprimir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                	int l_copias = this.GetCopiasFactura();
                	int i;
                	
                	for(i=0;i<l_copias;i++)
                    	this.printdoc.Print();
                }
                //else
                //{                       
                //    this.printpw.ShowDialog();
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
		}
		
		private string GetEncabezadoNota()
		{
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '002';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            string l_result = l_reader["EncabezadoNota"].ToString();

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
		}		
*/
		private void printdoc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
/*
			this.LoadDocPositions();

            int l_desglosar_iva = this.DesglosarIVA();
			
			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Arial",this.mp_int_TamanioLetra);    
			System.Drawing.Font l_fontcant = new Font("Arial",this.mp_int_TamanioLetra);
            System.Drawing.Font l_fontcanorig = new Font("Arial", 7);
			System.Drawing.Font l_fontcanorighead = new Font("Arial", 7,FontStyle.Bold);

            if (this.m_bool_EsNota == true)
                e.Graphics.DrawString("*******************************************************", l_font, l_brush, 1, 0);

			//Leyenda...
			if(this.mp_string_Leyenda.Trim()!="")
				e.Graphics.DrawString(this.mp_string_Leyenda,l_font,l_brush,5,5);

            if (this.m_bool_EsNota == true)
            {
				string[] lLineas = this.GetEncabezadoNota().Split('|');
				int lStart = 30;
				
				foreach(string lLine in lLineas)
				{
					if( lLine.Trim() == "" )
						continue;
					
					e.Graphics.DrawString(lLine, l_font, l_brush, 5, lStart);
					lStart+=10;
				}

                e.Graphics.DrawString("*******************************************************", l_font, l_brush, 1, 100);
            }

            if (this.mp_int_PosNumFactX != -1)
                e.Graphics.DrawString("No. " + this.m_numfac, l_font, l_brush, this.mp_int_PosNumFactX, this.mp_int_PosNumFactY);   			 

			//Nombre
			if(this.mp_int_PosNombreX != -1)
				e.Graphics.DrawString(this.txt_nombre.Text,l_font,l_brush,this.mp_int_PosNombreX,this.mp_int_PosNombreY);   			 

			//Direcci�n
			if(this.mp_int_PosDireccionX != -1)
				e.Graphics.DrawString(this.txt_dir.Text,l_font,l_brush,this.mp_int_PosDireccionX,this.mp_int_PosDireccionY);   			 

			//Ciudad
			if(this.mp_int_PosCiudadX != -1)
				e.Graphics.DrawString(this.m_ciudad,l_font,l_brush,this.mp_int_PosCiudadX,this.mp_int_PosCiudadY);   			 

			//Fecha
			if(this.mp_int_PosFechaX != -1)
				e.Graphics.DrawString( this.m_now.ToString()  ,l_font,l_brush,this.mp_int_PosFechaX,this.mp_int_PosFechaY);   			 

			//RFC
			if(this.mp_int_PosRFCX != -1)
				e.Graphics.DrawString(this.txt_rfc.Text,l_font,l_brush,this.mp_int_PosRFCX,this.mp_int_PosRFCY);   			 
	 
			
			System.Int32 i;
			System.Int32 l_pos = 0;

			System.Double l_d1,l_d2;
			System.String l_s1,l_s2;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_pos = i*this.mp_int_EspacioDetalle;

				//C�digo
				if(this.mp_int_PosCodigoX != -1)
					e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][2].ToString(),l_font,l_brush,this.mp_int_PosCodigoX,this.mp_int_PosCodigoY+l_pos);   		
				//Cantidad
				if(this.mp_int_PosCantidadX != -1)
                    e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][6].ToString() + " " + this.m_detail.Tables[0].Rows[i][10].ToString(), l_font, l_brush, this.mp_int_PosCantidadX, this.mp_int_PosCantidadY + l_pos);   		
				//Descripci�n
                if (this.mp_int_PosDescripcionX != -1)//Aqui muevele rich
                {
                    if (this.m_detail.Tables[0].Rows[i][3].ToString().Length>15)
                        e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][3].ToString().Substring(0, 15), l_font, l_brush, this.mp_int_PosDescripcionX, this.mp_int_PosDescripcionY + l_pos);
                    else
                        e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][3].ToString(), l_font, l_brush, this.mp_int_PosDescripcionX, this.mp_int_PosDescripcionY + l_pos);
                    
                }
				l_d1 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][5].ToString());  
				l_d2 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][8].ToString());  

				l_s1 = System.String.Format("{0:C}",l_d1);
				l_s2 = System.String.Format("{0:C}",l_d2);
 		
				//Precio
				if(this.mp_int_PosPrecioX != -1)
					e.Graphics.DrawString(l_s1,l_font,l_brush,this.mp_int_PosPrecioX,this.mp_int_PosPrecioY+l_pos);   		
				//Total
				if(this.mp_int_PosTotalX != -1)
					e.Graphics.DrawString(l_s2,l_font,l_brush,this.mp_int_PosTotalX,this.mp_int_PosTotalY+l_pos);   		
			}

			System.Double l_total=0;
			System.Double l_iva=0;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				l_iva = l_iva + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][9].ToString() ) - System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

            if (l_desglosar_iva == 1)
            {

                //subtotal
                if (this.mp_int_PosSubTotalX != -1)
                {
                    if (this.mp_int_PosSubTotalY == -2)
                    {
                        l_pos += 20;
                        e.Graphics.DrawString("SUBTOTAL", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_total), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        l_pos += this.mp_int_EspacioDetalle;
                    }
                    else
                    {
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_total), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosSubTotalY);
                    }
                }

                //Iva
                //l_iva = l_total*this.mp_IVA;
                //l_iva = System.Math.Round(l_iva,2);  
                if (this.mp_int_PosIVAX != -1)
                {
                    if (this.mp_int_PosIVAY == -2)
                    {
                        e.Graphics.DrawString("IVA", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        l_pos += this.mp_int_EspacioDetalle;
                    }
                    else
                    {
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosIVAY);
                        l_pos += this.mp_int_EspacioDetalle;
                    }
                }

            }
            else 
            {
                l_pos += this.mp_int_EspacioDetalle;
            }

			//Total
			l_total = l_total + l_iva;
			l_total = System.Math.Round(l_total,2);  
			if(this.mp_int_PosGTotalX != -1)
			{
				if(this.mp_int_PosGTotalY == -2)
				{
					e.Graphics.DrawString("TOTAL",l_font,l_brush,this.mp_int_PosSubTotalX - 100,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   			 
					e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   		
				}
				else
				{
					e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosGTotalY);   		
				}
			}

            if (this.m_bool_EsNota == false)
            {
                if (this.mp_int_PosCadenaOriginalX != -1)
                {
                    if (this.mp_int_PosCadenaOriginalY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
						e.Graphics.DrawString("Cadena Original",
                                l_fontcanorighead, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY );
						
                        while (lPos < this.m_cadena_original.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_cadena_original.Length)
                                lPosEnd = this.m_cadena_original.Length;

                            e.Graphics.DrawString(this.m_cadena_original.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }

        //int mp_int_PosSelloX = 0;
        //int mp_int_PosSelloY = 0; 

            if (this.m_bool_EsNota == false)
            {
                if (this.mp_int_PosSelloX != -1)
                {
                    if (this.mp_int_PosSelloY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
                            e.Graphics.DrawString("Sello Digital",
                                l_fontcanorighead, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY );						
						
                        while (lPos < this.m_sello.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_sello.Length)
                                lPosEnd = this.m_sello.Length;

                            e.Graphics.DrawString(this.m_sello.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }


            if (this.m_bool_EsNota == true)
                e.Graphics.DrawString("PAGO EN UNA SOLA EXHIBICION", l_font, l_brush, 3, this.mp_int_PosTotalY + l_pos + 40);

            if (this.mp_string_mensaje != "" && this.m_bool_EsNota == true)
                e.Graphics.DrawString(this.mp_string_mensaje, l_font, l_brush, 3, this.mp_int_PosTotalY + l_pos + 60); 

            /////////////////////////////////////////////////////////
            //Factura electronica
            if (this.m_bool_EsNota == false)
            {
 
            }
            /////////////////////////////////////////////////////////

			//Total en letras

			//Separar los centavos...
			System.Double l_centavos;

			l_total = l_total * 100;
			l_centavos = l_total % 100;
            l_total = l_total - l_centavos;
			l_total = l_total / 100;

			l_total = System.Math.Round(l_total,2);

			System.String l_cantidad;

			l_cantidad = this.GetStringValue(System.String.Format("{0:C}",l_total));

			if(l_centavos > 0)
			{
				System.String l_cantcent = System.String.Format(" {0}/100",System.Math.Round(l_centavos,2));
				l_cantidad = l_cantidad + l_cantcent;
			}

			l_cantidad = l_cantidad + " MN";
			if(this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY != -2)
				    e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,this.mp_int_PosGTotalLetrasX,this.mp_int_PosGTotalLetrasY);


            if (this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY == -2)
                    e.Graphics.DrawString(l_cantidad, l_fontcant, l_brush, this.mp_int_PosGTotalLetrasX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle + 13); 
*/			
		}
/*
        private int DesglosarIVA()
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            int l_result = Convert.ToInt32(l_reader["DesglosarIva"]);

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
        }

		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 
            string l_retval = "";

			clsUtils.cUtils l_utils = new clsUtils.cUtils();

            if ( Convert.ToDouble(l_num) < 1 )
                l_retval = "CERO PESOS " + l_utils.Transforma(l_num);
            else
			    l_retval = l_utils.Transforma(l_num);

            return l_retval;
		}
*/
        private void ll_nuevo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_nuevo_Click(sender, e);
        }

        private void ll_buscar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_buscar_Click(sender, e);
        }
/*
        private void ll_agregar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.txt_nombre.Text.Trim() == "")
            {
                MessageBox.Show("Seleccione primero un cliente!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.cmd_agregar_Click(sender, e);
        }
*/
        private void ll_borrar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //this.cmd_borrar_Click(sender, e);
        }

        private void ll_generar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_generar_Click(sender, e);
        }

        private void ll_cancelar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cdm_cerrar_Click(sender, e);
        }

        private void frm_notascred_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
            	case Keys.Delete:
            		//this.cmd_borrar_Click(sender, e);
            		e.Handled = true;
            		break;
                case Keys.F1:
                    //this.ll_producto_LinkClicked(sender, null);
                    //this.txt_cantidad.SelectAll();
                    //this.txt_cantidad.Focus();
                    break;
                case Keys.F2:
                    //this.ll_agregar_LinkClicked(sender, null);
                    break;
                case Keys.F6:
                    this.cmd_nuevo_Click(sender, e);
                    break;
                case Keys.F7:
                    this.ll_buscar_LinkClicked(sender, null);
                    break;
                case Keys.F8:
                    //this.chk_credito.Checked = !this.chk_credito.Checked;
                    /*
                    // SVM Dic2010  ahora las notas tambien funcionan a credito
                    if (this.m_bool_EsNota == false)
                        this.chk_credito.Checked = !this.chk_credito.Checked;
                    */
                    break;
                case Keys.F10:
                    this.ll_generar_LinkClicked(sender, null);
                    break;
                case Keys.Escape:
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        this.Close();
                    break;
            }
        }
/*	        
        #region posiciones de la factura...
        ////////////////////////////////////////////////     
        //Posiciones de la factura...
		int mp_int_PosNombreX = 0;        
		int mp_int_PosNombreY = 0;        
	
		int mp_int_PosDireccionX = 0;        
		int mp_int_PosDireccionY = 0;        

		int mp_int_PosCiudadX = 0;        
		int mp_int_PosCiudadY = 0;        

		int mp_int_PosRFCX = 0;        
		int mp_int_PosRFCY = 0;        

		int mp_int_PosNumFactX = 0;        
		int mp_int_PosNumFactY = 0;        

		int mp_int_PosFechaX = 0;        
		int mp_int_PosFechaY = 0;        
		
		int mp_int_PosCodigoX = 0;        
		int mp_int_PosCodigoY = 0;        

		int mp_int_PosCantidadX = 0;        
		int mp_int_PosCantidadY = 0;        

		int mp_int_PosDescripcionX = 0;        
		int mp_int_PosDescripcionY = 0;        

		int mp_int_PosPrecioX = 0;        
		int mp_int_PosPrecioY = 0;        
		
		int mp_int_PosTotalX = 0;        
		int mp_int_PosTotalY = 0;        
		
		int mp_int_PosSubTotalX = 0;        
		int mp_int_PosSubTotalY = 0;        
		
		int mp_int_PosIVAX = 0;        
		int mp_int_PosIVAY = 0;        

		int mp_int_PosGTotalX = 0;        
		int mp_int_PosGTotalY = 0;

        int mp_int_PosCadenaOriginalX = 0;
        int mp_int_PosCadenaOriginalY = 0;

        int mp_int_PosSelloX = 0;
        int mp_int_PosSelloY = 0; 
		
		int mp_int_PosGTotalLetrasX = 0;        
		int mp_int_PosGTotalLetrasY = 0;        
		
		int mp_int_EspacioDetalle = 0;
		int mp_int_TamanioLetra = 0;		
		
		string mp_string_Leyenda = "";
		
		#endregion

        string mp_string_mensaje = "";

		private void LoadDocPositions()
		{
			try
			{
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				
				if(this.m_bool_EsNota == false)
					l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '001'";
				else
					l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '002'";

				this.m_conn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//PosNombre					
					l_temp = l_reader["PosNombre"].ToString().Split(',');
					this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);
					
					//PosDireccion
					l_temp = l_reader["PosDireccion"].ToString().Split(',');
					this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);
					
					//PosCiudad
					l_temp = l_reader["PosCiudad"].ToString().Split(',');
					this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);
					
					//PosRFC
					l_temp = l_reader["PosRFC"].ToString().Split(',');
					this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);
					
					//PosNumFact
					l_temp = l_reader["PosNumFact"].ToString().Split(',');
					this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);
					
					//PosFecha
					l_temp = l_reader["PosFecha"].ToString().Split(',');
					this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);
					
					//PosCodigo
					l_temp = l_reader["PosCodigo"].ToString().Split(',');
					this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);
					
					//PosCantidad
					l_temp = l_reader["PosCantidad"].ToString().Split(',');
					this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);
					
					//PosDescripcion
					l_temp = l_reader["PosDescripcion"].ToString().Split(',');
					this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);
					
					//PosPrecio
					l_temp = l_reader["PosPrecio"].ToString().Split(',');
					this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);
					
					//PosTotal
					l_temp = l_reader["PosTotal"].ToString().Split(',');
					this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosSubtotal
					l_temp = l_reader["PosSubtotal"].ToString().Split(',');
					this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosIVA
					l_temp = l_reader["PosIVA"].ToString().Split(',');
					this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotal
					l_temp = l_reader["PosGTotal"].ToString().Split(',');
					this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotalLetras
					l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
					this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);

                    //PosCadenaOriginal
                    l_temp = l_reader["PosCadenaOriginal"].ToString().Split(',');
                    this.mp_int_PosCadenaOriginalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCadenaOriginalY = Convert.ToInt32(l_temp[1]);

                    //PosSello
                    l_temp = l_reader["PosSello"].ToString().Split(',');
                    this.mp_int_PosSelloX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSelloY = Convert.ToInt32(l_temp[1]);
					
					//EspacioDetalle
					this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());
					
					//TamanioLetra
					this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());
					
					//Leyenda
					this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                    //Mensaje
                    this.mp_string_mensaje = l_reader["mensaje"].ToString();
					
				}
				
				l_reader.Close();				
			
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}
*/		
		double mp_IVA = 0.15;
		string mp_clientenotas = "";
        int mp_usa_iva_por_articulo = 0;
        int mp_usa_existencia0 = 0;
		
		private void LoadSystemValues()
		{
			try
			{
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				
				l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001'";

				this.m_conn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//IVA					
					this.mp_IVA = Convert.ToDouble(l_reader["IVA"]);
                    this.mp_iva_to_store = Convert.ToInt32( Convert.ToDouble(l_reader["IVA"])*100 );
					
					//Cliente Notas
					this.mp_clientenotas = l_reader["ClienteNotas"].ToString();

                    //Usa Iva por articulo?
                    this.mp_usa_iva_por_articulo = Convert.ToInt32(l_reader["UsarIvaPorArtic"]);

                    //Usa Iva por articulo?
                    this.mp_usa_existencia0 = Convert.ToInt32(l_reader["UsarExistencia0"]);
					
				}
				
				l_reader.Close();				
			
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}
		
/*		
		void Lnk_directpriceLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			
			if( this.txt_concepto.Text.Trim()=="" )
			{
				MessageBox.Show("Seleccione primero un articulo","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			
			frm_precio l_frm_price = new frm_precio();
			if( l_frm_price.ShowDialog() == DialogResult.OK )
			{
				//MessageBox.Show( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") );
				//this.txt_total.Text = Convert.ToDouble( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") ).ToString();
                this.txt_total.Text = "";

                try
                {
                this.m_curprice = Convert.ToDouble( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") );
                this.m_orprice = this.m_curprice;
                System.Double l_total = 0; // Convert.ToDouble(l_frm_price.txt_precio.Text.Replace("$", "").Replace(",", "")) * Convert.ToDouble(this.txt_cantidad.Text);
				l_total = System.Math.Round(l_total ,2);
				this.txt_subtotal.Text = l_total.ToString();
                
                this.txt_total.Text = Convert.ToString(System.Math.Round(l_total * (1 + this.mp_IVA), 2));
                }
                catch{}
				
			}
		}
*/		
		void Txt_conceptoKeyDown(object sender, KeyEventArgs e)
		{
			if(e.KeyCode == Keys.Enter)
			{
                if (this.txt_nombre.Text.Trim() == "")
                {
                    MessageBox.Show("Seleccione primero un cliente!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                //this.cmd_agregar_Click(sender, e);
			}
		}
/*				
		void Txt_cantidadKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Enter )
			{
	            if (this.txt_nombre.Text.Trim() == "")
	            {
	                MessageBox.Show("Seleccione primero un cliente!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
	                return;
	            }
	
	            this.cmd_agregar_Click(sender, e);				
			}
		}
*/
        private void txt_total_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.txt_total_Validated(sender, e);
            }
        }

        private void CalculSubtotal()
        { 
            this.txt_total.Text = Math.Round(Convert.ToDouble(this.txt_total.Text),2).ToString();
            this.txt_subtotal.Text = Math.Round(Convert.ToDouble(this.txt_total.Text) / (1 + this.mp_IVA),2).ToString();

            this.ll_generar.Visible = true;
        }

        private void txt_total_Validated(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(this.txt_total.Text) < 0.0)
                {
                    MessageBox.Show("Dato inv�lido!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            catch
            {
                MessageBox.Show("Dato inv�lido!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            //this.cmd_agregar_Click(sender, e);
            CalculSubtotal();

        }
		
	}
}
