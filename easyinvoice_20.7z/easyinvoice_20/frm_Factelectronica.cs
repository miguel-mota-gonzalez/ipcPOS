using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using clsFactElectronica;

namespace EasyInvoice
{
    public partial class frm_Factelectronica : Form
    {
        public frm_Factelectronica()
        {
            InitializeComponent();
        }

        private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();

        private void frm_Factelectronica_Load(object sender, EventArgs e)
        {
			this.LoadData();
            this.pGrid.SelectedObject = this.mConfFact;
        }
		
		private void SaveData()
		{
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "UPDATE confFacturaElectronica SET Version=?,Serie=?,Numero_de_Aprobacion=?,Anio_Aprobacion=?,Tipo_de_Comprobante=?,RFC=?,Razon_Social=?,Calle=?,Numero_Exterior=?,Numero_Interior=?,Colonia=?,Localidad=?,Referencia=?,Municipio=?,Estado=?,Pais=?,Codigo_Postal=?,Numero_Certificado=? WHERE iidconfsystem = 1";

			lCmd.Parameters.AddWithValue("@Version",this.mConfFact.Version);
			lCmd.Parameters.AddWithValue("@Serie",this.mConfFact.Serie);
			lCmd.Parameters.AddWithValue("@Numero_de_Aprobacion",this.mConfFact.Numero_de_Aprobacion);
			lCmd.Parameters.AddWithValue("@Anio_Aprobacion",this.mConfFact.Anio_Aprobacion);
			lCmd.Parameters.AddWithValue("@Tipo_de_Comprobante",this.mConfFact.Tipo_de_Comprobante);
			lCmd.Parameters.AddWithValue("@RFC",this.mConfFact.RFC);
			lCmd.Parameters.AddWithValue("@Razon_Social",this.mConfFact.Razon_Social);
			lCmd.Parameters.AddWithValue("@Calle",this.mConfFact.Calle);
			lCmd.Parameters.AddWithValue("@Numero_Exterior",this.mConfFact.Numero_Exterior);
			lCmd.Parameters.AddWithValue("@Numero_Interior",this.mConfFact.Numero_Interior);
			lCmd.Parameters.AddWithValue("@Colonia",this.mConfFact.Colonia);
			lCmd.Parameters.AddWithValue("@Localidad",this.mConfFact.Localidad);
			lCmd.Parameters.AddWithValue("@Referencia",this.mConfFact.Referencia);
			lCmd.Parameters.AddWithValue("@Municipio",this.mConfFact.Municipio);
			lCmd.Parameters.AddWithValue("@Estado",this.mConfFact.Estado);
			lCmd.Parameters.AddWithValue("@Pais",this.mConfFact.Pais);
			lCmd.Parameters.AddWithValue("@Codigo_Postal",this.mConfFact.Codigo_Postal);
			lCmd.Parameters.AddWithValue("@Numero_Certificado",this.mConfFact.Numero_Certificado);
			
			lConn.Open();
			lCmd.ExecuteNonQuery();
			lConn.Close();
			
		}
		
		private void LoadData()
		{
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

			lConn.Open();
			System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();
            
			if( lReader.Read() )
			{
				this.mConfFact.Version = lReader["Version"].ToString();
				this.mConfFact.Serie = lReader["Serie"].ToString();
				this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
				this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
				this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
				this.mConfFact.RFC = lReader["RFC"].ToString();
				this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
				this.mConfFact.Calle = lReader["Calle"].ToString();
				this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
				this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
				this.mConfFact.Colonia = lReader["Colonia"].ToString();
				this.mConfFact.Localidad = lReader["Localidad"].ToString();
				this.mConfFact.Referencia = lReader["Referencia"].ToString();
				this.mConfFact.Municipio = lReader["Municipio"].ToString();
				this.mConfFact.Estado = lReader["Estado"].ToString();
				this.mConfFact.Pais = lReader["Pais"].ToString();
				this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
				this.mConfFact.Numero_Certificado = lReader["Numero_Certificado"].ToString();
				
			}
			
			lConn.Close();			
		}

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdGuardar_Click(object sender, EventArgs e)
        {
			this.SaveData();
			this.Close();
        }
    }

}
