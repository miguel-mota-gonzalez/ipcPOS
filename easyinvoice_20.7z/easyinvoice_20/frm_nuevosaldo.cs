using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_nuevosaldo : Form
    {
        public frm_nuevosaldo()
        {
            InitializeComponent();
        }
        
        void Frm_nuevosaldoLoad(object sender, EventArgs e)
        {
        	
        }
        
        void Frm_nuevosaldoKeyDown(object sender, KeyEventArgs e)
        {
        	
        }
    }
}
