using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_ProductosProv : Form
    {
        public int mIdProducto = -1;
		public System.Collections.Generic.SortedList<string,int> mProveedores = new System.Collections.Generic.SortedList<string, int>();

        public frm_ProductosProv()
        {
            InitializeComponent();
        }

        public void FillDataSet()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
			
			this.mProveedores.Clear();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "select cp.Nombre,cp.IdProveedor from relProductoProveedor rpp  inner join catProveedores cp on rpp.IdProveedor = cp.IdProveedor where rpp.IdProducto = " + this.mIdProducto.ToString();

                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                while (lReader.Read())
                {
                    this.lbProveedores.Items.Add(lReader["Nombre"]);
					this.mProveedores.Add(lReader["Nombre"].ToString(),Convert.ToInt32(lReader["IdProveedor"]));
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_ProductosProv_Load(object sender, EventArgs e)
        {
			this.cmdGuardar.Visible = false;
        }

        private void cmdGuardar_Click(object sender, EventArgs e)
        {

        }

        private void cmdBorrar_Click(object sender, EventArgs e)
        {
            List<object> lItemsToDelete=new List<object>();
			foreach(object lItem in this.lbProveedores.SelectedItems)
			{
                lItemsToDelete.Add(lItem);
            }
			foreach(object lItem in lItemsToDelete)
			{
				int lProvToDelete = this.mProveedores[lItem.ToString()];
				
				/////////////////////////////////////////////
            	System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            	System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();				
				
				try
				{
				
					lConn.ConnectionString = frm_Main.mps_strconnection;
					lConn.Open();
					
					lCmd.Connection = lConn;
					lCmd.CommandText = "DELETE FROM relProductoProveedor WHERE IdProducto = " + this.mIdProducto.ToString() + " and IdProveedor = " + lProvToDelete.ToString();
					
					lCmd.ExecuteNonQuery();
					
					this.lbProveedores.Items.Remove(lItem);
				}
				catch(System.Exception ex)
				{
					MessageBox.Show("Error : " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					
				}
				finally
				{
					if( lConn.State == ConnectionState.Open)
					{
						lConn.Close();
					}
				}				
				/////////////////////////////////////////////
			}
        }

        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            frm_listaprovadd lFrm = new frm_listaprovadd();
			lFrm.mIdProducto = this.mIdProducto;
            if( lFrm.ShowDialog() == DialogResult.OK)
			{
            	System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            	System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();				
				System.Data.Odbc.OdbcTransaction lTransaction = null;
				
				try
				{
				
					lConn.ConnectionString = frm_Main.mps_strconnection;
					lConn.Open();

                    lTransaction = lConn.BeginTransaction(System.Data.IsolationLevel.Serializable);
					
					lCmd.Connection = lConn;
					lCmd.Transaction = lTransaction;
					lCmd.CommandText = "DELETE FROM relProductoProveedor WHERE IdProducto = " + this.mIdProducto.ToString();
					
					lCmd.ExecuteNonQuery();
					
					foreach(int lIdProveedor in lFrm.mProveedoresSeleccionados)
					{
						System.Data.Odbc.OdbcCommand lCmd1 = new System.Data.Odbc.OdbcCommand();
						lCmd1.Connection = lConn;
						lCmd1.Transaction = lTransaction;
						lCmd1.CommandText = "INSERT INTO relProductoProveedor(IdProducto,IdProveedor) VALUES(" + this.mIdProducto.ToString() + "," + lIdProveedor.ToString() + ")";
						lCmd1.ExecuteNonQuery();
					}
				
					lTransaction.Commit();
					
					this.lbProveedores.Items.Clear();
					
					foreach(string lPName in lFrm.mProveedoresSeleccionadosName)
					{
						this.lbProveedores.Items.Add( lPName );
					}
					
				}
				catch(System.Exception ex)
				{
					if( lTransaction != null )
						lTransaction.Rollback();
					
					MessageBox.Show("Error : " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					
				}
				finally
				{
					if( lConn.State == ConnectionState.Open)
					{
						lConn.Close();
					}
				}
				
			}
        }
    }
}
