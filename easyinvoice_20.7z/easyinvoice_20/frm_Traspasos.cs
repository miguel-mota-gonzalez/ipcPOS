﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_Traspasos : Form
    {
        public frm_TraspasosList frm_TraspPrin = null;
        public System.Int32 m_KeyRecord;

        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        private System.Data.Odbc.OdbcConnection m_conn = null;
        private System.Data.Odbc.OdbcDataAdapter m_da;
        private System.Data.Odbc.OdbcCommand m_select;

        private System.Data.DataSet m_dataset = null;
        public bool m_IsModified = false;
        public bool mp_Loading = false;
        private System.Collections.SortedList slAlmacenes = null;

        public frm_Traspasos()
        {
            InitializeComponent();
            this.m_KeyRecord = -1;
        }

        public frm_Traspasos(System.Int32 p_KeyRecord)
        {
            InitializeComponent();
            this.m_KeyRecord = p_KeyRecord;
        }

        private void frm_Traspasos_Load(object sender, EventArgs e)
        {
            this.mp_Loading = true;

            this.FillComboAlmacenes();
            if (slAlmacenes.Count <= 1)
            {
                MessageBox.Show("Número de almacenes insuficientes", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            this.FillTraspaso();

            this.mp_Loading = false;
        }

        private void FillTraspaso()
        {
            try
            {

                if (this.m_KeyRecord == -1)
                {
                    this.cmb_AlmacenOrig.SelectedIndex = 0;
                    this.dateTimePicker1.Value = System.DateTime.Today;
                    this.txt_observs.Text = "";
                    this.txt_cantidad.Value = 1;
                    this.cmb_AlmacenDest.SelectedIndex = 1;
                }
                else
                {
                    this.m_conn = new System.Data.Odbc.OdbcConnection();
                    this.m_conn.ConnectionString = frm_Main.mps_strconnection;

                    this.m_select = new System.Data.Odbc.OdbcCommand();
                    this.m_select.Connection = this.m_conn;

                    this.m_select.CommandText = "Select * From catTraspasos where idTraspaso = " + this.m_KeyRecord.ToString() + ";";

                    this.m_da = new System.Data.Odbc.OdbcDataAdapter();
                    this.m_da.SelectCommand = this.m_select;
                    this.m_dataset = new System.Data.DataSet();
                    this.m_da.Fill(this.m_dataset);
                }

                this.FillData();

            }
            catch
            {
            }
            finally
            {
                if (this.m_conn != null)
                {
                    if (this.m_conn.State == System.Data.ConnectionState.Open)
                    {
                        this.m_conn.Close();
                    }
                }
            }

        }

        private void FillData()
        {
            if (this.m_KeyRecord != -1)
            {
                if (slAlmacenes.ContainsKey(this.m_dataset.Tables[0].Rows[0]["idAlmacenOrig"].ToString()))
                {
                    this.cmb_AlmacenOrig.Text = slAlmacenes[this.m_dataset.Tables[0].Rows[0]["idAlmacenOrig"].ToString()].ToString();
                }
                else
                {
                    this.cmb_AlmacenOrig.Text = "";
                }
                this.dateTimePicker1.Value = (DateTime)this.m_dataset.Tables[0].Rows[0]["Fecha"];
                this.txt_observs.Text = this.m_dataset.Tables[0].Rows[0]["Observaciones"].ToString();
            }

            // lee detalle
            this.FillTraspasoDetalle();

            this.cmb_AlmacenOrig.Enabled = (this.m_KeyRecord == -1);
            this.cmb_AlmacenDest.Enabled = (this.m_KeyRecord == -1);
            this.dateTimePicker1.Enabled = (this.m_KeyRecord == -1);
            this.txt_observs.Enabled = (this.m_KeyRecord == -1);
            this.txt_codigo.Enabled = (this.m_KeyRecord == -1);
            this.txt_cantidad.Enabled = (this.m_KeyRecord == -1);
            //this.dataGridView1.Enabled = (this.m_KeyRecord == -1);
            this.cmd_save.Visible = (this.m_KeyRecord == -1);
            this.cmd_delete.Visible = (this.m_KeyRecord == -1);
            // this.cmd_Generar.Visible = (this.m_KeyRecord == -1);
        }

        private void FillTraspasoDetalle()
        {
            try
            {

                this.m_conn = new System.Data.Odbc.OdbcConnection();
                this.m_conn.ConnectionString = frm_Main.mps_strconnection;

                this.m_select = new System.Data.Odbc.OdbcCommand();
                this.m_select.Connection = this.m_conn;

                this.m_select.CommandText = "Select detTraspasos.idProducto, idAlmacenDest, catProductos.codigo, catProductos.descripcion, cantidad, catAlmacenes.Descripcion as Almacen_Destino , catProductos.UnidadVenta, catProductos.Marca, catProductos.PrecioProveedor, detTraspasos.Solicitado, detTraspasos.Estado From detTraspasos left join catAlmacenes on detTraspasos.idAlmacenDest=catAlmacenes.idAlmacen left join catProductos on detTraspasos.idProducto=catProductos.idProducto where idTraspaso = " + this.m_KeyRecord.ToString() + ";";

                this.m_da = new System.Data.Odbc.OdbcDataAdapter();
                this.m_da.SelectCommand = this.m_select;
                this.m_dataset = new System.Data.DataSet();
                this.m_da.Fill(this.m_dataset);
                this.m_dataset.Tables[0].TableName = "detalle";
                DataColumn[] keys = new DataColumn[2];
                keys[0] = this.m_dataset.Tables[0].Columns["idProducto"];
                keys[1] = this.m_dataset.Tables[0].Columns["idAlmacenDest"];
                this.m_dataset.Tables[0].PrimaryKey = keys;

                if (this.m_KeyRecord != -1)
                {
                    if (slAlmacenes.ContainsKey(this.m_dataset.Tables[0].Rows[0]["idAlmacenDest"].ToString()))
                    {
                        this.cmb_AlmacenDest.Text = slAlmacenes[this.m_dataset.Tables[0].Rows[0]["idAlmacenDest"].ToString()].ToString();
                    }
                    else
                    {
                        this.cmb_AlmacenDest.Text = "";
                    }
                }

                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;
                this.dataGridView1.Columns[1].Visible = false;
                this.dataGridView1.Columns[2].Width = 80;
                this.dataGridView1.Columns[3].Width = 250;
                this.dataGridView1.Columns[4].Width = 80;
                this.dataGridView1.Columns[4].DefaultCellStyle.Format = "###,##0.00";
                this.dataGridView1.Columns[5].Visible = false;  // almacen_destino
                this.dataGridView1.Columns[6].HeaderText = "Unidad";
                this.dataGridView1.Columns[8].Visible = false;  // precioproveedor
                this.dataGridView1.Columns[9].DefaultCellStyle.Format = "###,##0.00";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (this.m_conn != null)
                {
                    if (this.m_conn.State == System.Data.ConnectionState.Open)
                    {
                        this.m_conn.Close();
                    }
                }
            }

        }



        private void FillComboAlmacenes()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            l_cmd.Connection = l_conn;

            this.cmb_AlmacenOrig.Items.Clear();
            this.cmb_AlmacenDest.Items.Clear();
            slAlmacenes = new System.Collections.SortedList();

            try
            {
                l_conn.Open();

                l_cmd.CommandText = "SELECT IdAlmacen, Descripcion FROM catAlmacenes;";
                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();
                //l_rdr = l_cmd.ExecuteReader();
                while (l_rdr.Read())
                {
                    slAlmacenes.Add(l_rdr["IdAlmacen"].ToString(), l_rdr["Descripcion"].ToString());

                    if (System.Convert.ToInt32(l_rdr["IdAlmacen"]) < 3)
                    {
                    cmb_AlmacenOrig.Items.Add(l_rdr["Descripcion"].ToString());
                    }

                    if (System.Convert.ToInt32(l_rdr["IdAlmacen"]) < 3)
                    {
                    cmb_AlmacenDest.Items.Add(l_rdr["Descripcion"].ToString());
                    }
                }
                l_rdr.Close();

                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }



        void TextBox1KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                frm_productoslist l_frmProductos = new frm_productoslist();
                l_frmProductos.cmd_nuevo.Enabled = false;
                l_frmProductos.ShowDialog();

                if (l_frmProductos.m_KeyRecord != -1)
                {
                    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                    l_recid.Connection = this.m_conn;
                    l_recid.CommandText = "SELECT Codigo FROM catProductos WHERE IdProducto = ?;";
                    l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@IdProducto", l_frmProductos.m_KeyRecord));

                    this.m_conn.Open();
                    System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();
                    l_reader.Read();

                    this.txt_codigo.Text = l_reader["Codigo"].ToString();

                    l_reader.Close();
                    this.m_conn.Close();

                }
                return;
            }

            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    if (cmb_AlmacenOrig.Text == cmb_AlmacenDest.Text)
                    {
                        MessageBox.Show("El almacen destino debe ser diferente del almacen origen", "Información", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                    //Buscar el articulo...
                    System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                    l_recid.Connection = this.m_conn;
                    l_recid.CommandText = "SELECT catProductos.*, catExistencias.Existencia as existenc_almacen FROM catProductos LEFT JOIN catExistencias ON catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=? WHERE Codigo = ?;";
                    l_recid.Parameters.AddWithValue("@IdAlmacen", slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenOrig.Text)));
                    l_recid.Parameters.Add(new System.Data.Odbc.OdbcParameter("@Codigo", this.txt_codigo.Text));

                    this.m_conn.Open();
                    System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();

                    if (l_reader.Read() == false)
                    {
                        l_reader.Close();
                        this.m_conn.Close();
                        this.lbl_msg.Text = "";
                        MessageBox.Show("El árticulo no existe", "Información", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                    else
                    {
                        string l_descripcion = l_reader["Descripcion"].ToString();
                        System.Decimal existen = 0;
                        System.Decimal solicitado = 0;
                        this.lbl_msg.Text = this.txt_cantidad.Value.ToString() + " Agregado(s) - " + l_reader["Descripcion"].ToString();

                        //Determinar existencia en almacen origen
                        try
                        {
                            existen = Convert.ToDecimal(l_reader["existenc_almacen"]);
                        }
                        catch
                        {
                            existen = 0;
                        }
                        this.lbl_Existencia.Text = "Actual " + Convert.ToDecimal(existen).ToString("####,##0.00");
                        this.lbl_Result.Text = "Final " + Convert.ToDecimal(existen - this.txt_cantidad.Value).ToString("####,##0.00");
                        solicitado = Convert.ToDecimal(this.txt_cantidad.Value);
                        if (existen < this.txt_cantidad.Value)
                        {
                            DialogResult res = DialogResult.No;
                            if (existen > Convert.ToDecimal(0.0))
                            {
                                res = MessageBox.Show("No se tiene la cantidad suficiente de productos (" + this.lbl_Existencia.Text + ") en el almacen " + this.cmb_AlmacenOrig.Text + ", desea traspasar todo el inventario?", "Información", MessageBoxButtons.YesNo , MessageBoxIcon.Question);
                            }
                            else
                            {
                                MessageBox.Show("No se tiene la cantidad suficiente de productos (" + this.lbl_Existencia.Text + ") en el almacen " + this.cmb_AlmacenOrig.Text + " para traspasar", "Información", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                            if (res == DialogResult.No)
                            {
                                return;
                            }
                            else 
                            {
                                this.txt_cantidad.Value = existen;
                                this.lbl_Result.Text = "Final " + Convert.ToDecimal(existen - this.txt_cantidad.Value).ToString("####,##0.00");
                            }
                        }

                        //Agregar al grid
                        //"Select detTraspasos.idProducto, idAlmacenDest, catProductos.codigo, catProductos.descripcion, cantidad, catAlmacenes.Descripcion as Almacen_Destino From detTraspasos left join catAlmacenes on detTraspasos.idAlmacenDest=catAlmacenes.idAlmacen left join catProductos on detTraspasos.idProducto=catProductos.idProducto where idTraspaso = " + this.m_KeyRecord.ToString() + ";";
                        System.Data.DataRow dr;
                        object[] keys = new object[2];
                        keys[0] = l_reader["IdProducto"];
                        keys[1] = slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenDest.Text));
                        dr = this.m_dataset.Tables[0].Rows.Find(keys);
                        if (dr == null)
                        {
                            dr = this.m_dataset.Tables[0].NewRow();
                            dr["idProducto"] = keys[0];
                            dr["idAlmacenDest"] = keys[1];
                            dr["codigo"] = l_reader["Codigo"].ToString();
                            dr["Descripcion"] = l_reader["Descripcion"].ToString();
                            dr["cantidad"] = this.txt_cantidad.Value;
                            dr["Almacen_Destino"] = cmb_AlmacenDest.Text;
                            dr["UnidadVenta"] = l_reader["UnidadVenta"].ToString();
                            dr["Marca"] = l_reader["Marca"].ToString();
                            dr["PrecioProveedor"] = Convert.ToDouble(l_reader["PrecioProveedor"]);
                            dr["Solicitado"] = solicitado;
                            dr["Estado"] = "S";
                            if (Convert.ToDecimal(this.txt_cantidad.Value) < solicitado)
                                dr["Estado"] = "P";
                            if (Convert.ToDecimal(this.txt_cantidad.Value) <= 0)
                                dr["Estado"] = "N";

                            this.m_dataset.Tables[0].Rows.Add(dr);
                        }
                        else
                        {
                            dr["cantidad"] = this.txt_cantidad.Value;
                            dr["Solicitado"] = solicitado;
                            dr["Estado"] = "S";
                            if (Convert.ToDecimal(this.txt_cantidad.Value) < solicitado)
                                dr["Estado"] = "P";
                            if (Convert.ToDecimal(this.txt_cantidad.Value) <= 0)
                                dr["Estado"] = "N";

                        }
                        this.m_dataset.Tables[0].AcceptChanges();

                        l_reader.Close();

                        this.cmb_AlmacenOrig.Enabled = false;
                        this.cmb_AlmacenDest.Enabled = false;
                    }
                }
                catch (Exception ee)
                {
                    MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (this.m_conn.State == System.Data.ConnectionState.Open)
                        this.m_conn.Close();
                }

            }   //if( e.KeyCode == Keys.Enter )
        }


        private void cmd_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_codigo_KeyDown(object sender, KeyEventArgs e)
        {
            this.TextBox1KeyDown(sender, e);
        }

        private void cmd_delete_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow dgRow in this.dataGridView1.SelectedRows)
                {
                    this.dataGridView1.Rows.Remove(dgRow);
                }
                this.m_dataset.Tables[0].AcceptChanges();
                this.cmb_AlmacenOrig.Enabled = (this.m_dataset.Tables[0].Rows.Count <= 0);
                this.cmb_AlmacenDest.Enabled = (this.m_dataset.Tables[0].Rows.Count <= 0);
                this.lbl_msg.Text = "";
                this.lbl_Existencia.Text = "";
                this.lbl_Result.Text = "";

            }
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            int idTrasp = 0;
            int id = 0;
            decimal canttras;
            decimal solicitado;
            Boolean isOk = true;
            List<string> invalids = new List<string>();;
            if (this.dataGridView1.Rows.Count <= 0)
            {
                MessageBox.Show("Debe incluir al menos un artículo para poder registrar el traspaso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction lTransaction = null;
            try
            {
                idTrasp = Convert.ToInt32(slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenOrig.Text)));
                if(this.m_conn==null)
                {
                    this.m_conn = new System.Data.Odbc.OdbcConnection();
                    this.m_conn.ConnectionString = frm_Main.mps_strconnection;
                }
                if(this.m_conn.State == ConnectionState.Closed)
                    this.m_conn.Open();
                lTransaction = this.m_conn.BeginTransaction();
                System.DateTime dtim=new DateTime(this.dateTimePicker1.Value.Year,this.dateTimePicker1.Value.Month,this.dateTimePicker1.Value.Day,DateTime.Now.Hour,DateTime.Now.Minute,DateTime.Now.Second);

                lCmd.Connection = this.m_conn;
                lCmd.Transaction = lTransaction;
                lCmd.CommandText = "INSERT INTO catTraspasos (idAlmacenOrig,Fecha,Observaciones,usuario) VALUES (?,?,?,?);";
                lCmd.Parameters.AddWithValue("@idAlmacenOrig", idTrasp);
                lCmd.Parameters.AddWithValue("@Fecha", dtim);
                lCmd.Parameters.AddWithValue("@Observaciones", this.txt_observs.Text);
                lCmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                lCmd.ExecuteNonQuery();

                lCmd.Parameters.Clear();
                lCmd.Transaction = lTransaction;
                lCmd.CommandText = "SELECT idTraspaso FROM catTraspasos WHERE idAlmacenOrig=? AND Fecha=? AND usuario=?;";
                lCmd.Parameters.AddWithValue("@idAlmacenOrig", idTrasp);
                lCmd.Parameters.AddWithValue("@Fecha", dtim);
                lCmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                id = Convert.ToInt32(lCmd.ExecuteScalar());

                foreach (DataGridViewRow rw in this.dataGridView1.Rows)
                {
                    // VALIDAR EXISTENCIAS!!
                    solicitado = Convert.ToDecimal(rw.Cells["Solicitado"].Value);
                    canttras=this.LeeDescontableAlmacen(Convert.ToInt32(rw.Cells["IdProducto"].Value), idTrasp, Convert.ToDecimal(rw.Cells["Cantidad"].Value), this.m_conn, lTransaction);
                    //if (canttras > 0)
                    //{
                        if (canttras != Convert.ToDecimal(rw.Cells["Cantidad"].Value))
                        {
                            invalids.Add(String.Format("El traspaso del producto {0} {1} solo se genero por {2}", rw.Cells["Codigo"].Value, rw.Cells["Descripcion"].Value, canttras.ToString("####,##0.00")));
                            rw.Cells["Cantidad"].Value = canttras;
                        }
                        lCmd = new System.Data.Odbc.OdbcCommand();
                        lCmd.Connection = this.m_conn;
                        lCmd.Parameters.Clear();
                        lCmd.Transaction = lTransaction;
                        lCmd.CommandText = "INSERT INTO detTraspasos (IdTraspaso,IdProducto,Cantidad,idAlmacenDest,Solicitado,Estado) VALUES (?,?,?,?,?,?);";
                        lCmd.Parameters.AddWithValue("@IdTraspaso", id);
                        lCmd.Parameters.AddWithValue("@IdProducto", rw.Cells["IdProducto"].Value);
                        lCmd.Parameters.AddWithValue("@Cantidad", rw.Cells["Cantidad"].Value);
                        lCmd.Parameters.AddWithValue("@idAlmacenDest", rw.Cells["idAlmacenDest"].Value);
                        lCmd.Parameters.AddWithValue("@Solicitado", solicitado);
                        if (canttras <= 0)
                        {
                            lCmd.Parameters.AddWithValue("@Estado", "N");
                        }
                        else
                        {
                            if (canttras != solicitado )
                                lCmd.Parameters.AddWithValue("@Estado", "P");
                            else
                                lCmd.Parameters.AddWithValue("@Estado", "S");
                        }
                        if (lCmd.ExecuteNonQuery() > 0 && canttras>0)
                        {
                            this.DeducirInventarioAlmacen(idTrasp, false, Convert.ToInt32(rw.Cells["IdProducto"].Value), Convert.ToDecimal(rw.Cells["Cantidad"].Value), Convert.ToDouble(rw.Cells["PrecioProveedor"].Value), dtim, this.m_conn, lTransaction, rw);
                            this.DeducirInventarioAlmacen(Convert.ToInt32(rw.Cells["idAlmacenDest"].Value), true, Convert.ToInt32(rw.Cells["IdProducto"].Value), Convert.ToDecimal(rw.Cells["Cantidad"].Value), Convert.ToDouble(rw.Cells["PrecioProveedor"].Value), dtim, this.m_conn, lTransaction, rw);
                        }
                    //}
                    //else
                    //{
                    //    invalids.Add(String.Format("No se pudo realizar el traspaso del producto {0} {1} por no tener existencias en el almacen origen", rw.Cells["Codigo"].Value, rw.Cells["Descripcion"].Value));
                    //}
                }

                lTransaction.Commit();

            }
            catch (System.Exception ex)
            {
                if (lTransaction != null)
                    lTransaction.Rollback();

                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                invalids.Clear();
                isOk = false;
            }
            finally
            {
                if (this.m_conn.State == ConnectionState.Open)
                {
                    this.m_conn.Close();
                }
            }
            if (invalids.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Se presentaron omisiones o diferencias al momento de generar el traspaso:");
                foreach (string str1 in invalids)
                    sb.AppendLine(str1);
                MessageBox.Show(sb.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if (isOk)
            {
                this.frm_TraspPrin.FillDataset();
                this.Close();
            }

        }

        private string DeducirInventarioAlmacen(System.Int32 p_Almacen, System.Boolean esEntrada, System.Int32 p_Key, System.Decimal p_cant, System.Double p_impte, System.DateTime dtime, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, DataGridViewRow oRow)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            string strMess="";
            Decimal pcant;

            try
            {
                //l_cmd.CommandText = "UPDATE catProductos SET existencia = existencia - " + p_cant.ToString() + " WHERE IdProducto = " + p_Key.ToString() + ";";
                //l_cmd.ExecuteNonQuery();

                if (esEntrada)
                    pcant = p_cant;
                else
                    pcant = -1 * p_cant;

                frm_productos.Save_Existencias_Almacen(p_Almacen, p_Key, pcant, p_conn, p_trans, out strMess);
                if (strMess.Length > 0)
                {
                    MessageBox.Show("Error modificando existencias:" + Environment.NewLine + strMess, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return strMess;
                }

                l_cmd.Connection = p_conn;
                l_cmd.Transaction = p_trans;

                //Modificar el inventario
                l_cmd.CommandText = "UPDATE catProductos SET Existencia = Existencia + " + pcant.ToString() + ",dtRegModificado = ?,UsuarioModif = ? WHERE Codigo = ?;";
                l_cmd.Parameters.Clear();
                l_cmd.Parameters.Add(new System.Data.Odbc.OdbcParameter("@dtRegModificado", DateTime.Now));
                l_cmd.Parameters.Add(new System.Data.Odbc.OdbcParameter("@UsuarioModif", frm_Main.mps_usuario));
                l_cmd.Parameters.Add(new System.Data.Odbc.OdbcParameter("@Codigo", oRow.Cells["Codigo"].Value));
                l_cmd.ExecuteNonQuery();

                l_cmd.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,iimporte,clogin,entrada,observaciones,idAlmacen) VALUES(?,?,?,?,?,?,?,?,?);";
                l_cmd.Parameters.Clear();
                l_cmd.Parameters.AddWithValue("@ccodigo", oRow.Cells["Codigo"].Value);
                l_cmd.Parameters.AddWithValue("@dtfecha", dtime);
                l_cmd.Parameters.AddWithValue("@cdescripcion", oRow.Cells["Descripcion"].Value);
                l_cmd.Parameters.AddWithValue("@icantidad", Convert.ToDouble(p_cant));
                l_cmd.Parameters.AddWithValue("@iimporte", System.Math.Round(p_impte, 2));
                l_cmd.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                if (esEntrada)
                {
                    l_cmd.Parameters.AddWithValue("@entrada", 1);
                    l_cmd.Parameters.AddWithValue("@observaciones", "TRASP DE " + cmb_AlmacenOrig.Text);
                }
                else
                {
                    l_cmd.Parameters.AddWithValue("@entrada", 0);
                    l_cmd.Parameters.AddWithValue("@observaciones", "TRASP A  " + cmb_AlmacenDest.Text);
                }
                l_cmd.Parameters.AddWithValue("@idAlmacen", p_Almacen);

                l_cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                strMess = ex.ToString();
                MessageBox.Show("Error deduciendo inventario:" + Environment.NewLine + strMess, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return strMess;

        }


        /// <summary>
        /// funcion que regresa la cantidad que puede deducir de inventario
        /// </summary>
        /// <param name="p_Key"></param>
        /// <param name="p_cant"></param>
        /// <param name="p_conn"></param>
        /// <param name="p_trans"></param>
        /// <returns></returns>
        private System.Decimal LeeDescontableAlmacen(System.Int32 p_Key, System.Int32 p_Almacen, System.Decimal p_cant, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = p_conn;
            if (p_trans != null)
                l_cmd.Transaction = p_trans;
            if (frm_Main.mp_idAlmacen <= 0)
            {
                l_cmd.CommandText = "SELECT existencia FROM catProductos WHERE IdProducto = ?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
            }
            else
            {
                l_cmd.CommandText = "SELECT Existencia from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
                l_cmd.Parameters.AddWithValue("@IdAlmacen", p_Almacen);
            }

            if(p_conn.State == ConnectionState.Closed) 
                p_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
            l_reader.Read();

            System.Decimal l_inv = 0;
            try
            {
                l_inv = Convert.ToDecimal(l_reader[0]);
            }
            catch
            {
                l_inv = 0;
            }

            l_reader.Close();

            if (p_cant <= l_inv)
                return p_cant;
            else
                return Math.Max(l_inv, 0);
        }


        private void cmd_Generar_Click(object sender, EventArgs e)
        {
            System.Decimal l_Ajuste;
            System.Decimal l_Ajuste1;
            System.Int32 lId;
            if (cmb_AlmacenOrig.Text == cmb_AlmacenDest.Text)
            {
                MessageBox.Show("El almacen destino debe ser diferente del almacen origen", "Información", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
 
            if (this.dataGridView1.Rows.Count > 0)
            {
                if (MessageBox.Show("Este proceso eliminara lo ya capturado para generar los movimientos de traspaso de los productos que esten en reorden en el almacen destino, desea continuar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }
            else
            {
                if (MessageBox.Show("Este proceso genera los movimientos de traspaso de los productos que esten en reorden en el almacen destino, desea continuar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;
            }
            //this.dataGridView1.Rows.Clear();
            this.m_dataset.Tables[0].Rows.Clear();
            this.m_dataset.Tables[0].AcceptChanges();
            this.Enabled = false; 
            // Encontrar todo los productos del almacen destino que esten en punto de reorden y que tengan
            // inventario suficiente en almacen origen (sin importar si quedan en cero) para llevarlo al pto maximo
            try
            {
                //Buscar los articulos...
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
                l_recid.Connection = this.m_conn;
                l_recid.CommandText = "SELECT catProductos.Codigo, catProductos.Descripcion, catProductos.PrecioProveedor, catProductos.UnidadVenta, catProductos.Marca, catProductos.empaque, catExistencias.* FROM catExistencias LEFT JOIN catProductos ON catProductos.IdProducto=catExistencias.IdProducto WHERE catExistencias.Existencia<=catExistencias.PtoReorden AND catExistencias.PtoMaximo>catExistencias.PtoReorden AND catExistencias.IdAlmacen=?;";
                l_recid.Parameters.AddWithValue("@IdAlmacen", slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenDest.Text)));

                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader();

                while (l_reader.Read())
                {
                    lId = Convert.ToInt32(l_reader["IdProducto"]);
                    // validar que tenga existencia suficiente en almacen origen 
                    l_Ajuste = Convert.ToDecimal(l_reader["PtoMaximo"]) - Convert.ToDecimal(l_reader["Existencia"]);
                    // svm may2012 :  dividir cantidad a pedir entre paquete, pedir el entero mas proximo
                    if (frm_productos.IsNumeric(l_reader["empaque"].ToString()))
                    {
                        if (Convert.ToInt32(l_reader["empaque"]) > 1)
                        {
                            Decimal div1 = l_Ajuste / Convert.ToDecimal(l_reader["empaque"]);
                            if((div1 - Math.Truncate(div1)) > Convert.ToDecimal(0.5))
                                l_Ajuste = (Math.Truncate(div1) + 1) * Convert.ToDecimal(l_reader["empaque"]);
                            else
                                l_Ajuste = Math.Truncate(div1) * Convert.ToDecimal(l_reader["empaque"]);

                        }
                        if (Convert.ToInt32(l_reader["empaque"]) < 1)
                            continue;
                    }

                    l_Ajuste1 = this.LeeDescontableAlmacen(Convert.ToInt32(l_reader["IdProducto"]), Convert.ToInt32(slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenOrig.Text))), l_Ajuste, this.m_conn, null);
                    this.lbl_msg.Text = l_reader["Codigo"].ToString() + " " + l_reader["Descripcion"].ToString();
                    this.lbl_msg.Refresh();
                    //Agregar al grid
                    //"Select detTraspasos.idProducto, idAlmacenDest, catProductos.codigo, catProductos.descripcion, cantidad, catAlmacenes.Descripcion as Almacen_Destino From detTraspasos left join catAlmacenes on detTraspasos.idAlmacenDest=catAlmacenes.idAlmacen left join catProductos on detTraspasos.idProducto=catProductos.idProducto where idTraspaso = " + this.m_KeyRecord.ToString() + ";";
                    System.Data.DataRow dr;
                    object[] keys = new object[2];
                    keys[0] = l_reader["IdProducto"];
                    keys[1] = slAlmacenes.GetKey(slAlmacenes.IndexOfValue(cmb_AlmacenDest.Text));
                    dr = this.m_dataset.Tables[0].Rows.Find(keys);
                    if (dr == null)
                    {
                        dr = this.m_dataset.Tables[0].NewRow();
                        dr["idProducto"] = keys[0];
                        dr["idAlmacenDest"] = keys[1];
                        dr["codigo"] = l_reader["Codigo"].ToString();
                        dr["Descripcion"] = l_reader["Descripcion"].ToString();
                        dr["cantidad"] = l_Ajuste1;
                        dr["Almacen_Destino"] = cmb_AlmacenDest.Text;
                        dr["UnidadVenta"] = l_reader["UnidadVenta"].ToString();
                        dr["Marca"] = l_reader["Marca"].ToString();
                        dr["PrecioProveedor"] = Convert.ToDouble(l_reader["PrecioProveedor"]);
                        dr["Solicitado"] = l_Ajuste;
                        dr["Estado"] = "S";
                        if (l_Ajuste1 < l_Ajuste)
                            dr["Estado"] = "P";
                        if (l_Ajuste1 <= 0)
                            dr["Estado"] = "N";

                        this.m_dataset.Tables[0].Rows.Add(dr);
                    }
                    else
                    {
                        dr["cantidad"] = this.txt_cantidad.Value;
                    }
                    this.m_dataset.Tables[0].AcceptChanges();
                    
                }
                l_reader.Close();

            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

            this.lbl_msg.Text = "";
            this.lbl_msg.Refresh();
            this.Enabled = true;
            if (this.m_dataset.Tables[0].Rows.Count <= 0)
                MessageBox.Show("No se encontraron productos en punto de reorden o no existe inventario suficiente en el almacen origen", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }

        private void txt_codigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int index = e.RowIndex; index <= e.RowIndex + e.RowCount - 1; index++)
            {
                DataGridViewRow row = this.dataGridView1.Rows[index];
                if (String.IsNullOrEmpty(row.Cells["Solicitado"].Value.ToString()))
                    row.Cells["Solicitado"].Value = row.Cells["Cantidad"].Value ;
                if (!String.IsNullOrEmpty(row.Cells["Estado"].Value.ToString()))
                {
                    if (row.Cells["Estado"].Value.ToString() == "P")  // Pendiente, cantidad menor a lo solicitado
                        row.DefaultCellStyle.BackColor = Color.LightGreen;
                    if (row.Cells["Estado"].Value.ToString() == "N")  // No aplicado, no hay existencias en almacen origen
                        row.DefaultCellStyle.BackColor = Color.LightPink;
                    if (row.Cells["Estado"].Value.ToString() == "S")  // Surtido, estatus normal
                        row.DefaultCellStyle.BackColor = Color.White;
                }
                else
                {
                    row.Cells["Estado"].Value = "S";
                    row.DefaultCellStyle.BackColor = Color.White;
                }

       
            } 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


    }

}
