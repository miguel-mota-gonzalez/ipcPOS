using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using clsFactElectronica;

namespace EasyInvoice
{
    public partial class frm_ExportarFacturas : Form
    {
		private System.Data.Odbc.OdbcConnection m_conn;
		private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();
		
        public frm_ExportarFacturas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
			System.Windows.Forms.ProgressBar.CheckForIllegalCrossThreadCalls = false;
			string lCurFolder = Environment.CurrentDirectory;
			
			if( this.folderBrowserDialog1.ShowDialog() == DialogResult.OK)
			{
				System.Threading.Thread lProcess = new System.Threading.Thread(this.ExportarFacturas);
				lProcess.Start();
			}
			Environment.CurrentDirectory = lCurFolder;
        }
		
		private void ExportarFacturas()
		{
				this.LoadData();
				this.LoadSystemValues();
			
				//MessageBox.Show("data loaded");
			
				string lStartPath = Environment.CurrentDirectory;	
			
				this.m_conn = new System.Data.Odbc.OdbcConnection();
                this.m_conn.ConnectionString = frm_Main.mps_strconnection;
			
				//Load template strings
				string lHeaderFile = System.IO.File.ReadAllText("header.xml");
				string lItemFile = System.IO.File.ReadAllText("item.xml");
				string lFooterFile = System.IO.File.ReadAllText("footer.xml");


				string lStart = this.monthCalendar1.SelectionStart.Year.ToString() + "-" + this.monthCalendar1.SelectionStart.Month.ToString() + "-" + this.monthCalendar1.SelectionStart.Day.ToString();
				string lEnd = this.monthCalendar2.SelectionStart.Year.ToString() + "-" + this.monthCalendar2.SelectionStart.Month.ToString() + "-" + this.monthCalendar2.SelectionStart.Day.ToString();
			
			
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand(); ;
                l_cmd.Connection = this.m_conn;
                l_cmd.CommandText = "SELECT count(IdFactura) as Total FROM catFacturas WHERE Fecha >= '"+lStart+" 00:00:00' AND Fecha <='" + lEnd + " 23:59:59'";

                System.Data.Odbc.OdbcCommand l_cmd2 = new System.Data.Odbc.OdbcCommand(); ;
                l_cmd2.Connection = this.m_conn;
                l_cmd2.CommandText = "SELECT * FROM catFacturas WHERE Fecha >= '"+lStart+" 00:00:00' AND Fecha <='" + lEnd + " 23:59:59'";			

				//System.Console.WriteLine( l_cmd2.CommandText );
			
                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
				l_reader.Read();
				int lTotal = Convert.ToInt32(l_reader["Total"]);
			
				this.progressBar1.Maximum = lTotal;
			
				System.Data.Odbc.OdbcDataReader l_reader2 = l_cmd2.ExecuteReader();
			
				while(l_reader2.Read())
				{
					System.Text.StringBuilder lFileContent = new System.Text.StringBuilder();
					System.Text.StringBuilder lFilecontentItems = new System.Text.StringBuilder();
				
					this.progressBar1.Value++;
				
					string[] lCadenaOriginal = l_reader2["cadenaoriginal"].ToString().Split('|');
				
					string lHeader = lHeaderFile;
					lHeader = lHeader.Replace("$$serie$$",this.mConfFact.Serie).Replace("$$version$$",this.mConfFact.Version).Replace("$$folio$$",l_reader2["NumeroFactura"].ToString());
					lHeader = lHeader.Replace("$$fecha$$",lCadenaOriginal[5]).Replace("$$sello$$",l_reader2["sello"].ToString()).Replace("$$numero_certificado$$",this.mConfFact.Numero_Certificado);
					lHeader = lHeader.Replace("$$subtotal$$",string.Format("{0:0.00}",l_reader2["Subtotal"])).Replace("$$total$$",string.Format("{0:0.00}",l_reader2["Total"])).Replace("$$numero_aprov$$",this.mConfFact.Numero_de_Aprobacion);
					lHeader = lHeader.Replace("$$anio_aprov$$",this.mConfFact.Anio_Aprobacion).Replace("$$forma_pago$$","UNA SOLA EXIBICION");
					lHeader = lHeader.Replace("$$tipo_comprobante$$",this.mConfFact.Tipo_de_Comprobante).Replace("$$rfc_emisor$$",this.mConfFact.RFC).Replace("$$razon_social_emisor$$",this.mConfFact.Razon_Social);		
					lHeader = lHeader.Replace("$$calle_emisor$$",this.mConfFact.Calle).Replace("$$no_exterior_emisor$$",this.mConfFact.Numero_Exterior);
					lHeader = lHeader.Replace("$$colonia_emisor$$",this.mConfFact.Colonia).Replace("$$localidad_emisor$$",this.mConfFact.Localidad).Replace("$$municipio_emisor$$",this.mConfFact.Municipio);
					lHeader = lHeader.Replace("$$estado_emisor$$",this.mConfFact.Estado).Replace("$$pais_emisor$$",this.mConfFact.Pais).Replace("$$zip_emisor$$",this.mConfFact.Codigo_Postal);
				
                	System.Data.Odbc.OdbcCommand l_cmdCli = new System.Data.Odbc.OdbcCommand(); ;
                	l_cmdCli.Connection = this.m_conn;
                	l_cmdCli.CommandText = "SELECT * FROM catClientes WHERE IdCliente = " + l_reader2["IdCliente"].ToString();		
				
					System.Data.Odbc.OdbcDataReader lClienteReader = l_cmdCli.ExecuteReader();
				
					lClienteReader.Read();
				
					lHeader = lHeader.Replace("$$rfc_receptor$$",lClienteReader["RFC"].ToString()).Replace("$$razon_social_receptor$$",lClienteReader["Nombre"].ToString()).Replace("$$calle_receptor$$",lClienteReader["Calle"].ToString());
					lHeader = lHeader.Replace("$$no_experior_rceptor$$",lClienteReader["Numero"].ToString()).Replace("$$colonia_receptor$$",lClienteReader["Colonia"].ToString()).Replace("$$estado_receptor$$",lClienteReader["Estado"].ToString());
					lHeader = lHeader.Replace("$$pais_receptor$$",lClienteReader["Pais"].ToString()).Replace("$$zip_receptor$$",lClienteReader["CodigoPostal"].ToString());
					lHeader = lHeader.Replace("$$localidad_receptor$$",lClienteReader["ciudad"].ToString()).Replace("$$municipio_receptor$$",lClienteReader["Municipio"].ToString());
				
				
	                System.Data.Odbc.OdbcCommand l_cmd3 = new System.Data.Odbc.OdbcCommand();
	                l_cmd3.Connection = this.m_conn;
	                l_cmd3.CommandText = "select detFactura.*,catProductos.Descripcion,catProductos.UnidadVenta,catProductos.Codigo,catProductos.Descripcion from detFactura inner join catProductos on detFactura.IdProducto = catProductos.IdProducto WHERE IdFactura = " + l_reader2["IdFactura"].ToString();		
				
					System.Data.Odbc.OdbcDataReader l_reader3 = l_cmd3.ExecuteReader();
				
				
					double lDescuento = 0;
					while(l_reader3.Read())
					{
						string lItem = lItemFile;
					
						double lTotalItem = Convert.ToDouble(l_reader3["PrecioOriginal"]);
						double lDescuentoItem = Convert.ToDouble(l_reader3["PrecioDescuento"]);
					
						lDescuento += lTotalItem - lDescuentoItem;
					
		                if (this.mp_usa_iva_por_articulo == 1)
		                {
		                    this.mp_IVA = Convert.ToDouble(l_reader3["iva"]);
		                    this.mp_IVA = this.mp_IVA / 100;
		                }
					
						//lDescuento += (  )
					
						lItem = lItem.Replace("$$cantidad$$",string.Format("{0:0.00}",l_reader3["Cantidad"])).Replace("$$servicio$$",l_reader3["UnidadVenta"].ToString()).Replace("$$codigo$$",l_reader3["Codigo"].ToString());
						lItem = lItem.Replace("$$descripcion$$",l_reader3["Descripcion"].ToString()).Replace("$$valor_unitario$$",string.Format("{0:0.00}",l_reader3["PrecioOriginal"])).Replace("$$importe$$",string.Format("{0:0.00}",l_reader3["PrecioCalculado"]));
					
						//lFileContent.Append(Environment.NewLine);
						lFilecontentItems.Append( lItem );
					
					}
				
					lHeader = lHeader.Replace("$$descuento$$", string.Format("{0:0.00}",lDescuento) );
				
					lFileContent.Append(lHeader);
					lFileContent.Append( lFilecontentItems.ToString() );
				
					string lFooter = lFooterFile;
					double lTotalIva = Convert.ToDouble(l_reader2["Total"]) - Convert.ToDouble(l_reader2["Subtotal"]);
					lTotalIva = System.Math.Round(lTotalIva,2);
					
					lFooter = lFooter.Replace("$$total_impuestos$$", string.Format("{0:0.00}",lTotalIva));
					lFooter = lFooter.Replace("$$iva$$","IVA");
					lFooter = lFooter.Replace("$$importe$$",string.Format("{0:0.00}",lTotalIva));
					lFooter = lFooter.Replace("$$tasa$$", string.Format("{0:0.00}",this.mp_IVA*100));
				
					//lFileContent.Append(Environment.NewLine);
					lFileContent.Append( lFooter );				
				
					Environment.CurrentDirectory = this.folderBrowserDialog1.SelectedPath;
					System.IO.File.WriteAllText( l_reader2["NumeroFactura"].ToString() + ".xml",lFileContent.ToString());
				
				}			
			
				Environment.CurrentDirectory = lStartPath;	
				this.m_conn.Close();
		}

        private void button2_Click(object sender, EventArgs e)
        {
			this.Close();
        }
		
        private void LoadData()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

            lConn.Open();
            System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

            if (lReader.Read())
            {
                this.mConfFact.Version = lReader["Version"].ToString();
                this.mConfFact.Serie = lReader["Serie"].ToString();
                this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
                this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
                this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
                this.mConfFact.RFC = lReader["RFC"].ToString();
                this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
                this.mConfFact.Calle = lReader["Calle"].ToString();
                this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
                this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
                this.mConfFact.Colonia = lReader["Colonia"].ToString();
                this.mConfFact.Localidad = lReader["Localidad"].ToString();
                this.mConfFact.Referencia = lReader["Referencia"].ToString();
                this.mConfFact.Municipio = lReader["Municipio"].ToString();
                this.mConfFact.Estado = lReader["Estado"].ToString();
                this.mConfFact.Pais = lReader["Pais"].ToString();
                this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
				this.mConfFact.Numero_Certificado = lReader["Numero_Certificado"].ToString();
            }

            lConn.Close();
        }
		
		double mp_IVA = 0.15;
		string mp_clientenotas = "";
        int mp_usa_iva_por_articulo = 0;
		int mp_iva_to_store = 0;
		
		private void LoadSystemValues()
		{
			System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
			
			try
			{
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				lConn.ConnectionString = frm_Main.mps_strconnection;
				
				l_cmd.Connection = lConn;;
				
				l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001'";

				lConn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//IVA					
					this.mp_IVA = Convert.ToDouble(l_reader["IVA"]);
                    this.mp_iva_to_store = Convert.ToInt32( Convert.ToDouble(l_reader["IVA"])*100 );
					
					//MessageBox.Show( mp_iva_to_store.ToString() );
					
					//Cliente Notas
					this.mp_clientenotas = l_reader["ClienteNotas"].ToString();

                    //Usa Iva por articulo?
                    this.mp_usa_iva_por_articulo = Convert.ToInt32(l_reader["UsarIvaPorArtic"]);
					//MessageBox.Show("done");
										
				}
				
				l_reader.Close();		
			
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(lConn.State == System.Data.ConnectionState.Open)
					lConn.Close();
			}
			
		}			
			
    }
}
