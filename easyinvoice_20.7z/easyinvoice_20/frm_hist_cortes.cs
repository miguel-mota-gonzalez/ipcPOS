﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
    public partial class frm_hist_cortes : Form
    {
        private System.Data.Odbc.OdbcConnection m_conn;

        public frm_hist_cortes()
        {
            InitializeComponent();
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            this.LoadDocPositions();

        }

        private void frm_hist_cortes_Load(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT catCorte.iidCorte,catCorte.dtFecha,catCorte.Total,catUsuarios.cnombre FROM catCorte INNER JOIN catUsuarios ON catCorte.cusuario = catUsuarios.clogin ORDER BY catCorte.dtFecha DESC;";

            //l_cmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            while (l_reader.Read())
            {
                ListViewItem l_item = this.listView1.Items.Add(l_reader["dtFecha"].ToString());
                l_item.SubItems.Add(System.String.Format("{0:C}", l_reader["Total"]));
                l_item.SubItems.Add(l_reader["cnombre"].ToString());
                l_item.SubItems.Add(l_reader["iidCorte"].ToString());
            }

            l_reader.Close();
            this.m_conn.Close();
        }

        ////////////////////////////////////////////////     
        #region Posiciones de la factura...
        int mp_int_PosNombreX = 0;
        int mp_int_PosNombreY = 0;

        int mp_int_PosDireccionX = 0;
        int mp_int_PosDireccionY = 0;

        int mp_int_PosCiudadX = 0;
        int mp_int_PosCiudadY = 0;

        int mp_int_PosRFCX = 0;
        int mp_int_PosRFCY = 0;

        int mp_int_PosNumFactX = 0;
        int mp_int_PosNumFactY = 0;

        int mp_int_PosFechaX = 0;
        int mp_int_PosFechaY = 0;

        int mp_int_PosCodigoX = 0;
        int mp_int_PosCodigoY = 0;

        int mp_int_PosCantidadX = 0;
        int mp_int_PosCantidadY = 0;

        int mp_int_PosDescripcionX = 0;
        int mp_int_PosDescripcionY = 0;

        int mp_int_PosPrecioX = 0;
        int mp_int_PosPrecioY = 0;

        int mp_int_PosTotalX = 0;
        int mp_int_PosTotalY = 0;

        int mp_int_PosSubTotalX = 0;
        int mp_int_PosSubTotalY = 0;

        int mp_int_PosIVAX = 0;
        int mp_int_PosIVAY = 0;

        int mp_int_PosGTotalX = 0;
        int mp_int_PosGTotalY = 0;

        int mp_int_PosGTotalLetrasX = 0;
        int mp_int_PosGTotalLetrasY = 0;

        int mp_int_EspacioDetalle = 0;
        int mp_int_TamanioLetra = 0;

        string mp_string_Leyenda = "";

        #endregion

        private void LoadDocPositions()
        {
            try
            {

                this.m_conn.ConnectionString = frm_Main.mps_strconnection;


                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '003'";


                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

                if (l_reader.Read())
                {
                    string[] l_temp = new string[2];

                    //PosNombre					
                    l_temp = l_reader["PosNombre"].ToString().Split(',');
                    this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);

                    //PosDireccion
                    l_temp = l_reader["PosDireccion"].ToString().Split(',');
                    this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);

                    //PosCiudad
                    l_temp = l_reader["PosCiudad"].ToString().Split(',');
                    this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);

                    //PosRFC
                    l_temp = l_reader["PosRFC"].ToString().Split(',');
                    this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);

                    //PosNumFact
                    l_temp = l_reader["PosNumFact"].ToString().Split(',');
                    this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);

                    //PosFecha
                    l_temp = l_reader["PosFecha"].ToString().Split(',');
                    this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);

                    //PosCodigo
                    l_temp = l_reader["PosCodigo"].ToString().Split(',');
                    this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);

                    //PosCantidad
                    l_temp = l_reader["PosCantidad"].ToString().Split(',');
                    this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);

                    //PosDescripcion
                    l_temp = l_reader["PosDescripcion"].ToString().Split(',');
                    this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);

                    //PosPrecio
                    l_temp = l_reader["PosPrecio"].ToString().Split(',');
                    this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);

                    //PosTotal
                    l_temp = l_reader["PosTotal"].ToString().Split(',');
                    this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);

                    //PosSubtotal
                    l_temp = l_reader["PosSubtotal"].ToString().Split(',');
                    this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);

                    //PosIVA
                    l_temp = l_reader["PosIVA"].ToString().Split(',');
                    this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);

                    //PosGTotal
                    l_temp = l_reader["PosGTotal"].ToString().Split(',');
                    this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);

                    //PosGTotalLetras
                    l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
                    this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);

                    //EspacioDetalle
                    this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());

                    //TamanioLetra
                    this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());

                    //Leyenda
                    this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                }

                l_reader.Close();

            }
            catch (OleDbException ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

        }

        private void cmd_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private int mp_idcorte = -1;
        private int mp_iiddetcorte = 0;
        private double mp_totalrep = 0;

        private void mp_pdcorte_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int l_ypos = 140;
            System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
            System.Drawing.Font l_fonth = new Font("Arial", this.mp_int_TamanioLetra + 2, FontStyle.Bold);
            System.Drawing.Font l_fonth1 = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Bold | FontStyle.Italic);
            System.Drawing.Font l_font = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Regular);

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT catCorte.*,catUsuarios.cnombre as nombre_usuario FROM catCorte INNER JOIN catUsuarios ON catCorte.cusuario = catUsuarios.clogin WHERE catCorte.iidCorte = " + this.mp_idcorte.ToString();

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();


            e.Graphics.DrawString("Corte de Caja", l_fonth, l_brush, 350, 50);

            if (l_reader.Read())
            {
                e.Graphics.DrawString("Corte de caja realizado el " + l_reader["dtFecha"].ToString() + " por el usuario : " + l_reader["nombre_usuario"].ToString(), l_fonth1, l_brush, 15, 70);
                e.Graphics.DrawString("Total " + System.String.Format("{0:C}", l_reader["Total"]), l_fonth1, l_brush, 15, 85);
            }

            l_reader.Close();

            e.Graphics.DrawString("Numero", l_fonth1, l_brush, 15, 110);
            e.Graphics.DrawString("Fecha", l_fonth1, l_brush, 100, 110);
            //e.Graphics.DrawString("Nota o Factura", l_fonth1, l_brush, 250, 110);
            e.Graphics.DrawString("Total", l_fonth1, l_brush, 450, 110);

            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, 125, 835, 125);

            //Imprimir el detalle
            l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM detCorte WHERE iidCorte = " + this.mp_idcorte.ToString() + " AND iidDetCorte > " + this.mp_iiddetcorte.ToString() + " ORDER BY esfactura, dtFecha";

            l_reader = l_cmd.ExecuteReader();

            int k = 0;
            int doc, curdoc=-1;
            double totaldoc=0;
            while (l_reader.Read())
            {
                doc=Convert.ToInt32(l_reader["esfactura"]);
                if (curdoc != doc)
                {
                    switch (doc)
                    {
                        case 1:
                            if (totaldoc > 0)
                            {
                                e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);
                                e.Graphics.DrawString(System.String.Format("{0:C}", totaldoc), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);
                                l_ypos += this.mp_int_EspacioDetalle;
                                k++;
                            }
                            e.Graphics.DrawString("Facturas", l_fonth1, l_brush, 15, l_ypos);
                            totaldoc = 0;
                            break;
                        case 0:
                            if (totaldoc > 0)
                            {
                                e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);
                                e.Graphics.DrawString(System.String.Format("{0:C}", totaldoc), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);
                                l_ypos += this.mp_int_EspacioDetalle;
                                k++;
                            }
                            e.Graphics.DrawString("Notas", l_fonth1, l_brush, 15, l_ypos);
                            totaldoc = 0;
                            break;
                        case 2:
                            if (totaldoc > 0)
                            {
                                e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);
                                e.Graphics.DrawString(System.String.Format("{0:C}", totaldoc), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);
                                l_ypos += this.mp_int_EspacioDetalle;
                                k++;
                            }
                            e.Graphics.DrawString("Pagos/Abonos", l_fonth1, l_brush, 15, l_ypos);
                            totaldoc = 0;
                            break;
                    }
                    curdoc=doc;
                    l_ypos += this.mp_int_EspacioDetalle;
                    k++;
                }
                e.Graphics.DrawString(l_reader["cNumero"].ToString(), l_font, l_brush, 15, l_ypos);
                e.Graphics.DrawString(System.Convert.ToDateTime(l_reader["dtFecha"]).ToString(), l_font, l_brush, 100, l_ypos);
                //e.Graphics.DrawString((Convert.ToBoolean(l_reader["esfactura"]) ? "Factura" : "Nota"), l_font, l_brush, 250, l_ypos);
                e.Graphics.DrawString(System.String.Format("{0:C}", l_reader["Total"]), l_font, l_brush, 450, l_ypos);

                this.mp_totalrep += Convert.ToDouble(l_reader["Total"]);
                totaldoc += Convert.ToDouble(l_reader["Total"]);
                this.mp_idcorte = Convert.ToInt32(l_reader["iidDetCorte"]);

                l_ypos += this.mp_int_EspacioDetalle;
                k++;

                if (k == 60)
                {
                    e.HasMorePages = true;
                    return;
                }

            }

            if (totaldoc > 0)
            {
                e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);
                e.Graphics.DrawString(System.String.Format("{0:C}", totaldoc), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);
                l_ypos += this.mp_int_EspacioDetalle;
                k++;
            }

            l_reader.Close();
            this.m_conn.Close();

            e.HasMorePages = false;
            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);

            l_ypos += this.mp_int_TamanioLetra;

            e.Graphics.DrawString(System.String.Format("{0:C}", this.mp_totalrep), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);

            this.mp_iiddetcorte = 0;
            this.mp_totalrep = 0;
        }

        private void cmd_reporte_Click(object sender, EventArgs e)
        {
            if (this.listView1.SelectedItems.Count > 0)
            {
                this.mp_idcorte = System.Convert.ToInt32(this.listView1.SelectedItems[0].SubItems[3].Text);

                this.mp_ppvw.WindowState = FormWindowState.Maximized;
                this.mp_ppvw.ShowDialog();

            }
        }


    }
}
