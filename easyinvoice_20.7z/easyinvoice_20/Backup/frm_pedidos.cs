using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_pedidos.
	/// </summary>
	public class frm_pedidos : System.Windows.Forms.Form
    {
        
        private System.Data.DataSet m_dataset;
        public System.Int32 m_KeyRecord;
        private IContainer components;

        private DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        private ToolBar toolBar1;
        private ToolBarButton cmdt_actualizar;
        private ToolBarButton cmdt_cerrar;
        private ToolBarButton toolBarButton5;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private ComboBox cmb_criterios;
        private TextBox txt_criterio;

        public Int32 p_Result;
        public Int32 p_currentId;
        private ComboBox cmb_Proveedores;
        public TextBox txtProducto;
        private Label label3;
        public TextBox txtCantidad;
        private Label label4;
        private Label label5;
        private Label lbl_Pieza;
        private Button cmd_Agregar;
        private Button cmd_Borrar;
        private Button cmd_Save;
        private DataGridView dataGridView2;

        private SortedList sl_ProdsProvs = new SortedList();
        System.Collections.Generic.List<int> idProvs = new System.Collections.Generic.List<int>();
        private System.Data.DataSet m_detail = new System.Data.DataSet();
        public TextBox txtPrecioUnit;
        private Label label6;
        private Button cmd_makefiles;    

        private System.Data.Odbc.OdbcConnection OdbcConnection1 = new System.Data.Odbc.OdbcConnection();

		public frm_pedidos()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_pedidos));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolBar1 = new System.Windows.Forms.ToolBar();
            this.cmdt_actualizar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_cerrar = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_criterios = new System.Windows.Forms.ComboBox();
            this.txt_criterio = new System.Windows.Forms.TextBox();
            this.cmb_Proveedores = new System.Windows.Forms.ComboBox();
            this.txtProducto = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCantidad = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_Pieza = new System.Windows.Forms.Label();
            this.cmd_Agregar = new System.Windows.Forms.Button();
            this.cmd_Borrar = new System.Windows.Forms.Button();
            this.cmd_Save = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.txtPrecioUnit = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmd_makefiles = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.PowderBlue;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 50);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(807, 168);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // toolBar1
            // 
            this.toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.cmdt_actualizar,
            this.cmdt_cerrar,
            this.toolBarButton5});
            this.toolBar1.ButtonSize = new System.Drawing.Size(55, 45);
            this.toolBar1.DropDownArrows = true;
            this.toolBar1.ImageList = this.imageList1;
            this.toolBar1.Location = new System.Drawing.Point(0, 0);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.ShowToolTips = true;
            this.toolBar1.Size = new System.Drawing.Size(808, 51);
            this.toolBar1.TabIndex = 0;
            this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // cmdt_actualizar
            // 
            this.cmdt_actualizar.ImageIndex = 2;
            this.cmdt_actualizar.Name = "cmdt_actualizar";
            this.cmdt_actualizar.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
            this.cmdt_actualizar.Tag = "actualizar";
            this.cmdt_actualizar.Text = "Todos los productos";
            this.cmdt_actualizar.ToolTipText = "Ver la lista completa de productos o s�lo los que estan en punto de reorden";
            // 
            // cmdt_cerrar
            // 
            this.cmdt_cerrar.ImageIndex = 3;
            this.cmdt_cerrar.Name = "cmdt_cerrar";
            this.cmdt_cerrar.Tag = "cerrar";
            this.cmdt_cerrar.Text = "Cerrar";
            this.cmdt_cerrar.ToolTipText = "Cerrar esta ventana...";
            // 
            // toolBarButton5
            // 
            this.toolBarButton5.Name = "toolBarButton5";
            this.toolBarButton5.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "cube_blue_new.ico");
            this.imageList1.Images.SetKeyName(1, "edit.ico");
            this.imageList1.Images.SetKeyName(2, "refresh.ico");
            this.imageList1.Images.SetKeyName(3, "exit.ico");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(243, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(485, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "criterio:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(277, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Buscar por";
            // 
            // cmb_criterios
            // 
            this.cmb_criterios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_criterios.Location = new System.Drawing.Point(347, 23);
            this.cmb_criterios.Name = "cmb_criterios";
            this.cmb_criterios.Size = new System.Drawing.Size(121, 21);
            this.cmb_criterios.TabIndex = 2;
            // 
            // txt_criterio
            // 
            this.txt_criterio.Location = new System.Drawing.Point(539, 23);
            this.txt_criterio.Name = "txt_criterio";
            this.txt_criterio.Size = new System.Drawing.Size(257, 20);
            this.txt_criterio.TabIndex = 4;
            this.txt_criterio.TextChanged += new System.EventHandler(this.txt_criterio_TextChanged);
            this.txt_criterio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_criterio_KeyDown);
            // 
            // cmb_Proveedores
            // 
            this.cmb_Proveedores.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmb_Proveedores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Proveedores.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Proveedores.Location = new System.Drawing.Point(93, 252);
            this.cmb_Proveedores.Name = "cmb_Proveedores";
            this.cmb_Proveedores.Size = new System.Drawing.Size(317, 24);
            this.cmb_Proveedores.TabIndex = 10;
            this.cmb_Proveedores.SelectedValueChanged += new System.EventHandler(this.cmb_Proveedores_SelectedValueChanged);
            // 
            // txtProducto
            // 
            this.txtProducto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtProducto.Enabled = false;
            this.txtProducto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProducto.ForeColor = System.Drawing.Color.Blue;
            this.txtProducto.Location = new System.Drawing.Point(80, 224);
            this.txtProducto.Name = "txtProducto";
            this.txtProducto.Size = new System.Drawing.Size(451, 22);
            this.txtProducto.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Proveedor";
            // 
            // txtCantidad
            // 
            this.txtCantidad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtCantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidad.ForeColor = System.Drawing.Color.Blue;
            this.txtCantidad.Location = new System.Drawing.Point(502, 252);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(93, 22);
            this.txtCantidad.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(434, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Cantidad";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Producto";
            // 
            // lbl_Pieza
            // 
            this.lbl_Pieza.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbl_Pieza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pieza.Location = new System.Drawing.Point(560, 227);
            this.lbl_Pieza.Name = "lbl_Pieza";
            this.lbl_Pieza.Size = new System.Drawing.Size(118, 16);
            this.lbl_Pieza.TabIndex = 8;
            // 
            // cmd_Agregar
            // 
            this.cmd_Agregar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_Agregar.Location = new System.Drawing.Point(692, 281);
            this.cmd_Agregar.Name = "cmd_Agregar";
            this.cmd_Agregar.Size = new System.Drawing.Size(104, 23);
            this.cmd_Agregar.TabIndex = 15;
            this.cmd_Agregar.Text = "&Agregar";
            this.cmd_Agregar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Agregar.Click += new System.EventHandler(this.cmd_Agregar_Click);
            // 
            // cmd_Borrar
            // 
            this.cmd_Borrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmd_Borrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_Borrar.Location = new System.Drawing.Point(15, 498);
            this.cmd_Borrar.Name = "cmd_Borrar";
            this.cmd_Borrar.Size = new System.Drawing.Size(124, 23);
            this.cmd_Borrar.TabIndex = 17;
            this.cmd_Borrar.Text = "&Eliminar";
            this.cmd_Borrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Borrar.Click += new System.EventHandler(this.cmd_Borrar_Click);
            // 
            // cmd_Save
            // 
            this.cmd_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_Save.Location = new System.Drawing.Point(579, 498);
            this.cmd_Save.Name = "cmd_Save";
            this.cmd_Save.Size = new System.Drawing.Size(217, 23);
            this.cmd_Save.TabIndex = 18;
            this.cmd_Save.Text = "&Generar ordenes de compra";
            this.cmd_Save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Save.Click += new System.EventHandler(this.cmd_Save_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Silver;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 310);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(807, 182);
            this.dataGridView2.TabIndex = 16;
            // 
            // txtPrecioUnit
            // 
            this.txtPrecioUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPrecioUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrecioUnit.ForeColor = System.Drawing.Color.Blue;
            this.txtPrecioUnit.Location = new System.Drawing.Point(692, 253);
            this.txtPrecioUnit.Name = "txtPrecioUnit";
            this.txtPrecioUnit.Size = new System.Drawing.Size(104, 22);
            this.txtPrecioUnit.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(610, 256);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "Precio Unit.";
            // 
            // cmd_makefiles
            // 
            this.cmd_makefiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmd_makefiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_makefiles.Location = new System.Drawing.Point(449, 498);
            this.cmd_makefiles.Name = "cmd_makefiles";
            this.cmd_makefiles.Size = new System.Drawing.Size(124, 23);
            this.cmd_makefiles.TabIndex = 19;
            this.cmd_makefiles.Text = "&Crear archivos ";
            this.cmd_makefiles.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_makefiles.Click += new System.EventHandler(this.cmd_makefiles_Click);
            // 
            // frm_pedidos
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(808, 522);
            this.Controls.Add(this.cmd_makefiles);
            this.Controls.Add(this.txtPrecioUnit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.cmd_Agregar);
            this.Controls.Add(this.cmd_Borrar);
            this.Controls.Add(this.cmd_Save);
            this.Controls.Add(this.lbl_Pieza);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmb_Proveedores);
            this.Controls.Add(this.txtProducto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCantidad);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_criterios);
            this.Controls.Add(this.txt_criterio);
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_pedidos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Levantamiento de Pedidos";
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_pedidos_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
            this.FillDataset(this.cmdt_actualizar.Pushed);

            if (m_dataset.Tables.Count > 0)
            {

                foreach (System.Data.DataColumn l_col in m_dataset.Tables[0].Columns)
                {
                    if (l_col.DataType.Name == "String" && this.dataGridView1.Columns[l_col.ColumnName].Visible)
                        this.cmb_criterios.Items.Add(l_col.ColumnName);
                }

                this.cmb_criterios.Text = "Codigo";
            }

            DataColumn[] keys = new DataColumn[2];
            this.m_detail.Tables.Add("detail");
            this.m_detail.Tables[0].Columns.Add("idProducto");
            this.m_detail.Tables[0].Columns.Add("Codigo");
            this.m_detail.Tables[0].Columns.Add("Descripcion");
            this.m_detail.Tables[0].Columns.Add("idProveedor");
            this.m_detail.Tables[0].Columns.Add("Proveedor");
            this.m_detail.Tables[0].Columns.Add("Cantidad",Type.GetType("System.Double"));
            this.m_detail.Tables[0].Columns.Add("PrecioUnit", Type.GetType("System.Double"));
            keys[0] = this.m_detail.Tables[0].Columns["idProducto"];
            keys[1] = this.m_detail.Tables[0].Columns["idProveedor"];
            this.m_detail.Tables[0].PrimaryKey = keys;
            this.dataGridView2.DataSource = this.m_detail.Tables[0];

            this.dataGridView2.Columns[0].Visible = false;
            this.dataGridView2.Columns[3].Visible = false;

            this.dataGridView2.Columns[1].Width = 100;
            this.dataGridView2.Columns[2].Width = 240;
            this.dataGridView2.Columns[5].Width = 80;
            this.dataGridView2.Columns[5].DefaultCellStyle.Format = "###,##0.00";
            this.dataGridView2.Columns[6].Width = 100;
            this.dataGridView2.Columns[6].DefaultCellStyle.Format = "###,##0.00";

            if (frm_Main.mp_idAlmacen > 0)
                this.Text = this.Text + " - " + frm_Main.mp_strAlmacen; 

		}

		
        private void FillDataset(bool ListAll)
        {
            try
            {
                string strSelect;
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                if (frm_Main.mp_idAlmacen <= 0)
                {
                    strSelect = "SELECT IdProducto,CodigoProd,Codigo,Descripcion,Existencia,PtoReorden,UnidadVenta,Observaciones from catProductos";
                    if (!ListAll)
                        strSelect += " WHERE Existencia<=PtoReorden";
                    strSelect += ";";
                }
                else
                {
                    strSelect = "SELECT catExistencias.IdProducto,catProductos.CodigoProd,catProductos.Codigo,catProductos.Descripcion,catExistencias.Existencia,catExistencias.PtoReorden,catProductos.UnidadVenta,catProductos.Observaciones from catExistencias LEFT JOIN catProductos ON catExistencias.IdProducto=catProductos.IdProducto";
                    strSelect += " WHERE catExistencias.idAlmacen=" + frm_Main.mp_idAlmacen.ToString();
                    if (!ListAll)
                        strSelect += " AND catExistencias.Existencia<=catExistencias.PtoReorden";
                    strSelect += ";";
                }

                l_select.Connection = l_conn;
                l_select.CommandText = strSelect;
                		
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "productos";
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;
                this.dataGridView1.Columns[4].DefaultCellStyle.Format = "###,##0.00";
                this.dataGridView1.Columns[5].DefaultCellStyle.Format = "###,##0.00";
                this.dataGridView1.Columns[6].Visible = false;
                this.dataGridView1.Columns[3].Width = 250;
                this.dataGridView1.Columns[4].Width = 70;
                this.dataGridView1.Columns[5].Width = 70;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_criterio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }        	
        }

        private void frm_pedidos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if(MessageBox.Show("Desea salir?","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                    this.Close();
            }
        }


        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {

            switch ((string)e.Button.Tag)
            {
                case "actualizar":
                    this.FillDataset(this.cmdt_actualizar.Pushed);
                    if (this.cmdt_actualizar.Pushed)
                        this.cmdt_actualizar.Text = "En punto de reorden";
                    else
                        this.cmdt_actualizar.Text = "Todos los productos";
                    break;
                case "cerrar":
                    this.Close();
                    break;

            }
        }

        private void txt_criterio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                this.dataGridView1.Focus();
        }

        // selecciono un registro, llena el combo
        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            SortedList sl;
            if(this.m_KeyRecord == (int)this.dataGridView1.Rows[e.RowIndex].Cells[0].Value)
                return;

            this.m_KeyRecord = (int)this.dataGridView1.Rows[e.RowIndex].Cells[0].Value;

            txtProducto.Text = (string)this.dataGridView1.Rows[e.RowIndex].Cells["CodigoProd"].Value + " " + (string)this.dataGridView1.Rows[e.RowIndex].Cells["Descripcion"].Value;
            lbl_Pieza.Text = (string)this.dataGridView1.Rows[e.RowIndex].Cells["UnidadVenta"].Value;
            if(txtCantidad.Text=="")
                txtCantidad.Text = "1.00";
            if (txtPrecioUnit.Text == "")
                txtPrecioUnit.Text = "0.00";
            
            // carga proveedores asociados al producto
            if(!sl_ProdsProvs.ContainsKey(this.m_KeyRecord))
            {
                sl_ProdsProvs.Add(this.m_KeyRecord, ListaProveedores(this.m_KeyRecord));
            }
            idProvs.Clear();
            this.cmb_Proveedores.Items.Clear();
            sl=(SortedList)sl_ProdsProvs[this.m_KeyRecord];
            foreach(string id in sl.Keys)
            {
                idProvs.Add(Convert.ToInt32(id));
                this.cmb_Proveedores.Items.Add(sl[id]);
            }
            idProvs.Add(-1);
            this.cmb_Proveedores.Items.Add("==> Seleccionar un proveedor diferente");
            this.cmb_Proveedores.SelectedItem = null;
        }

        public SortedList ListaProveedores(int keyRecord)
        {
            SortedList sl = new SortedList();
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();

            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                lCmd.Connection = lConn;
                lCmd.CommandText = "select rpp.idProveedor, cp.Nombre from relProductoProveedor rpp  inner join catProveedores cp on rpp.IdProveedor = cp.IdProveedor where rpp.IdProducto = " + keyRecord.ToString();

                System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

                while (lReader.Read())
                {
                    if(!sl.ContainsKey(lReader["idProveedor"].ToString()))
                    {
                        sl.Add(lReader["idProveedor"].ToString(),lReader["Nombre"].ToString());
                    }
                }

                lReader.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {

                if (lConn.State == System.Data.ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
            return sl;
        }

        private void cmb_Proveedores_SelectedValueChanged(object sender, EventArgs e)
        {
            // seleccionando un proveedor no asignado al producto
            if(this.idProvs[this.cmb_Proveedores.SelectedIndex] == -1)
            {
                frm_ProveedoresList l_frmProveedores = new frm_ProveedoresList();
                l_frmProveedores.m_KeyRecord = -1;
                l_frmProveedores.cmd_nuevo.Enabled = false; 
                l_frmProveedores.ShowDialog(this);

                if(l_frmProveedores.m_KeyRecord!=-1)
                {
                    if(this.idProvs.Contains(l_frmProveedores.m_KeyRecord))
                    {
                        this.cmb_Proveedores.SelectedIndex = this.idProvs.IndexOf(l_frmProveedores.m_KeyRecord);
                    }
                    else
                    {
                        idProvs[idProvs.Count-1]=l_frmProveedores.m_KeyRecord;
                        this.cmb_Proveedores.Items[idProvs.Count-1]=l_frmProveedores.m_provName;
                        idProvs.Add(-1);
                        this.cmb_Proveedores.Items.Add("==> Seleccionar un proveedor diferente");
                        this.cmb_Proveedores.SelectedIndex = this.cmb_Proveedores.Items.Count - 2;
                        if(MessageBox.Show("Desea asignar este proveedor al producto","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)== DialogResult.Yes)
                        {
                            this.AddProveedorProducto(this.m_KeyRecord, l_frmProveedores.m_KeyRecord);
                            string strp = l_frmProveedores.m_KeyRecord.ToString();
                            if (!((SortedList)sl_ProdsProvs[this.m_KeyRecord]).ContainsKey(strp))
                                ((SortedList)sl_ProdsProvs[this.m_KeyRecord]).Add(strp,l_frmProveedores.m_provName);
                        }
                    }
                }
            }
        }

        private void AddProveedorProducto(int idProducto, int idProveedor)
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction lTransaction = null;

            try
            {

                if (idProducto <= 0)
                    return;

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();
                
                // checa si no ya esta asignado
                object res;
                string idProvs="";
                System.Data.Odbc.OdbcCommand lCmd1 = new System.Data.Odbc.OdbcCommand();
                lCmd1.Connection = lConn;
                lCmd1.CommandText = "SELECT IdProducto FROM relProductoProveedor WHERE IdProducto = " + idProducto.ToString() + " AND IdProveedor = " + idProveedor.ToString();
                res = lCmd1.ExecuteScalar();
                if (res!=null)
                { 
                    if (lConn.State == ConnectionState.Open)
                        lConn.Close();
                    return;
                }

                idProvs = "";
                lCmd1.CommandText = "SELECT IdProveedor FROM relProductoProveedor WHERE IdProducto = " + idProducto.ToString();
                System.Data.Odbc.OdbcDataReader lReader = lCmd1.ExecuteReader();

                while (lReader.Read())
                {
                    idProvs += Convert.ToString(lReader[0]) + " ";
                }
                idProvs += idProveedor.ToString();
                lReader.Close();

                lTransaction = lConn.BeginTransaction();

                lCmd.Connection = lConn;
                lCmd.Transaction = lTransaction;
                lCmd.CommandText = "INSERT INTO relProductoProveedor(IdProducto,IdProveedor) VALUES(" + idProducto.ToString() + "," + idProveedor.ToString() + ");";
                lCmd.ExecuteNonQuery();

                lCmd.CommandText = "UPDATE catProductos SET Proveedores = '" + idProvs + "' WHERE IdProducto = " + idProducto.ToString() + ";";
                lCmd.ExecuteNonQuery();

                lTransaction.Commit();

            }
            catch (System.Exception ex)
            {
                if (lTransaction != null)
                    lTransaction.Rollback();

                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private void cmd_Agregar_Click(object sender, EventArgs e)
        {
            if (this.cmb_Proveedores.SelectedIndex < 0)
            {
                MessageBox.Show("Seleccione el proveedor antes de agregar el pedido" , "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation );
                this.cmb_Proveedores.Focus();
                return;
            }
            if (this.idProvs[this.cmb_Proveedores.SelectedIndex] <= 0)
            {
                MessageBox.Show("Seleccione un proveedor v�lido antes de agregar el pedido", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.cmb_Proveedores.Focus();
                return;
            }
            if (!frm_config.IsNumeric(this.txtCantidad.Text))
            {
                MessageBox.Show("Dato inv�lido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtCantidad.Focus();
                return;
            }
            if (!frm_config.IsNumeric(this.txtPrecioUnit.Text))
            {
                MessageBox.Show("Dato inv�lido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.txtPrecioUnit.Focus();
                return;
            }

            if(this.dataGridView1.SelectedRows.Count<=0)
            {
                MessageBox.Show("Seleccione un producto a agregar", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            DataRow row;
            object[] keys = new object[2];
            keys[0]=this.m_KeyRecord;
            keys[1]=this.idProvs[this.cmb_Proveedores.SelectedIndex];
            row = this.m_detail.Tables[0].Rows.Find(keys);
            if (row == null)
            {
                row = this.m_detail.Tables[0].NewRow();
                row["idProducto"] = keys[0];
                row["idProveedor"] = keys[1];
                row["Codigo"] = this.dataGridView1.SelectedRows[0].Cells["CodigoProd"].Value;
                row["Descripcion"] = this.dataGridView1.SelectedRows[0].Cells["Descripcion"].Value;
                row["Proveedor"] = this.cmb_Proveedores.Text;
                row["Cantidad"] = this.txtCantidad.Text;
                row["PrecioUnit"] = this.txtPrecioUnit.Text;
                this.m_detail.Tables[0].Rows.Add(row);
            }
            else
            {
                row["Cantidad"] = this.txtCantidad.Text;
                row["PrecioUnit"] = this.txtPrecioUnit.Text;
            }
            this.m_detail.Tables[0].AcceptChanges();
        }

        private void cmd_Borrar_Click(object sender, EventArgs e)
        {
            if(this.dataGridView2.SelectedRows.Count>0)
            {
                foreach(DataGridViewRow dgRow in this.dataGridView2.SelectedRows)
                {
                    this.dataGridView2.Rows.Remove(dgRow);
                }
            }   
        }

        private void cmd_Save_Click(object sender, EventArgs e)
        {
            this.MakeOrdenesCompra();
            this.m_detail.Tables[0].Rows.Clear();
        }


        private void MakeOrdenesCompra()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction lTransaction = null;

            if (this.m_detail.Tables[0].Rows.Count <= 0)
                return;

            SortedList sl = new SortedList();
            string str1;
            int id;
            foreach( DataRow row in this.m_detail.Tables[0].Rows)
            {
                str1 = Convert.ToString(row["idProducto"]) + "~" + Convert.ToString(row["Cantidad"]) + "~" + Convert.ToString(row["PrecioUnit"]);
                id=Convert.ToInt32(row["idProveedor"]);
                if(sl.Contains(id))
                {
                    ((System.Collections.Generic.List<string>)sl[id]).Add(str1);
                }
                else
                {
                    System.Collections.Generic.List<string> det = new System.Collections.Generic.List<string>();
                    det.Add(str1);
                    sl.Add(id,det);
                }
            }


            try
            {

                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();

                // checa si no ya esta asignado
                int consec;
                DateTime dt;
                System.Data.Odbc.OdbcCommand lCmd1 = new System.Data.Odbc.OdbcCommand();
                lCmd1.Connection = lConn;
                lCmd1.CommandText = "SELECT ConsOrdenesCompra FROM confConsFactura";
                consec = Convert.ToInt32(lCmd1.ExecuteScalar());

                foreach( int idProv in sl.Keys)
                {
                    lCmd = new System.Data.Odbc.OdbcCommand();
                    dt=System.DateTime.Now;
                    lTransaction = lConn.BeginTransaction();

                    lCmd.Connection = lConn;
                    lCmd.Transaction = lTransaction;
                    lCmd.CommandText = "INSERT INTO catOrdenesCompra (IdProveedor,NumeroOrdenCompra,Fecha,NumProductos,Subtotal,Total,usuario,estatus) VALUES (?,?,?,?,?,?,?,?);";
                    lCmd.Parameters.AddWithValue("@IdProveedor",idProv);
                    lCmd.Parameters.AddWithValue("@NumeroOrdenCompra", consec);
                    lCmd.Parameters.AddWithValue("@Fecha", dt);
                    lCmd.Parameters.AddWithValue("@NumProductos", ((System.Collections.Generic.List<string>)sl[idProv]).Count);
                    lCmd.Parameters.AddWithValue("@Subtotal", 0);
                    lCmd.Parameters.AddWithValue("@Total", 0);
                    lCmd.Parameters.AddWithValue("@usuario", frm_Main.mps_usuario);
                    lCmd.Parameters.AddWithValue("@estatus", 'P');
                    lCmd.ExecuteNonQuery();

                    lCmd.Parameters.Clear();
                    lCmd.Transaction = lTransaction;
                    lCmd.CommandText = "SELECT IdOrdenCompra FROM catOrdenesCompra WHERE NumeroOrdenCompra=? AND IdProveedor=? AND Fecha=?;";
                    lCmd.Parameters.AddWithValue("@NumeroOrdenCompra", consec);
                    lCmd.Parameters.AddWithValue("@IdProveedor", idProv);
                    lCmd.Parameters.AddWithValue("@Fecha", dt);
                    id=Convert.ToInt32(lCmd.ExecuteScalar());

                    foreach(string str2 in ((System.Collections.Generic.List<string>)sl[idProv]))
                    {
                        string[] strs = str2.Split('~');
                        lCmd = new System.Data.Odbc.OdbcCommand();
                        lCmd.Connection = lConn;
                        lCmd.Parameters.Clear();
                        lCmd.Transaction = lTransaction;
                        lCmd.CommandText = "INSERT INTO detOrdenesCompra (IdOrdenCompra,IdProducto,Cantidad,Importe,Iva) VALUES (?,?,?,?,?);";
                        lCmd.Parameters.AddWithValue("@IdOrdenCompra", id);
                        lCmd.Parameters.AddWithValue("@IdProducto", strs[0]);
                        lCmd.Parameters.AddWithValue("@Cantidad", Convert.ToDouble(strs[1]));
                        lCmd.Parameters.AddWithValue("@Importe", System.Math.Round(Convert.ToDouble(strs[2]),2));
                        lCmd.Parameters.AddWithValue("@Iva", 0);
                        lCmd.ExecuteNonQuery();
                    }

                    lTransaction.Commit();
                    lCmd = null;
                    consec+=1;
                }

                lCmd1.Parameters.Clear();
                lCmd1.CommandText = "UPDATE confConsFactura SET ConsOrdenesCompra = ?;";
                lCmd1.Parameters.AddWithValue("@ConsOrdenesCompra", consec);
                lCmd1.ExecuteNonQuery();

				MessageBox.Show("La orden de compra se genero exitosamente","Informacion",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                if (lTransaction != null)
                    lTransaction.Rollback();

                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        //- Pedidos: Generar CSV (excel) general y por proveedor ligado al prod (no tomar en cuenta pto reorden=0)
        //  con codigoprod,codigo,descripcion, unidad (pza, caja. etc.),cantidad(ptmo maximo-existencia),orden(consecutivo), precio(0) 
        private void cmd_makefiles_Click(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcDataReader l_reader = null;

            if (this.m_dataset.Tables[0].Rows.Count <= 0)
                return;

            try
            {
                int id=0;
                string fileProv;
                System.Text.StringBuilder sb;
                foreach (string myFile in System.IO.Directory.GetFiles(".\\", "PEDIDOS-*.csv"))
                {
                    System.IO.File.Delete(myFile);
                }
                System.IO.StreamWriter swGen = new System.IO.StreamWriter(".\\PEDIDOS-General.csv",false);
                System.IO.StreamWriter swProv;
                
                lConn.ConnectionString = frm_Main.mps_strconnection;
                lConn.Open();
                
                foreach( DataRow row in this.m_dataset.Tables[0].Rows)
                {

                    //IdProducto,CodigoProd,Codigo,Descripcion,Existencia,PtoReorden,UnidadVenta,Observaciones
                    l_reader = this.LeeArticuloyExistencias(Convert.ToInt32(row["idProducto"]), lConn);
                    if(l_reader != null)
                    {
                        if (Convert.ToInt32(l_reader["PtoReorden"]) > 0)
                        {
                            id += 1;
                            sb = new System.Text.StringBuilder();
                            sb.Append(l_reader["CodigoProd"]);
                            sb.Append(",");
                            sb.Append(l_reader["Codigo"]);
                            sb.Append(",");
                            sb.Append(l_reader["Descripcion"]);
                            sb.Append(",");
                            sb.Append(l_reader["UnidadVenta"]);
                            sb.Append(",");
                            sb.Append(l_reader["Marca"]);
                            sb.Append(",");
                            try
                            {
                                sb.Append((Convert.ToDecimal(l_reader["PtoMaximo"]) - Convert.ToDecimal(l_reader["Existencia"])).ToString("######0.00"));
                            }
                            catch
                            {
                                sb.Append("0.00");
                            }
                            sb.Append(",");
                            sb.Append(id);
                            sb.Append(",0");
                            sb.Append(",");
                            sb.Append(l_reader["Observaciones"]);

                            swGen.WriteLine(sb.ToString());

                            System.Data.Odbc.OdbcDataReader l_readerProvs = this.LeeProveedoresArticulo(Convert.ToInt32(row["idProducto"]), lConn);
                            while (l_readerProvs.Read())
                            {
                                fileProv = l_readerProvs["Nombre"].ToString().Trim();
                                try
                                {
                                    swProv = new System.IO.StreamWriter(".\\PEDIDOS-" + fileProv + ".csv", true);
                                    swProv.WriteLine(sb.ToString());
                                    swProv.Close();
                                }
                                catch (Exception ex1)
                                {
                                    MessageBox.Show("Error al generar archivo " + fileProv + " : " + ex1.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            l_readerProvs.Close();
                        }
                        l_reader.Close();
                    }

                }
                swGen.Close();
                MessageBox.Show("Se generaron los archivos exitosamente", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (lConn.State == ConnectionState.Open)
                {
                    lConn.Close();
                }
            }
        }

        private System.Data.Odbc.OdbcDataReader LeeArticuloyExistencias(System.Int32 pkey, System.Data.Odbc.OdbcConnection l_conn)
        {
            //Buscar el articulo...
            System.Data.Odbc.OdbcDataReader l_reader=null;
            System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
            l_recid.Connection = l_conn;
            try
            {
                if (frm_Main.mp_idAlmacen <= 0)
                {
                    l_recid.CommandText = "SELECT * FROM catProductos WHERE IdProducto = ?;";
                    l_recid.Parameters.AddWithValue("@IdProducto", pkey);
                }
                else
                {
                    l_recid.CommandText = "SELECT catExistencias.*,catProductos.CodigoProd, catProductos.Codigo, catProductos.Descripcion, catProductos.UnidadVenta, catProductos.Marca, catProductos.Observaciones  FROM catProductos LEFT JOIN catExistencias ON catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=? WHERE catExistencias.idProducto=?;";
                    l_recid.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
                    l_recid.Parameters.AddWithValue("@IdProducto", pkey);
                }

                l_reader = l_recid.ExecuteReader();

                if (l_reader.Read() == false)
                {
                    l_reader.Close();
                    l_reader = null;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return l_reader;
        }

        private System.Data.Odbc.OdbcDataReader LeeProveedoresArticulo(System.Int32 pkey, System.Data.Odbc.OdbcConnection l_conn)
        {
            //Buscar el articulo...
            System.Data.Odbc.OdbcDataReader l_reader = null;
            System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
            l_recid.Connection = l_conn;
            try
            {
                l_recid.CommandText = "SELECT catProveedores.Nombre FROM catProveedores left join relProductoProveedor on catProveedores.idProveedor=relProductoProveedor.idProveedor WHERE relProductoProveedor.IdProducto=?;";
                l_recid.Parameters.AddWithValue("@IdProducto", pkey);

                l_reader = l_recid.ExecuteReader();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return l_reader;
        }

      /////////////////////////////////////////////////////////////////////////
      }

}
