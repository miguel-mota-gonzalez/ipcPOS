using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_Proveedores.
	/// </summary>
	public class frm_Proveedores : System.Windows.Forms.Form
	{
		private System.Data.Odbc.OdbcConnection m_conn;
		private System.Data.Odbc.OdbcDataAdapter m_da;
		private System.Data.Odbc.OdbcCommand m_select;
		private System.Data.DataSet m_dataset;   
		private System.Int32 m_KeyRecord;
		private System.Windows.Forms.Label lbl_Nombre;
		private System.Windows.Forms.Label lbl_ciudad;
		private System.Windows.Forms.Label lbl_contacto;
		private System.Windows.Forms.Label lbl_email;
		private System.Windows.Forms.Label lbl_Fecha;
		private System.Windows.Forms.Label lbl_telefono;
		private System.Windows.Forms.Label lbl_rfc;
		private System.Windows.Forms.Label lbl_direccion;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_nombre;
		private System.Windows.Forms.TextBox txt_rfc;
		private System.Windows.Forms.TextBox txt_dir;
		private System.Windows.Forms.TextBox txt_tel;
		private System.Windows.Forms.TextBox txt_fax;
		private System.Windows.Forms.TextBox txt_email;
		private System.Windows.Forms.TextBox txt_contacto;
		private System.Windows.Forms.TextBox txt_ciudad;
		private System.Windows.Forms.DateTimePicker txt_fechaalta;
		private System.Windows.Forms.Button cmd_cerrar;
		private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_Borrar;
        private System.Windows.Forms.Button cmd_Facturas;
        private ImageList imageList1;
        private IContainer components;

        public frm_ProveedoresList frm_ProvPrin = null;

		public frm_Proveedores()
		{
			InitializeComponent();
			this.m_KeyRecord = -1;
		}

		public frm_Proveedores(System.Int32 p_KeyRecord)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_KeyRecord = p_KeyRecord;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Proveedores));
            this.lbl_Nombre = new System.Windows.Forms.Label();
            this.lbl_ciudad = new System.Windows.Forms.Label();
            this.lbl_contacto = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_Fecha = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.lbl_rfc = new System.Windows.Forms.Label();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_rfc = new System.Windows.Forms.TextBox();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_tel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_fax = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_contacto = new System.Windows.Forms.TextBox();
            this.txt_ciudad = new System.Windows.Forms.TextBox();
            this.txt_fechaalta = new System.Windows.Forms.DateTimePicker();
            this.cmd_cerrar = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_Borrar = new System.Windows.Forms.Button();
            this.cmd_Facturas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Nombre
            // 
            this.lbl_Nombre.Location = new System.Drawing.Point(32, 24);
            this.lbl_Nombre.Name = "lbl_Nombre";
            this.lbl_Nombre.Size = new System.Drawing.Size(72, 16);
            this.lbl_Nombre.TabIndex = 0;
            this.lbl_Nombre.Text = "Nombre";
            // 
            // lbl_ciudad
            // 
            this.lbl_ciudad.Location = new System.Drawing.Point(32, 296);
            this.lbl_ciudad.Name = "lbl_ciudad";
            this.lbl_ciudad.Size = new System.Drawing.Size(72, 16);
            this.lbl_ciudad.TabIndex = 2;
            this.lbl_ciudad.Text = "Ciudad";
            // 
            // lbl_contacto
            // 
            this.lbl_contacto.Location = new System.Drawing.Point(32, 264);
            this.lbl_contacto.Name = "lbl_contacto";
            this.lbl_contacto.Size = new System.Drawing.Size(72, 16);
            this.lbl_contacto.TabIndex = 3;
            this.lbl_contacto.Text = "Contacto";
            // 
            // lbl_email
            // 
            this.lbl_email.Location = new System.Drawing.Point(32, 232);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(72, 16);
            this.lbl_email.TabIndex = 4;
            this.lbl_email.Text = "Email";
            // 
            // lbl_Fecha
            // 
            this.lbl_Fecha.Location = new System.Drawing.Point(32, 200);
            this.lbl_Fecha.Name = "lbl_Fecha";
            this.lbl_Fecha.Size = new System.Drawing.Size(80, 16);
            this.lbl_Fecha.TabIndex = 5;
            this.lbl_Fecha.Text = "Fecha de Alta";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.Location = new System.Drawing.Point(32, 136);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(72, 16);
            this.lbl_telefono.TabIndex = 6;
            this.lbl_telefono.Text = "Telefono";
            // 
            // lbl_rfc
            // 
            this.lbl_rfc.Location = new System.Drawing.Point(32, 56);
            this.lbl_rfc.Name = "lbl_rfc";
            this.lbl_rfc.Size = new System.Drawing.Size(72, 16);
            this.lbl_rfc.TabIndex = 7;
            this.lbl_rfc.Text = "RFC";
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.Location = new System.Drawing.Point(32, 88);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(72, 16);
            this.lbl_direccion.TabIndex = 8;
            this.lbl_direccion.Text = "Direccion";
            // 
            // txt_nombre
            // 
            this.txt_nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_nombre.Location = new System.Drawing.Point(104, 24);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(344, 20);
            this.txt_nombre.TabIndex = 0;
            this.txt_nombre.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_rfc
            // 
            this.txt_rfc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_rfc.Location = new System.Drawing.Point(104, 56);
            this.txt_rfc.Name = "txt_rfc";
            this.txt_rfc.Size = new System.Drawing.Size(344, 20);
            this.txt_rfc.TabIndex = 1;
            this.txt_rfc.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_dir
            // 
            this.txt_dir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_dir.Location = new System.Drawing.Point(104, 88);
            this.txt_dir.Multiline = true;
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.Size = new System.Drawing.Size(344, 40);
            this.txt_dir.TabIndex = 2;
            this.txt_dir.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_tel
            // 
            this.txt_tel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_tel.Location = new System.Drawing.Point(104, 136);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.Size = new System.Drawing.Size(344, 20);
            this.txt_tel.TabIndex = 3;
            this.txt_tel.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(32, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Fax";
            // 
            // txt_fax
            // 
            this.txt_fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_fax.Location = new System.Drawing.Point(104, 168);
            this.txt_fax.Name = "txt_fax";
            this.txt_fax.Size = new System.Drawing.Size(344, 20);
            this.txt_fax.TabIndex = 4;
            this.txt_fax.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_email
            // 
            this.txt_email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_email.Location = new System.Drawing.Point(104, 232);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(344, 20);
            this.txt_email.TabIndex = 6;
            this.txt_email.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_contacto
            // 
            this.txt_contacto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_contacto.Location = new System.Drawing.Point(104, 264);
            this.txt_contacto.Name = "txt_contacto";
            this.txt_contacto.Size = new System.Drawing.Size(344, 20);
            this.txt_contacto.TabIndex = 7;
            this.txt_contacto.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_ciudad
            // 
            this.txt_ciudad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ciudad.Location = new System.Drawing.Point(104, 296);
            this.txt_ciudad.Name = "txt_ciudad";
            this.txt_ciudad.Size = new System.Drawing.Size(344, 20);
            this.txt_ciudad.TabIndex = 8;
            this.txt_ciudad.TextChanged += new System.EventHandler(this.txt_nombre_TextChanged);
            // 
            // txt_fechaalta
            // 
            this.txt_fechaalta.Location = new System.Drawing.Point(104, 200);
            this.txt_fechaalta.Name = "txt_fechaalta";
            this.txt_fechaalta.Size = new System.Drawing.Size(200, 20);
            this.txt_fechaalta.TabIndex = 5;
            this.txt_fechaalta.ValueChanged += new System.EventHandler(this.txt_fechaalta_ValueChanged);
            // 
            // cmd_cerrar
            // 
            this.cmd_cerrar.ImageKey = "exit.ico";
            this.cmd_cerrar.ImageList = this.imageList1;
            this.cmd_cerrar.Location = new System.Drawing.Point(361, 328);
            this.cmd_cerrar.Name = "cmd_cerrar";
            this.cmd_cerrar.Size = new System.Drawing.Size(87, 23);
            this.cmd_cerrar.TabIndex = 11;
            this.cmd_cerrar.Text = "&Cerrar";
            this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_cerrar.Click += new System.EventHandler(this.cmd_cerrar_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "delete2.ico");
            this.imageList1.Images.SetKeyName(1, "disk_blue.ico");
            this.imageList1.Images.SetKeyName(2, "exit.ico");
            this.imageList1.Images.SetKeyName(3, "Folder.ico");
            // 
            // cmd_save
            // 
            this.cmd_save.ImageKey = "disk_blue.ico";
            this.cmd_save.ImageList = this.imageList1;
            this.cmd_save.Location = new System.Drawing.Point(240, 328);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(115, 23);
            this.cmd_save.TabIndex = 10;
            this.cmd_save.Text = "&Guardar y cerrar";
            this.cmd_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_Borrar
            // 
            this.cmd_Borrar.ImageKey = "delete2.ico";
            this.cmd_Borrar.ImageList = this.imageList1;
            this.cmd_Borrar.Location = new System.Drawing.Point(24, 328);
            this.cmd_Borrar.Name = "cmd_Borrar";
            this.cmd_Borrar.Size = new System.Drawing.Size(124, 23);
            this.cmd_Borrar.TabIndex = 9;
            this.cmd_Borrar.Text = "&Eliminar Registro";
            this.cmd_Borrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Borrar.Visible = false;
            this.cmd_Borrar.Click += new System.EventHandler(this.cmd_Borrar_Click);
            // 
            // cmd_Facturas
            // 
            this.cmd_Facturas.ImageIndex = 3;
            this.cmd_Facturas.ImageList = this.imageList1;
            this.cmd_Facturas.Location = new System.Drawing.Point(240, 353);
            this.cmd_Facturas.Name = "cmd_Facturas";
            this.cmd_Facturas.Size = new System.Drawing.Size(115, 23);
            this.cmd_Facturas.TabIndex = 12;
            this.cmd_Facturas.Text = "&Ver Facturas";
            this.cmd_Facturas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Facturas.Click += new System.EventHandler(this.cmd_Facturas_Click);
            // 
            // frm_Proveedores
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(472, 384);
            this.Controls.Add(this.cmd_Facturas);
            this.Controls.Add(this.cmd_Borrar);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.cmd_cerrar);
            this.Controls.Add(this.txt_fechaalta);
            this.Controls.Add(this.txt_ciudad);
            this.Controls.Add(this.txt_contacto);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_fax);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.txt_dir);
            this.Controls.Add(this.txt_rfc);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_direccion);
            this.Controls.Add(this.lbl_rfc);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.lbl_Fecha);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_contacto);
            this.Controls.Add(this.lbl_ciudad);
            this.Controls.Add(this.lbl_Nombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frm_Proveedores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Proveedor";
            this.Load += new System.EventHandler(this.frm_Clientes_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_Clientes_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_Clientes_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

        public bool m_IsModified = false;
        public bool mp_Loading = false;		
		
		private void frm_Clientes_Load(object sender, System.EventArgs e)
		{
            this.mp_Loading = true;
			
			this.txt_fechaalta.Value = System.DateTime.Today;

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.m_select = new System.Data.Odbc.OdbcCommand();
			this.m_select.Connection = this.m_conn;

            if (frm_ProvPrin != null)
            {
                frm_ProvPrin.p_Result = 0;
                frm_ProvPrin.p_currentId = -1;
            }

			if(this.m_KeyRecord!=-1)
				this.m_select.CommandText = "Select * From catProveedores where idproveedor = " + this.m_KeyRecord.ToString() + ";";     
			else
                this.m_select.CommandText = "Select * From catProveedores where idproveedor = -1;";

            this.m_da = new System.Data.Odbc.OdbcDataAdapter();
			this.m_da.SelectCommand = this.m_select;
			this.m_dataset = new System.Data.DataSet();
			this.m_da.Fill(this.m_dataset);

            if (this.m_KeyRecord == -1)
            {
                this.mp_Loading = false;
                return;
            }

			this.cmd_Borrar.Visible = true; 
			this.FillData();

            this.mp_Loading = false;
		}

		private void FillData()
		{
			this.txt_nombre.Text = this.m_dataset.Tables[0].Rows[0][1].ToString();     
			this.txt_rfc.Text = this.m_dataset.Tables[0].Rows[0][5].ToString();       
			this.txt_dir.Text = this.m_dataset.Tables[0].Rows[0][2].ToString();         
			this.txt_tel.Text = this.m_dataset.Tables[0].Rows[0][4].ToString();           
			this.txt_fax.Text = this.m_dataset.Tables[0].Rows[0][3].ToString();             
			this.txt_fechaalta.Value = System.Convert.ToDateTime(this.m_dataset.Tables[0].Rows[0][6]);  
			this.txt_email.Text = this.m_dataset.Tables[0].Rows[0][7].ToString();             
			this.txt_contacto.Text = this.m_dataset.Tables[0].Rows[0][8].ToString();             
			this.txt_ciudad.Text = this.m_dataset.Tables[0].Rows[0][9].ToString();             

		}

		private void cmd_cerrar_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void cmd_save_Click(object sender, System.EventArgs e)
		{
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcCommand l_updatei = new System.Data.Odbc.OdbcCommand();
			l_update.Connection = this.m_conn;
			l_updatei.Connection = this.m_conn;

			if(this.m_KeyRecord!=-1)
			{
				if(this.txt_nombre.Text.Trim()=="")
				{
					MessageBox.Show("Debe capturar al menos el nombre del proveedor. NO SE HA ACTUALIZADO EL REGISTRO.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					return;
				}
				
				try
				{
					this.m_conn.Open();
				
					l_update.CommandText = "UPDATE catProveedores SET Nombre=?,Direccion=?,Fax=?,Telefono=?,RFC=?,Fecha=?,email=?,contacto=?,ciudad=? WHERE IdProveedor=?";
					
					l_update.Parameters.AddWithValue("@Nombre",this.txt_nombre.Text);
					l_update.Parameters.AddWithValue("@Direccion",this.txt_dir.Text);
					l_update.Parameters.AddWithValue("@Fax",this.txt_fax.Text);
					l_update.Parameters.AddWithValue("@Telefono",this.txt_tel.Text);
					l_update.Parameters.AddWithValue("@RFC",this.txt_rfc.Text);
					l_update.Parameters.AddWithValue("@Fecha",this.txt_fechaalta.Value);
					l_update.Parameters.AddWithValue("@email",this.txt_email.Text);
					l_update.Parameters.AddWithValue("@contacto",this.txt_contacto.Text);
					l_update.Parameters.AddWithValue("@ciudad",this.txt_ciudad.Text);
					
					l_update.Parameters.AddWithValue("@IdProveedor",this.m_KeyRecord);
					
					l_update.ExecuteNonQuery();

                    this.m_IsModified = false;

                    if (frm_ProvPrin != null)
                    {
                        frm_ProvPrin.p_Result = 1;
                        frm_ProvPrin.p_currentId = this.m_KeyRecord;
                    }

                    //if (!string.IsNullOrEmpty(EasyInvoice.frm_Main.mps_strconnectionRepl))
                    //    this.SaveProveedorReplica();

					this.Close();                    
				
				}
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al actualizar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al actualizar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}
			}
			else
			{
				//MessageBox.Show("Registro nuevo...");
				
				if(this.txt_nombre.Text.Trim()=="")
				{
					MessageBox.Show("Debe capturar al menos el nombre del proveedor. NO SE HA AGREGADO EL REGISTRO.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					return;
				}
				
				try
				{
					this.m_conn.Open();
				
					l_update.CommandText = "INSERT INTO catProveedores(Nombre,Direccion,Fax,Telefono,RFC,Fecha,email,contacto,ciudad) VALUES (?,?,?,?,?,?,?,?,?)";
					
					l_update.Parameters.AddWithValue("@Nombre",this.txt_nombre.Text);
					l_update.Parameters.AddWithValue("@Direccion",this.txt_dir.Text);
					l_update.Parameters.AddWithValue("@Fax",this.txt_fax.Text);
					l_update.Parameters.AddWithValue("@Telefono",this.txt_tel.Text);
					l_update.Parameters.AddWithValue("@RFC",this.txt_rfc.Text);
					l_update.Parameters.AddWithValue("@Fecha",this.txt_fechaalta.Value);
					l_update.Parameters.AddWithValue("@email",this.txt_email.Text);
					l_update.Parameters.AddWithValue("@contacto",this.txt_contacto.Text);
					l_update.Parameters.AddWithValue("@ciudad",this.txt_ciudad.Text);
					
					l_update.ExecuteNonQuery();

                    this.m_IsModified = false;

                    if (frm_ProvPrin != null)
                    {
                        l_update.Parameters.Clear();
                        l_update.CommandText = "SELECT IdProveedor from catProveedores WHERE Nombre=? AND Fax=? AND Telefono=? AND RFC=? AND Fecha=?;";
                        l_update.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                        //l_update.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                        l_update.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                        l_update.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                        l_update.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                        l_update.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);

                        frm_ProvPrin.p_Result = 1;
                        frm_ProvPrin.p_currentId = (Int32)l_update.ExecuteScalar();
                    }

                    if (!string.IsNullOrEmpty(EasyInvoice.frm_Main.mps_strconnectionRepl))
                        this.SaveProveedorReplica();

					this.Close();                    
				
				}
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al agregar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al agregar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}
				
			}			
		}

        private void SaveProveedorReplica()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction l_trans = null;
            l_conn.ConnectionString = EasyInvoice.frm_Main.mps_strconnectionRepl;

            int m_keyrecord = -1;
            Boolean ok = true;

            try
            {
                if (l_conn.State != System.Data.ConnectionState.Open)
                    l_conn.Open();
                l_update.Connection = l_conn;

                l_update.Parameters.Clear();
                l_update.CommandText = "SELECT IdProveedor from catProveedores WHERE Nombre=? AND Fax=? AND Telefono=? AND RFC=? AND Fecha=?;";
                l_update.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                //l_update.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                l_update.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                l_update.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                l_update.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                l_update.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);
                object obj = l_update.ExecuteScalar();
                if (obj == null)
                    m_keyrecord = -1;
                else
                    m_keyrecord = Convert.ToInt32(obj);

                // salvar el nuevo registro
                if (m_keyrecord == -1)
                {
                    l_trans = l_conn.BeginTransaction();
                    l_update.Transaction = l_trans;

                    //agregar
                    l_update.CommandText = "INSERT INTO catProveedores(Nombre,Direccion,Fax,Telefono,RFC,Fecha,email,contacto,ciudad) VALUES (?,?,?,?,?,?,?,?,?)";
                    l_update.Parameters.Clear();
                    l_update.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                    l_update.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                    l_update.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                    l_update.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                    l_update.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                    l_update.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);
                    l_update.Parameters.AddWithValue("@email", this.txt_email.Text);
                    l_update.Parameters.AddWithValue("@contacto", this.txt_contacto.Text);
                    l_update.Parameters.AddWithValue("@ciudad", this.txt_ciudad.Text);

                    l_update.ExecuteNonQuery();

                    if (ok)
                        l_trans.Commit();

                }

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro  repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();

                l_conn.Dispose();
                l_conn = null;
            }

        }

		
		private void cmd_Borrar_Click(object sender, System.EventArgs e)
		{
            System.Data.Odbc.OdbcCommand l_delete = new System.Data.Odbc.OdbcCommand();

			if( MessageBox.Show("Esta a punto de eliminar este registro �Confirma que desea continuar?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;
			
            try
            {
            	this.m_conn.Open();
            	
				l_delete.Connection = this.m_conn;
				l_delete.CommandText = "delete from catProveedores where idproveedor = ?;";
				l_delete.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@idproveedor",this.m_KeyRecord )  );           
				
				l_delete.ExecuteNonQuery();

                this.m_IsModified = false;
                if (frm_ProvPrin != null)
                {
                    frm_ProvPrin.p_Result = 1;
                    frm_ProvPrin.p_currentId = -1;
                }
				
				this.Close(); 
            }
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}            			
		}
		
        private void cmd_Facturas_Click(object sender, System.EventArgs e)
        {
        	frm_facturasprov l_frm = new frm_facturasprov();

            l_frm.mp_int_KeyRecord = this.m_KeyRecord;
            l_frm.label1.Text = "Facturas de : " + this.txt_nombre.Text;

        	l_frm.ShowDialog();
        }
		
		private void frm_Clientes_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
            	case Keys.Enter:
            		this.cmd_save_Click(sender, e);
            		break;
                case Keys.Escape:
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        this.Close();
                    break;
                case Keys.F2:
                    this.cmd_save_Click(sender, e);
                    break;
            }

        }
		
        private void frm_Clientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.m_IsModified == true)
            {
                switch (MessageBox.Show("Ha modificado informaci�n en esta ventana �Desea guardar los datos antes de cerrar?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        this.cmd_save_Click(sender, e);
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void txt_nombre_TextChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
        }

        private void txt_fechaalta_ValueChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
        }        
		
	}
}
