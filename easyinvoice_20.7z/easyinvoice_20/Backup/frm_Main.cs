//#define ES_UNIX

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Win32;
using System.Configuration;
using System.Xml;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frm_Main : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
        private System.Windows.Forms.MenuItem menuItem11;
        private System.Windows.Forms.MenuItem menuItem13;
        private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
        private ToolStrip toolStrip1;
        private ToolStripButton cmd_clientes;
        private ToolStripButton cmd_proveedores;
        private MenuItem menuItem12;
        private ToolStripButton toolStripButton1;
        private ToolStripButton toolStripButton2;
        private ToolStripButton toolStripButton3;
        private ToolStripButton toolStripButton4;
        private ToolStripButton toolStripButton5;
        private IContainer components;
        private Timer timer1;
        private ToolStripButton cmd_corte;
        private MenuItem cmd_historial_cortes;

        //public string mp_acceso = "Caja";
        public static string mps_acceso = "Caja";
        private ToolStripButton cmd_entrada_rapida;
        private MenuItem menuItem16;
        public static int mp_idAlmacen = 0;
        public static string mp_strAlmacen = "";
        
        public static string mps_usuario = "";
        public static string m_curdir = ".";
        private MenuItem menuItem17;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripSeparator toolStripSeparator2;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private MenuItem cmdFacturacionelectronica;
        private MenuItem cmdImportarLlave;
        private OpenFileDialog openFileDialog1;
        private MenuItem cmdExportarFacturas;
        public static string mps_strconnection = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=.\\Invoices.mdb;Persist Security Info=False;Jet OLEDB:Database Password=";
        private ToolStripButton cmd_caja_efec;
        private ToolStripButton cmd_lista_notacredito;
        private ToolStripButton cmd_nva_notacredito;
        private MenuItem menuItem18;
        private MenuItem menuItem19;
        private ToolStripButton cmd_OrdenesCompra;
        private MenuItem menuItemPedidos;
        private MenuItem menuItemOrdenesCompra;
        private MenuItem menuItemResumenMovs;
        private ToolStripStatusLabel toolStripAlmacen;
        private ToolStripButton cmd_Traspaso;
		public static frm_ConsolidacionFact mFrmConsolidarFactura = null;

        //SVM Jun2014
        //Variables estaticas para traspasos y restriccion de mtto de catalogos
        public static string mps_strconnectionTrasp = null;
        public static int mps_DbTraspIsOrig = 1;
        private static string mps_strcontrolsnoaccess = null;
        public static string mps_strcatalogsnoaccess = "";
        private ToolStripDropDownButton cmd_Pedidos;
        private ToolStripMenuItem cmd_pedidosgen;
        private ToolStripMenuItem cmd_pedidosprv;
        private MenuItem menuItemPedidosGen;
        private MenuItem menuItemPedidosPrv;
        public static string mps_strconnectionRepl = "";
	
		public frm_Main()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();			

			//Dejar registro...			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main));
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.menuItem10 = new System.Windows.Forms.MenuItem();
            this.menuItem18 = new System.Windows.Forms.MenuItem();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem16 = new System.Windows.Forms.MenuItem();
            this.menuItem17 = new System.Windows.Forms.MenuItem();
            this.menuItem12 = new System.Windows.Forms.MenuItem();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.menuItem7 = new System.Windows.Forms.MenuItem();
            this.menuItem11 = new System.Windows.Forms.MenuItem();
            this.menuItem19 = new System.Windows.Forms.MenuItem();
            this.menuItemPedidos = new System.Windows.Forms.MenuItem();
            this.menuItemPedidosGen = new System.Windows.Forms.MenuItem();
            this.menuItemPedidosPrv = new System.Windows.Forms.MenuItem();
            this.menuItemOrdenesCompra = new System.Windows.Forms.MenuItem();
            this.menuItemResumenMovs = new System.Windows.Forms.MenuItem();
            this.menuItem13 = new System.Windows.Forms.MenuItem();
            this.menuItem14 = new System.Windows.Forms.MenuItem();
            this.menuItem15 = new System.Windows.Forms.MenuItem();
            this.cmd_historial_cortes = new System.Windows.Forms.MenuItem();
            this.cmdFacturacionelectronica = new System.Windows.Forms.MenuItem();
            this.cmdImportarLlave = new System.Windows.Forms.MenuItem();
            this.cmdExportarFacturas = new System.Windows.Forms.MenuItem();
            this.menuItem8 = new System.Windows.Forms.MenuItem();
            this.menuItem9 = new System.Windows.Forms.MenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.cmd_clientes = new System.Windows.Forms.ToolStripButton();
            this.cmd_proveedores = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.cmd_lista_notacredito = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.cmd_nva_notacredito = new System.Windows.Forms.ToolStripButton();
            this.cmd_Pedidos = new System.Windows.Forms.ToolStripDropDownButton();
            this.cmd_pedidosgen = new System.Windows.Forms.ToolStripMenuItem();
            this.cmd_pedidosprv = new System.Windows.Forms.ToolStripMenuItem();
            this.cmd_OrdenesCompra = new System.Windows.Forms.ToolStripButton();
            this.cmd_Traspaso = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cmd_reportes = new System.Windows.Forms.ToolStripButton();
            this.cmd_corte = new System.Windows.Forms.ToolStripButton();
            this.cmd_entrada_rapida = new System.Windows.Forms.ToolStripButton();
            this.cmd_caja_efec = new System.Windows.Forms.ToolStripButton();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripAlmacen = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem6,
            this.menuItem8});
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 0;
            this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem2,
            this.menuItem10,
            this.menuItem18,
            this.menuItem3,
            this.menuItem5,
            this.menuItem4,
            this.menuItem16,
            this.menuItem17,
            this.menuItem12});
            this.menuItem1.Text = "Catalogos";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 0;
            this.menuItem2.Shortcut = System.Windows.Forms.Shortcut.CtrlF;
            this.menuItem2.Text = "Facturas";
            this.menuItem2.Visible = false;
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // menuItem10
            // 
            this.menuItem10.Index = 1;
            this.menuItem10.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
            this.menuItem10.Text = "Notas";
            this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
            // 
            // menuItem18
            // 
            this.menuItem18.Index = 2;
            this.menuItem18.Text = "Notas de cr�dito";
            this.menuItem18.Visible = false;
            this.menuItem18.Click += new System.EventHandler(this.menuItem18_Click);
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 3;
            this.menuItem3.Shortcut = System.Windows.Forms.Shortcut.CtrlC;
            this.menuItem3.Text = "Clientes";
            this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
            // 
            // menuItem5
            // 
            this.menuItem5.Index = 4;
            this.menuItem5.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
            this.menuItem5.Text = "Proveedores";
            this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 5;
            this.menuItem4.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
            this.menuItem4.Text = "Productos";
            this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
            // 
            // menuItem16
            // 
            this.menuItem16.Index = 6;
            this.menuItem16.Text = "Familias";
            this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
            // 
            // menuItem17
            // 
            this.menuItem17.Index = 7;
            this.menuItem17.Text = "Configuracion";
            this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click);
            // 
            // menuItem12
            // 
            this.menuItem12.Index = 8;
            this.menuItem12.Shortcut = System.Windows.Forms.Shortcut.CtrlX;
            this.menuItem12.Text = "Salir";
            this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
            // 
            // menuItem6
            // 
            this.menuItem6.Index = 1;
            this.menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem7,
            this.menuItem11,
            this.menuItem19,
            this.menuItemPedidos,
            this.menuItemOrdenesCompra,
            this.menuItemResumenMovs,
            this.menuItem13,
            this.menuItem14,
            this.menuItem15,
            this.cmd_historial_cortes,
            this.cmdFacturacionelectronica,
            this.cmdImportarLlave,
            this.cmdExportarFacturas});
            this.menuItem6.Text = "Acciones";
            this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
            // 
            // menuItem7
            // 
            this.menuItem7.Index = 0;
            this.menuItem7.Shortcut = System.Windows.Forms.Shortcut.F4;
            this.menuItem7.Text = "Capturar una nueva factura";
            this.menuItem7.Visible = false;
            this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
            // 
            // menuItem11
            // 
            this.menuItem11.Index = 1;
            this.menuItem11.Shortcut = System.Windows.Forms.Shortcut.F5;
            this.menuItem11.Text = "Capturar una nueva nota";
            this.menuItem11.Visible = false;
            this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
            // 
            // menuItem19
            // 
            this.menuItem19.Index = 2;
            this.menuItem19.Text = "Capturar una nueva nota de cr�dito";
            this.menuItem19.Visible = false;
            this.menuItem19.Click += new System.EventHandler(this.menuItem19_Click);
            // 
            // menuItemPedidos
            // 
            this.menuItemPedidos.Index = 3;
            this.menuItemPedidos.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItemPedidosGen,
            this.menuItemPedidosPrv});
            this.menuItemPedidos.Text = "Pedidos";
            // 
            // menuItemPedidosGen
            // 
            this.menuItemPedidosGen.Index = 0;
            this.menuItemPedidosGen.Text = "General";
            this.menuItemPedidosGen.Click += new System.EventHandler(this.menuItemPedidosGen_Click);
            // 
            // menuItemPedidosPrv
            // 
            this.menuItemPedidosPrv.Index = 1;
            this.menuItemPedidosPrv.Text = "Por Proveedor";
            this.menuItemPedidosPrv.Click += new System.EventHandler(this.menuItemPedidosPrv_Click);
            // 
            // menuItemOrdenesCompra
            // 
            this.menuItemOrdenesCompra.Index = 4;
            this.menuItemOrdenesCompra.Text = "Ordenes de Compra";
            this.menuItemOrdenesCompra.Click += new System.EventHandler(this.menuItemOrdenesCompra_Click);
            // 
            // menuItemResumenMovs
            // 
            this.menuItemResumenMovs.Index = 5;
            this.menuItemResumenMovs.Text = "Resumen de Movimientos del d�a";
            this.menuItemResumenMovs.Click += new System.EventHandler(this.menuItemResumenMovs_Click);
            // 
            // menuItem13
            // 
            this.menuItem13.Index = 6;
            this.menuItem13.Text = "Usuarios";
            this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
            // 
            // menuItem14
            // 
            this.menuItem14.Index = 7;
            this.menuItem14.Text = "Respaldar informacion";
            this.menuItem14.Visible = false;
            this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
            // 
            // menuItem15
            // 
            this.menuItem15.Index = 8;
            this.menuItem15.Text = "Configuracion";
            this.menuItem15.Visible = false;
            this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
            // 
            // cmd_historial_cortes
            // 
            this.cmd_historial_cortes.Index = 9;
            this.cmd_historial_cortes.Text = "Historial de cortes de caja";
            this.cmd_historial_cortes.Visible = false;
            this.cmd_historial_cortes.Click += new System.EventHandler(this.cmd_historial_cortes_Click);
            // 
            // cmdFacturacionelectronica
            // 
            this.cmdFacturacionelectronica.Index = 10;
            this.cmdFacturacionelectronica.Text = "Configuracion de facturacion electronica";
            this.cmdFacturacionelectronica.Visible = false;
            this.cmdFacturacionelectronica.Click += new System.EventHandler(this.cmdFacturacionelectronica_Click);
            // 
            // cmdImportarLlave
            // 
            this.cmdImportarLlave.Index = 11;
            this.cmdImportarLlave.Text = "Importar la Llave para la Facturacion Electronica";
            this.cmdImportarLlave.Click += new System.EventHandler(this.cmdImportarLlave_Click);
            // 
            // cmdExportarFacturas
            // 
            this.cmdExportarFacturas.Index = 12;
            this.cmdExportarFacturas.Text = "Exportar Facturas...";
            this.cmdExportarFacturas.Click += new System.EventHandler(this.cmdExportarFacturas_Click);
            // 
            // menuItem8
            // 
            this.menuItem8.Index = 2;
            this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem9});
            this.menuItem8.Text = "Acerca de...";
            // 
            // menuItem9
            // 
            this.menuItem9.Index = 0;
            this.menuItem9.Text = "Acerca de...";
            this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmd_clientes,
            this.cmd_proveedores,
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.cmd_lista_notacredito,
            this.toolStripButton4,
            this.toolStripButton5,
            this.cmd_nva_notacredito,
            this.cmd_Pedidos,
            this.cmd_OrdenesCompra,
            this.cmd_Traspaso,
            this.toolStripSeparator2,
            this.cmd_reportes,
            this.cmd_corte,
            this.cmd_entrada_rapida,
            this.cmd_caja_efec});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(972, 44);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // cmd_clientes
            // 
            this.cmd_clientes.Image = ((System.Drawing.Image)(resources.GetObject("cmd_clientes.Image")));
            this.cmd_clientes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_clientes.Name = "cmd_clientes";
            this.cmd_clientes.Size = new System.Drawing.Size(49, 41);
            this.cmd_clientes.Text = "Clientes";
            this.cmd_clientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_clientes.ToolTipText = "Lista de clientes {Ctrl + C}";
            this.cmd_clientes.Click += new System.EventHandler(this.cmd_clientes_Click);
            // 
            // cmd_proveedores
            // 
            this.cmd_proveedores.Image = ((System.Drawing.Image)(resources.GetObject("cmd_proveedores.Image")));
            this.cmd_proveedores.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_proveedores.Name = "cmd_proveedores";
            this.cmd_proveedores.Size = new System.Drawing.Size(59, 41);
            this.cmd_proveedores.Text = "Productos";
            this.cmd_proveedores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_proveedores.ToolTipText = "Lista de productos {Ctrl + P}";
            this.cmd_proveedores.Click += new System.EventHandler(this.cmd_proveedores_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(72, 41);
            this.toolStripButton1.Text = "Proveedores";
            this.toolStripButton1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton1.ToolTipText = "Lista de proveedores {Ctrl + S}";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 44);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(53, 41);
            this.toolStripButton2.Text = "Facturas";
            this.toolStripButton2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton2.ToolTipText = "Lista de Facturas {Ctrl + F}";
            this.toolStripButton2.Visible = false;
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(39, 41);
            this.toolStripButton3.Text = "Notas";
            this.toolStripButton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton3.ToolTipText = "Lista de Notas {Ctrl + N}";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // cmd_lista_notacredito
            // 
            this.cmd_lista_notacredito.Image = ((System.Drawing.Image)(resources.GetObject("cmd_lista_notacredito.Image")));
            this.cmd_lista_notacredito.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_lista_notacredito.Name = "cmd_lista_notacredito";
            this.cmd_lista_notacredito.Size = new System.Drawing.Size(90, 41);
            this.cmd_lista_notacredito.Text = "Notas de cr�dito";
            this.cmd_lista_notacredito.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_lista_notacredito.ToolTipText = "Lista de Notas de Cr�dito";
            this.cmd_lista_notacredito.Visible = false;
            this.cmd_lista_notacredito.Click += new System.EventHandler(this.cmd_lista_notacredito_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(82, 41);
            this.toolStripButton4.Text = "Nueva Factura";
            this.toolStripButton4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton4.ToolTipText = "Nueva Factura {F4}";
            this.toolStripButton4.Visible = false;
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(68, 41);
            this.toolStripButton5.Text = "Nueva Nota";
            this.toolStripButton5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton5.ToolTipText = "Nueva Nota {F5}";
            this.toolStripButton5.Visible = false;
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // cmd_nva_notacredito
            // 
            this.cmd_nva_notacredito.Image = ((System.Drawing.Image)(resources.GetObject("cmd_nva_notacredito.Image")));
            this.cmd_nva_notacredito.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_nva_notacredito.Name = "cmd_nva_notacredito";
            this.cmd_nva_notacredito.Size = new System.Drawing.Size(119, 41);
            this.cmd_nva_notacredito.Text = "Nueva Nota de cr�dito";
            this.cmd_nva_notacredito.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_nva_notacredito.Visible = false;
            this.cmd_nva_notacredito.Click += new System.EventHandler(this.cmd_nva_notacredito_Click);
            // 
            // cmd_Pedidos
            // 
            this.cmd_Pedidos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmd_pedidosgen,
            this.cmd_pedidosprv});
            this.cmd_Pedidos.Image = ((System.Drawing.Image)(resources.GetObject("cmd_Pedidos.Image")));
            this.cmd_Pedidos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_Pedidos.Name = "cmd_Pedidos";
            this.cmd_Pedidos.Size = new System.Drawing.Size(57, 41);
            this.cmd_Pedidos.Text = "Pedidos";
            this.cmd_Pedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_Pedidos.ToolTipText = "Levantar pedidos para generar ordenes de compra";
            // 
            // cmd_pedidosgen
            // 
            this.cmd_pedidosgen.Name = "cmd_pedidosgen";
            this.cmd_pedidosgen.Size = new System.Drawing.Size(154, 22);
            this.cmd_pedidosgen.Text = "General";
            this.cmd_pedidosgen.Click += new System.EventHandler(this.cmd_pedidosgen_Click);
            // 
            // cmd_pedidosprv
            // 
            this.cmd_pedidosprv.Name = "cmd_pedidosprv";
            this.cmd_pedidosprv.Size = new System.Drawing.Size(154, 22);
            this.cmd_pedidosprv.Text = "Por Proveedor";
            this.cmd_pedidosprv.Click += new System.EventHandler(this.cmd_pedidosprv_Click);
            // 
            // cmd_OrdenesCompra
            // 
            this.cmd_OrdenesCompra.Image = ((System.Drawing.Image)(resources.GetObject("cmd_OrdenesCompra.Image")));
            this.cmd_OrdenesCompra.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_OrdenesCompra.Name = "cmd_OrdenesCompra";
            this.cmd_OrdenesCompra.Size = new System.Drawing.Size(107, 41);
            this.cmd_OrdenesCompra.Text = "Ordenes de Compra";
            this.cmd_OrdenesCompra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_OrdenesCompra.ToolTipText = "Consulta de ordenes de compra";
            this.cmd_OrdenesCompra.Click += new System.EventHandler(this.cmd_OrdenesCompra_Click);
            // 
            // cmd_Traspaso
            // 
            this.cmd_Traspaso.Image = ((System.Drawing.Image)(resources.GetObject("cmd_Traspaso.Image")));
            this.cmd_Traspaso.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_Traspaso.Name = "cmd_Traspaso";
            this.cmd_Traspaso.Size = new System.Drawing.Size(60, 41);
            this.cmd_Traspaso.Text = "Traspasos";
            this.cmd_Traspaso.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_Traspaso.Click += new System.EventHandler(this.cmd_Traspaso_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 44);
            // 
            // cmd_reportes
            // 
            this.cmd_reportes.Image = ((System.Drawing.Image)(resources.GetObject("cmd_reportes.Image")));
            this.cmd_reportes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_reportes.Name = "cmd_reportes";
            this.cmd_reportes.Size = new System.Drawing.Size(55, 41);
            this.cmd_reportes.Text = "Reportes";
            this.cmd_reportes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_reportes.Click += new System.EventHandler(this.Cmd_reportesClick);
            // 
            // cmd_corte
            // 
            this.cmd_corte.Image = ((System.Drawing.Image)(resources.GetObject("cmd_corte.Image")));
            this.cmd_corte.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_corte.Name = "cmd_corte";
            this.cmd_corte.Size = new System.Drawing.Size(76, 41);
            this.cmd_corte.Text = "Corte de caja";
            this.cmd_corte.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_corte.Visible = false;
            this.cmd_corte.Click += new System.EventHandler(this.cmd_corte_Click);
            // 
            // cmd_entrada_rapida
            // 
            this.cmd_entrada_rapida.Image = ((System.Drawing.Image)(resources.GetObject("cmd_entrada_rapida.Image")));
            this.cmd_entrada_rapida.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_entrada_rapida.Name = "cmd_entrada_rapida";
            this.cmd_entrada_rapida.Size = new System.Drawing.Size(138, 41);
            this.cmd_entrada_rapida.Text = "Recepciones/Devoluciones";
            this.cmd_entrada_rapida.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_entrada_rapida.Click += new System.EventHandler(this.cmd_entrada_rapida_Click);
            // 
            // cmd_caja_efec
            // 
            this.cmd_caja_efec.Image = ((System.Drawing.Image)(resources.GetObject("cmd_caja_efec.Image")));
            this.cmd_caja_efec.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmd_caja_efec.Name = "cmd_caja_efec";
            this.cmd_caja_efec.Size = new System.Drawing.Size(108, 41);
            this.cmd_caja_efec.Text = "Movimientos de caja";
            this.cmd_caja_efec.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.cmd_caja_efec.Visible = false;
            this.cmd_caja_efec.Click += new System.EventHandler(this.cmd_caja_efec_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "mdb";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripAlmacen});
            this.statusStrip1.Location = new System.Drawing.Point(0, 541);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(972, 25);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.toolStripStatusLabel1.Image = global::EasyInvoice.Properties.Resources.users2;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(129, 20);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripAlmacen
            // 
            this.toolStripAlmacen.Image = global::EasyInvoice.Properties.Resources.Be_Libbe;
            this.toolStripAlmacen.Name = "toolStripAlmacen";
            this.toolStripAlmacen.Size = new System.Drawing.Size(125, 20);
            this.toolStripAlmacen.Text = "toolStripStatusLabel2";
            this.toolStripAlmacen.Visible = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // frm_Main
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(972, 566);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Menu = this.mainMenu1;
            this.Name = "frm_Main";
            this.Text = "Easy Invoice";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_Main_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_Main_KeyDown);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.ToolStripButton cmd_reportes;
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			m_curdir = Application.StartupPath;
			//System.Diagnostics.Debugger.Break();

#if ES_UNIX 		
			
            //SVM Nov2009 lee cadena de conexion
            if(System.IO.File.Exists(m_curdir + "/EasyInvoice.dat"))
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(m_curdir + "/EasyInvoice.dat");
                mps_strconnection = sr.ReadToEnd();
                sr.Close();
                sr = null;
            }

            if (System.IO.File.Exists(m_curdir + "/EasyInvoicePrm.dat"))
            {
                string line;
                System.IO.StreamReader sr = new System.IO.StreamReader(m_curdir + "/EasyInvoicePrm.dat");
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.ToUpper().StartsWith("CONNECTIONTRASP="))
                        mps_strconnectionTrasp = line.Substring("CONNECTIONTRASP=".Length).Trim();
                    if (line.ToUpper().StartsWith("MENUSNOACCESS="))
                        EasyInvoice.frm_Main.mps_strmenusnoaccess = line.Substring("MENUSNOACCESS=".Length).Trim();
                    if (line.ToUpper().StartsWith("CATALOGOSNOACCESS="))
                        EasyInvoice.frm_Main.mps_strcatalogsnoaccess = line.Substring("CATALOGOSNOACCESS=".Length).Trim().ToUpper();
                }
                sr.Close();
                sr = null;
            }

#else
            //SVM Nov2009 lee cadena de conexion
            if(System.IO.File.Exists(m_curdir + "\\EasyInvoice.dat"))
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(m_curdir + "\\EasyInvoice.dat");
                mps_strconnection = sr.ReadToEnd();
                sr.Close();
                sr = null;
            }
			
            if(System.IO.File.Exists(m_curdir + "\\EasyInvoicePrm.dat"))
            {
                string line;
                System.IO.StreamReader sr = new System.IO.StreamReader(m_curdir + "\\EasyInvoicePrm.dat");
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.ToUpper().StartsWith("CONNECTIONTRASP="))
                        EasyInvoice.frm_Main.mps_strconnectionTrasp = line.Substring("CONNECTIONTRASP=".Length).Trim();
                    if (line.ToUpper().StartsWith("CONTROLSNOACCESS="))
                        EasyInvoice.frm_Main.mps_strcontrolsnoaccess = line.Substring("CONTROLSNOACCESS=".Length).Trim();
                    if (line.ToUpper().StartsWith("CATALOGOSNOACCESS="))  //PRODUCTOS,CLIENTES,PROVEEDORES
                        EasyInvoice.frm_Main.mps_strcatalogsnoaccess = line.Substring("CATALOGOSNOACCESS=".Length).Trim().ToUpper();
                    if (line.ToUpper().StartsWith("CONNECTIONREPL="))
                        EasyInvoice.frm_Main.mps_strconnectionRepl = line.Substring("CONNECTIONREPL=".Length).Trim().ToUpper();
                }
        
                sr.Close();
                sr = null;
            }			

#endif

            //TODO: Splash Screen?				
            frm_splash l_splash = new frm_splash();
            l_splash.timer1.Enabled = true;
            l_splash.ShowDialog();
			
			/*
			try
			{
				object l_objrg = Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Key","");
				
				if(l_objrg == null)
				{				
					object l_obj = Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Date","null");				
					
					if(l_obj==null)
					{
						Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Date",System.DateTime.Now.ToLongDateString());
					}
					else
					{
						if( System.Convert.ToDateTime(l_obj).AddDays(30) < System.DateTime.Now )
						{
							MessageBox.Show("�La versi�n demo ha expirado!\nContacte a su distribuidor para obtener una licencia.","Informaci�n", 
							                MessageBoxButtons.OK, MessageBoxIcon.Warning);						
							
							frmAbout l_frm = new frmAbout();
							l_frm.ShowDialog();
							
							return;
						}
					}
				}
				else
				{
					if(l_objrg.ToString()!="054FFADCF589878-547985324-AB986D098-1524A")
					{
						object l_obj = Registry.GetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Date","null");				
						
						if(l_obj==null)
						{
							Registry.SetValue("HKEY_LOCAL_MACHINE\\SOFTWARE\\MsExpMangr","Date",System.DateTime.Now);				
						}
						else
						{
							if( System.Convert.ToDateTime(l_obj).AddDays(30) < System.DateTime.Now )
							{
								MessageBox.Show("�La versi�n demo ha expirado!\nContacte a su distribuidor para obtener una licencia.","Informaci�n", 
								                MessageBoxButtons.OK, MessageBoxIcon.Warning);						
								
								frmAbout l_frm = new frmAbout();
								l_frm.ShowDialog();
								
								return;
							}
						}												
					}
				}
			}
			catch(System.Exception ex)
			{
				//MessageBox.Show(ex.Message);
                MessageBox.Show("Error al iniciar el sistema","ERROR" , MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
			}	
			*/	
			
			//Clave de acceso para Video America...
			clsAcceso l_acceso = new clsAcceso();
            if (l_acceso.ShowDialog() != DialogResult.Cancel)
            {
                frm_Main l_form = new frm_Main();
                frm_Main.mps_acceso = l_acceso.mp_permiso;
                frm_Main.mps_usuario = l_acceso.mp_usuario;
                frm_Main.mp_idAlmacen = l_acceso.mp_idAlmacen;
                frm_Main.mp_strAlmacen = l_acceso.mp_strAlmacen;
                Application.Run(l_form);
            }
			//else
			//	MessageBox.Show("Imposible acceder al sistema","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
						
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			frm_productoslist l_frmProductos = new frm_productoslist(); 
			l_frmProductos.MdiParent = this;
			l_frmProductos.Show();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			frm_Facturaslist l_frmFacturasList = new frm_Facturaslist(); 
			l_frmFacturasList.MdiParent = this;
			l_frmFacturasList.Show();
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			frm_ClientsList l_frmClientes = new frm_ClientsList();
			l_frmClientes.MdiParent = this;
			l_frmClientes.Show();
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			frm_ProveedoresList l_frmProveedores = new frm_ProveedoresList(); 
			l_frmProveedores.MdiParent = this;
			l_frmProveedores.Show();
		}

		
		private void frm_Main_Load(object sender, System.EventArgs e)
		{
            this.toolStripStatusLabel1.Text = frm_Main.mps_usuario;
            if (frm_Main.mp_strAlmacen.Length > 0)
            {
                this.toolStripAlmacen.Text = frm_Main.mp_strAlmacen;
                this.toolStripAlmacen.Visible = true;
            }
            else
            {
                this.toolStripAlmacen.Visible = false;
            }
            //Es acceso limitado?
            switch(frm_Main.mps_acceso)
            {
                case "Caja":
                {
                    //la cajera solo: corte de caja y facturas y notas
                    menuItem6.Enabled = false;  //menu acciones
                    menuItem1.Enabled = false;  //menu catalogos
                    this.cmd_clientes.Enabled = false;  // clientes
                    this.cmd_proveedores.Enabled = false; //proveedores
                    this.toolStripButton1.Enabled = false;  //proveedores
                    
                    this.toolStripButton4.Enabled = false;  //nueva facturas
                    this.toolStripButton5.Enabled = false;  //nueva notas
                    this.cmd_nva_notacredito.Enabled = false;   //nueva nota credito
                    this.cmd_reportes.Enabled = false;      //reportes
                    this.cmd_entrada_rapida.Enabled = false;   // entradas/devoluciones
                    this.cmd_corte.Enabled = true;   //core de caja
                    break;
                }
                case "Vendedor":
                {
                    //vendedores, harian notas,facturas y entradas y devoluciuones
                    menuItem6.Enabled = false;  //menu acciones
                    menuItem1.Enabled = false;  //menu catalogos
                    this.cmd_clientes.Enabled = false;  // clientes
                    this.cmd_proveedores.Enabled = false; //proveedores
                    this.toolStripButton1.Enabled = false;  //proveedores
                    this.toolStripButton2.Enabled = false;  //facturas
                    this.toolStripButton3.Enabled = false;  //notas
                    this.cmd_lista_notacredito.Enabled = false;  //notas cred
                    this.cmd_reportes.Enabled = false;      //reportes
                    this.cmd_entrada_rapida.Enabled = true;   // entradas/devoluciones
                    this.cmd_corte.Enabled = false;   //core de caja
                    break;
                }
            }

            if (!string.IsNullOrEmpty(mps_strcontrolsnoaccess))
            {
                // SVM jun2014  - Oculta controles y menus que no se deban visualizar
                // se usa la variable estatica para indicar que controles y menus ocultar
                // Ejemplo CONTROLSNOACCESS=Productos;cmd_proveedores
                this.ProcessControls(this);   // en el caso de controles se debe indicar el nombre del control 
                foreach (MenuItem mnu in this.Menu.MenuItems)   // en el caso de controles se debe indicar el texto del menu
                {
                    this.ProcessMenuItems(mnu);
                }
            }

            if (!string.IsNullOrEmpty(mps_strcatalogsnoaccess))
            {
                // SVM jun2014  - Oculta catalogos
                
            }
            // SVM jul2014 - se oculta
            this.cmdFacturacionelectronica.Visible = false;  // Config factura electronica
            this.cmdImportarLlave.Visible = false;  // Importar llave fac. electronica
            this.cmdExportarFacturas.Visible = false;  // Exportar facturas
            this.menuItem14.Visible = false;  // Respaldar informacion

		}

        private void ProcessControls(Control ctrlContainer)
        {
            string[] controlsnoaccess = mps_strcontrolsnoaccess.Split(';');
            foreach (Control ctrl in ctrlContainer.Controls)
            {
                if (ctrl.HasChildren)
                {
                    ProcessControls(ctrl);
                }
                else
                {
                    if (ctrl is ToolStrip)
                    {
                        foreach (ToolStripItem ts in ((ToolStrip)ctrl).Items)
                        {
                            if (Array.IndexOf(controlsnoaccess, ts.Name) >= 0)
                                ts.Visible = false;
                        }
                    }
                }

                if (Array.IndexOf(controlsnoaccess, ctrl.Name) >= 0)
                    ctrl.Visible = false;
            }
        }

        private void ProcessMenuItems(MenuItem menu)
        {
            string[] controlsnoaccess = mps_strcontrolsnoaccess.Split(';');
            foreach (MenuItem mn in menu.MenuItems)
                ProcessMenuItems(mn);

            if (Array.IndexOf(controlsnoaccess, menu.Text) >= 0)
                menu.Visible = false;
        }

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
		
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			frm_factura l_frmf = new frm_factura(); 
			//l_frmf.MdiParent = this;
			l_frmf.Show();		
        }

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			frmAbout l_form = new frmAbout();
			l_form.ShowDialog(); 
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
            frm_Facturaslist l_frmFacturasList = new frm_Facturaslist();
            l_frmFacturasList.MdiParent = this;
            l_frmFacturasList.m_notas = true;
            l_frmFacturasList.Show();
        }

		private void menuItem11_Click(object sender, System.EventArgs e)
		{			
            frm_factura l_frmf = new frm_factura();
            //l_frmf.MdiParent = this;
            l_frmf.m_bool_EsNota = true;
            l_frmf.Show();		
		}
		
		private void menuItem13_Click(object sender, System.EventArgs e)
		{

            if (mps_usuario == "plaza")
            {
                frm_cambiarclave l_form = new frm_cambiarclave();
                l_form.ShowDialog();
            }
            else
            {
                MessageBox.Show("No disponible consulte al administrador..");
            }
			
			
		}
		
		private void menuItem14_Click(object sender, System.EventArgs e)
		{
#if ES_UNIX			
            string lCurPath = Environment.CurrentDirectory;
			//mysqldump --u=root --password=santi Invoices > backupfile.sql
			
			if( this.saveFileDialog1.ShowDialog() == DialogResult.OK)
			{
                Environment.CurrentDirectory = lCurPath;
				
				try
				{
					//System.IO.File.Copy( m_curdir + "\\Invoices.mdb",this.saveFileDialog1.FileName);
					System.Diagnostics.Process proc = new System.Diagnostics.Process();
					proc.EnableRaisingEvents=false;
                    proc.StartInfo.UseShellExecute = false;
                    proc.StartInfo.RedirectStandardOutput = true;
                    proc.StartInfo.FileName = ConfigurationSettings.AppSettings["mysqlpath"] + "mysqldump";
					proc.StartInfo.Arguments="--u=root --password Invoices";
					
					//MessageBox.Show(proc.StartInfo.Arguments);
					
					proc.Start();	
					proc.WaitForExit();
					
					System.IO.File.WriteAllText(this.saveFileDialog1.FileName,proc.StandardOutput.ReadToEnd());
					
					MessageBox.Show("Respaldo generado exitosamente.","EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch(System.Exception ex)
				{
					MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
#else
				MessageBox.Show("No implementado en windows...");
#endif			
             
		}
		
		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("En construcci�n.");
			//frm_sysconf l_form = new frm_sysconf();
			//l_form.ShowDialog();
		}

		private void frm_Main_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			
		}

        private void cmd_clientes_Click(object sender, EventArgs e)
        {
            frm_ClientsList l_frmClientes = new frm_ClientsList();
            l_frmClientes.MdiParent = this;
            l_frmClientes.Show();
        }

        private void cmd_proveedores_Click(object sender, EventArgs e)
        {
            frm_productoslist l_frmProductos = new frm_productoslist();
            l_frmProductos.MdiParent = this;
            l_frmProductos.Show();
        }

        private void menuItem12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            frm_ProveedoresList l_frmProveedores = new frm_ProveedoresList();
            l_frmProveedores.MdiParent = this;
            l_frmProveedores.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            frm_Facturaslist l_frmFacturasList = new frm_Facturaslist();
            l_frmFacturasList.MdiParent = this;
            l_frmFacturasList.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            frm_Facturaslist l_frmFacturasList = new frm_Facturaslist();
            l_frmFacturasList.MdiParent = this;
            l_frmFacturasList.m_notas = true;
            l_frmFacturasList.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            frm_factura l_frmf = new frm_factura();            
            l_frmf.Show();		
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            frm_factura l_frmf = new frm_factura();
            l_frmf.m_bool_EsNota = true;
            l_frmf.Show();		
        }
		
		void Cmd_reportesClick(object sender, EventArgs e)
		{
			frm_reportes l_form = new frm_reportes();			
			l_form.MdiParent = this;
			l_form.Show();
		}

        private void timer1_Tick(object sender, EventArgs e)
        {            
        }

        private void cmd_corte_Click(object sender, EventArgs e)
        {
            frm_corte l_frm = new frm_corte();
            l_frm.MdiParent = this;
            l_frm.Show();
        }

        private void cmd_historial_cortes_Click(object sender, EventArgs e)
        {
            frm_hist_cortes l_frm = new frm_hist_cortes();
            l_frm.MdiParent = this;
            l_frm.Show();
        }

        private void cmd_entrada_rapida_Click(object sender, EventArgs e)
        {
        	frm_altas_caja l_frm = new frm_altas_caja();
        	l_frm.MdiParent = this;
        	l_frm.Show();
        }

        //SVM Nov2009
        // Ventana de familias
        private void menuItem16_Click(object sender, EventArgs e)
        {
            frm_familias l_frm = new frm_familias();
            l_frm.MdiParent = this;
            l_frm.Show();
        }

        private void menuItem17_Click(object sender, EventArgs e)
        {
            if (frm_Main.mps_acceso != "Administrador")
                return;
            frm_config l_frm = new frm_config();
            l_frm.ShowDialog();
        }

        private void cmdFacturacionelectronica_Click(object sender, EventArgs e)
        {
            frm_Factelectronica lFrm = new frm_Factelectronica();
            lFrm.ShowDialog();
        }

        public void UpdateKey(string strKey, string newValue)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(AppDomain.CurrentDomain.BaseDirectory + "EasyInvoice.exe.config");
            XmlNode appSettingsNode = xmlDoc.SelectSingleNode("configuration/appSettings");

            // Attempt to locate the requested setting.
            foreach (XmlNode childNode in appSettingsNode)
            {
                if (childNode.Attributes["key"].Value == strKey)
				{
					MessageBox.Show("found");
                    childNode.Attributes["value"].Value = newValue;
				}
            }
            xmlDoc.Save(AppDomain.CurrentDomain.BaseDirectory + "EasyInvoice.exe.config");
            xmlDoc.Save(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
        }

        private void cmdImportarLlave_Click(object sender, EventArgs e)
        {
            string lCurPath = Environment.CurrentDirectory;

			if( this.openFileDialog1.ShowDialog() == DialogResult.OK)
			{
                Environment.CurrentDirectory = lCurPath;
				try
				{
                    clsFactElectronica.clsFactElec lFE = new clsFactElectronica.clsFactElec();

                    lFE.mOpenSSLPath = ConfigurationSettings.AppSettings["opensslpath"];
					
					if( ConfigurationSettings.AppSettings["keypwd"] != null )
					{
						lFE.mPassword = ConfigurationSettings.AppSettings["keypwd"];
					}

                    string lFileName = this.openFileDialog1.FileName;

                    int lPos = lFileName.LastIndexOf("\\");
                    if( lPos == -1)
                        lPos = lFileName.LastIndexOf("/");

                    lFileName = lFileName.Substring(lPos,lFileName.Length - lPos);
                    lFileName = lFileName.Replace("\\", "").Replace("/", "");

                    //MessageBox.Show(lFileName);

                    System.IO.File.Copy(this.openFileDialog1.FileName, lFileName,true);
                    string lResultFile = lFE.GeneratePEMKey(lFileName);
                    
                    //Save the last key name
                    //ConfigurationSettings.AppSettings.Set("keyfile", lResultFile);
                    //this.UpdateKey("keyfile", lResultFile);
					System.IO.File.WriteAllText("keyfile.txt",lResultFile);

                    MessageBox.Show("Llave importada exitosamente a " + lResultFile + ".", "EasyInvoice", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				catch(System.Exception ex)
				{
					MessageBox.Show(ex.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
        }

        private void cmdExportarFacturas_Click(object sender, EventArgs e)
        {
            frm_ExportarFacturas lFrm = new frm_ExportarFacturas();
            lFrm.ShowDialog();
        }

        private void cmd_caja_efec_Click(object sender, EventArgs e)
        {
            frm_caja_efec lFrm = new frm_caja_efec();
            lFrm.ShowDialog();
        }

        // Lista de notas de credito
        private void menuItem18_Click(object sender, EventArgs e)
        {
            frm_notascredlist l_frmnotascredList = new frm_notascredlist();
            l_frmnotascredList.MdiParent = this;
            l_frmnotascredList.Show();

        }

        // nva nota de credito
        private void menuItem19_Click(object sender, EventArgs e)
        {
            frm_notascred l_frmnc = new frm_notascred();
            l_frmnc.Show();		

        }

        private void cmd_lista_notacredito_Click(object sender, EventArgs e)
        {
            this.menuItem18_Click(sender, e);
        }

        private void cmd_nva_notacredito_Click(object sender, EventArgs e)
        {
            this.menuItem19_Click(sender, e);
        }

        private void menuItemPedidosGen_Click(object sender, EventArgs e)
        {
            frm_pedidos l_frmPedidos = new frm_pedidos();
            l_frmPedidos.MdiParent = this;
            l_frmPedidos.Show();
        }

        private void menuItemPedidosPrv_Click(object sender, EventArgs e)
        {
            frm_pedidosprv l_frmPedidosPrv = new frm_pedidosprv();
            l_frmPedidosPrv.MdiParent = this;
            l_frmPedidosPrv.Show();
        }


        private void menuItemOrdenesCompra_Click(object sender, EventArgs e)
        {
            frm_ordenescompralist l_ordenescompralist = new frm_ordenescompralist();
            l_ordenescompralist.MdiParent = this;
            l_ordenescompralist.Show();

        }

        private void cmd_Pedidos_Click(object sender, EventArgs e)
        {

        }

        private void cmd_pedidosgen_Click(object sender, EventArgs e)
        {
            this.menuItemPedidosGen_Click(sender, e);
        }

        private void cmd_pedidosprv_Click(object sender, EventArgs e)
        {
            this.menuItemPedidosPrv_Click(sender, e);
        }


        private void cmd_OrdenesCompra_Click(object sender, EventArgs e)
        {
            this.menuItemOrdenesCompra_Click(sender, e);
        }

        private void menuItemResumenMovs_Click(object sender, EventArgs e)
        {
            frm_arqueo l_arqueo = new frm_arqueo();
            l_arqueo.MdiParent = this;
            l_arqueo.Show();            
        }

        private void cmd_Traspaso_Click(object sender, EventArgs e)
        {
            frm_TraspasosList l_frmTraspasosLst = new frm_TraspasosList();
            l_frmTraspasosLst.MdiParent = this;
            l_frmTraspasosLst.Show();
        }

        public static System.DateTime Now_()
        {
            System.Data.Odbc.OdbcConnection l_conn;
            System.Data.Odbc.OdbcCommand l_cmd;
            System.DateTime dt = new DateTime(1900,1,1);

            if(!System.IO.File.Exists("SRVTIME.BIN"))
                return System.DateTime.Now;

            l_conn = new System.Data.Odbc.OdbcConnection();
            l_cmd = new System.Data.Odbc.OdbcCommand();
            try
            {
                string str1;
                l_conn.ConnectionString = frm_Main.mps_strconnection;
                l_cmd.Connection = l_conn;
                l_conn.Open();
                l_cmd.CommandText = "select SYSDATE()+0;";
                l_cmd.CommandType = System.Data.CommandType.Text;
                str1 = Convert.ToString(l_cmd.ExecuteScalar());
                //solo SYSDATE() -> 2006-04-12 13:47:46 (varia segun idioma)  O  SYSDATE()+0 -> 20111204155516 
                dt = new DateTime( Convert.ToInt32(str1.Substring(0, 4)), Convert.ToInt32(str1.Substring(4, 2)), Convert.ToInt32(str1.Substring(6, 2)), Convert.ToInt32(str1.Substring(8, 2)), Convert.ToInt32(str1.Substring(10, 2)), Convert.ToInt32(str1.Substring(12, 2)));
            }
            catch(Exception ex)
            {
               
            }
            finally
            {
                if (l_conn.State == ConnectionState.Open)
                    l_conn.Close();

            }
            if (dt.Year == 1900)
                return System.DateTime.Now;
            else
                return dt;
        }


	}
}
