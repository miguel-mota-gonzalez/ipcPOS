﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class frm_familias
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_familias));
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_oldkey = new System.Windows.Forms.Label();
            this.cmd_cancel = new System.Windows.Forms.Button();
            this.lvw_main = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_del = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.cmb_acceso = new System.Windows.Forms.ComboBox();
            this.lbl_acceso = new System.Windows.Forms.Label();
            this.cmd_add = new System.Windows.Forms.Button();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.SuspendLayout();
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(385, 26);
            this.txt_nombre.MaxLength = 50;
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(113, 20);
            this.txt_nombre.TabIndex = 0;
            this.txt_nombre.Enter += new System.EventHandler(this.Txt_new1Enter);
            // 
            // lbl_oldkey
            // 
            this.lbl_oldkey.AutoSize = true;
            this.lbl_oldkey.Location = new System.Drawing.Point(388, 9);
            this.lbl_oldkey.Name = "lbl_oldkey";
            this.lbl_oldkey.Size = new System.Drawing.Size(40, 13);
            this.lbl_oldkey.TabIndex = 3;
            this.lbl_oldkey.Text = "Código";
            // 
            // cmd_cancel
            // 
            this.cmd_cancel.Location = new System.Drawing.Point(547, 256);
            this.cmd_cancel.Name = "cmd_cancel";
            this.cmd_cancel.Size = new System.Drawing.Size(75, 23);
            this.cmd_cancel.TabIndex = 7;
            this.cmd_cancel.Text = "Cerrar";
            this.cmd_cancel.UseVisualStyleBackColor = true;
            this.cmd_cancel.Click += new System.EventHandler(this.Cmd_cancelClick);
            // 
            // lvw_main
            // 
            this.lvw_main.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvw_main.FullRowSelect = true;
            this.lvw_main.Location = new System.Drawing.Point(12, 8);
            this.lvw_main.MultiSelect = false;
            this.lvw_main.Name = "lvw_main";
            this.lvw_main.Size = new System.Drawing.Size(366, 270);
            this.lvw_main.TabIndex = 8;
            this.lvw_main.UseCompatibleStateImageBehavior = false;
            this.lvw_main.View = System.Windows.Forms.View.Details;
            this.lvw_main.SelectedIndexChanged += new System.EventHandler(this.lvw_main_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Código";
            this.columnHeader1.Width = 87;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Descripción";
            this.columnHeader2.Width = 149;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Padre";
            this.columnHeader3.Width = 122;
            // 
            // cmd_save
            // 
            this.cmd_save.Location = new System.Drawing.Point(391, 221);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(75, 23);
            this.cmd_save.TabIndex = 5;
            this.cmd_save.Text = "Guardar";
            this.cmd_save.UseVisualStyleBackColor = true;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_del
            // 
            this.cmd_del.Location = new System.Drawing.Point(391, 255);
            this.cmd_del.Name = "cmd_del";
            this.cmd_del.Size = new System.Drawing.Size(75, 23);
            this.cmd_del.TabIndex = 6;
            this.cmd_del.Text = "Borrar";
            this.cmd_del.UseVisualStyleBackColor = true;
            this.cmd_del.Click += new System.EventHandler(this.cmd_del_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(388, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Descripción";
            // 
            // txt_login
            // 
            this.txt_login.Location = new System.Drawing.Point(385, 65);
            this.txt_login.MaxLength = 16;
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(237, 20);
            this.txt_login.TabIndex = 1;
            // 
            // cmb_acceso
            // 
            this.cmb_acceso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_acceso.FormattingEnabled = true;
            this.cmb_acceso.Items.AddRange(new object[] {
            "Administrador",
            "Caja"});
            this.cmb_acceso.Location = new System.Drawing.Point(385, 113);
            this.cmb_acceso.Name = "cmb_acceso";
            this.cmb_acceso.Size = new System.Drawing.Size(237, 21);
            this.cmb_acceso.TabIndex = 4;
            // 
            // lbl_acceso
            // 
            this.lbl_acceso.AutoSize = true;
            this.lbl_acceso.Location = new System.Drawing.Point(387, 95);
            this.lbl_acceso.Name = "lbl_acceso";
            this.lbl_acceso.Size = new System.Drawing.Size(35, 13);
            this.lbl_acceso.TabIndex = 15;
            this.lbl_acceso.Text = "Padre";
            // 
            // cmd_add
            // 
            this.cmd_add.Location = new System.Drawing.Point(547, 221);
            this.cmd_add.Name = "cmd_add";
            this.cmd_add.Size = new System.Drawing.Size(75, 23);
            this.cmd_add.TabIndex = 16;
            this.cmd_add.Text = "Agregar";
            this.cmd_add.UseVisualStyleBackColor = true;
            this.cmd_add.Click += new System.EventHandler(this.cmd_add_Click);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "idPadre";
            this.columnHeader4.Width = 0;
            // 
            // frm_familias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(630, 290);
            this.Controls.Add(this.cmd_add);
            this.Controls.Add(this.lbl_acceso);
            this.Controls.Add(this.cmb_acceso);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.cmd_del);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.lvw_main);
            this.Controls.Add(this.cmd_cancel);
            this.Controls.Add(this.lbl_oldkey);
            this.Controls.Add(this.txt_nombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_familias";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Familias";
            this.Load += new System.EventHandler(this.frm_cambiarclave_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
		private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Button cmd_cancel;
		private System.Windows.Forms.Label lbl_oldkey;
        private System.Windows.Forms.ListView lvw_main;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_del;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.ComboBox cmb_acceso;
        private System.Windows.Forms.Label lbl_acceso;
        private System.Windows.Forms.Button cmd_add;
        private System.Windows.Forms.ColumnHeader columnHeader4;
	}
}
