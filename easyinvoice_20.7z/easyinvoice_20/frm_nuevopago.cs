using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_nuevopago : Form
    {

        private int m_idcliente =-1;
        private int m_nc = -1;
        private System.String m_folio = "";

        public System.String Folio { 
            get
            { 
                return m_folio;
            }
            set
            {
                m_folio = value;
                if (m_folio.Length > 0)
                    this.lblFolio.Text = "Folio: " + m_folio;
                else
                    this.lblFolio.Text = "";
            }
        }

        public int idCliente
        {
            get
            {
                return m_idcliente;
            }
            set
            {
                m_idcliente = value;
            }
        }

        public int NumeroNotaCred
        {
            get
            {
                return m_nc;
            }
        }

        public frm_nuevopago()
        {
            InitializeComponent();
        }

        private void cmd_aceptar_Click(object sender, EventArgs e)
        {
            if(!frm_config.IsNumeric(this.txtCantidad.Text))
            {
                MessageBox.Show("Dato invalido, debe ser num�rico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txtCantidad.Focus();
                return;
            }
            m_nc = -1;
            if (this.radioButton2.Checked)
            {
                m_nc = Convert.ToInt32(this.cmb_notascred.Text.Substring(0, this.cmb_notascred.Text.IndexOf("-")).Trim()  );
            }
            this.Close();
            this.DialogResult = DialogResult.OK;
        }

        private void cmd_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            this.DialogResult = DialogResult.Cancel;
        }

        private void frm_nuevopago_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    this.Close();
                    this.DialogResult = DialogResult.OK;
                    break;
                case Keys.Escape:
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        this.Close();
                    this.DialogResult = DialogResult.Cancel;
                    break;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                // solo la 1a vez o si esta vacio lee las notas de credito pendientes de asignar
                if (this.cmb_notascred.Items.Count == 0)
                {                    
                    System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                    l_conn.ConnectionString = frm_Main.mps_strconnection;
                    try
                    {
                        l_conn.Open();

                        System.Data.DataSet m_dataset = new System.Data.DataSet();
                        System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                        l_select.Connection = l_conn;
                        l_select.CommandText = "SELECT numeronotacred,fecha,total,concepto FROM catnotascred WHERE cancelada=0 AND estatus=0 AND idcliente=" + this.m_idcliente + " order by Fecha";
                        System.Data.Odbc.OdbcDataReader l_reader = l_select.ExecuteReader();

                        this.cmb_notascred.Items.Clear();
                        while (l_reader.Read())
                        {
                            this.cmb_notascred.Items.Add(l_reader[0].ToString() + " --> " + Convert.ToDateTime(l_reader[1]).ToString("dd-MM-yyyy") + " " + l_reader[3].ToString() + " {" + l_reader[2].ToString() + "}" );
                        }
                        l_reader.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error leyendo notas de credito " + ex.Message , "Error", MessageBoxButtons.OK, MessageBoxIcon.Error );
                    }
                    finally
                    {
                        if (l_conn.State == ConnectionState.Open)
                            l_conn.Close();
                    }
                }
                if (this.cmb_notascred.Items.Count == 0)
                {
                    this.cmb_notascred.Visible = false;
                    MessageBox.Show("No se encontraron notas de credito pendientes de asignar para el cliente, registre una nueva nota de cr�dito", "Notas de Cr�dito", MessageBoxButtons.OK, MessageBoxIcon.Information );
                    this.radioButton1.Checked = true;
                    this.txtCantidad.Enabled = true;
                }
                else
                {
                    this.cmb_notascred.SelectedIndex = 0;
                    this.cmb_notascred.Visible = true;
                    this.txtCantidad.Enabled = false; 
                }
            }
            else
            {
                this.cmb_notascred.Visible = false;
            }
        }

        private void cmb_notascred_SelectedIndexChanged(object sender, EventArgs e)
        {
            string val="";
            val = this.cmb_notascred.Text.Substring(this.cmb_notascred.Text.LastIndexOf("{") + 1);
            val = val.Replace("}", "");
            this.txtCantidad.Text= val;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.txtCantidad.Enabled = true;
        }
    }
}
