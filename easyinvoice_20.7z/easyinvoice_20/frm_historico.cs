﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_historico : Form
    {
        public static string observs = "";

        public frm_historico()
        {
            InitializeComponent();
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            observs = this.txt_observs.Text;
            this.Close();
        }

        private void frm_historico_Load(object sender, EventArgs e)
        {
            observs = "";
            this.txt_observs.Text = "";
        }
    }
}
