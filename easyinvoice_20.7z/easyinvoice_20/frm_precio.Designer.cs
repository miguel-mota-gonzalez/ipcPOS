﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 3/2/2008
 * Time: 1:13 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class frm_precio
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_precio));
			this.lbl_precio = new System.Windows.Forms.Label();
			this.txt_precio = new System.Windows.Forms.MaskedTextBox();
			this.cmd_ok = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lbl_precio
			// 
			this.lbl_precio.AutoSize = true;
			this.lbl_precio.Location = new System.Drawing.Point(12, 23);
			this.lbl_precio.Name = "lbl_precio";
			this.lbl_precio.Size = new System.Drawing.Size(37, 13);
			this.lbl_precio.TabIndex = 0;
			this.lbl_precio.Text = "Precio";
			// 
			// txt_precio
			// 
			this.txt_precio.Location = new System.Drawing.Point(12, 39);
			this.txt_precio.Mask = "$999,999.99";
			this.txt_precio.Name = "txt_precio";
			this.txt_precio.Size = new System.Drawing.Size(173, 20);
			this.txt_precio.TabIndex = 1;
			this.txt_precio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_precioKeyDown);
			// 
			// cmd_ok
			// 
			this.cmd_ok.Location = new System.Drawing.Point(109, 80);
			this.cmd_ok.Name = "cmd_ok";
			this.cmd_ok.Size = new System.Drawing.Size(75, 23);
			this.cmd_ok.TabIndex = 2;
			this.cmd_ok.Text = "Aceptar";
			this.cmd_ok.UseVisualStyleBackColor = true;
			this.cmd_ok.Click += new System.EventHandler(this.Cmd_okClick);
			// 
			// frm_precio
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(199, 115);
			this.Controls.Add(this.cmd_ok);
			this.Controls.Add(this.txt_precio);
			this.Controls.Add(this.lbl_precio);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frm_precio";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Precio";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		public System.Windows.Forms.MaskedTextBox txt_precio;
		private System.Windows.Forms.Button cmd_ok;
		private System.Windows.Forms.Label lbl_precio;
	}
}
