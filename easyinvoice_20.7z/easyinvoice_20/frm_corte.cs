using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
    public partial class frm_corte : Form
    {
        private System.Data.Odbc.OdbcConnection m_conn;

        public frm_corte()
        {
            InitializeComponent();

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            this.LoadDocPositions();
        }

        private void cmd_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmd_generar_Click(object sender, EventArgs e)
        {
            if (
            MessageBox.Show("¿Confirma que desea generar el corte de caja?", "A T E N C I O N", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes
               )
            {
                this.cmd_generar.Enabled = false;

                System.Collections.ArrayList l_facturas = new System.Collections.ArrayList();
                int l_total_facturas = 0;
                double l_total = 0;
                double l_totalp = 0;
                this.lbl_msg.Text = "Cargando facturas, notas y movimientos de caja, espere por favor...";

                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

                l_cmd.Connection = this.m_conn;
                // SVM Dic2010
                //l_cmd.CommandText = "SELECT catFacturas.IdFactura,catFacturas.NumeroFactura, catFacturas.Subtotal, catFacturas.Total, catFacturas.Fecha,detCorte.iidCorte FROM catFacturas LEFT JOIN detCorte ON catFacturas.IdFactura = detCorte.IdFactura AND catFacturas.esfactura = detCorte.esfactura WHERE (((detCorte.iidCorte) Is Null) and catFacturas.usuario = ? and catFacturas.estatus = 1 ) Order by catFacturas.Fecha;";
                l_cmd.CommandText = "SELECT catFacturas.IdFactura,catFacturas.NumeroFactura, catFacturas.Subtotal, catFacturas.Total, catFacturas.Fecha,detCorte.iidCorte FROM catFacturas LEFT JOIN detCorte ON catFacturas.IdFactura = detCorte.IdFactura AND catFacturas.esfactura = detCorte.esfactura WHERE (((detCorte.iidCorte) Is Null) and catFacturas.usuarioventa = ? and catFacturas.estatus = 1 ) Order by catFacturas.Fecha;";

                l_cmd.Parameters.AddWithValue("@usuarioventa",frm_Main.mps_usuario);
                
                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

                while (l_reader.Read())
                {
                    //MessageBox.Show( l_reader["NumeroFactura"].ToString() );
                    l_facturas.Add(l_reader["IdFactura"].ToString() + "|" + l_reader["NumeroFactura"].ToString() + "|" + l_reader["Fecha"].ToString() + "|" + l_reader["Total"].ToString() + "|1");
                    l_total += (Convert.ToDouble(l_reader["Total"])); 
                    l_total_facturas++;
                }

                l_reader.Close();
                this.m_conn.Close();
                
                //---------------------------------------
                
                l_cmd = new System.Data.Odbc.OdbcCommand();

                l_cmd.Connection = this.m_conn;
                // SVM Dic2010
                //l_cmd.CommandText = "SELECT catNotas.IdFactura,catNotas.NumeroFactura, catNotas.Subtotal, catNotas.Total, catNotas.Fecha,detCorte.iidCorte FROM catNotas LEFT JOIN detCorte ON catNotas.IdFactura = detCorte.IdFactura AND catNotas.esfactura = detCorte.esfactura WHERE (((detCorte.iidCorte) Is Null) and catNotas.usuario = ? AND catNotas.estatus = 1 ) Order by catNotas.Fecha;";
                l_cmd.CommandText = "SELECT catNotas.IdFactura,catNotas.NumeroFactura, catNotas.Subtotal, catNotas.Total, catNotas.Fecha,detCorte.iidCorte FROM catNotas LEFT JOIN detCorte ON catNotas.IdFactura = detCorte.IdFactura AND catNotas.esfactura = detCorte.esfactura WHERE (((detCorte.iidCorte) Is Null) and catNotas.usuarioventa = ? AND catNotas.estatus = 1 ) Order by catNotas.Fecha;";

                l_cmd.Parameters.AddWithValue("@usuarioventa",frm_Main.mps_usuario);
                
                this.m_conn.Open();
                l_reader = l_cmd.ExecuteReader();

                while (l_reader.Read())
                {
                    //MessageBox.Show( l_reader["NumeroFactura"].ToString() );
                    l_facturas.Add(l_reader["IdFactura"].ToString() + "|" + l_reader["NumeroFactura"].ToString() + "|" + l_reader["Fecha"].ToString() + "|" + l_reader["Total"].ToString() + "|0");
                    l_total += (Convert.ToDouble(l_reader["Total"])); 
                    l_total_facturas++;
                }

                l_reader.Close();
                this.m_conn.Close();

                //--------------------------------------- CAJA

                l_cmd = new System.Data.Odbc.OdbcCommand();

                l_cmd.Connection = this.m_conn;
                l_cmd.CommandText = "SELECT catCaja.iidcaja,catCaja.iimporte as total, catCaja.dtfecha, catCaja.observaciones, detCorte.iidCorte FROM catCaja LEFT JOIN detCorte ON catCaja.iidcaja = detCorte.IdFactura AND detCorte.esfactura=2 WHERE (((detCorte.iidCorte) Is Null) and catCaja.clogin= ? ) Order by catCaja.dtfecha;";

                l_cmd.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);

                this.m_conn.Open();
                l_reader = l_cmd.ExecuteReader();

                while (l_reader.Read())
                {
                    //MessageBox.Show( l_reader["NumeroFactura"].ToString() );
                    l_facturas.Add(l_reader["iidcaja"].ToString() + "||" + l_reader["dtfecha"].ToString() + "|" + l_reader["total"].ToString() + "|2" + "|" + l_reader["observaciones"].ToString());
                    l_totalp += (Convert.ToDouble(l_reader["total"]));
                    l_total_facturas++;
                }

                l_reader.Close();
                this.m_conn.Close();                

                
                //---------------------------------------
				//MessageBox.Show("facturas ledas " + l_total_facturas.ToString());

                if (l_total_facturas == 0)
                {
                    MessageBox.Show("No hay ningun movimiento para generar el corte", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.cmd_generar.Enabled = true;
                    this.lbl_msg.Text = "...";
                    return;
                }

                this.lbl_msg.Text = l_total_facturas.ToString() + "  elementos. Generando el corte, espere por favor...";

                this.m_pb.Maximum = l_total_facturas;
                this.m_pb.Value = 0;

                int l_cid = this.CreateHeader(l_total+l_totalp);
                
                foreach (string l_fac in l_facturas)
                {
					//System.Console.WriteLine( l_fac );
					
                    string[] l_items = l_fac.Split('|');

                    this.InsertDetail(l_cid, Convert.ToInt32(l_items[0]), l_items[1], Convert.ToDateTime(l_items[2]), Convert.ToDouble(l_items[3]), Convert.ToInt32( l_items[4] ));

                    this.m_pb.Value++;
                }                                

                this.lbl_msg.Text = "";
                MessageBox.Show("Corte de caja generado", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.m_pb.Value = 0;                
                this.cmd_generar.Enabled = true;

                this.mp_ppvw.WindowState = FormWindowState.Maximized;
                this.mp_ppvw.ShowDialog();

            }
        }

        public void InsertDetail(int p_idcorte,int p_idfactura, string p_numero, DateTime p_fecha, double p_total,int p_esfactura)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "INSERT INTO detCorte(iidCorte,IdFactura,cNumero,dtFecha,Total,esfactura) VALUES(?,?,?,?,?,?)";

            l_cmd.Parameters.AddWithValue("@iidCorte", p_idcorte);
            l_cmd.Parameters.AddWithValue("@IdFactura", p_idfactura);
            l_cmd.Parameters.AddWithValue("@cNumero", p_numero);
            l_cmd.Parameters.AddWithValue("@dtFecha", p_fecha);
            l_cmd.Parameters.AddWithValue("@Total", p_total);
			l_cmd.Parameters.AddWithValue("@esfactura", p_esfactura);
            
            this.m_conn.Open();

            l_cmd.ExecuteNonQuery();

            this.m_conn.Close();
        }

        public int CreateHeader(double p_total)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
			int l_id = -1;

			try{
			
		            l_cmd.Connection = this.m_conn;
		            l_cmd.CommandText = "INSERT INTO catCorte(dtFecha,Total,cusuario) VALUES(?,?,?)";
		
		            DateTime l_now = Convert.ToDateTime(System.DateTime.Now.ToString());
		
		            l_cmd.Parameters.AddWithValue("@dtFecha", l_now);
		            l_cmd.Parameters.AddWithValue("@Total", p_total);
		            l_cmd.Parameters.AddWithValue("@cusuario", frm_Main.mps_usuario);
		
		            this.m_conn.Open();
		
		            l_cmd.ExecuteNonQuery();
				
				    //l_cmd = new System.Data.Odbc.OdbcCommand();
					//l_cmd.Connection = this.m_conn;
		
		            //Obtener el id insertado...
		            l_cmd.CommandText = "SELECT LAST_INSERT_ID()";
		            //l_cmd.CommandText = "SELECT iidCorte from catCorte WHERE dtFecha=? AND Total=? AND cusuario=?;";
		            l_cmd.Parameters.Clear();
		            l_cmd.Parameters.AddWithValue("@dtFecha", l_now);
		            l_cmd.Parameters.AddWithValue("@Total", p_total);
		            l_cmd.Parameters.AddWithValue("@cusuario", frm_Main.mps_usuario);
		
				   // MessageBox.Show("Before...");
		
		            l_id = Convert.ToInt32(l_cmd.ExecuteScalar());
				
				 //   MessageBox.Show("After..." + l_id.ToString());
		
		            this.m_conn.Close();
						
		            this.mp_idcorte = l_id;

			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			
            return l_id;
        }

        private int mp_idcorte = -1;

        ////////////////////////////////////////////////     
        #region Posiciones de la factura...
        int mp_int_PosNombreX = 0;
        int mp_int_PosNombreY = 0;

        int mp_int_PosDireccionX = 0;
        int mp_int_PosDireccionY = 0;

        int mp_int_PosCiudadX = 0;
        int mp_int_PosCiudadY = 0;

        int mp_int_PosRFCX = 0;
        int mp_int_PosRFCY = 0;

        int mp_int_PosNumFactX = 0;
        int mp_int_PosNumFactY = 0;

        int mp_int_PosFechaX = 0;
        int mp_int_PosFechaY = 0;

        int mp_int_PosCodigoX = 0;
        int mp_int_PosCodigoY = 0;

        int mp_int_PosCantidadX = 0;
        int mp_int_PosCantidadY = 0;

        int mp_int_PosDescripcionX = 0;
        int mp_int_PosDescripcionY = 0;

        int mp_int_PosPrecioX = 0;
        int mp_int_PosPrecioY = 0;

        int mp_int_PosTotalX = 0;
        int mp_int_PosTotalY = 0;

        int mp_int_PosSubTotalX = 0;
        int mp_int_PosSubTotalY = 0;

        int mp_int_PosIVAX = 0;
        int mp_int_PosIVAY = 0;

        int mp_int_PosGTotalX = 0;
        int mp_int_PosGTotalY = 0;

        int mp_int_PosGTotalLetrasX = 0;
        int mp_int_PosGTotalLetrasY = 0;

        int mp_int_EspacioDetalle = 0;
        int mp_int_TamanioLetra = 0;

        string mp_string_Leyenda = "";

        #endregion


        private void LoadDocPositions()
        {
            try
            {

                this.m_conn.ConnectionString = frm_Main.mps_strconnection;


                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand(); ;

                l_cmd.Connection = this.m_conn;

                l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '003'";


                this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

                if (l_reader.Read())
                {
                    string[] l_temp = new string[2];

                    //PosNombre					
                    l_temp = l_reader["PosNombre"].ToString().Split(',');
                    this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);

                    //PosDireccion
                    l_temp = l_reader["PosDireccion"].ToString().Split(',');
                    this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);

                    //PosCiudad
                    l_temp = l_reader["PosCiudad"].ToString().Split(',');
                    this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);

                    //PosRFC
                    l_temp = l_reader["PosRFC"].ToString().Split(',');
                    this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);

                    //PosNumFact
                    l_temp = l_reader["PosNumFact"].ToString().Split(',');
                    this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);

                    //PosFecha
                    l_temp = l_reader["PosFecha"].ToString().Split(',');
                    this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);

                    //PosCodigo
                    l_temp = l_reader["PosCodigo"].ToString().Split(',');
                    this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);

                    //PosCantidad
                    l_temp = l_reader["PosCantidad"].ToString().Split(',');
                    this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);

                    //PosDescripcion
                    l_temp = l_reader["PosDescripcion"].ToString().Split(',');
                    this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);

                    //PosPrecio
                    l_temp = l_reader["PosPrecio"].ToString().Split(',');
                    this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);

                    //PosTotal
                    l_temp = l_reader["PosTotal"].ToString().Split(',');
                    this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);

                    //PosSubtotal
                    l_temp = l_reader["PosSubtotal"].ToString().Split(',');
                    this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);

                    //PosIVA
                    l_temp = l_reader["PosIVA"].ToString().Split(',');
                    this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);

                    //PosGTotal
                    l_temp = l_reader["PosGTotal"].ToString().Split(',');
                    this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);

                    //PosGTotalLetras
                    l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
                    this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);

                    //EspacioDetalle
                    this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());

                    //TamanioLetra
                    this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());

                    //Leyenda
                    this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                }

                l_reader.Close();

            }
            catch (OleDbException ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

        }

        private int mp_iiddetcorte = 0;
        private double mp_totalrep = 0;

        private void mp_pdcorte_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int l_ypos = 140;						
            System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
            System.Drawing.Font l_fonth = new Font("Arial", this.mp_int_TamanioLetra + 2, FontStyle.Bold);
            System.Drawing.Font l_fonth1 = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Bold | FontStyle.Italic);
            System.Drawing.Font l_font = new Font("Arial", this.mp_int_TamanioLetra, FontStyle.Regular);    
         
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT catCorte.*,catUsuarios.cnombre as nombre_usuario FROM catCorte INNER JOIN catUsuarios ON catCorte.cusuario = catUsuarios.clogin WHERE catCorte.iidCorte = " + this.mp_idcorte.ToString();

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();


            e.Graphics.DrawString("Corte de Caja", l_fonth, l_brush, 350, 50);

            if (l_reader.Read())
            {
                e.Graphics.DrawString("Corte de caja realizado el " + l_reader["dtFecha"].ToString() + " por el usuario : " + l_reader["nombre_usuario"].ToString(), l_fonth1, l_brush, 15, 70);
                e.Graphics.DrawString("Total " + System.String.Format("{0:C}", l_reader["Total"]), l_fonth1, l_brush, 15, 85);   			 
            }

            l_reader.Close();

            e.Graphics.DrawString("Numero", l_fonth1, l_brush, 15, 110);
            e.Graphics.DrawString("Fecha", l_fonth1, l_brush, 100, 110);
            e.Graphics.DrawString("Nota o Factura", l_fonth1, l_brush, 250, 110);
            e.Graphics.DrawString("Total", l_fonth1, l_brush, 450, 110);

            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, 125, 835, 125);

            //Imprimir el detalle
            l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM detCorte WHERE iidCorte = " + this.mp_idcorte.ToString() + " AND iidDetCorte > " + this.mp_iiddetcorte.ToString();
            
            l_reader = l_cmd.ExecuteReader();

            int k = 0;
            int curdoc=-1;
            while (l_reader.Read())
            {
                e.Graphics.DrawString(l_reader["cNumero"].ToString(), l_font, l_brush, 15, l_ypos);
                e.Graphics.DrawString(System.Convert.ToDateTime(l_reader["dtFecha"]).ToString(), l_font, l_brush, 100, l_ypos);
                curdoc = Convert.ToInt32(l_reader["esfactura"]);
                switch (curdoc)
                {
                    case 1:
                        e.Graphics.DrawString( "Factura" , l_font, l_brush, 250, l_ypos);
                        break;
                    case 0:
                        e.Graphics.DrawString( "Nota", l_font, l_brush, 250, l_ypos);
                        break;
                    case 2:
                        e.Graphics.DrawString("Pago/Abono", l_font, l_brush, 250, l_ypos);
                        break;
                }
                //e.Graphics.DrawString( (Convert.ToBoolean(l_reader["esfactura"]) ? "Factura" : "Nota") , l_font, l_brush, 250, l_ypos);

                e.Graphics.DrawString(System.String.Format("{0:C}", l_reader["Total"]), l_font, l_brush, 450, l_ypos);

                this.mp_totalrep += Convert.ToDouble(l_reader["Total"]);
                this.mp_idcorte = Convert.ToInt32(l_reader["iidDetCorte"]);

                l_ypos += this.mp_int_EspacioDetalle;
                k++;

                if (k == 60)
                {
                    e.HasMorePages = true;
                    return;
                }					

            }

            l_reader.Close();
            this.m_conn.Close();

            e.HasMorePages = false;
            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);

            l_ypos += this.mp_int_TamanioLetra;

            e.Graphics.DrawString(System.String.Format("{0:C}", this.mp_totalrep), l_fonth1, l_brush, 450, l_ypos + this.mp_int_TamanioLetra);

            this.mp_iiddetcorte = 0;
            this.mp_totalrep = 0;

        }

    }
}
