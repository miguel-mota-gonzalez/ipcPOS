namespace EasyInvoice
{
    partial class frm_PagosFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_PagosFactura));
            this.lbl_cliente = new System.Windows.Forms.Label();
            this.lbl_numero = new System.Windows.Forms.Label();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.lbl_pagado = new System.Windows.Forms.Label();
            this.lbl_adeudo = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ll_agregar = new System.Windows.Forms.LinkLabel();
            this.ll_eliminar = new System.Windows.Forms.LinkLabel();
            this.cmd_cancelar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_cliente
            // 
            this.lbl_cliente.AutoSize = true;
            this.lbl_cliente.Location = new System.Drawing.Point(13, 13);
            this.lbl_cliente.Name = "lbl_cliente";
            this.lbl_cliente.Size = new System.Drawing.Size(48, 13);
            this.lbl_cliente.TabIndex = 0;
            this.lbl_cliente.Text = "Cliente : ";
            // 
            // lbl_numero
            // 
            this.lbl_numero.AutoSize = true;
            this.lbl_numero.Location = new System.Drawing.Point(13, 40);
            this.lbl_numero.Name = "lbl_numero";
            this.lbl_numero.Size = new System.Drawing.Size(104, 13);
            this.lbl_numero.TabIndex = 1;
            this.lbl_numero.Text = "N�mero de Factura :";
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Location = new System.Drawing.Point(13, 67);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(43, 13);
            this.lbl_fecha.TabIndex = 2;
            this.lbl_fecha.Text = "Fecha :";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.ForeColor = System.Drawing.Color.Black;
            this.lbl_total.Location = new System.Drawing.Point(13, 97);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(44, 13);
            this.lbl_total.TabIndex = 3;
            this.lbl_total.Text = "Total :";
            // 
            // lbl_pagado
            // 
            this.lbl_pagado.AutoSize = true;
            this.lbl_pagado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pagado.ForeColor = System.Drawing.Color.Blue;
            this.lbl_pagado.Location = new System.Drawing.Point(13, 121);
            this.lbl_pagado.Name = "lbl_pagado";
            this.lbl_pagado.Size = new System.Drawing.Size(129, 13);
            this.lbl_pagado.TabIndex = 4;
            this.lbl_pagado.Text = "Pagado hasta ahora :";
            // 
            // lbl_adeudo
            // 
            this.lbl_adeudo.AutoSize = true;
            this.lbl_adeudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_adeudo.ForeColor = System.Drawing.Color.Red;
            this.lbl_adeudo.Location = new System.Drawing.Point(13, 151);
            this.lbl_adeudo.Name = "lbl_adeudo";
            this.lbl_adeudo.Size = new System.Drawing.Size(58, 13);
            this.lbl_adeudo.TabIndex = 5;
            this.lbl_adeudo.Text = "Adeudo :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Green;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Location = new System.Drawing.Point(16, 182);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(406, 177);
            this.dataGridView1.TabIndex = 6;
            // 
            // ll_agregar
            // 
            this.ll_agregar.AutoSize = true;
            this.ll_agregar.Location = new System.Drawing.Point(227, 151);
            this.ll_agregar.Name = "ll_agregar";
            this.ll_agregar.Size = new System.Drawing.Size(94, 13);
            this.ll_agregar.TabIndex = 7;
            this.ll_agregar.TabStop = true;
            this.ll_agregar.Text = "Agregar pago {F2}";
            this.ll_agregar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_agregar_LinkClicked);
            // 
            // ll_eliminar
            // 
            this.ll_eliminar.AutoSize = true;
            this.ll_eliminar.Location = new System.Drawing.Point(327, 151);
            this.ll_eliminar.Name = "ll_eliminar";
            this.ll_eliminar.Size = new System.Drawing.Size(99, 13);
            this.ll_eliminar.TabIndex = 8;
            this.ll_eliminar.TabStop = true;
            this.ll_eliminar.Text = "Cancelar pago {F3}";
            this.ll_eliminar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_eliminar_LinkClicked);
            // 
            // cmd_cancelar
            // 
            this.cmd_cancelar.Image = ((System.Drawing.Image)(resources.GetObject("cmd_cancelar.Image")));
            this.cmd_cancelar.Location = new System.Drawing.Point(345, 365);
            this.cmd_cancelar.Name = "cmd_cancelar";
            this.cmd_cancelar.Size = new System.Drawing.Size(77, 23);
            this.cmd_cancelar.TabIndex = 9;
            this.cmd_cancelar.Text = "Cerrar";
            this.cmd_cancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_cancelar.UseVisualStyleBackColor = true;
            this.cmd_cancelar.Click += new System.EventHandler(this.cmd_cancelar_Click);
            // 
            // frm_PagosFactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(444, 400);
            this.Controls.Add(this.cmd_cancelar);
            this.Controls.Add(this.ll_eliminar);
            this.Controls.Add(this.ll_agregar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbl_adeudo);
            this.Controls.Add(this.lbl_pagado);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_numero);
            this.Controls.Add(this.lbl_cliente);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_PagosFactura";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Detalle de pagos de la factura";
            this.Load += new System.EventHandler(this.frmPagosFactura_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_PagosFactura_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cliente;
        private System.Windows.Forms.Label lbl_numero;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label lbl_pagado;
        private System.Windows.Forms.Label lbl_adeudo;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.LinkLabel ll_agregar;
        private System.Windows.Forms.LinkLabel ll_eliminar;
        private System.Windows.Forms.Button cmd_cancelar;
    }
}
