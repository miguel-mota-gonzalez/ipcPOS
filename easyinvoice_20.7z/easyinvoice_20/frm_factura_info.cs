/*
 * Creado por SharpDevelop.
 * Usuario: mikem
 * Fecha: 13/11/2008
 * Hora: 01:18 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificaci�n | Editar Encabezados Est�ndar
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_factura_info.
	/// </summary>
	public partial class frm_factura_info : Form
	{
        public bool m_esnota  =true;
		public string m_docto = "1000";

		
		public frm_factura_info()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void frm_factura_infoLoad(object sender, EventArgs e)
		{
            if (this.m_esnota)
                this.lbl_total.Text = "NOTA GENERADA";
            else
                this.lbl_total.Text = "FACTURA GENERADA";

            this.txt_entregado.Text = this.m_docto;
		}
		
		void frm_factura_infoKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Escape )
				this.Close();
		}
		
		void Cmd_cerrarClick(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
