using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_Facturaslist.
	/// </summary>
	public class frm_Notasslist : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Data.Odbc.OdbcConnection OdbcConnection1;
		private System.Data.DataSet m_dataset;
		public System.Int32 m_KeyRecord;
		private System.Windows.Forms.Button cmd_buscar;
		private System.Windows.Forms.TextBox txt_criterio; 
		private System.Int32 m_curcel;
		private System.Windows.Forms.Button cmd_actualizar;
		private System.Windows.Forms.Label lbl_curcel;

		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frm_Notasslist()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			m_curcel=0;
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frm_Facturaslist));
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.OdbcConnection1 = new System.Data.Odbc.OdbcConnection();
			this.cmd_buscar = new System.Windows.Forms.Button();
			this.txt_criterio = new System.Windows.Forms.TextBox();
			this.cmd_actualizar = new System.Windows.Forms.Button();
			this.lbl_curcel = new System.Windows.Forms.Label();
			this.printDocument1 = new System.Drawing.Printing.PrintDocument();
			this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGrid1
			// 
			this.dataGrid1.AllowSorting = false;
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 32);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.PreferredColumnWidth = 150;
			this.dataGrid1.ReadOnly = true;
			this.dataGrid1.Size = new System.Drawing.Size(784, 424);
			this.dataGrid1.TabIndex = 4;
			this.dataGrid1.DoubleClick += new System.EventHandler(this.dataGrid1_DoubleClick);
			this.dataGrid1.Navigate += new System.Windows.Forms.NavigateEventHandler(this.dataGrid1_Navigate);
			this.dataGrid1.CurrentCellChanged += new System.EventHandler(this.dataGrid1_CurrentCellChanged);
			// 
			// OdbcConnection1
			// 
			this.OdbcConnection1.ConnectionString = "dsn=easy;";
			// 
			// cmd_buscar
			// 
			this.cmd_buscar.Location = new System.Drawing.Point(136, 8);
			this.cmd_buscar.Name = "cmd_buscar";
			this.cmd_buscar.Size = new System.Drawing.Size(112, 23);
			this.cmd_buscar.TabIndex = 1;
			this.cmd_buscar.Text = "Buscar Registro";
			this.cmd_buscar.Click += new System.EventHandler(this.cmd_buscar_Click);
			// 
			// txt_criterio
			// 
			this.txt_criterio.Location = new System.Drawing.Point(264, 8);
			this.txt_criterio.Name = "txt_criterio";
			this.txt_criterio.Size = new System.Drawing.Size(336, 20);
			this.txt_criterio.TabIndex = 2;
			this.txt_criterio.Text = "";
			// 
			// cmd_actualizar
			// 
			this.cmd_actualizar.Location = new System.Drawing.Point(680, 8);
			this.cmd_actualizar.Name = "cmd_actualizar";
			this.cmd_actualizar.Size = new System.Drawing.Size(112, 23);
			this.cmd_actualizar.TabIndex = 3;
			this.cmd_actualizar.Text = "Actualizar";
			this.cmd_actualizar.Click += new System.EventHandler(this.cmd_actualizar_Click);
			// 
			// lbl_curcel
			// 
			this.lbl_curcel.Location = new System.Drawing.Point(600, 8);
			this.lbl_curcel.Name = "lbl_curcel";
			this.lbl_curcel.Size = new System.Drawing.Size(64, 24);
			this.lbl_curcel.TabIndex = 6;
			// 
			// printDocument1
			// 
			this.printDocument1.DocumentName = "Factura";
			this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
			// 
			// printPreviewDialog1
			// 
			this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
			this.printPreviewDialog1.Document = this.printDocument1;
			this.printPreviewDialog1.Enabled = true;
			this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
			this.printPreviewDialog1.Location = new System.Drawing.Point(287, 17);
			this.printPreviewDialog1.MinimumSize = new System.Drawing.Size(375, 250);
			this.printPreviewDialog1.Name = "printPreviewDialog1";
			this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
			this.printPreviewDialog1.Visible = false;
			// 
			// frm_Facturaslist
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(808, 470);
			this.Controls.Add(this.lbl_curcel);
			this.Controls.Add(this.cmd_actualizar);
			this.Controls.Add(this.txt_criterio);
			this.Controls.Add(this.cmd_buscar);
			this.Controls.Add(this.dataGrid1);
			this.Name = "frm_Notasslist";
			this.Text = "Lista de Notas";
			this.SizeChanged += new System.EventHandler(this.frm_ClientsList_SizeChanged);
			this.Load += new System.EventHandler(this.frm_ClientsList_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
			this.OdbcConnection1.ConnectionString = @"dsn=easy;";

			System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
			System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();
			this.m_dataset = new System.Data.DataSet();

			l_select.Connection = this.OdbcConnection1;
			l_select.CommandText = "SELECT catNotas.IdFactura, catNotas.NumeroFactura, catNotas.Fecha, catClientes.Nombre, catNotas.NumProductos,catNotas.Subtotal, catNotas.Total FROM catNotas LEFT OUTER JOIN catClientes ON catNotas.IdCliente = catClientes.IdCliente;";
			l_da.SelectCommand = l_select;

			l_da.Fill( m_dataset  );

			this.dataGrid1.DataSource = m_dataset.Tables[0];
			

			this.dataGrid1.Top = 40;
			this.dataGrid1.Left = 0;
			this.dataGrid1.Height = this.Height-80;
			this.dataGrid1.Width = this.Width-7;  
			  

		}

		private void frm_ClientsList_SizeChanged(object sender, System.EventArgs e)
		{

			if(this.Height < 30 || this.Width < 7)
				return;

			this.dataGrid1.Top = 40;
			this.dataGrid1.Left = 0;
			this.dataGrid1.Height = this.Height-80;
			this.dataGrid1.Width = this.Width-7; 		
		}

		private void dataGrid1_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
		
		}

		private void dataGrid1_DoubleClick(object sender, System.EventArgs e)
		{

			this.printPreviewDialog1.WindowState = FormWindowState.Maximized;  
			this.printPreviewDialog1.ShowDialog(); 

			this.FillDataset(); 
		}

		private void FillDataset()	
		{
			System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
			System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();
			this.m_dataset = new System.Data.DataSet();

			l_select.Connection = this.OdbcConnection1;
			l_select.CommandText = "SELECT catNotas.IdFactura, catNotas.NumeroFactura, catNotas.Fecha, catClientes.Nombre, catNotas.NumProductos,catNotas.Subtotal, catNotas.Total FROM catNotas LEFT OUTER JOIN catClientes ON catNotas.IdCliente = catClientes.IdCliente;";
			l_da.SelectCommand = l_select;

			l_da.Fill( m_dataset  );

			this.dataGrid1.DataSource = m_dataset.Tables[0];		
		}

		private void cmd_buscar_Click(object sender, System.EventArgs e)
		{
			System.Int32 i;
			System.String l_target;
			System.String l_criterio;

			l_target = txt_criterio.Text;
			l_target = l_target.ToUpper();
			
			for(i=0;i<this.m_dataset.Tables[0].Rows.Count;i++)
			{
				l_criterio = this.m_dataset.Tables[0].Rows[i][m_curcel].ToString();  
				l_criterio = l_criterio.ToUpper(); 

				if(l_criterio.LastIndexOf(l_target)>=0)
				{
					this.dataGrid1.CurrentRowIndex = i; 
					break;				
				}
			}

			if(i==this.m_dataset.Tables[0].Rows.Count)
			{
				MessageBox.Show("No se encontraron registros","Easy Invoice",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Information );
			}
				

			txt_criterio.Text = "";

		}

		private void dataGrid1_CurrentCellChanged(object sender, System.EventArgs e)
		{
			//MessageBox.Show( this.dataGrid1.CurrentCell.ColumnNumber.ToString() ); 
			m_curcel = this.dataGrid1.CurrentCell.ColumnNumber;
			lbl_curcel.Text = m_curcel.ToString();
		}

		private void cmd_actualizar_Click(object sender, System.EventArgs e)
		{
			this.FillDataset(); 
		}

		private void printPreviewDialog1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			//MessageBox.Show( this.m_dataset.Tables[0].Rows[this.dataGrid1.CurrentRowIndex][0].ToString() ); 
			System.String l_key = this.m_dataset.Tables[0].Rows[this.dataGrid1.CurrentRowIndex][0].ToString(); 

			System.Data.Odbc.OdbcCommand l_cmd;
			System.Data.Odbc.OdbcCommand l_cmd2;
			System.Data.Odbc.OdbcDataReader l_reader;
			System.Data.Odbc.OdbcDataReader l_reader2;  
  
			l_cmd = new System.Data.Odbc.OdbcCommand();
			l_cmd.Connection = this.OdbcConnection1;
			l_cmd.CommandText = "SELECT catNotas.NumeroFactura, catNotas.Fecha, catNotas.Subtotal, catNotas.Total, catClientes.Nombre, catClientes.Direccion, catClientes.RFC, catClientes.ciudad FROM catNotas LEFT OUTER JOIN catClientes ON catNotas.IdCliente = catClientes.IdCliente WHERE IdFactura = " + l_key + ";";

			l_cmd2 = new System.Data.Odbc.OdbcCommand();
			l_cmd2.Connection = this.OdbcConnection1;
			l_cmd2.CommandText = "SELECT detNota.PrecioCalculado, detNota.Cantidad, detNota.PrecioDescuento, catProductos.Codigo, catProductos.Descripcion, detNota.IdFactura FROM detNota LEFT OUTER JOIN catProductos ON detNota.IdProducto = catProductos.IdProducto WHERE IdFactura = " + l_key + ";";

			this.OdbcConnection1.Open();

			l_reader = l_cmd.ExecuteReader();

			l_reader.Read();

			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Arial",8);    
			System.Drawing.Font l_fontcant = new Font("Arial",8);    

			//Numero
			//MessageBox.Show("antes del numero"); 
			e.Graphics.DrawString("No. " + l_reader.GetInt32(0).ToString(),l_font,l_brush,700,93);   			 

			//Nombre
			//MessageBox.Show("antes del nombre"); 
			e.Graphics.DrawString(l_reader.GetString(4),l_font,l_brush,125,93);   			 

			//Direcci�n
			//MessageBox.Show("antes del direccion"); 
			e.Graphics.DrawString(l_reader.GetString(5),l_font,l_brush,125,113);   			 

			//Ciudad
			//MessageBox.Show("antes del ciudad"); 
			e.Graphics.DrawString(l_reader.GetString(7),l_font,l_brush,125,135);   			 

			//Fecha
			//MessageBox.Show("antes del fecha"); 
			e.Graphics.DrawString( System.String.Format("{0:d}",l_reader.GetDateTime(1))  ,l_font,l_brush,700,113);   			 

			//RFC
			//MessageBox.Show("antes del rfc"); 
			e.Graphics.DrawString(l_reader.GetString(6),l_font,l_brush,550,133);   		
	 
			//subtotal
			//MessageBox.Show("antes del subtotal"); 

			e.Graphics.DrawString(System.String.Format("{0:C}",l_reader.GetDouble(2)),l_font,l_brush,750,470);   			 

			//Iva
			//MessageBox.Show("antes del iva"); 
			e.Graphics.DrawString(System.String.Format("{0:C}",l_reader.GetDouble(3)-l_reader.GetDouble(2)),l_font,l_brush,750,485);   			 

			//Total
			//MessageBox.Show("antes del total"); 
			e.Graphics.DrawString(System.String.Format("{0:C}",l_reader.GetDouble(3)),l_font,l_brush,750,500);   		

			//Total en letras
			

			//Separar los centavos...
			System.Double l_centavos;
			System.Double l_total;

			l_total = l_reader.GetDouble(3);

			l_total = l_total * 100;
			l_centavos = l_total % 100;
			l_total = l_total - l_centavos;
			l_total = l_total / 100;

			l_total = System.Math.Round(l_total,2);

			System.String l_cantidad;

			l_cantidad = this.GetStringValue(System.String.Format("{0:C}",l_total));

			if(l_centavos > 0)
			{
				System.String l_cantcent = System.String.Format(" {0}/100",System.Math.Round(l_centavos,2));
				l_cantidad = l_cantidad + l_cantcent;
			}

			l_cantidad = l_cantidad + " MN";
			e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,150,485);   			 		 


			e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,150,485);   			 		 

			l_reader.Close(); 

			l_reader2 = l_cmd2.ExecuteReader();

			System.Int32 i=0;
			System.Int32 l_pos;

			System.Double l_d1,l_d2;
			System.String l_s1,l_s2;

			//MessageBox.Show("antes del loop"); 
 
			while(l_reader2.Read())
			{
				l_pos = i*12;

				e.Graphics.DrawString( l_reader2.GetString(3) ,l_font,l_brush,40,190+l_pos);   		
				e.Graphics.DrawString( l_reader2.GetInt32(1).ToString() ,l_font,l_brush,140,190+l_pos);   		
				e.Graphics.DrawString( l_reader2.GetString(4) ,l_font,l_brush,180,190+l_pos);  

				//MessageBox.Show("antes del precio 1"); 
				l_d1 = System.Convert.ToDouble(l_reader2.GetDouble(2));  
				//MessageBox.Show("antes del precio 2"); 
				l_d2 = System.Convert.ToDouble(l_reader2.GetDouble(0));  

				l_s1 = System.String.Format("{0:C}",l_d1);
				l_s2 = System.String.Format("{0:C}",l_d2);
 		
				e.Graphics.DrawString(l_s1,l_font,l_brush,650,190+l_pos);   		
				e.Graphics.DrawString(l_s2,l_font,l_brush,750,190+l_pos);   		

				i++;

			}

			l_reader2.Close(); 

			this.OdbcConnection1.Close();  
		
		}
        /*
        private int DesglosarIVA()
        {
            System.Data.OleDb.OleDbCommand l_cmd = new System.Data.OleDb.OleDbCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001';";

            this.m_conn.Open();
            System.Data.OleDb.OleDbDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            int l_result = Convert.ToInt32(l_reader["DesglosarIva"]);

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
        }*/

		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 

			clsUtils.cUtils l_utils = new clsUtils.cUtils(); 

			return l_utils.Transforma(l_num); 

		}
		
	}
}
