﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class frm_cambiarclave
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_cambiarclave));
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_clave1 = new System.Windows.Forms.TextBox();
            this.txt_clave2 = new System.Windows.Forms.TextBox();
            this.lbl_oldkey = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmd_cancel = new System.Windows.Forms.Button();
            this.lvw_main = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_del = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.cmb_acceso = new System.Windows.Forms.ComboBox();
            this.lbl_acceso = new System.Windows.Forms.Label();
            this.cmd_add = new System.Windows.Forms.Button();
            this.pnl_Almacen = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_Almacen = new System.Windows.Forms.ComboBox();
            this.pnl_Almacen.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(469, 9);
            this.txt_nombre.MaxLength = 50;
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(163, 20);
            this.txt_nombre.TabIndex = 1;
            this.txt_nombre.Enter += new System.EventHandler(this.Txt_new1Enter);
            // 
            // txt_clave1
            // 
            this.txt_clave1.Location = new System.Drawing.Point(469, 69);
            this.txt_clave1.MaxLength = 32;
            this.txt_clave1.Name = "txt_clave1";
            this.txt_clave1.PasswordChar = '*';
            this.txt_clave1.Size = new System.Drawing.Size(163, 20);
            this.txt_clave1.TabIndex = 5;
            this.txt_clave1.Enter += new System.EventHandler(this.Txt_new1Enter);
            // 
            // txt_clave2
            // 
            this.txt_clave2.Location = new System.Drawing.Point(469, 95);
            this.txt_clave2.MaxLength = 32;
            this.txt_clave2.Name = "txt_clave2";
            this.txt_clave2.PasswordChar = '*';
            this.txt_clave2.Size = new System.Drawing.Size(163, 20);
            this.txt_clave2.TabIndex = 7;
            this.txt_clave2.Enter += new System.EventHandler(this.Txt_new1Enter);
            // 
            // lbl_oldkey
            // 
            this.lbl_oldkey.AutoSize = true;
            this.lbl_oldkey.Location = new System.Drawing.Point(388, 9);
            this.lbl_oldkey.Name = "lbl_oldkey";
            this.lbl_oldkey.Size = new System.Drawing.Size(44, 13);
            this.lbl_oldkey.TabIndex = 0;
            this.lbl_oldkey.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(388, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nueva clave";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(388, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Confirmar clave";
            // 
            // cmd_cancel
            // 
            this.cmd_cancel.Location = new System.Drawing.Point(557, 256);
            this.cmd_cancel.Name = "cmd_cancel";
            this.cmd_cancel.Size = new System.Drawing.Size(75, 23);
            this.cmd_cancel.TabIndex = 14;
            this.cmd_cancel.Text = "Cerrar";
            this.cmd_cancel.UseVisualStyleBackColor = true;
            this.cmd_cancel.Click += new System.EventHandler(this.Cmd_cancelClick);
            // 
            // lvw_main
            // 
            this.lvw_main.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvw_main.FullRowSelect = true;
            this.lvw_main.Location = new System.Drawing.Point(12, 9);
            this.lvw_main.MultiSelect = false;
            this.lvw_main.Name = "lvw_main";
            this.lvw_main.Size = new System.Drawing.Size(366, 270);
            this.lvw_main.TabIndex = 15;
            this.lvw_main.UseCompatibleStateImageBehavior = false;
            this.lvw_main.View = System.Windows.Forms.View.Details;
            this.lvw_main.SelectedIndexChanged += new System.EventHandler(this.lvw_main_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nombre";
            this.columnHeader1.Width = 196;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Login";
            this.columnHeader2.Width = 66;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Acceso";
            this.columnHeader3.Width = 98;
            // 
            // cmd_save
            // 
            this.cmd_save.Location = new System.Drawing.Point(391, 225);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(75, 23);
            this.cmd_save.TabIndex = 11;
            this.cmd_save.Text = "Guardar";
            this.cmd_save.UseVisualStyleBackColor = true;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_del
            // 
            this.cmd_del.Location = new System.Drawing.Point(391, 256);
            this.cmd_del.Name = "cmd_del";
            this.cmd_del.Size = new System.Drawing.Size(75, 23);
            this.cmd_del.TabIndex = 13;
            this.cmd_del.Text = "Borrar";
            this.cmd_del.UseVisualStyleBackColor = true;
            this.cmd_del.Click += new System.EventHandler(this.cmd_del_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(388, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Login";
            // 
            // txt_login
            // 
            this.txt_login.Location = new System.Drawing.Point(469, 36);
            this.txt_login.MaxLength = 16;
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(163, 20);
            this.txt_login.TabIndex = 3;
            // 
            // cmb_acceso
            // 
            this.cmb_acceso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_acceso.FormattingEnabled = true;
            this.cmb_acceso.Items.AddRange(new object[] {
            "Administrador",
            "Caja",
            "Vendedor",
            "Supervisor"});
            this.cmb_acceso.Location = new System.Drawing.Point(469, 128);
            this.cmb_acceso.Name = "cmb_acceso";
            this.cmb_acceso.Size = new System.Drawing.Size(163, 21);
            this.cmb_acceso.TabIndex = 9;
            this.cmb_acceso.SelectedIndexChanged += new System.EventHandler(this.cmb_acceso_SelectedIndexChanged);
            // 
            // lbl_acceso
            // 
            this.lbl_acceso.AutoSize = true;
            this.lbl_acceso.Location = new System.Drawing.Point(389, 131);
            this.lbl_acceso.Name = "lbl_acceso";
            this.lbl_acceso.Size = new System.Drawing.Size(43, 13);
            this.lbl_acceso.TabIndex = 8;
            this.lbl_acceso.Text = "Acceso";
            // 
            // cmd_add
            // 
            this.cmd_add.Location = new System.Drawing.Point(557, 225);
            this.cmd_add.Name = "cmd_add";
            this.cmd_add.Size = new System.Drawing.Size(75, 23);
            this.cmd_add.TabIndex = 12;
            this.cmd_add.Text = "Agregar";
            this.cmd_add.UseVisualStyleBackColor = true;
            this.cmd_add.Click += new System.EventHandler(this.cmd_add_Click);
            // 
            // pnl_Almacen
            // 
            this.pnl_Almacen.Controls.Add(this.label4);
            this.pnl_Almacen.Controls.Add(this.cmb_Almacen);
            this.pnl_Almacen.Location = new System.Drawing.Point(384, 155);
            this.pnl_Almacen.Name = "pnl_Almacen";
            this.pnl_Almacen.Size = new System.Drawing.Size(255, 34);
            this.pnl_Almacen.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Almacen";
            // 
            // cmb_Almacen
            // 
            this.cmb_Almacen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Almacen.FormattingEnabled = true;
            this.cmb_Almacen.Location = new System.Drawing.Point(85, 7);
            this.cmb_Almacen.Name = "cmb_Almacen";
            this.cmb_Almacen.Size = new System.Drawing.Size(163, 21);
            this.cmb_Almacen.TabIndex = 1;
            // 
            // frm_cambiarclave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(644, 290);
            this.Controls.Add(this.pnl_Almacen);
            this.Controls.Add(this.cmd_add);
            this.Controls.Add(this.lbl_acceso);
            this.Controls.Add(this.cmb_acceso);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.cmd_del);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.lvw_main);
            this.Controls.Add(this.cmd_cancel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_oldkey);
            this.Controls.Add(this.txt_clave2);
            this.Controls.Add(this.txt_clave1);
            this.Controls.Add(this.txt_nombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_cambiarclave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Usuarios";
            this.Load += new System.EventHandler(this.frm_cambiarclave_Load);
            this.pnl_Almacen.ResumeLayout(false);
            this.pnl_Almacen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.TextBox txt_clave1;
		private System.Windows.Forms.TextBox txt_clave2;
		private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Button cmd_cancel;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lbl_oldkey;
        private System.Windows.Forms.ListView lvw_main;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_del;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.ComboBox cmb_acceso;
        private System.Windows.Forms.Label lbl_acceso;
        private System.Windows.Forms.Button cmd_add;
        private System.Windows.Forms.Panel pnl_Almacen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_Almacen;
	}
}
