﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_config : Form
    {

        private System.Data.Odbc.OdbcConnection m_conn;
        private System.Data.Odbc.OdbcDataAdapter m_da;
        private System.Data.Odbc.OdbcCommand m_select;
        private System.Data.DataSet m_dataset;   

        public bool m_IsModified = false;
        public bool mp_Loading = false;

        public frm_config()
        {
            InitializeComponent();
        }

        private void frm_config_Load(object sender, EventArgs e)
        {
            this.mp_Loading = true;


            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.m_select = new System.Data.Odbc.OdbcCommand();
            this.m_select.Connection = this.m_conn;

           this.m_select.CommandText = "Select * From confSystem where CodTienda='001';";

            this.m_da = new System.Data.Odbc.OdbcDataAdapter();
            this.m_da.SelectCommand = this.m_select;
            this.m_dataset = new System.Data.DataSet();
            this.m_da.Fill(this.m_dataset,"system");

            this.m_select.CommandText = "Select * From confConsFactura;";
            this.m_da.SelectCommand = this.m_select;
            this.m_da.Fill(this.m_dataset, "consec");

            this.FillData();

            this.m_conn.Close();

            this.mp_Loading = false;
        }

        private void FillData()
        {
            this.txt_nombre.Text = this.m_dataset.Tables[0].Rows[0]["ClienteNotas"].ToString();
            this.txt_iva.Text = this.m_dataset.Tables[0].Rows[0]["iva"].ToString();
            this.txt_copias.Text = this.m_dataset.Tables[0].Rows[0]["copiasFactura"].ToString();

            this.checkBox1.Checked = (Convert.ToInt32(this.m_dataset.Tables[0].Rows[0]["UsarIvaPorArtic"])==1);

            this.checkBox2.Checked = (Convert.ToInt32(this.m_dataset.Tables[0].Rows[0]["UsarFactElec"]) == 1);

            this.checkBox3.Checked = (Convert.ToInt32(this.m_dataset.Tables[0].Rows[0]["UsarExistencia0"]) == 1);

            this.txt_facturasig.Text = this.m_dataset.Tables[1].Rows[0][0].ToString();
            this.txt_notasig.Text = this.m_dataset.Tables[1].Rows[0][1].ToString();
            this.txt_pagosig.Text = this.m_dataset.Tables[1].Rows[0][2].ToString();
            this.txt_ncsig.Text = this.m_dataset.Tables[1].Rows[0][3].ToString();
            this.txt_ordencomprasig.Text = this.m_dataset.Tables[1].Rows[0][4].ToString();

        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcCommand l_updatei = new System.Data.Odbc.OdbcCommand();

            if (!IsNumeric(this.txt_iva.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_iva.Focus();
                return;
            }
            if (!IsNumeric(this.txt_copias.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_copias.Focus();
                return;
            }
            if (!IsNumeric(this.txt_facturasig.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_facturasig.Focus();
                return;
            }
            if (!IsNumeric(this.txt_notasig.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_notasig.Focus();
                return;
            }
            if (!IsNumeric(this.txt_pagosig.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_pagosig.Focus();
                return;
            }
            if (!IsNumeric(this.txt_ncsig.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_ncsig.Focus();
                return;
            }
            if (!IsNumeric(this.txt_ordencomprasig.Text))
            {
                MessageBox.Show("Dato invalido, debe ser numérico", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.txt_ordencomprasig.Focus();
                return;
            }

            try
            {
                if (this.m_conn.State != System.Data.ConnectionState.Open)
                    this.m_conn.Open();

                l_update.Connection = this.m_conn;
                l_updatei.Connection = this.m_conn;

                l_update.CommandText = "UPDATE confSystem SET ClienteNotas=?, iva=?, copiasFactura=?,UsarIvaPorArtic=?, UsarFactElec=?, UsarExistencia0=? WHERE CodTienda='001';";
                l_update.Parameters.AddWithValue("@ClienteNotas", this.txt_nombre.Text);
                l_update.Parameters.AddWithValue("@iva", this.txt_iva.Text);
                l_update.Parameters.AddWithValue("@copiasFactura", this.txt_copias.Text);
                if(this.checkBox1.Checked)
                    l_update.Parameters.AddWithValue("@UsarIvaPorArtic", 1);
                else
                    l_update.Parameters.AddWithValue("@UsarIvaPorArtic", 0);
                if (this.checkBox2.Checked)
                    l_update.Parameters.AddWithValue("@UsarFactElec", 1);
                else
                    l_update.Parameters.AddWithValue("@UsarFactElec", 0);
                if (this.checkBox3.Checked)
                    l_update.Parameters.AddWithValue("@UsarExistencia0", 1);
                else
                    l_update.Parameters.AddWithValue("@UsarExistencia0", 0);

                l_update.ExecuteNonQuery();

                l_updatei.CommandText = "UPDATE confConsFactura SET ConsFactura=?,ConsNota=?, ConsPago=?, ConsNotaCred=?, ConsOrdenesCompra=?;";
                l_updatei.Parameters.AddWithValue("@ConsFactura", this.txt_facturasig.Text);
                l_updatei.Parameters.AddWithValue("@ConsNota", this.txt_notasig.Text);
                l_updatei.Parameters.AddWithValue("@ConsPago", this.txt_pagosig.Text);
                l_updatei.Parameters.AddWithValue("@ConsNotaCred", this.txt_ncsig.Text);
                l_updatei.Parameters.AddWithValue("@ConsOrdenesCompra", this.txt_ordencomprasig.Text);
                l_updatei.ExecuteNonQuery();


			}
			catch(System.Data.OleDb.OleDbException ex)
			{
                MessageBox.Show("Error al actualizar configuración. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}				
			catch(System.Exception ex)
			{
				MessageBox.Show("Error al actualizar configuración. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}

            this.Close();
        }

        public static bool IsNumeric(String str)
        {
            if (str == null)
                return false;
            if (str.Length == 0)
                return false;
            try
            {
                double x = Convert.ToDouble(str);
                return true;
            }
            catch
            {
                return false;
            }

        }


        private void cmd_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
