﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyReports
{
    class clsRptPedido
    {
        public Boolean ShowReport(Object[] parameters)
        {
            System.Data.Odbc.OdbcConnection l_conn = null;
            System.Data.DataSet ds= new System.Data.DataSet();
            Boolean res = true;
            try
            {
                l_conn = new System.Data.Odbc.OdbcConnection();
                System.Data.Odbc.OdbcDataAdapter odbcAdapter = new System.Data.Odbc.OdbcDataAdapter();
                l_conn.ConnectionString = ReportAdmin.ConnectionString;
                l_conn.Open();
                odbcAdapter.SelectCommand  =  new System.Data.Odbc.OdbcCommand("SELECT * FROM catOrdenesCompra WHERE IdOrdenCompra = " + parameters[0].ToString(),l_conn);
                odbcAdapter.Fill(ds, "catOrdenesCompra");
                odbcAdapter.SelectCommand = new System.Data.Odbc.OdbcCommand("SELECT * FROM detOrdenesCompra WHERE IdOrdenCompra = " + parameters[0].ToString(), l_conn);
                odbcAdapter.Fill(ds, "detOrdenesCompra");
                CrystalDecisions.CrystalReports.Engine.ReportDocument lFormatoPedido = new CrystalDecisions.CrystalReports.Engine.ReportDocument();

                string reportPath = ".\\rptPedido.rpt";
                lFormatoPedido.Load(reportPath);
                lFormatoPedido.SetDataSource(ds);

                frmReporte frmRep = new frmReporte();
                frmRep.crystalReportViewer1.ReportSource=lFormatoPedido;
                //frmRep.crystalReportViewer1.;
                frmRep.Show();
                //System.Windows.Forms.MessageBox.Show("imprimiendo repte pedidos " + parameters[0].ToString());
            }
            catch (Exception ex)
            {
                ReportAdmin.lastErrorString = "rptPedido :" + ex.Message;
                res = false;
            }
            finally
            {
               if (l_conn != null)
                    l_conn.Close();
            }
            return res;
        }

    }
}
