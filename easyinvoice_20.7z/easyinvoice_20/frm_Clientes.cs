using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_Clientes.
	/// </summary>
	public class frm_Clientes : System.Windows.Forms.Form
	{

		private System.Data.Odbc.OdbcConnection m_conn;
		private System.Data.Odbc.OdbcDataAdapter m_da;
		private System.Data.Odbc.OdbcCommand m_select;

		private System.Data.DataSet m_dataset;   
		public System.Int32 m_KeyRecord;
        private System.Windows.Forms.Label lbl_Nombre;
		private System.Windows.Forms.Label lbl_contacto;
		private System.Windows.Forms.Label lbl_email;
		private System.Windows.Forms.Label lbl_Fecha;
		private System.Windows.Forms.Label lbl_telefono;
		private System.Windows.Forms.Label lbl_rfc;
		private System.Windows.Forms.Label lbl_direccion;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_nombre;
		private System.Windows.Forms.TextBox txt_rfc;
		private System.Windows.Forms.TextBox txt_dir;
		private System.Windows.Forms.TextBox txt_tel;
		private System.Windows.Forms.TextBox txt_fax;
		private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_contacto;
		private System.Windows.Forms.DateTimePicker txt_fechaalta;
		private System.Windows.Forms.Button cmd_cerrar;
		private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_Borrar;
        private ImageList imageList1;
        private TextBox txt_curp;
        private Label label2;
        private IContainer components;
        private GroupBox groupBox1;
        private TextBox txtMunicipio;
        private Label label8;
        private TextBox txtReferencia;
        private Label label7;
        private TextBox txtColonia;
        private Label label6;
        private TextBox txtInterior;
        private Label label5;
        private TextBox txtNumero;
        private Label label4;
        private TextBox txtCalle;
        private Label label3;
        private TextBox txtCp;
        private Label label11;
        private TextBox txtPais;
        private Label label10;
        private TextBox txtEstado;
        private Label label9;
        private TextBox txt_ciudad;
        private Label lbl_ciudad;

        public frm_ClientsList frm_CliPrin = null;

		public frm_Clientes()
		{
			InitializeComponent();
			this.m_KeyRecord = -1;
		}

		public frm_Clientes(System.Int32 p_KeyRecord)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//			
			//
			this.m_KeyRecord = p_KeyRecord;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Clientes));
            this.lbl_Nombre = new System.Windows.Forms.Label();
            this.lbl_contacto = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_Fecha = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.lbl_rfc = new System.Windows.Forms.Label();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_rfc = new System.Windows.Forms.TextBox();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_tel = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_fax = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_contacto = new System.Windows.Forms.TextBox();
            this.txt_fechaalta = new System.Windows.Forms.DateTimePicker();
            this.cmd_cerrar = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_Borrar = new System.Windows.Forms.Button();
            this.txt_curp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCalle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtInterior = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtColonia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtReferencia = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMunicipio = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCp = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPais = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEstado = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_ciudad = new System.Windows.Forms.TextBox();
            this.lbl_ciudad = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Nombre
            // 
            this.lbl_Nombre.Location = new System.Drawing.Point(32, 24);
            this.lbl_Nombre.Name = "lbl_Nombre";
            this.lbl_Nombre.Size = new System.Drawing.Size(72, 16);
            this.lbl_Nombre.TabIndex = 0;
            this.lbl_Nombre.Text = "Nombre";
            // 
            // lbl_contacto
            // 
            this.lbl_contacto.Location = new System.Drawing.Point(32, 243);
            this.lbl_contacto.Name = "lbl_contacto";
            this.lbl_contacto.Size = new System.Drawing.Size(72, 16);
            this.lbl_contacto.TabIndex = 3;
            this.lbl_contacto.Text = "Contacto";
            // 
            // lbl_email
            // 
            this.lbl_email.Location = new System.Drawing.Point(32, 211);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(72, 16);
            this.lbl_email.TabIndex = 4;
            this.lbl_email.Text = "Email";
            // 
            // lbl_Fecha
            // 
            this.lbl_Fecha.Location = new System.Drawing.Point(32, 179);
            this.lbl_Fecha.Name = "lbl_Fecha";
            this.lbl_Fecha.Size = new System.Drawing.Size(80, 16);
            this.lbl_Fecha.TabIndex = 5;
            this.lbl_Fecha.Text = "Fecha de Alta";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.Location = new System.Drawing.Point(32, 115);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(72, 16);
            this.lbl_telefono.TabIndex = 6;
            this.lbl_telefono.Text = "Telefono";
            // 
            // lbl_rfc
            // 
            this.lbl_rfc.Location = new System.Drawing.Point(32, 56);
            this.lbl_rfc.Name = "lbl_rfc";
            this.lbl_rfc.Size = new System.Drawing.Size(72, 16);
            this.lbl_rfc.TabIndex = 7;
            this.lbl_rfc.Text = "RFC";
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.Location = new System.Drawing.Point(32, 269);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(72, 16);
            this.lbl_direccion.TabIndex = 8;
            this.lbl_direccion.Text = "Direccion";
            // 
            // txt_nombre
            // 
            this.txt_nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_nombre.Location = new System.Drawing.Point(104, 24);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(344, 20);
            this.txt_nombre.TabIndex = 0;
            this.txt_nombre.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_rfc
            // 
            this.txt_rfc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_rfc.Location = new System.Drawing.Point(104, 56);
            this.txt_rfc.Name = "txt_rfc";
            this.txt_rfc.Size = new System.Drawing.Size(344, 20);
            this.txt_rfc.TabIndex = 1;
            this.txt_rfc.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_dir
            // 
            this.txt_dir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_dir.Location = new System.Drawing.Point(104, 269);
            this.txt_dir.Multiline = true;
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.Size = new System.Drawing.Size(344, 40);
            this.txt_dir.TabIndex = 8;
            this.txt_dir.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_tel
            // 
            this.txt_tel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_tel.Location = new System.Drawing.Point(104, 115);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.Size = new System.Drawing.Size(344, 20);
            this.txt_tel.TabIndex = 3;
            this.txt_tel.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(32, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Fax";
            // 
            // txt_fax
            // 
            this.txt_fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_fax.Location = new System.Drawing.Point(104, 147);
            this.txt_fax.Name = "txt_fax";
            this.txt_fax.Size = new System.Drawing.Size(344, 20);
            this.txt_fax.TabIndex = 4;
            this.txt_fax.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_email
            // 
            this.txt_email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_email.Location = new System.Drawing.Point(104, 211);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(344, 20);
            this.txt_email.TabIndex = 6;
            this.txt_email.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_contacto
            // 
            this.txt_contacto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_contacto.Location = new System.Drawing.Point(104, 243);
            this.txt_contacto.Name = "txt_contacto";
            this.txt_contacto.Size = new System.Drawing.Size(344, 20);
            this.txt_contacto.TabIndex = 7;
            this.txt_contacto.TextChanged += new System.EventHandler(this.txt_TextChanged);
            // 
            // txt_fechaalta
            // 
            this.txt_fechaalta.Location = new System.Drawing.Point(104, 179);
            this.txt_fechaalta.Name = "txt_fechaalta";
            this.txt_fechaalta.Size = new System.Drawing.Size(200, 20);
            this.txt_fechaalta.TabIndex = 5;
            this.txt_fechaalta.ValueChanged += new System.EventHandler(this.txt_fechaalta_ValueChanged);
            // 
            // cmd_cerrar
            // 
            this.cmd_cerrar.ImageIndex = 2;
            this.cmd_cerrar.ImageList = this.imageList1;
            this.cmd_cerrar.Location = new System.Drawing.Point(519, 328);
            this.cmd_cerrar.Name = "cmd_cerrar";
            this.cmd_cerrar.Size = new System.Drawing.Size(75, 23);
            this.cmd_cerrar.TabIndex = 21;
            this.cmd_cerrar.Text = "&Cancelar";
            this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_cerrar.Click += new System.EventHandler(this.cmd_cerrar_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "delete2.ico");
            this.imageList1.Images.SetKeyName(1, "disk_blue.ico");
            this.imageList1.Images.SetKeyName(2, "exit.ico");
            // 
            // cmd_save
            // 
            this.cmd_save.ImageKey = "disk_blue.ico";
            this.cmd_save.ImageList = this.imageList1;
            this.cmd_save.Location = new System.Drawing.Point(397, 328);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(119, 23);
            this.cmd_save.TabIndex = 20;
            this.cmd_save.Text = "&Guardar y cerrar";
            this.cmd_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_Borrar
            // 
            this.cmd_Borrar.ImageKey = "delete2.ico";
            this.cmd_Borrar.ImageList = this.imageList1;
            this.cmd_Borrar.Location = new System.Drawing.Point(170, 328);
            this.cmd_Borrar.Name = "cmd_Borrar";
            this.cmd_Borrar.Size = new System.Drawing.Size(116, 23);
            this.cmd_Borrar.TabIndex = 19;
            this.cmd_Borrar.Text = "Eliminar Registro";
            this.cmd_Borrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_Borrar.Visible = false;
            this.cmd_Borrar.Click += new System.EventHandler(this.cmd_Borrar_Click);
            // 
            // txt_curp
            // 
            this.txt_curp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_curp.Location = new System.Drawing.Point(104, 85);
            this.txt_curp.Name = "txt_curp";
            this.txt_curp.Size = new System.Drawing.Size(344, 20);
            this.txt_curp.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(32, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "CURP";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCp);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtMunicipio);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtReferencia);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtColonia);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtInterior);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtNumero);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCalle);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(472, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(309, 215);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Direccion para facturacion electronica";
            // 
            // txtCalle
            // 
            this.txtCalle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCalle.Location = new System.Drawing.Point(91, 19);
            this.txtCalle.Name = "txtCalle";
            this.txtCalle.Size = new System.Drawing.Size(177, 20);
            this.txtCalle.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(19, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Calle";
            // 
            // txtNumero
            // 
            this.txtNumero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNumero.Location = new System.Drawing.Point(91, 45);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(177, 20);
            this.txtNumero.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(19, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Numero";
            // 
            // txtInterior
            // 
            this.txtInterior.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInterior.Location = new System.Drawing.Point(91, 73);
            this.txtInterior.Name = "txtInterior";
            this.txtInterior.Size = new System.Drawing.Size(177, 20);
            this.txtInterior.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(19, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "Interior";
            // 
            // txtColonia
            // 
            this.txtColonia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtColonia.Location = new System.Drawing.Point(91, 101);
            this.txtColonia.Name = "txtColonia";
            this.txtColonia.Size = new System.Drawing.Size(177, 20);
            this.txtColonia.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(19, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Colonia";
            // 
            // txtReferencia
            // 
            this.txtReferencia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReferencia.Location = new System.Drawing.Point(91, 127);
            this.txtReferencia.Name = "txtReferencia";
            this.txtReferencia.Size = new System.Drawing.Size(177, 20);
            this.txtReferencia.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(19, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 18;
            this.label7.Text = "Referencia";
            // 
            // txtMunicipio
            // 
            this.txtMunicipio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMunicipio.Location = new System.Drawing.Point(91, 153);
            this.txtMunicipio.Name = "txtMunicipio";
            this.txtMunicipio.Size = new System.Drawing.Size(177, 20);
            this.txtMunicipio.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(19, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Municipio";
            // 
            // txtCp
            // 
            this.txtCp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCp.Location = new System.Drawing.Point(91, 180);
            this.txtCp.Name = "txtCp";
            this.txtCp.Size = new System.Drawing.Size(177, 20);
            this.txtCp.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(19, 180);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 20);
            this.label11.TabIndex = 26;
            this.label11.Text = "C.P.";
            // 
            // txtPais
            // 
            this.txtPais.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPais.Location = new System.Drawing.Point(544, 288);
            this.txtPais.Name = "txtPais";
            this.txtPais.Size = new System.Drawing.Size(177, 20);
            this.txtPais.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(472, 288);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "Pais";
            // 
            // txtEstado
            // 
            this.txtEstado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEstado.Location = new System.Drawing.Point(544, 262);
            this.txtEstado.Name = "txtEstado";
            this.txtEstado.Size = new System.Drawing.Size(177, 20);
            this.txtEstado.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(472, 262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 20);
            this.label9.TabIndex = 28;
            this.label9.Text = "Estado";
            // 
            // txt_ciudad
            // 
            this.txt_ciudad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ciudad.Location = new System.Drawing.Point(544, 237);
            this.txt_ciudad.Name = "txt_ciudad";
            this.txt_ciudad.Size = new System.Drawing.Size(177, 20);
            this.txt_ciudad.TabIndex = 16;
            // 
            // lbl_ciudad
            // 
            this.lbl_ciudad.Location = new System.Drawing.Point(472, 237);
            this.lbl_ciudad.Name = "lbl_ciudad";
            this.lbl_ciudad.Size = new System.Drawing.Size(66, 20);
            this.lbl_ciudad.TabIndex = 26;
            this.lbl_ciudad.Text = "Ciudad";
            // 
            // frm_Clientes
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(793, 368);
            this.Controls.Add(this.txtPais);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtEstado);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_ciudad);
            this.Controls.Add(this.lbl_ciudad);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txt_curp);
            this.Controls.Add(this.txt_dir);
            this.Controls.Add(this.lbl_direccion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmd_Borrar);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.cmd_cerrar);
            this.Controls.Add(this.txt_fechaalta);
            this.Controls.Add(this.txt_contacto);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_fax);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.txt_rfc);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_rfc);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.lbl_Fecha);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_contacto);
            this.Controls.Add(this.lbl_Nombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frm_Clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cliente";
            this.Load += new System.EventHandler(this.frm_Clientes_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_Clientes_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_Clientes_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

        public bool m_IsModified = false;
        public bool mp_Loading = false;

        private void frm_Clientes_Load(object sender, System.EventArgs e)
		{
            this.mp_Loading = true;
			
			this.txt_fechaalta.Value = System.DateTime.Today;

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.m_select = new System.Data.Odbc.OdbcCommand();
			this.m_select.Connection = this.m_conn;

            if (frm_CliPrin != null)
            {
                frm_CliPrin.p_Result = 0;
                frm_CliPrin.p_currentId = -1;
            }

			if(this.m_KeyRecord!=-1)
				this.m_select.CommandText = "Select * From catClientes where idcliente = " + this.m_KeyRecord.ToString() + ";";     
			else
				this.m_select.CommandText = "Select * From catClientes;";

            this.m_da = new System.Data.Odbc.OdbcDataAdapter();
			this.m_da.SelectCommand = this.m_select;
			this.m_dataset = new System.Data.DataSet();
			this.m_da.Fill(this.m_dataset);

            if (this.m_KeyRecord == -1)
            {
                this.mp_Loading = false;
                return;
            }

			this.cmd_Borrar.Visible = true; 
			this.FillData();

            this.mp_Loading = false;
		}

		private void FillData()
		{
			this.txt_nombre.Text = this.m_dataset.Tables[0].Rows[0][1].ToString();     
			this.txt_rfc.Text = this.m_dataset.Tables[0].Rows[0][5].ToString();       
			this.txt_dir.Text = this.m_dataset.Tables[0].Rows[0][2].ToString();         
			this.txt_tel.Text = this.m_dataset.Tables[0].Rows[0][4].ToString();           
			this.txt_fax.Text = this.m_dataset.Tables[0].Rows[0][3].ToString();             
			this.txt_fechaalta.Value = System.Convert.ToDateTime(this.m_dataset.Tables[0].Rows[0][6]);  
			this.txt_email.Text = this.m_dataset.Tables[0].Rows[0][7].ToString();             
			this.txt_contacto.Text = this.m_dataset.Tables[0].Rows[0][8].ToString();             
			this.txt_ciudad.Text = this.m_dataset.Tables[0].Rows[0][9].ToString();             
			this.txt_curp.Text = this.m_dataset.Tables[0].Rows[0][10].ToString();

            this.txtCalle.Text = this.m_dataset.Tables[0].Rows[0][11].ToString();
            this.txtNumero.Text = this.m_dataset.Tables[0].Rows[0][12].ToString();
            this.txtInterior.Text = this.m_dataset.Tables[0].Rows[0][13].ToString();
            this.txtColonia.Text = this.m_dataset.Tables[0].Rows[0][14].ToString();
            this.txtReferencia.Text = this.m_dataset.Tables[0].Rows[0][15].ToString();
            this.txtMunicipio.Text = this.m_dataset.Tables[0].Rows[0][16].ToString();
            this.txtEstado.Text = this.m_dataset.Tables[0].Rows[0][17].ToString();
            this.txtPais.Text = this.m_dataset.Tables[0].Rows[0][18].ToString();
            this.txtCp.Text = this.m_dataset.Tables[0].Rows[0][19].ToString();

		}

		private void cmd_cerrar_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void cmd_save_Click(object sender, System.EventArgs e)
		{
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcCommand l_updatei = new System.Data.Odbc.OdbcCommand();
			l_update.Connection = this.m_conn;
			l_updatei.Connection = this.m_conn;

			if(this.m_KeyRecord!=-1)
			{
				if(this.txt_nombre.Text.Trim()=="")
				{
					MessageBox.Show("Debe capturar al menos el nombre del cliente. NO SE HA ACTUALIZADO EL REGISTRO.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					return;
				}
				
				try
				{
					this.m_conn.Open();

                    l_update.CommandText = "UPDATE catClientes SET Nombre=?,Direccion=?,Fax=?,Telefono=?,RFC=?,Fecha=?,email=?,contacto=?,ciudad=?,CURP=?,Calle=?,Numero=?,NumeroInt=?,Colonia=?,Referencia=?,Municipio=?,Estado=?,Pais=?,CodigoPostal=? WHERE IdCliente=?";
					
					l_update.Parameters.AddWithValue("@Nombre",this.txt_nombre.Text);
					l_update.Parameters.AddWithValue("@Direccion",this.txt_dir.Text);
					l_update.Parameters.AddWithValue("@Fax",this.txt_fax.Text);
					l_update.Parameters.AddWithValue("@Telefono",this.txt_tel.Text);
					l_update.Parameters.AddWithValue("@RFC",this.txt_rfc.Text);
					l_update.Parameters.AddWithValue("@Fecha",this.txt_fechaalta.Value);
					l_update.Parameters.AddWithValue("@email",this.txt_email.Text);
					l_update.Parameters.AddWithValue("@contacto",this.txt_contacto.Text);
					l_update.Parameters.AddWithValue("@ciudad",this.txt_ciudad.Text);
					l_update.Parameters.AddWithValue("@CURP",this.txt_curp.Text);

                    l_update.Parameters.AddWithValue("@Calle", this.txtCalle.Text);
                    l_update.Parameters.AddWithValue("@Numero", this.txtNumero.Text);
                    l_update.Parameters.AddWithValue("@NumeroInt", this.txtInterior.Text);
                    l_update.Parameters.AddWithValue("@Colonia", this.txtColonia.Text);
                    l_update.Parameters.AddWithValue("@Referencia", this.txtReferencia.Text);
                    l_update.Parameters.AddWithValue("@Municipio", this.txtMunicipio.Text);
                    l_update.Parameters.AddWithValue("@Estado", this.txtEstado.Text);
                    l_update.Parameters.AddWithValue("@Pais", this.txtPais.Text);
                    l_update.Parameters.AddWithValue("@CodigoPostal", this.txtCp.Text);
					
					l_update.Parameters.AddWithValue("@IdCliente",this.m_KeyRecord);
					
					l_update.ExecuteNonQuery();

                    this.m_IsModified = false;

                    if (frm_CliPrin != null)
                    {
                        frm_CliPrin.p_Result = 1;
                        frm_CliPrin.p_currentId = this.m_KeyRecord;
                    }

                    //if (!string.IsNullOrEmpty(EasyInvoice.frm_Main.mps_strconnectionRepl))
                    //    this.SaveClienteReplica();

					this.Close();                    
				
				}
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al actualizar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al actualizar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}
			}
			else
			{
				//MessageBox.Show("Registro nuevo...");
				
				if(this.txt_nombre.Text.Trim()=="")
				{
					MessageBox.Show("Debe capturar al menos el nombre del cliente. NO SE HA AGREGADO EL REGISTRO.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
					return;
				}
				
				try
				{
					this.m_conn.Open();

                    l_update.CommandText = "INSERT INTO catClientes(Nombre,Direccion,Fax,Telefono,RFC,Fecha,email,contacto,ciudad,CURP,Calle,Numero,NumeroInt,Colonia,Referencia,Municipio,Estado,Pais,CodigoPostal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					
					l_update.Parameters.AddWithValue("@Nombre",this.txt_nombre.Text);
					l_update.Parameters.AddWithValue("@Direccion",this.txt_dir.Text);
					l_update.Parameters.AddWithValue("@Fax",this.txt_fax.Text);
					l_update.Parameters.AddWithValue("@Telefono",this.txt_tel.Text);
					l_update.Parameters.AddWithValue("@RFC",this.txt_rfc.Text);
					l_update.Parameters.AddWithValue("@Fecha",this.txt_fechaalta.Value);
					l_update.Parameters.AddWithValue("@email",this.txt_email.Text);
					l_update.Parameters.AddWithValue("@contacto",this.txt_contacto.Text);
					l_update.Parameters.AddWithValue("@ciudad",this.txt_ciudad.Text);
					l_update.Parameters.AddWithValue("@CURP",this.txt_curp.Text);

                    l_update.Parameters.AddWithValue("@Calle", this.txtCalle.Text);
                    l_update.Parameters.AddWithValue("@Numero", this.txtNumero.Text);
                    l_update.Parameters.AddWithValue("@NumeroInt", this.txtInterior.Text);
                    l_update.Parameters.AddWithValue("@Colonia", this.txtColonia.Text);
                    l_update.Parameters.AddWithValue("@Referencia", this.txtReferencia.Text);
                    l_update.Parameters.AddWithValue("@Municipio", this.txtMunicipio.Text);
                    l_update.Parameters.AddWithValue("@Estado", this.txtEstado.Text);
                    l_update.Parameters.AddWithValue("@Pais", this.txtPais.Text);
                    l_update.Parameters.AddWithValue("@CodigoPostal", this.txtCp.Text);
					
					l_update.ExecuteNonQuery();

                    //Obtener el ID de la inserci�n...
                    System.Data.Odbc.OdbcCommand l_getid = new System.Data.Odbc.OdbcCommand();
                    l_getid.Connection = this.m_conn;
                    l_getid.CommandText = "SELECT IdCliente FROM catClientes WHERE Nombre = ? AND Direccion = ? AND Fax = ? AND Telefono = ? AND RFC = ? AND Fecha = ? AND email = ? AND contacto = ? AND ciudad = ?;";

                    l_getid.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                    l_getid.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                    l_getid.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                    l_getid.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                    l_getid.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                    l_getid.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);
                    l_getid.Parameters.AddWithValue("@email", this.txt_email.Text);
                    l_getid.Parameters.AddWithValue("@contacto", this.txt_contacto.Text);
                    l_getid.Parameters.AddWithValue("@ciudad", this.txt_ciudad.Text);

                    object l_retid = l_getid.ExecuteScalar();

                    if (l_retid != null && l_retid != DBNull.Value)
                    {
                        this.m_KeyRecord = Convert.ToInt32(l_retid);
                    }

                    this.m_IsModified = false;
                    if (frm_CliPrin != null)
                    {
                        frm_CliPrin.p_Result = 1;
                        frm_CliPrin.p_currentId = this.m_KeyRecord;
                    }
					//this.Close();                   
                    if (!string.IsNullOrEmpty(EasyInvoice.frm_Main.mps_strconnectionRepl))
                        this.SaveClienteReplica();
				
				}
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al agregar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al agregar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}
                this.Close(); 
			}

		}

        private void SaveClienteReplica()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            System.Data.Odbc.OdbcCommand l_update = new System.Data.Odbc.OdbcCommand();
            System.Data.Odbc.OdbcTransaction l_trans = null;
            l_conn.ConnectionString = EasyInvoice.frm_Main.mps_strconnectionRepl;

            int m_keyrecord = -1;
            Boolean ok = true;

            try
            {
                if (l_conn.State != System.Data.ConnectionState.Open)
                    l_conn.Open();
                l_update.Connection = l_conn;

                l_update.Parameters.Clear();
                l_update.CommandText = "SELECT IdCliente FROM catClientes WHERE Nombre = ? AND Direccion = ? AND Fax = ? AND Telefono = ? AND RFC = ? AND Fecha = ? AND email = ? AND contacto = ? AND ciudad = ?;";

                l_update.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                l_update.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                l_update.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                l_update.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                l_update.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                l_update.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);
                l_update.Parameters.AddWithValue("@email", this.txt_email.Text);
                l_update.Parameters.AddWithValue("@contacto", this.txt_contacto.Text);
                l_update.Parameters.AddWithValue("@ciudad", this.txt_ciudad.Text);

                object l_retid = l_update.ExecuteScalar();
                object obj = l_update.ExecuteScalar();
                if (obj == null)
                    m_keyrecord = -1;
                else
                    m_keyrecord = Convert.ToInt32(obj);

                // salvar el nuevo registro
                if (m_keyrecord == -1)
                {
                    l_trans = l_conn.BeginTransaction();
                    l_update.Transaction = l_trans;

                    //agregar
                    l_update.CommandText = "INSERT INTO catClientes(Nombre,Direccion,Fax,Telefono,RFC,Fecha,email,contacto,ciudad,CURP,Calle,Numero,NumeroInt,Colonia,Referencia,Municipio,Estado,Pais,CodigoPostal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                    l_update.Parameters.Clear();
                    l_update.Parameters.AddWithValue("@Nombre", this.txt_nombre.Text);
                    l_update.Parameters.AddWithValue("@Direccion", this.txt_dir.Text);
                    l_update.Parameters.AddWithValue("@Fax", this.txt_fax.Text);
                    l_update.Parameters.AddWithValue("@Telefono", this.txt_tel.Text);
                    l_update.Parameters.AddWithValue("@RFC", this.txt_rfc.Text);
                    l_update.Parameters.AddWithValue("@Fecha", this.txt_fechaalta.Value);
                    l_update.Parameters.AddWithValue("@email", this.txt_email.Text);
                    l_update.Parameters.AddWithValue("@contacto", this.txt_contacto.Text);
                    l_update.Parameters.AddWithValue("@ciudad", this.txt_ciudad.Text);
                    l_update.Parameters.AddWithValue("@CURP", this.txt_curp.Text);

                    l_update.Parameters.AddWithValue("@Calle", this.txtCalle.Text);
                    l_update.Parameters.AddWithValue("@Numero", this.txtNumero.Text);
                    l_update.Parameters.AddWithValue("@NumeroInt", this.txtInterior.Text);
                    l_update.Parameters.AddWithValue("@Colonia", this.txtColonia.Text);
                    l_update.Parameters.AddWithValue("@Referencia", this.txtReferencia.Text);
                    l_update.Parameters.AddWithValue("@Municipio", this.txtMunicipio.Text);
                    l_update.Parameters.AddWithValue("@Estado", this.txtEstado.Text);
                    l_update.Parameters.AddWithValue("@Pais", this.txtPais.Text);
                    l_update.Parameters.AddWithValue("@CodigoPostal", this.txtCp.Text);

                    l_update.ExecuteNonQuery();

                    if (ok)
                        l_trans.Commit();

                }

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro  repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                ok = false;
                l_trans.Rollback();
                MessageBox.Show("Error al agregar/editar el registro repl. " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();

                l_conn.Dispose();
                l_conn = null;
            }

        }


		private void cmd_Borrar_Click(object sender, System.EventArgs e)
		{
            if (frm_Main.mps_acceso == "Caja")
                return;

            System.Data.Odbc.OdbcCommand l_delete = new System.Data.Odbc.OdbcCommand();

			if( MessageBox.Show("Esta a punto de eliminar este registro �Confirma que desea continuar?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;
			
            try
            {
            	this.m_conn.Open();
            	
				l_delete.Connection = this.m_conn;
				l_delete.CommandText = "delete from catclientes where idcliente = ?;";
				l_delete.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@idcliente",this.m_KeyRecord )  );           
				
				l_delete.ExecuteNonQuery();

                this.m_IsModified = false;
                if (frm_CliPrin != null)
                {
                    frm_CliPrin.p_Result = 1;
                    frm_CliPrin.p_currentId = -1;
                }

				this.Close(); 
            }
				catch(System.Data.OleDb.OleDbException ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}				
				catch(System.Exception ex)
				{
					MessageBox.Show("Error al borrar el registro. " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
				}
				finally
				{
					if(this.m_conn.State == System.Data.ConnectionState.Open)
						this.m_conn.Close();
				}            
				
		}

        private void frm_Clientes_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
            	case Keys.Enter:
            		this.cmd_save_Click(sender, e);
            		break;
                case Keys.Escape:
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        this.Close();
                    break;
                case Keys.F2:
                    this.cmd_save_Click(sender, e);
                    break;
            }

        }

        private void txt_TextChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
        }

        private void txt_fechaalta_ValueChanged(object sender, EventArgs e)
        {
            if (this.mp_Loading == true)
                return;
            this.m_IsModified = true;
        }

        private void frm_Clientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.m_IsModified == true)
            {
                switch (MessageBox.Show("Ha modificado informaci�n en esta ventana �Desea guardar los datos antes de cerrar?", "Pregunta ?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        this.cmd_save_Click(sender, e);
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }
	}
}

