using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frmClientsList.
	/// </summary>
	public class frm_TraspasosList : System.Windows.Forms.Form
    {
		private System.Data.DataSet m_dataset;
		public System.Windows.Forms.Button cmd_nuevo;
		public System.Int32 m_KeyRecord;
		private System.Windows.Forms.Button cmd_buscar;
		public System.Windows.Forms.TextBox txt_criterio; 		
		private System.Windows.Forms.Button cmd_actualizar;
        private System.Windows.Forms.Label lbl_curcel;
        public ToolBar mp_toolbar;
		private System.Windows.Forms.ToolBarButton cdmt_nuevo;
		private System.Windows.Forms.ToolBarButton cmdt_editar;
		private System.Windows.Forms.ToolBarButton cmdt_actualizar;
		private System.Windows.Forms.ImageList mp_imagelisttb;
		private System.Windows.Forms.ToolBarButton cmdt_exit;
		private System.Windows.Forms.ToolBarButton toolBarButton1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ComboBox cmb_criterios;
        private DataGridView dataGridView1;
		private System.ComponentModel.IContainer components;

        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        public string mp_criteriousar = "";

        public Int32 p_Result;
        private DateTimePicker dateTimePicker1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem imprimirToolStripMenuItem;
        public Int32 p_currentId;

		public frm_TraspasosList()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//			
			//			
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_TraspasosList));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmd_nuevo = new System.Windows.Forms.Button();
            this.cmd_buscar = new System.Windows.Forms.Button();
            this.txt_criterio = new System.Windows.Forms.TextBox();
            this.cmd_actualizar = new System.Windows.Forms.Button();
            this.lbl_curcel = new System.Windows.Forms.Label();
            this.mp_toolbar = new System.Windows.Forms.ToolBar();
            this.cdmt_nuevo = new System.Windows.Forms.ToolBarButton();
            this.cmdt_editar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_actualizar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_exit = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.mp_imagelisttb = new System.Windows.Forms.ImageList(this.components);
            this.cmb_criterios = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmd_nuevo
            // 
            this.cmd_nuevo.Location = new System.Drawing.Point(16, 72);
            this.cmd_nuevo.Name = "cmd_nuevo";
            this.cmd_nuevo.Size = new System.Drawing.Size(112, 23);
            this.cmd_nuevo.TabIndex = 0;
            this.cmd_nuevo.Text = "Nuevo Cliente";
            this.cmd_nuevo.Visible = false;
            // 
            // cmd_buscar
            // 
            this.cmd_buscar.Location = new System.Drawing.Point(16, 104);
            this.cmd_buscar.Name = "cmd_buscar";
            this.cmd_buscar.Size = new System.Drawing.Size(112, 23);
            this.cmd_buscar.TabIndex = 1;
            this.cmd_buscar.Text = "Buscar Registro";
            this.cmd_buscar.Visible = false;
            // 
            // txt_criterio
            // 
            this.txt_criterio.Location = new System.Drawing.Point(560, 16);
            this.txt_criterio.Name = "txt_criterio";
            this.txt_criterio.Size = new System.Drawing.Size(232, 20);
            this.txt_criterio.TabIndex = 0;
            this.txt_criterio.TextChanged += new System.EventHandler(this.txt_criterio_TextChanged);
            this.txt_criterio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_criterio_KeyDown);
            // 
            // cmd_actualizar
            // 
            this.cmd_actualizar.Location = new System.Drawing.Point(40, 408);
            this.cmd_actualizar.Name = "cmd_actualizar";
            this.cmd_actualizar.Size = new System.Drawing.Size(112, 23);
            this.cmd_actualizar.TabIndex = 3;
            this.cmd_actualizar.Text = "Actualizar";
            this.cmd_actualizar.Visible = false;
            this.cmd_actualizar.Click += new System.EventHandler(this.cmd_actualizar_Click);
            // 
            // lbl_curcel
            // 
            this.lbl_curcel.Location = new System.Drawing.Point(608, 8);
            this.lbl_curcel.Name = "lbl_curcel";
            this.lbl_curcel.Size = new System.Drawing.Size(64, 24);
            this.lbl_curcel.TabIndex = 5;
            // 
            // mp_toolbar
            // 
            this.mp_toolbar.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.mp_toolbar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mp_toolbar.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.cdmt_nuevo,
            this.cmdt_editar,
            this.cmdt_actualizar,
            this.cmdt_exit,
            this.toolBarButton1});
            this.mp_toolbar.ButtonSize = new System.Drawing.Size(55, 45);
            this.mp_toolbar.DropDownArrows = true;
            this.mp_toolbar.ImageList = this.mp_imagelisttb;
            this.mp_toolbar.Location = new System.Drawing.Point(0, 0);
            this.mp_toolbar.Name = "mp_toolbar";
            this.mp_toolbar.ShowToolTips = true;
            this.mp_toolbar.Size = new System.Drawing.Size(808, 51);
            this.mp_toolbar.TabIndex = 2;
            this.mp_toolbar.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.mp_toolbar_ButtonClick);
            // 
            // cdmt_nuevo
            // 
            this.cdmt_nuevo.ImageIndex = 0;
            this.cdmt_nuevo.Name = "cdmt_nuevo";
            this.cdmt_nuevo.Text = "Agregar";
            this.cdmt_nuevo.ToolTipText = "Presione este bot�n para agregar un cliente nuevo al sistema...";
            // 
            // cmdt_editar
            // 
            this.cmdt_editar.ImageIndex = 1;
            this.cmdt_editar.Name = "cmdt_editar";
            this.cmdt_editar.Text = "Ver";
            this.cmdt_editar.ToolTipText = "Presione este bot�n para editar los datos relativos al cliente seleccionado en la" +
                " lista...";
            // 
            // cmdt_actualizar
            // 
            this.cmdt_actualizar.ImageIndex = 2;
            this.cmdt_actualizar.Name = "cmdt_actualizar";
            this.cmdt_actualizar.Text = "Actualizar";
            this.cmdt_actualizar.ToolTipText = "Presione este bot�n para actualizar la lista de clientes...";
            // 
            // cmdt_exit
            // 
            this.cmdt_exit.ImageIndex = 3;
            this.cmdt_exit.Name = "cmdt_exit";
            this.cmdt_exit.Text = "Cerrar";
            this.cmdt_exit.ToolTipText = "Presione este bot�n para cerrar este ventana...";
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // mp_imagelisttb
            // 
            this.mp_imagelisttb.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("mp_imagelisttb.ImageStream")));
            this.mp_imagelisttb.TransparentColor = System.Drawing.Color.Transparent;
            this.mp_imagelisttb.Images.SetKeyName(0, "cube_blue_new.ico");
            this.mp_imagelisttb.Images.SetKeyName(1, "Drafts.ico");
            this.mp_imagelisttb.Images.SetKeyName(2, "refresh.ico");
            this.mp_imagelisttb.Images.SetKeyName(3, "exit.ico");
            this.mp_imagelisttb.Images.SetKeyName(4, "find.ico");
            // 
            // cmb_criterios
            // 
            this.cmb_criterios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_criterios.Location = new System.Drawing.Point(368, 16);
            this.cmb_criterios.Name = "cmb_criterios";
            this.cmb_criterios.Size = new System.Drawing.Size(121, 21);
            this.cmb_criterios.TabIndex = 1;
            this.cmb_criterios.SelectionChangeCommitted += new System.EventHandler(this.cmb_criterios_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(296, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Buscar por";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(504, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "criterio:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(264, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightYellow;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Location = new System.Drawing.Point(0, 50);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(808, 414);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            this.dataGridView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView1_KeyDown);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.imprimirToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(153, 48);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(560, 17);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(232, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.Visible = false;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // frm_TraspasosList
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(808, 470);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_criterios);
            this.Controls.Add(this.txt_criterio);
            this.Controls.Add(this.mp_toolbar);
            this.Controls.Add(this.lbl_curcel);
            this.Controls.Add(this.cmd_actualizar);
            this.Controls.Add(this.cmd_buscar);
            this.Controls.Add(this.cmd_nuevo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_TraspasosList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista de Traspasos";
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_ClientsList_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion
		
		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
			this.FillDataset();			

			if(m_dataset.Tables.Count > 0)
			{

				foreach(System.Data.DataColumn l_col in m_dataset.Tables[0].Columns)
				{
                    if (l_col.DataType.Name == "String")
					    this.cmb_criterios.Items.Add(l_col.ColumnName);
				}
                this.cmb_criterios.Items.Add("Fecha");
                this.cmb_criterios.Items.Add("Posteriores a la Fecha...");

				this.cmb_criterios.Text = "AlmacenOrigen";			
				
				if(this.mp_criteriousar.Trim()!="")
					this.txt_criterio.Text = this.mp_criteriousar;
			}

		}
				
		public void FillDataset()	
		{
            try
            {
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();                
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "select IdTraspaso as Consecutivo,catAlmacenes.Descripcion as AlmacenOrigen,Fecha,Observaciones from catTraspasos left join catAlmacenes on catTraspasos.idAlmacenOrig=catAlmacenes.idAlmacen ORDER BY Fecha;";
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "traspasos";
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;                
                
                this.dataGridView1.Columns[1].Width = 300;
                this.dataGridView1.Columns[2].Width = 80;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
		}
				
		private void cmd_actualizar_Click(object sender, System.EventArgs e)
		{
			//MessageBox.Show("ok");
		}

		private void mp_toolbar_ButtonClick(object sender, System.Windows.Forms.ToolBarButtonClickEventArgs e)
		{
			switch(e.Button.Text)
			{
				case "Agregar":
                    /*
					frm_Clientes l_frm = new frm_Clientes(); 
					l_frm.ShowDialog(); 	
					this.FillDataset();					
                     */
                    this.LoadTraspaso(-1);
					break;		
				case "Ver":
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        this.LoadTraspaso(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    }
					break;
				case "Actualizar":
					this.FillDataset();
					break;
				case "Cerrar":
					this.Close();
					break;

			}

		}

		private void txt_criterio_TextChanged(object sender, System.EventArgs e)
		{
            try
            {
                this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }        	

		}

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.cmd_nuevo.Enabled == true)
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    /*
                    frm_Clientes l_frm1 = new frm_Clientes(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    l_frm1.ShowDialog();
                    this.FillDataset();					
                     */
                    this.LoadTraspaso(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                }
            }
            else
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                    this.Close();
                }
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmd_nuevo.Enabled == true)
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        /*
                        frm_Clientes l_frm1 = new frm_Clientes(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                        l_frm1.ShowDialog();
                        this.FillDataset();					
                         */
                        this.LoadTraspaso(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value)); 
                    }
                }
                else 
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                        this.Close();
                    }
                }
            }
        }

        private void frm_ClientsList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void txt_criterio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                this.dataGridView1.Focus();
        }

        void LoadTraspaso(Int32 pID)
        {
            if (EasyInvoice.frm_Main.mps_strconnectionTrasp == null)
            {
                frm_Traspasos l_frm1;
                if (pID > 0)
                    l_frm1 = new frm_Traspasos(pID);
                else
                    l_frm1 = new frm_Traspasos();

                l_frm1.frm_TraspPrin = this;
                l_frm1.ShowDialog();
            }
            else
            {
                frm_Traspasos1 l_frm1;
                if (pID > 0)
                    l_frm1 = new frm_Traspasos1(pID);
                else
                    l_frm1 = new frm_Traspasos1();

                l_frm1.frm_TraspPrin = this;
                l_frm1.ShowDialog();
            }
            if (this.p_Result == 1)
            {
                this.FillDataset();
                if (this.p_currentId > 0)
                {
                    foreach (DataGridViewRow row in this.dataGridView1.Rows)
                    {
                        if ((Int32)row.Cells[0].Value == this.p_currentId)
                        {
                            row.Selected = true;
                            OnScroll(new ScrollEventArgs(ScrollEventType.LargeIncrement, row.Index));
                            this.dataGridView1.SelectedRows[0].Cells[1].Selected = true;
                            break;
                        }
                    }
                }
            }

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.cmb_criterios.Text == "Fecha")
                    this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " >= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 00:00:00# AND [" + this.cmb_criterios.Text + "] <= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 23:59:59#";
                else
                    this.mp_bs.Filter = "[Fecha]" + " >= #" + this.dateTimePicker1.Value.Year + "/" + this.dateTimePicker1.Value.Month + "/" + this.dateTimePicker1.Value.Day + " 00:00:00#";

                //this.UpdatePendientes();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            } 
        }

        private void cmb_criterios_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (this.cmb_criterios.Text == "Fecha" || this.cmb_criterios.Text == "Posteriores a la Fecha...")
            {
                this.txt_criterio.Visible = false;
                this.dateTimePicker1.Visible = true;
                this.dateTimePicker1.Focus();
                this.dateTimePicker1_ValueChanged(sender, e);
            }
            else
            {
                this.txt_criterio.Visible = true;
                this.dateTimePicker1.Visible = false;
                this.txt_criterio.Focus();
                this.txt_criterio_TextChanged(sender, e);
            }
        }

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.ImprimirTraspaso();

        }

        private void ImprimirTraspaso()
        {
            int idTraspaso;
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                idTraspaso = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
#if ES_UNIX 					
                    // CODIGO PARA MIKE   <======================== OJO,    MIGUEL MOTA ACA!!

#else
                object lInstance;
                try
                {
                    if (System.IO.File.Exists(".\\EASYREPORTS.DLL"))
                    {
                        object ret;
                        object[] parms = new object[1];
                        System.Reflection.MethodInfo MethodInf;
                        System.Reflection.Assembly lAssembly;
                        Type lType;

                        lAssembly = System.Reflection.Assembly.Load("EASYREPORTS");
                        lType = lAssembly.GetType("EasyReports.ReportAdmin");

                        lInstance = Activator.CreateInstance(lType);

                        MethodInf = lType.GetMethod("setConnectionString");
                        parms[0] = frm_Main.mps_strconnection;
                        ret = MethodInf.Invoke(lInstance, parms);

                        MethodInf = lType.GetMethod("setReportOption");
                        parms[0] = 3;  //ID en EASYREPORTS para Traspasos
                        ret = MethodInf.Invoke(lInstance, parms);

                        MethodInf = lType.GetMethod("invokeReport");
                        object[] parmsrep = new object[1];
                        parmsrep[0] = idTraspaso;
                        parms[0] = parmsrep;
                        ret = MethodInf.Invoke(lInstance, parms);

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    lInstance = null;
                }
#endif
            }
        }


	}

}


