﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frm_familias_tree : Form
    {
        private System.Data.Odbc.OdbcConnection m_conn;
        private System.Data.Odbc.OdbcCommand m_select;
        public frm_productos frmproductos = null;

        public frm_familias_tree()
        {
            InitializeComponent();
        }

        private void cmd_ok_Click(object sender, EventArgs e)
        {
            if (frmproductos != null)
            {
                if (this.treeView1.SelectedNode != null)
                    this.frmproductos.SetFamilia(this.treeView1.SelectedNode.Text);
            }
            this.Close();
        }

        private void frm_familias_tree_Load(object sender, EventArgs e)
        {
            Int32 idPadre;
            TreeNode[] lnodes;
            SortedList<String,String> sl_nodes = new SortedList<string,String>(); 
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            this.m_conn.Open();

            this.m_select = new System.Data.Odbc.OdbcCommand();
            this.m_select.Connection = this.m_conn;

            if (this.treeView1.Nodes.Count  == 0)
            {
                this.m_select.CommandText = "SELECT idFamilia,descripcion,idPadre FROM catFamilias order by idFamilia;";
                System.Data.Odbc.OdbcDataReader l_rdr = this.m_select.ExecuteReader();
                while (l_rdr.Read())
                {
                    idPadre = Convert.ToInt32(l_rdr["idPadre"]);
                    if (idPadre <= 0)
                    {
                        this.treeView1.Nodes.Add(Convert.ToString(l_rdr["idFamilia"]), Convert.ToString(l_rdr["descripcion"]));
                    }
                    else
                    {
                        lnodes = this.treeView1.Nodes.Find(Convert.ToString(idPadre),true);
                        if (lnodes.Length > 0)
                            lnodes[0].Nodes.Add(Convert.ToString(l_rdr["idFamilia"]), Convert.ToString(l_rdr["descripcion"]));
                        else
                            sl_nodes.Add(Convert.ToString(l_rdr["idFamilia"]),Convert.ToString(l_rdr["idPadre"])+ "@" + Convert.ToString(l_rdr["descripcion"]));
                    }
                }
                //Procesa items no agregados al TreeView
                List<String> keys_processed = new List<string>(); 
                while(sl_nodes.Count > 0)
                {
                    keys_processed.Clear();
                    foreach (String key in sl_nodes.Keys )
                    {
                        lnodes = this.treeView1.Nodes.Find(sl_nodes[key].Substring(0, sl_nodes[key].IndexOf("@")), true);
                        if (lnodes.Length > 0)
                        {
                            lnodes[0].Nodes.Add(key, sl_nodes[key].Substring(sl_nodes[key].IndexOf("@")+1));
                            keys_processed.Add(key);
                        }
                    }
                    if (keys_processed.Count > 0)
                    {
                        // borra de la lista los elementos procesados
                        foreach (String key in keys_processed)
                            sl_nodes.Remove(key);
                    }
                    else
                    {
                        // si no proceso nada, se sale del ciclo x ser items con padre inexistente
                        break;
                    }
                }

                l_rdr.Close();
            }

            this.m_conn.Close();

            this.treeView1.ExpandAll();
        }

        private void cmd_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
