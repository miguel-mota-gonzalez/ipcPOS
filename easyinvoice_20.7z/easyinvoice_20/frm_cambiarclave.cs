﻿/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:37 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_cambiarclave.
	/// </summary>
	public partial class frm_cambiarclave : Form
	{
		
		private System.Data.Odbc.OdbcConnection m_conn;
        private System.Collections.SortedList slAlmacenes= null;
		
		public frm_cambiarclave()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
			
		}
		
		void Cmd_cancelClick(object sender, EventArgs e)
		{
			this.Close();
		}
		
		void Cmd_okClick(object sender, EventArgs e)
		{
            /*
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT clave FROM ConfSystem;";
			
			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();   

			l_reader.Read();
 
			string l_pwd = l_reader[0].ToString().ToUpper();
			System.Text.StringBuilder l_pwdb = new System.Text.StringBuilder();

			l_reader.Close();
			this.m_conn.Close();  			
			
			///////////////////////////////////////////////
			 
			foreach(char l_char in this.txt_clave.Text.Trim().ToUpper())
			{
				switch(l_char)
				{
					case 'A':
						l_pwdb.Append('1');
						break;
					case 'E':
						l_pwdb.Append('2');
						break;
					case 'I':
						l_pwdb.Append('3');
						break;
					case '0':
						l_pwdb.Append('4');
						break;
					case 'U':
						l_pwdb.Append('5');
						break;	
					case 'J':
						l_pwdb.Append('6');
						break;	
					case 'N':
						l_pwdb.Append('7');
						break;	
					case 'S':
						l_pwdb.Append('8');
						break;	
					case 'M':
						l_pwdb.Append('9');
						break;								
					default:
						l_pwdb.Append(l_char);
						break;
				}
			}
			

			if( l_pwd == l_pwdb.ToString() && this.txt_new1.Text == this.txt_new2.Text )
			{				
				System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();
				
				System.Text.StringBuilder l_pwdb1 = new System.Text.StringBuilder();
				
				foreach(char l_char in this.txt_new1.Text.Trim().ToUpper())
				{
					switch(l_char)
					{
						case 'A':
							l_pwdb1.Append('1');
							break;
						case 'E':
							l_pwdb1.Append('2');
							break;
						case 'I':
							l_pwdb1.Append('3');
							break;
						case '0':
							l_pwdb1.Append('4');
							break;
						case 'U':
							l_pwdb1.Append('5');
							break;	
						case 'J':
							l_pwdb1.Append('6');
							break;	
						case 'N':
							l_pwdb1.Append('7');
							break;	
						case 'S':
							l_pwdb1.Append('8');
							break;	
						case 'M':
							l_pwdb1.Append('9');
							break;								
						default:
							l_pwdb1.Append(l_char);
							break;
					}
				}				
				
				//////////////////////////////////////////
				
				l_cmd1.Connection = this.m_conn;
				l_cmd1.CommandText = "UPDATE ConfSystem SET clave = ?";
				l_cmd1.Parameters.AddWithValue("@clave",l_pwdb1.ToString());
				
				this.m_conn.Open(); 

				//Update...
				l_cmd1.ExecuteNonQuery();
				
				this.m_conn.Close();  							
				
				//////////////////////////////////////////
				
				
				MessageBox.Show( "Clave actualizada", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information );				
				this.Close();
			}			
			else
			{
				MessageBox.Show("Verifique la información","ERRROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			*/
		}
		
		void Txt_new1Enter(object sender, EventArgs e)
		{
			this.txt_nombre.SelectAll();
			this.txt_nombre.SelectAll();
			this.txt_clave2.SelectAll();
		}

        private void frm_cambiarclave_Load(object sender, EventArgs e)
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            this.lvw_main.Items.Clear();
            this.cmb_acceso.SelectedIndex = 0;
            
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "SELECT * FROM catUsuarios;";

            try
            {
                l_conn.Open();

                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();

                while (l_rdr.Read())
                {
                    ListViewItem l_lvwi = this.lvw_main.Items.Add(l_rdr["cnombre"].ToString());
                    l_lvwi.SubItems.Add(l_rdr["clogin"].ToString());
                    l_lvwi.SubItems.Add(l_rdr["cacceso"].ToString());
                }
                l_rdr.Close();

                if(slAlmacenes==null)
                {
                    slAlmacenes=new System.Collections.SortedList();
                    cmb_Almacen.Items.Clear();
                    l_cmd.CommandText = "SELECT IdAlmacen, Descripcion FROM catAlmacenes;";
                    l_rdr = l_cmd.ExecuteReader();
                    while (l_rdr.Read())
                    {
                        slAlmacenes.Add(l_rdr["IdAlmacen"].ToString(),l_rdr["Descripcion"].ToString());
                        cmb_Almacen.Items.Add(l_rdr["Descripcion"].ToString());
                    }
                    if (slAlmacenes.Count <= 0)
                    {
                        slAlmacenes.Add("0", "");
                        cmb_Almacen.Items.Add("");
                        pnl_Almacen.Visible = false;
                    }
                    l_rdr.Close();
                }

                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
            
        }

        private void lvw_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lvw_main.SelectedItems.Count == 0)
                return;

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            this.cmb_acceso.SelectedIndex = 0;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "SELECT * FROM catUsuarios where clogin = ?;";

            l_cmd.Parameters.AddWithValue("@clogin", this.lvw_main.SelectedItems[0].SubItems[1].Text);

            try
            {
                l_conn.Open();

                System.Data.Odbc.OdbcDataReader l_rdr = l_cmd.ExecuteReader();

                if (l_rdr.Read())
                {
                    this.txt_nombre.Text = l_rdr["cnombre"].ToString();
                    this.txt_login.Text = l_rdr["clogin"].ToString();
                    this.txt_clave1.Text = l_rdr["cclave"].ToString();
                    this.txt_clave2.Text = l_rdr["cclave"].ToString();
                    this.cmb_acceso.Text = l_rdr["cacceso"].ToString();
                    if(slAlmacenes.ContainsKey(l_rdr["IdAlmacen"].ToString()))
                    {
                    this.cmb_Almacen.Text = slAlmacenes[l_rdr["IdAlmacen"].ToString()].ToString();
                    }
                    else
                    {
                    this.cmb_Almacen.Text = "";
                    }
                }

                l_rdr.Close();

                l_conn.Close();
            }
            catch
            {
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void cmd_save_Click(object sender, EventArgs e)
        {
            bool l_new = false;
            //Es un registro nuevo
            if (this.lvw_main.SelectedItems.Count > 0)
            {
                if (this.lvw_main.SelectedItems[0].SubItems[1].Text == this.txt_login.Text)
                    l_new = false;
            }
            else 
            {
                l_new = true;
            }

            if (this.txt_nombre.Text.Trim() == "")
                return;

            if (this.txt_login.Text.Trim() == "")
                return;

            if (this.txt_clave1.Text.Trim() == "")
                return;
            
            if (l_new)
            {
                if (this.txt_clave1.Text != this.txt_clave2.Text)
                {
                    MessageBox.Show("Las claves no coinciden, verifíquelas e intente de nuevo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txt_clave1.SelectAll();
                    this.txt_clave1.Focus();
                    return;
                }
                this.AgregarRegistro();
                this.frm_cambiarclave_Load(null, null);
            }
            else
            { 
                //Actualizar el registro...

                if (this.txt_clave1.Text != this.txt_clave2.Text)
                {
                    MessageBox.Show("Las claves no coinciden, verifíquelas e intente de nuevo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txt_clave1.SelectAll();
                    this.txt_clave1.Focus();
                    return;
                }
                this.ActualizarRegistro();
                this.frm_cambiarclave_Load(null, null);
            }

        }

        private void ActualizarRegistro()
        {
            string l_clave = this.txt_clave1.Text.ToUpper();

            System.Text.StringBuilder l_pwdb1 = new System.Text.StringBuilder();
            /*
            foreach (char l_char in l_clave)
            {
                switch (l_char)
                {
                    case 'A':
                        l_pwdb1.Append('1');
                        break;
                    case 'E':
                        l_pwdb1.Append('2');
                        break;
                    case 'I':
                        l_pwdb1.Append('3');
                        break;
                    case '0':
                        l_pwdb1.Append('4');
                        break;
                    case 'U':
                        l_pwdb1.Append('5');
                        break;
                    case 'J':
                        l_pwdb1.Append('6');
                        break;
                    case 'N':
                        l_pwdb1.Append('7');
                        break;
                    case 'S':
                        l_pwdb1.Append('8');
                        break;
                    case 'M':
                        l_pwdb1.Append('9');
                        break;
                    default:
                        l_pwdb1.Append(l_char);
                        break;
                }
            }
            
            l_clave = l_pwdb1.ToString();
            */
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "UPDATE catUsuarios set cclave = ?,cnombre = ?,cacceso = ?, IdAlmacen=? WHERE clogin = ?;";

            l_cmd.Parameters.AddWithValue("@cclave", l_clave);
            l_cmd.Parameters.AddWithValue("@cnombre", this.txt_nombre.Text);
            l_cmd.Parameters.AddWithValue("@cacceso", this.cmb_acceso.SelectedItem.ToString());
            if (slAlmacenes.ContainsValue(this.cmb_Almacen.Text))
            {
                l_cmd.Parameters.AddWithValue("@IdAlmacen", slAlmacenes.GetKey(slAlmacenes.IndexOfValue(this.cmb_Almacen.Text)));
            }
            else
            {
                l_cmd.Parameters.AddWithValue("@IdAlmacen", "0");
            }

            l_cmd.Parameters.AddWithValue("@clogin", this.txt_login.Text);

            try
            {
                l_conn.Open();

                //Guardar...
                l_cmd.ExecuteNonQuery();

                MessageBox.Show("Usuario " + this.txt_nombre.Text + " actualizado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch(System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void AgregarRegistro()
        {
            string l_clave = this.txt_clave1.Text.ToUpper();

            System.Text.StringBuilder l_pwdb1 = new System.Text.StringBuilder();
            /*
            foreach (char l_char in l_clave)
            {
                switch (l_char)
                {
                    case 'A':
                        l_pwdb1.Append('1');
                        break;
                    case 'E':
                        l_pwdb1.Append('2');
                        break;
                    case 'I':
                        l_pwdb1.Append('3');
                        break;
                    case '0':
                        l_pwdb1.Append('4');
                        break;
                    case 'U':
                        l_pwdb1.Append('5');
                        break;
                    case 'J':
                        l_pwdb1.Append('6');
                        break;
                    case 'N':
                        l_pwdb1.Append('7');
                        break;
                    case 'S':
                        l_pwdb1.Append('8');
                        break;
                    case 'M':
                        l_pwdb1.Append('9');
                        break;
                    default:
                        l_pwdb1.Append(l_char);
                        break;
                }
            }
            l_clave = l_pwdb1.ToString();
            */
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "INSERT INTO catUsuarios(cclave,cnombre,cacceso,clogin,IdAlmacen) VALUES(?,?,?,?,?);";

            l_cmd.Parameters.AddWithValue("@cclave", l_clave);
            l_cmd.Parameters.AddWithValue("@cnombre", this.txt_nombre.Text);
            l_cmd.Parameters.AddWithValue("@cacceso", this.cmb_acceso.SelectedItem.ToString());
            l_cmd.Parameters.AddWithValue("@clogin", this.txt_login.Text);
            if (slAlmacenes.ContainsValue(this.cmb_Almacen.Text))
            {
                l_cmd.Parameters.AddWithValue("@IdAlmacen", slAlmacenes.GetKey(slAlmacenes.IndexOfValue(this.cmb_Almacen.Text)));
            }
            else
            {
                l_cmd.Parameters.AddWithValue("@IdAlmacen", "0");
            }

            try
            {
                l_conn.Open();

                //Guardar...
                l_cmd.ExecuteNonQuery();

                MessageBox.Show("Usuario " + this.txt_nombre.Text + " agregado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void cmd_del_Click(object sender, EventArgs e)
        {
            if (this.lvw_main.SelectedItems.Count > 0)
            {
                if (MessageBox.Show("¿Realmente desea eliminar a " + this.txt_nombre.Text + "?", "Pregunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    return;

                this.BorrarUsuario();
                this.frm_cambiarclave_Load(null, null);
            }
        }

        private void BorrarUsuario()
        {
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = l_conn;
            l_cmd.CommandText = "DELETE FROM catUsuarios WHERE clogin = ?";

            l_cmd.Parameters.AddWithValue("@clogin", this.txt_login.Text);

            try
            {
                l_conn.Open();

                //Guardar...
                l_cmd.ExecuteNonQuery();

                MessageBox.Show("Usuario " + this.txt_nombre.Text + " eliminado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

                l_conn.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();
            }
        }

        private void cmd_add_Click(object sender, EventArgs e)
        {
            this.txt_nombre.Text = "";
            this.txt_login.Text = "";
            this.txt_clave1.Text = "";
            this.txt_clave2.Text = "";
            this.cmb_acceso.SelectedIndex = 1;
            this.cmb_Almacen.SelectedIndex = 0;
            this.txt_nombre.Focus();
        }

        private void cmb_acceso_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

	}
}
