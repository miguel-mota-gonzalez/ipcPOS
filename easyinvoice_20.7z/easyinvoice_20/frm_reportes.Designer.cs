/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/27/2007
 * Time: 12:59 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class frm_reportes
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_reportes));
            this.dp_desde = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dp_hasta = new System.Windows.Forms.DateTimePicker();
            this.rb_facturas = new System.Windows.Forms.RadioButton();
            this.rb_facturasporcliente = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_clients = new System.Windows.Forms.ListBox();
            this.cmd_ok = new System.Windows.Forms.Button();
            this.cmd_cancel = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog2 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.chk_canceladas = new System.Windows.Forms.CheckBox();
            this.chk_notas = new System.Windows.Forms.CheckBox();
            this.rb_entradas = new System.Windows.Forms.RadioButton();
            this.printDocument3 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog3 = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // dp_desde
            // 
            this.dp_desde.CustomFormat = "dd/MM/yyyy";
            this.dp_desde.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dp_desde.Location = new System.Drawing.Point(34, 103);
            this.dp_desde.Name = "dp_desde";
            this.dp_desde.Size = new System.Drawing.Size(136, 20);
            this.dp_desde.TabIndex = 0;
            this.dp_desde.Value = new System.DateTime(2007, 1, 1, 0, 0, 0, 0);
            this.dp_desde.ValueChanged += new System.EventHandler(this.Dp_desdeValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Desde";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Hasta";
            // 
            // dp_hasta
            // 
            this.dp_hasta.CustomFormat = "dd/MM/yyyy";
            this.dp_hasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dp_hasta.Location = new System.Drawing.Point(34, 143);
            this.dp_hasta.Name = "dp_hasta";
            this.dp_hasta.Size = new System.Drawing.Size(136, 20);
            this.dp_hasta.TabIndex = 2;
            this.dp_hasta.Value = new System.DateTime(2007, 1, 1, 0, 0, 0, 0);
            // 
            // rb_facturas
            // 
            this.rb_facturas.AutoSize = true;
            this.rb_facturas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_facturas.Location = new System.Drawing.Point(34, 29);
            this.rb_facturas.Name = "rb_facturas";
            this.rb_facturas.Size = new System.Drawing.Size(74, 17);
            this.rb_facturas.TabIndex = 4;
            this.rb_facturas.TabStop = true;
            this.rb_facturas.Text = "Facturas";
            this.rb_facturas.UseVisualStyleBackColor = true;
            // 
            // rb_facturasporcliente
            // 
            this.rb_facturasporcliente.AutoSize = true;
            this.rb_facturasporcliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_facturasporcliente.Location = new System.Drawing.Point(34, 52);
            this.rb_facturasporcliente.Name = "rb_facturasporcliente";
            this.rb_facturasporcliente.Size = new System.Drawing.Size(138, 17);
            this.rb_facturasporcliente.TabIndex = 5;
            this.rb_facturasporcliente.TabStop = true;
            this.rb_facturasporcliente.Text = "Facturas por cliente";
            this.rb_facturasporcliente.UseVisualStyleBackColor = true;
            this.rb_facturasporcliente.CheckedChanged += new System.EventHandler(this.Rb_facturasporclienteCheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Clientes";
            // 
            // lb_clients
            // 
            this.lb_clients.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_clients.FormattingEnabled = true;
            this.lb_clients.Location = new System.Drawing.Point(34, 196);
            this.lb_clients.Name = "lb_clients";
            this.lb_clients.Size = new System.Drawing.Size(312, 95);
            this.lb_clients.Sorted = true;
            this.lb_clients.TabIndex = 7;
            // 
            // cmd_ok
            // 
            this.cmd_ok.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_ok.Location = new System.Drawing.Point(187, 308);
            this.cmd_ok.Name = "cmd_ok";
            this.cmd_ok.Size = new System.Drawing.Size(75, 23);
            this.cmd_ok.TabIndex = 8;
            this.cmd_ok.Text = "Abrir";
            this.cmd_ok.UseVisualStyleBackColor = true;
            this.cmd_ok.Click += new System.EventHandler(this.Cmd_okClick);
            // 
            // cmd_cancel
            // 
            this.cmd_cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_cancel.Location = new System.Drawing.Point(271, 308);
            this.cmd_cancel.Name = "cmd_cancel";
            this.cmd_cancel.Size = new System.Drawing.Size(75, 23);
            this.cmd_cancel.TabIndex = 9;
            this.cmd_cancel.Text = "Cancelar";
            this.cmd_cancel.UseVisualStyleBackColor = true;
            this.cmd_cancel.Click += new System.EventHandler(this.Cmd_cancelClick);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.DocumentName = "Reporte de Facturas";
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument1PrintPage);
            // 
            // printPreviewDialog2
            // 
            this.printPreviewDialog2.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog2.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog2.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog2.Document = this.printDocument2;
            this.printPreviewDialog2.Enabled = true;
            this.printPreviewDialog2.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog2.Icon")));
            this.printPreviewDialog2.Name = "printPreviewDialog2";
            this.printPreviewDialog2.Visible = false;
            // 
            // printDocument2
            // 
            this.printDocument2.DocumentName = "Reporte de Facturas por cliente";
            this.printDocument2.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument2PrintPage);
            // 
            // chk_canceladas
            // 
            this.chk_canceladas.Location = new System.Drawing.Point(195, 142);
            this.chk_canceladas.Name = "chk_canceladas";
            this.chk_canceladas.Size = new System.Drawing.Size(125, 21);
            this.chk_canceladas.TabIndex = 10;
            this.chk_canceladas.Text = "Solo Canceladas";
            this.chk_canceladas.UseVisualStyleBackColor = true;
            // 
            // chk_notas
            // 
            this.chk_notas.Location = new System.Drawing.Point(195, 166);
            this.chk_notas.Name = "chk_notas";
            this.chk_notas.Size = new System.Drawing.Size(188, 24);
            this.chk_notas.TabIndex = 11;
            this.chk_notas.Text = "Usar Notas en lugar de facturas";
            this.chk_notas.UseVisualStyleBackColor = true;
            // 
            // rb_entradas
            // 
            this.rb_entradas.AutoSize = true;
            this.rb_entradas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_entradas.Location = new System.Drawing.Point(195, 29);
            this.rb_entradas.Name = "rb_entradas";
            this.rb_entradas.Size = new System.Drawing.Size(145, 17);
            this.rb_entradas.TabIndex = 12;
            this.rb_entradas.TabStop = true;
            this.rb_entradas.Text = "Entradas de articulos";
            this.rb_entradas.UseVisualStyleBackColor = true;
            // 
            // printDocument3
            // 
            this.printDocument3.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument3PrintPage);
            // 
            // printPreviewDialog3
            // 
            this.printPreviewDialog3.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog3.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog3.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog3.Document = this.printDocument3;
            this.printPreviewDialog3.Enabled = true;
            this.printPreviewDialog3.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog3.Icon")));
            this.printPreviewDialog3.Name = "printPreviewDialog3";
            this.printPreviewDialog3.Visible = false;
            // 
            // frm_reportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(382, 343);
            this.Controls.Add(this.rb_entradas);
            this.Controls.Add(this.chk_notas);
            this.Controls.Add(this.chk_canceladas);
            this.Controls.Add(this.cmd_cancel);
            this.Controls.Add(this.cmd_ok);
            this.Controls.Add(this.lb_clients);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rb_facturasporcliente);
            this.Controls.Add(this.rb_facturas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dp_hasta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dp_desde);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_reportes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reportes";
            this.Load += new System.EventHandler(this.Frm_reportesLoad);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Frm_reportesKeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog3;
		private System.Drawing.Printing.PrintDocument printDocument3;
		private System.Windows.Forms.RadioButton rb_entradas;
		private System.Windows.Forms.CheckBox chk_notas;
		private System.Windows.Forms.CheckBox chk_canceladas;
		private System.Drawing.Printing.PrintDocument printDocument2;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog2;
		private System.Drawing.Printing.PrintDocument printDocument1;
		public System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
		private System.Windows.Forms.RadioButton rb_facturasporcliente;
		private System.Windows.Forms.Button cmd_cancel;
		private System.Windows.Forms.Button cmd_ok;
		private System.Windows.Forms.ListBox lb_clients;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.RadioButton rb_facturas;
		private System.Windows.Forms.DateTimePicker dp_hasta;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DateTimePicker dp_desde;
	}
}
