﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyReports
{
    public enum enumReportOption
    {
        NONE=0,
        PEDIDO=1,
        FACTURA=2,
        TRASPASO=3
    }

    public class ReportAdmin
    {
        public enumReportOption ReportOption;
        public static string ConnectionString;
        public static string lastErrorString;

        public ReportAdmin()
        {
            ConnectionString = "";
            lastErrorString = "";
        }

        public Boolean setConnectionString(string strConn)
        {
            ConnectionString = strConn;
            return true;
        }

        public Boolean setReportOption(Int32 iReportOption)
        {
            try
            {
                ReportOption = (enumReportOption)iReportOption;
            }
            catch
            {
                ReportOption = enumReportOption.NONE;
            }
            return true;
        }

        public string GetlastErrorString()
        {
            return lastErrorString;
        }

        public Boolean invokeReport(Object[] parameters)
        {
            Boolean resul = true;
            //System.Windows.Forms.MessageBox.Show(ReportOption.ToString());
            clsRptPedido oRptPed = new clsRptPedido();
            oRptPed.ShowReport(parameters);

/*            switch(ReportOption)
            {
                case enumReportOption.PEDIDO:
                    clsRptPedido oRptPed = new clsRptPedido();
                    oRptPed.ShowReport(parameters);
                    break;
                case enumReportOption.TRASPASO:
                    clsRptPedido oRptTra = new clsRptPedido();
                    oRptTra.ShowReport(parameters);
                    break;
                default:
                    break;

            } 
 */
            return resul;
        }

    }
}
