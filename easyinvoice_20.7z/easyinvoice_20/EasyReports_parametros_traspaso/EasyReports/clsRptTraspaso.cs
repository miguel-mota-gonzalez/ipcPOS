﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyReports
{
    class clsRptTraspaso
    {
        public Boolean ShowReport(Object[] parameters)
        {
            System.Data.Odbc.OdbcConnection l_conn = null;
            System.Data.DataSet ds = new System.Data.DataSet();
            Boolean res = true;
            try
            {
                l_conn = new System.Data.Odbc.OdbcConnection();
                System.Data.Odbc.OdbcDataAdapter odbcAdapter = new System.Data.Odbc.OdbcDataAdapter();
                l_conn.ConnectionString = ReportAdmin.ConnectionString;
                l_conn.Open();
                odbcAdapter.SelectCommand = new System.Data.Odbc.OdbcCommand("SELECT * FROM catTraspasos WHERE idTraspaso = " + parameters[0].ToString(), l_conn);
                odbcAdapter.Fill(ds, "catTraspasos");
                odbcAdapter.SelectCommand = new System.Data.Odbc.OdbcCommand("SELECT * FROM detTraspasos WHERE idDetTraspaso = " + parameters[0].ToString(), l_conn);
                odbcAdapter.Fill(ds, "detTraspasos");
                CrystalDecisions.CrystalReports.Engine.ReportDocument lFormatoTraspaso = new CrystalDecisions.CrystalReports.Engine.ReportDocument();

                string reportPath = ".\\rptTraspaso.rpt";
                lFormatoTraspaso.Load(reportPath);
                lFormatoTraspaso.SetDataSource(ds);

                frmReporte frmRep = new frmReporte();
                frmRep.crystalReportViewer1.ReportSource = lFormatoTraspaso;
                //frmRep.crystalReportViewer1.;
                frmRep.Show();
                //System.Windows.Forms.MessageBox.Show("imprimiendo repte pedidos " + parameters[0].ToString());
            }
            catch (Exception ex)
            {
                ReportAdmin.lastErrorString = "rptTraspaso :" + ex.Message;
                res = false;
            }
            finally
            {
                if (l_conn != null)
                    l_conn.Close();
            }
            return res;
        }
    }
}
