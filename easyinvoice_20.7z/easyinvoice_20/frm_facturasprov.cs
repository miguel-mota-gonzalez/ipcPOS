/*
 * Created by SharpDevelop.
 * User: juan.mota
 * Date: 30/04/2007
 * Time: 12:55 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_facturasprov.
	/// </summary>
	public partial class frm_facturasprov
	{
        private System.Data.DataSet m_dataset;
        public int mp_int_KeyRecord = -1;
        private System.Windows.Forms.BindingSource mp_bs;

		public frm_facturasprov()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			//
		}

        private void frm_facturasprov_Load(object sender, EventArgs e)
        {
            this.FillDataset();
        }

        private void FillDataset()
        {
            try
            {
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                if (this.mp_bs != null)
                    this.mp_bs.Dispose();

                this.mp_bs = new BindingSource();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "SELECT IdcatFacturaProv,Numero,Fecha,TotalFactura,Pagado, 0.0 as Saldo FROM catFacturasProv WHERE IdProveedor = " + this.mp_int_KeyRecord.ToString() + " ORDER BY Fecha DESC";
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "facturas";
                this.mp_bs.DataSource = null;
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;
                
                this.dataGridView1.Columns[0].Visible = false;               

                foreach (DataGridViewRow l_row in this.dataGridView1.Rows)
                {
                    double l_total;
                    double l_pagado;
                    double l_saldo;

                    l_total = Convert.ToDouble(l_row.Cells["TotalFactura"].Value);
                    l_pagado = Convert.ToDouble(l_row.Cells["Pagado"].Value);

                    l_saldo = l_total - l_pagado;

                    l_row.Cells["Saldo"].Value = l_saldo.ToString();

                    if (l_saldo > 0)
                    {
                        l_row.Cells["Saldo"].Style.ForeColor = Color.Red;
                    }
                    else 
                    {
                        l_row.Cells["Saldo"].Style.ForeColor = Color.Blue;
                    }
                }
                
            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmd_cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_facturasprov_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    this.Close();
                    break;
                case Keys.F2:
                    //Agregar una factura
                    frm_nuevafactprv l_frm = new frm_nuevafactprv();
                    l_frm.mp_int32_KeyRecord = this.mp_int_KeyRecord;
                    if (l_frm.ShowDialog() == DialogResult.OK)
                    {
                        this.FillDataset();
                        this.dataGridView1.Refresh();
                    }
                    break;
                case Keys.F3:
                    //Editar el saldo....
                    this.ll_modificar_LinkClicked(sender, null);
                    break;
                case Keys.Delete:
                    //Eliminar la factura...
                   this.ll_eliminar_LinkClicked(sender, null);
                    break;
            }
        }

        private void ll_agregar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frm_nuevafactprv l_frm = new frm_nuevafactprv();
            l_frm.mp_int32_KeyRecord = this.mp_int_KeyRecord;
            if (l_frm.ShowDialog() == DialogResult.OK)
            {
                this.FillDataset();
                this.dataGridView1.Refresh();
            }
        }

        private void ll_modificar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        	frm_nuevopago l_frm = new frm_nuevopago();
            l_frm.Folio = "";
            l_frm.radioButton1.Visible = false;
            l_frm.radioButton2.Visible = false;
            l_frm.Text = "Pago a proveedor";
        	l_frm.BackColor = Color.LightSteelBlue;
        	l_frm.Text = "Nuevo valor";
        	
        	if(l_frm.ShowDialog() == DialogResult.OK)
        	{
	        	if(this.dataGridView1.SelectedRows.Count < 1)
	        		return;
	        					
	            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
	
	            try
	            {
                    l_conn.ConnectionString = frm_Main.mps_strconnection;
	                l_conn.Open();
	
	                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
	                l_cmd.Connection = l_conn;
	                l_cmd.CommandText = "UPDATE catFacturasProv SET Pagado = " + Convert.ToDouble(l_frm.txtCantidad.Text).ToString() + " WHERE IdcatFacturaProv = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
	
	                l_cmd.ExecuteNonQuery();
	
	            }
	            catch (System.Data.OleDb.OleDbException ex)
	            {
	                MessageBox.Show("Error al modificar la factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
	            }
	            catch (System.Exception ex)
	            {
	                MessageBox.Show("Error al modificar la factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
	            }
	            finally
	            {
	            	if( l_conn.State == System.Data.ConnectionState.Open )
	            		l_conn.Close();
	            	
	            	this.FillDataset();
	            }						        		
        	}
        	
        }

        private void ll_eliminar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        	
        	if(this.dataGridView1.SelectedRows.Count < 1)
        		return;
        	
			if( MessageBox.Show("Esta a punto de eliminar la factura seleccionada �Confirma que desea continuar?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;
			
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();

            try
            {
                l_conn.ConnectionString = frm_Main.mps_strconnection;
                l_conn.Open();

                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = l_conn;
                l_cmd.CommandText = "DELETE FROM catFacturasProv WHERE IdcatFacturaProv = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                l_cmd.ExecuteNonQuery();

                l_cmd.CommandText = "DELETE FROM detFacturasProv WHERE IdcatFacturaProv = " + this.dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                l_cmd.ExecuteNonQuery();

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show("Error al eliminar la factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al eliminar la factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            	if( l_conn.State == System.Data.ConnectionState.Open )
            		l_conn.Close();
            	
            	this.FillDataset();
            }						
			
        }

	}
}
