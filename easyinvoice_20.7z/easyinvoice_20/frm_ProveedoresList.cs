using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_ProveedoresList.
	/// </summary>
	public class frm_ProveedoresList : System.Windows.Forms.Form
    {
        public System.Int32 m_KeyRecord=-1;
        public string m_provName="";
        private System.Data.DataSet m_dataset;
        public Button cmd_nuevo;
		private System.Windows.Forms.Label lbl_curcel;
        private DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        private ToolBar toolBar1;
        private ToolBarButton toolBarButton1;
        private ToolBarButton toolBarButton2;
        private ToolBarButton toolBarButton3;
        private ToolBarButton toolBarButton4;
        private ToolBarButton toolBarButton5;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private ComboBox cmb_criterios;
        private TextBox txt_criterio;
        private ToolBarButton toolBarButton6;
        private IContainer components;

        public Int32 p_Result;
        public Int32 p_currentId;

		public frm_ProveedoresList()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_ProveedoresList));
            this.cmd_nuevo = new System.Windows.Forms.Button();
            this.lbl_curcel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolBar1 = new System.Windows.Forms.ToolBar();
            this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton6 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_criterios = new System.Windows.Forms.ComboBox();
            this.txt_criterio = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmd_nuevo
            // 
            this.cmd_nuevo.Location = new System.Drawing.Point(63, 126);
            this.cmd_nuevo.Name = "cmd_nuevo";
            this.cmd_nuevo.Size = new System.Drawing.Size(112, 23);
            this.cmd_nuevo.TabIndex = 0;
            this.cmd_nuevo.Text = "Nuevo Proveedor";
            this.cmd_nuevo.Visible = false;
            this.cmd_nuevo.Click += new System.EventHandler(this.cmd_nuevo_Click);
            // 
            // lbl_curcel
            // 
            this.lbl_curcel.Location = new System.Drawing.Point(600, 8);
            this.lbl_curcel.Name = "lbl_curcel";
            this.lbl_curcel.Size = new System.Drawing.Size(64, 24);
            this.lbl_curcel.TabIndex = 6;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(-2, 51);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(810, 421);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            this.dataGridView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView1_KeyDown);
            // 
            // toolBar1
            // 
            this.toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.toolBarButton1,
            this.toolBarButton2,
            this.toolBarButton3,
            this.toolBarButton6,
            this.toolBarButton4,
            this.toolBarButton5});
            this.toolBar1.DropDownArrows = true;
            this.toolBar1.ImageList = this.imageList1;
            this.toolBar1.Location = new System.Drawing.Point(0, 0);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.ShowToolTips = true;
            this.toolBar1.Size = new System.Drawing.Size(808, 50);
            this.toolBar1.TabIndex = 8;
            this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // toolBarButton1
            // 
            this.toolBarButton1.ImageIndex = 0;
            this.toolBarButton1.Name = "toolBarButton1";
            this.toolBarButton1.Text = "Agregar";
            this.toolBarButton1.ToolTipText = "Agregar un nuevo proveedor";
            // 
            // toolBarButton2
            // 
            this.toolBarButton2.ImageIndex = 1;
            this.toolBarButton2.Name = "toolBarButton2";
            this.toolBarButton2.Text = "Editar";
            this.toolBarButton2.ToolTipText = "Editar el proveedor seleccionado de ls lista...";
            // 
            // toolBarButton3
            // 
            this.toolBarButton3.ImageIndex = 2;
            this.toolBarButton3.Name = "toolBarButton3";
            this.toolBarButton3.Text = "Actualizar";
            this.toolBarButton3.ToolTipText = "Actualizar la lista de proveedores...";
            // 
            // toolBarButton6
            // 
            this.toolBarButton6.ImageIndex = 4;
            this.toolBarButton6.Name = "toolBarButton6";
            this.toolBarButton6.Text = "Ver Facturas";
            this.toolBarButton6.ToolTipText = "Ver la lista de facturas relativas al proveedor seleccionado...";
            // 
            // toolBarButton4
            // 
            this.toolBarButton4.ImageIndex = 3;
            this.toolBarButton4.Name = "toolBarButton4";
            this.toolBarButton4.Text = "Cerrar";
            this.toolBarButton4.ToolTipText = "Cerrar esta ventana...";
            // 
            // toolBarButton5
            // 
            this.toolBarButton5.Name = "toolBarButton5";
            this.toolBarButton5.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "user1_add.ico");
            this.imageList1.Images.SetKeyName(1, "user1_view.ico");
            this.imageList1.Images.SetKeyName(2, "user1_refresh.ico");
            this.imageList1.Images.SetKeyName(3, "exit.ico");
            this.imageList1.Images.SetKeyName(4, "Folder.ico");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(289, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(529, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "criterio:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(321, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 18;
            this.label1.Text = "Buscar por";
            // 
            // cmb_criterios
            // 
            this.cmb_criterios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_criterios.Location = new System.Drawing.Point(393, 12);
            this.cmb_criterios.Name = "cmb_criterios";
            this.cmb_criterios.Size = new System.Drawing.Size(121, 21);
            this.cmb_criterios.TabIndex = 2;
            // 
            // txt_criterio
            // 
            this.txt_criterio.Location = new System.Drawing.Point(585, 12);
            this.txt_criterio.Name = "txt_criterio";
            this.txt_criterio.Size = new System.Drawing.Size(211, 20);
            this.txt_criterio.TabIndex = 0;
            this.txt_criterio.TextChanged += new System.EventHandler(this.txt_criterio_TextChanged);
            this.txt_criterio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_criterio_KeyDown);
            // 
            // frm_ProveedoresList
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(808, 470);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_criterios);
            this.Controls.Add(this.txt_criterio);
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbl_curcel);
            this.Controls.Add(this.cmd_nuevo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_ProveedoresList";
            this.Text = "Lista de Proveedores";
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_ProveedoresList_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
            this.FillDataset();

            if (m_dataset.Tables.Count > 0)
            {

                foreach (System.Data.DataColumn l_col in m_dataset.Tables[0].Columns)
                {
                    if (l_col.DataType.Name == "String")
                        this.cmb_criterios.Items.Add(l_col.ColumnName);
                }

                this.cmb_criterios.Text = "Nombre";

                this.dataGridView1.Columns[1].Width = 150;
                this.dataGridView1.Columns[2].Width = 150;

                this.dataGridView1.Columns[5].Visible = false;
                this.dataGridView1.Columns[6].Visible = false;
                this.dataGridView1.Columns[8].Visible = false;
                this.dataGridView1.Columns[9].Visible = false;
            }

            if (EasyInvoice.frm_Main.mps_strcatalogsnoaccess.Contains("PROVEEDORES") || frm_Main.mps_acceso != "Administrador")
            {
                this.toolBar1.Buttons[0].Visible = false;
                //this.toolBar1.Buttons[1].Visible = false;
            }

		}

		private void cmd_nuevo_Click(object sender, System.EventArgs e)
		{

		}

		private void FillDataset()	
		{
            try
            {
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "SELECT * FROM catProveedores ORDER BY Nombre;";
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "proveedores";
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_criterio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }        	
        }

        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {
            switch (e.Button.Text)
            {
                case "Agregar":
                    /*
                    frm_Proveedores l_frm = new frm_Proveedores();
                    l_frm.ShowDialog();
                    this.FillDataset();
                     */
                    this.LoadProveedor(-1);
                    break;
                case "Editar":
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        /*
                        frm_Proveedores l_frm1 = new frm_Proveedores(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                        l_frm1.ShowDialog();
                        this.FillDataset();                        
                         */
                        this.LoadProveedor(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    }
                    break;
                case "Actualizar":
                    this.FillDataset();
                    break;
                case "Cerrar":
                    this.Close();
                    break;
                case "Ver Facturas":
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
			        	frm_facturasprov l_frm1 = new frm_facturasprov();
			
			            l_frm1.mp_int_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
			            l_frm1.label1.Text = "Facturas de : " + this.dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
			
			        	l_frm1.ShowDialog();                    
                    }
                    break;

            }
        }

        private void txt_criterio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                this.dataGridView1.Focus();
        }

        private void frm_ProveedoresList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmd_nuevo.Enabled == true)
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        /*
                        frm_Proveedores l_frm1 = new frm_Proveedores(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                        l_frm1.ShowDialog();
                        this.FillDataset();
                         */
                        this.LoadProveedor(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value)); 
                    }
                }
                else
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                        this.m_provName = Convert.ToString(this.dataGridView1.SelectedRows[0].Cells["Nombre"].Value);
                        this.Close();
                    }
                }
            }

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.cmd_nuevo.Enabled == true)
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    /*
                    frm_Proveedores l_frm1 = new frm_Proveedores(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    l_frm1.ShowDialog();
                    this.FillDataset();
                     */
                    this.LoadProveedor(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                }
            }
            else
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                    this.m_provName = Convert.ToString(this.dataGridView1.SelectedRows[0].Cells["Nombre"].Value);
                    this.Close();
                }
            }

        }

        void LoadProveedor(Int32 pID)
        {
            frm_Proveedores l_frm1;

            if (pID<=0 && (EasyInvoice.frm_Main.mps_strcatalogsnoaccess.Contains("PROVEEDORES") || frm_Main.mps_acceso != "Administrador"))
            {
                return;
            }


            if (pID > 0)
                l_frm1 = new frm_Proveedores(pID);
            else
                l_frm1 = new frm_Proveedores();

            l_frm1.frm_ProvPrin = this;
            l_frm1.ShowDialog();
            if (this.p_Result == 1)
            {
                this.FillDataset();
                if (this.p_currentId > 0)
                {
                    foreach (DataGridViewRow row in this.dataGridView1.Rows)
                    {
                        if ((Int32)row.Cells[0].Value == this.p_currentId)
                        {
                            row.Selected = true;
                            OnScroll(new ScrollEventArgs(ScrollEventType.LargeIncrement, row.Index));
                            this.dataGridView1.SelectedRows[0].Cells[1].Selected = true;
                            break;
                        }
                    }
                }
            }

        }
		
	}
}
