﻿namespace EasyInvoice
{
    partial class frm_AgruparEnvios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_arqueo));
            this.mp_pdarqueo = new System.Drawing.Printing.PrintDocument();
            this.mp_ppvw = new System.Windows.Forms.PrintPreviewDialog();
            this.cmd_close = new System.Windows.Forms.Button();
            this.txt_arqueo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // mp_ppvw
            // 
            this.mp_ppvw.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.mp_ppvw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.mp_ppvw.ClientSize = new System.Drawing.Size(400, 300);
            this.mp_ppvw.Document = this.mp_pdarqueo;
            this.mp_ppvw.Enabled = true;
            this.mp_ppvw.Icon = ((System.Drawing.Icon)(resources.GetObject("mp_ppvw.Icon")));
            this.mp_ppvw.Name = "mp_ppvw";
            this.mp_ppvw.ShowIcon = false;
            this.mp_ppvw.Visible = false;
            // 
            // cmd_close
            // 
            this.cmd_close.Image = global::EasyInvoice.Properties.Resources.exit;
            this.cmd_close.Location = new System.Drawing.Point(365, 256);
            this.cmd_close.Name = "cmd_close";
            this.cmd_close.Size = new System.Drawing.Size(79, 23);
            this.cmd_close.TabIndex = 1;
            this.cmd_close.Text = "Cerrar";
            this.cmd_close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_close.UseVisualStyleBackColor = true;
            this.cmd_close.Click += new System.EventHandler(this.cmd_close_Click);
            // 
            // txt_arqueo
            // 
            this.txt_arqueo.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_arqueo.Location = new System.Drawing.Point(11, 12);
            this.txt_arqueo.Multiline = true;
            this.txt_arqueo.Name = "txt_arqueo";
            this.txt_arqueo.Size = new System.Drawing.Size(433, 235);
            this.txt_arqueo.TabIndex = 2;
            // 
            // frm_arqueo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(456, 291);
            this.Controls.Add(this.txt_arqueo);
            this.Controls.Add(this.cmd_close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_AgruparEnvios";
            this.Text = "Agrupar Envíos";
            this.Load += new System.EventHandler(this.frm_arqueo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmd_close;
        private System.Drawing.Printing.PrintDocument mp_pdarqueo;
        private System.Windows.Forms.PrintPreviewDialog mp_ppvw;
        private System.Windows.Forms.TextBox txt_arqueo;
    }
}