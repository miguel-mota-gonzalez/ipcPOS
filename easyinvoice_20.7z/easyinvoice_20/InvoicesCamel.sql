/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50141
Source Host           : localhost:3306
Source Database       : Invoices

Target Server Type    : MYSQL
Target Server Version : 50141
File Encoding         : 65001

Date: 2011-02-03 00:28:36
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `catCaja`
-- ----------------------------
DROP TABLE IF EXISTS `catCaja`;
CREATE TABLE `catCaja` (
  `iidcaja` int(11) NOT NULL AUTO_INCREMENT,
  `dtfecha` datetime DEFAULT NULL,
  `iimporte` float DEFAULT '0',
  `clogin` varchar(50) DEFAULT NULL,
  `entrada` int(1) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`iidcaja`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catCaja
-- ----------------------------
INSERT INTO `catCaja` VALUES ('1', '2010-11-25 21:51:28', '1500', 'mikem', '1', 'inicial');
INSERT INTO `catCaja` VALUES ('2', '2010-11-25 21:51:28', '-200', 'mikem', '0', 'retiro');
INSERT INTO `catCaja` VALUES ('3', '2010-11-25 22:43:22', '8.98', 'mikem', '1', 'Nota número : 22');
INSERT INTO `catCaja` VALUES ('4', '2010-11-25 22:44:41', '2', 'mikem', '1', 'Nota número : 22');
INSERT INTO `catCaja` VALUES ('5', '2010-11-25 22:44:57', '-2', 'mikem', '1', 'Nota número : 22');

-- ----------------------------
-- Table structure for `catClientes`
-- ----------------------------
DROP TABLE IF EXISTS `catClientes`;
CREATE TABLE `catClientes` (
  `IdCliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) DEFAULT NULL,
  `Direccion` varchar(50) DEFAULT NULL,
  `Fax` varchar(50) DEFAULT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `RFC` varchar(64) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `CURP` varchar(64) DEFAULT NULL,
  `Calle` varchar(64) DEFAULT NULL,
  `Numero` varchar(16) DEFAULT NULL,
  `NumeroInt` varchar(16) DEFAULT NULL,
  `Colonia` varchar(128) DEFAULT NULL,
  `Referencia` varchar(256) DEFAULT NULL,
  `Municipio` varchar(128) DEFAULT NULL,
  `Estado` varchar(128) DEFAULT NULL,
  `Pais` varchar(128) DEFAULT NULL,
  `CodigoPostal` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`IdCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catClientes
-- ----------------------------
INSERT INTO `catClientes` VALUES ('1', 'CLIENTE DE MOSTRADOR', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'MOGJ010101', '2010-09-27 15:44:47', 'NINGUNO', '', 'NINGUNO', 'MOGJ010101', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO', 'NINGUNO');
INSERT INTO `catClientes` VALUES ('2', 'JUAN MIGUEL MOTA GONZALEZ', 'Calle 23 Numero 329 Entre 38 y 40 Sodzil Norte', '9991671111', '9991671111', 'MOGJ760131AB', '2010-09-30 00:00:00', 'mike.mota@gmail.com', 'Ricardo Peraza', 'Merida', 'MOGJ760131AB', '23', '329', '', 'Sodzil Norte', '', 'Merida', 'Yucatan', 'Mexico', '97117');

-- ----------------------------
-- Table structure for `catConsolidacionFactura`
-- ----------------------------
DROP TABLE IF EXISTS `catConsolidacionFactura`;
CREATE TABLE `catConsolidacionFactura` (
  `iidconsolidacion` int(11) NOT NULL AUTO_INCREMENT,
  `iidfactura` int(11) NOT NULL,
  PRIMARY KEY (`iidconsolidacion`,`iidfactura`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catConsolidacionFactura
-- ----------------------------
INSERT INTO `catConsolidacionFactura` VALUES ('14', '122');

-- ----------------------------
-- Table structure for `catCorte`
-- ----------------------------
DROP TABLE IF EXISTS `catCorte`;
CREATE TABLE `catCorte` (
  `iidCorte` int(11) NOT NULL AUTO_INCREMENT,
  `dtFecha` datetime DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `cusuario` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`iidCorte`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catCorte
-- ----------------------------
INSERT INTO `catCorte` VALUES ('23', '2010-09-28 10:18:10', '185.71', 'mikem');
INSERT INTO `catCorte` VALUES ('24', '2010-09-28 10:31:48', '6.32', 'mikem');
INSERT INTO `catCorte` VALUES ('25', '2010-09-28 10:32:32', '26.45', 'mikem');
INSERT INTO `catCorte` VALUES ('26', '2010-09-28 15:16:22', '7693.5', 'mikem');
INSERT INTO `catCorte` VALUES ('27', '2010-09-29 08:46:28', '1323.08', 'mikem');
INSERT INTO `catCorte` VALUES ('28', '2010-10-04 16:30:12', '2020.56', 'mikem');
INSERT INTO `catCorte` VALUES ('29', '2010-11-20 10:25:39', '1051.64', 'mikem');
INSERT INTO `catCorte` VALUES ('30', '2011-01-18 22:12:39', '1584.19', 'mikem');
INSERT INTO `catCorte` VALUES ('31', '2011-01-18 22:42:08', '1538.38', 'mikem');

-- ----------------------------
-- Table structure for `catentradas`
-- ----------------------------
DROP TABLE IF EXISTS `catentradas`;
CREATE TABLE `catentradas` (
  `iidEntrada` int(11) NOT NULL AUTO_INCREMENT,
  `ccodigo` varchar(64) DEFAULT NULL,
  `dtfecha` datetime DEFAULT NULL,
  `cdescripcion` varchar(255) DEFAULT NULL,
  `icantidad` float DEFAULT NULL,
  `iimporte` float DEFAULT '0',
  `clogin` varchar(50) DEFAULT NULL,
  `entrada` int(1) DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`iidEntrada`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catentradas
-- ----------------------------
INSERT INTO `catentradas` VALUES ('1', '0001', '2010-09-27 15:09:22', 'Articulo 1', '10000', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('4', '0001', '2010-09-27 15:54:01', 'Articulo 1', '-4', '0', 'mikem', '0', 'FAC 4');
INSERT INTO `catentradas` VALUES ('5', '0001', '2010-09-27 16:06:58', 'Articulo 1', '-6', '0', 'mikem', '0', 'FAC 5');
INSERT INTO `catentradas` VALUES ('6', '0001', '2010-09-27 16:13:41', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 2');
INSERT INTO `catentradas` VALUES ('7', '0001', '2010-09-27 16:31:17', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 6');
INSERT INTO `catentradas` VALUES ('8', '0001', '2010-09-27 16:32:45', 'Articulo 1', '-3', '0', 'mikem', '0', 'FAC 7');
INSERT INTO `catentradas` VALUES ('9', '0001', '2010-09-27 16:33:43', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 8');
INSERT INTO `catentradas` VALUES ('10', '0001', '2010-09-27 16:47:11', 'Articulo 1', '1', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('11', '0001', '2010-09-27 16:47:33', 'Articulo 1', '1', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('12', '0001', '2010-09-27 21:27:28', 'Articulo 1', '1', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('13', '0002', '2010-09-27 21:38:16', 'Producto 2', '1000', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('15', '0001', '2010-09-27 23:58:55', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 18');
INSERT INTO `catentradas` VALUES ('16', '0002', '2010-09-27 23:58:55', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 18');
INSERT INTO `catentradas` VALUES ('17', '0001', '2010-09-27 23:59:34', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 3');
INSERT INTO `catentradas` VALUES ('18', '0001', '2010-09-28 00:24:51', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 19');
INSERT INTO `catentradas` VALUES ('19', '0001', '2010-09-28 00:26:12', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 4');
INSERT INTO `catentradas` VALUES ('20', '0001', '2010-09-28 09:00:40', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 20');
INSERT INTO `catentradas` VALUES ('21', '0002', '2010-09-28 09:00:40', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 20');
INSERT INTO `catentradas` VALUES ('22', '0001', '2010-09-28 10:31:22', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 21');
INSERT INTO `catentradas` VALUES ('23', '0002', '2010-09-28 10:32:04', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 5');
INSERT INTO `catentradas` VALUES ('24', '0001', '2010-09-28 11:16:15', 'Articulo 1', '-40', '0', 'mikem', '0', 'FAC 22');
INSERT INTO `catentradas` VALUES ('25', '0002', '2010-09-28 11:16:15', 'Producto 2', '-200', '0', 'mikem', '0', 'FAC 22');
INSERT INTO `catentradas` VALUES ('26', '0001', '2010-09-28 11:34:18', 'Articulo 1', '-100', '0', 'mikem', '0', 'FAC 23');
INSERT INTO `catentradas` VALUES ('27', '0002', '2010-09-28 11:34:18', 'Producto 2', '-50', '0', 'mikem', '0', 'FAC 23');
INSERT INTO `catentradas` VALUES ('28', '0001', '2010-09-28 11:38:44', 'Articulo 1', '-10', '0', 'mikem', '0', 'FAC 24');
INSERT INTO `catentradas` VALUES ('29', '0002', '2010-09-28 11:38:44', 'Producto 2', '-5', '0', 'mikem', '0', 'FAC 24');
INSERT INTO `catentradas` VALUES ('30', '0001', '2010-09-28 12:20:37', 'Articulo 1', '1', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('31', '0001', '2010-09-28 12:20:37', 'Articulo 1', '500', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('32', '0001', '2010-09-28 15:29:20', 'Articulo 1', '-5', '0', 'mikem', '0', 'NOT 6');
INSERT INTO `catentradas` VALUES ('33', '0002', '2010-09-28 15:29:20', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 6');
INSERT INTO `catentradas` VALUES ('34', '0003', '2010-09-29 08:45:10', 'Producto numero 3', '5000', '0', 'mikem', '1', '');
INSERT INTO `catentradas` VALUES ('35', '0003', '2010-09-29 08:45:42', 'Producto numero 3', '-20', '0', 'mikem', '0', 'FAC 25');
INSERT INTO `catentradas` VALUES ('41', '0002', '2010-09-30 15:12:15', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 27');
INSERT INTO `catentradas` VALUES ('42', '0002', '2010-09-30 15:15:31', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 11');
INSERT INTO `catentradas` VALUES ('43', '0001', '2010-09-30 15:15:51', 'Articulo 1', '-50', '0', 'mikem', '0', 'FAC 28');
INSERT INTO `catentradas` VALUES ('44', '0002', '2010-09-30 15:15:51', 'Producto 2', '-100', '0', 'mikem', '0', 'FAC 28');
INSERT INTO `catentradas` VALUES ('45', '0001', '2010-09-30 15:20:40', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 29');
INSERT INTO `catentradas` VALUES ('46', '0002', '2010-09-30 15:20:40', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 29');
INSERT INTO `catentradas` VALUES ('47', '0001', '2010-09-30 15:21:06', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 30');
INSERT INTO `catentradas` VALUES ('48', '0002', '2010-09-30 15:21:06', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 30');
INSERT INTO `catentradas` VALUES ('49', '0001', '2010-09-30 15:22:43', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 31');
INSERT INTO `catentradas` VALUES ('50', '0002', '2010-09-30 15:22:43', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 31');
INSERT INTO `catentradas` VALUES ('51', '0001', '2010-09-30 15:27:29', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 32');
INSERT INTO `catentradas` VALUES ('52', '0002', '2010-09-30 15:27:29', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 32');
INSERT INTO `catentradas` VALUES ('53', '0001', '2010-09-30 15:29:38', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 33');
INSERT INTO `catentradas` VALUES ('54', '0002', '2010-09-30 15:29:38', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 33');
INSERT INTO `catentradas` VALUES ('55', '0001', '2010-09-30 15:33:35', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 34');
INSERT INTO `catentradas` VALUES ('56', '0002', '2010-09-30 15:33:35', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 34');
INSERT INTO `catentradas` VALUES ('57', '0001', '2010-09-30 15:47:04', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 35');
INSERT INTO `catentradas` VALUES ('58', '0002', '2010-09-30 15:47:04', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 35');
INSERT INTO `catentradas` VALUES ('59', '0001', '2010-09-30 15:49:51', 'Articulo 1', '-20', '0', 'mikem', '0', 'FAC 36');
INSERT INTO `catentradas` VALUES ('60', '0002', '2010-09-30 15:49:51', 'Producto 2', '-40', '0', 'mikem', '0', 'FAC 36');
INSERT INTO `catentradas` VALUES ('61', '0001', '2010-09-30 15:51:26', 'Articulo 1', '-20', '0', 'mikem', '0', 'FAC 37');
INSERT INTO `catentradas` VALUES ('62', '0002', '2010-09-30 15:51:26', 'Producto 2', '-15', '0', 'mikem', '0', 'FAC 37');
INSERT INTO `catentradas` VALUES ('63', '0001', '2010-09-30 16:06:53', 'Articulo 1', '-10', '0', 'mikem', '0', 'FAC 38');
INSERT INTO `catentradas` VALUES ('64', '0002', '2010-09-30 16:06:53', 'Producto 2', '-40', '0', 'mikem', '0', 'FAC 38');
INSERT INTO `catentradas` VALUES ('65', '0001', '2010-10-01 00:06:45', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 39');
INSERT INTO `catentradas` VALUES ('66', '0002', '2010-10-01 00:06:45', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 39');
INSERT INTO `catentradas` VALUES ('67', '0001', '2010-10-01 14:39:02', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 12');
INSERT INTO `catentradas` VALUES ('68', '0002', '2010-10-01 14:39:02', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 12');
INSERT INTO `catentradas` VALUES ('69', '0001', '2010-10-01 14:42:43', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 13');
INSERT INTO `catentradas` VALUES ('70', '0001', '2010-10-01 22:11:36', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 14');
INSERT INTO `catentradas` VALUES ('71', '0002', '2010-10-01 22:29:20', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 40');
INSERT INTO `catentradas` VALUES ('72', '0001', '2010-10-01 22:29:20', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 40');
INSERT INTO `catentradas` VALUES ('84', '0001', '2010-10-04 11:03:52', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 49');
INSERT INTO `catentradas` VALUES ('85', '0002', '2010-10-04 11:03:52', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 49');
INSERT INTO `catentradas` VALUES ('86', '0001', '2010-10-04 11:13:35', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 50');
INSERT INTO `catentradas` VALUES ('87', '0002', '2010-10-04 11:13:35', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 50');
INSERT INTO `catentradas` VALUES ('88', '0001', '2010-10-04 11:29:50', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 51');
INSERT INTO `catentradas` VALUES ('89', '0002', '2010-10-04 11:29:50', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 51');
INSERT INTO `catentradas` VALUES ('90', '0001', '2010-10-04 11:55:28', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 52');
INSERT INTO `catentradas` VALUES ('91', '0002', '2010-10-04 11:55:28', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 52');
INSERT INTO `catentradas` VALUES ('92', '0001', '2010-10-04 12:05:15', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 53');
INSERT INTO `catentradas` VALUES ('93', '0002', '2010-10-04 12:05:15', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 53');
INSERT INTO `catentradas` VALUES ('94', '0001', '2010-10-04 12:06:37', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 54');
INSERT INTO `catentradas` VALUES ('95', '0001', '2010-10-04 12:11:30', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 55');
INSERT INTO `catentradas` VALUES ('96', '0001', '2010-10-04 12:16:00', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 58');
INSERT INTO `catentradas` VALUES ('97', '0002', '2010-10-04 12:16:00', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 58');
INSERT INTO `catentradas` VALUES ('98', '0001', '2010-10-04 12:26:10', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 59');
INSERT INTO `catentradas` VALUES ('99', '0002', '2010-10-04 12:26:10', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 59');
INSERT INTO `catentradas` VALUES ('100', '0001', '2010-10-04 12:32:37', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 60');
INSERT INTO `catentradas` VALUES ('101', '0002', '2010-10-04 12:32:37', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 60');
INSERT INTO `catentradas` VALUES ('102', '0001', '2010-10-04 12:42:59', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 61');
INSERT INTO `catentradas` VALUES ('103', '0002', '2010-10-04 12:42:59', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 61');
INSERT INTO `catentradas` VALUES ('104', '0001', '2010-10-04 12:52:58', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 62');
INSERT INTO `catentradas` VALUES ('105', '0002', '2010-10-04 12:52:58', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 62');
INSERT INTO `catentradas` VALUES ('106', '0001', '2010-10-04 12:57:45', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 63');
INSERT INTO `catentradas` VALUES ('107', '0002', '2010-10-04 12:57:45', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 63');
INSERT INTO `catentradas` VALUES ('108', '0001', '2010-10-04 13:07:50', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 64');
INSERT INTO `catentradas` VALUES ('109', '0002', '2010-10-04 13:07:50', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 64');
INSERT INTO `catentradas` VALUES ('110', '0001', '2010-10-04 13:22:54', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 65');
INSERT INTO `catentradas` VALUES ('111', '0002', '2010-10-04 13:22:54', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 65');
INSERT INTO `catentradas` VALUES ('112', '0001', '2010-10-04 13:48:05', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 15');
INSERT INTO `catentradas` VALUES ('113', '0002', '2010-10-04 13:48:05', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 15');
INSERT INTO `catentradas` VALUES ('114', '0001', '2010-10-04 13:50:05', 'Articulo 1', '-10', '0', 'mikem', '0', 'NOT 16');
INSERT INTO `catentradas` VALUES ('115', '0002', '2010-10-04 13:50:05', 'Producto 2', '-50', '0', 'mikem', '0', 'NOT 16');
INSERT INTO `catentradas` VALUES ('116', '0001', '2010-10-04 13:51:25', 'Articulo 1', '-1', '0', 'mikem', '0', 'NOT 17');
INSERT INTO `catentradas` VALUES ('117', '0002', '2010-10-04 13:51:25', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 17');
INSERT INTO `catentradas` VALUES ('118', '0001', '2010-10-04 13:53:36', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 66');
INSERT INTO `catentradas` VALUES ('119', '0002', '2010-10-04 13:53:36', 'Producto 2', '-10', '0', 'mikem', '0', 'FAC 66');
INSERT INTO `catentradas` VALUES ('120', '0002', '2010-10-04 16:00:35', 'Producto 2', '-1', '0', 'mikem', '0', 'NOT 18');
INSERT INTO `catentradas` VALUES ('121', '0001', '2010-10-04 16:12:55', 'Articulo 1', '-100', '0', 'mikem', '0', 'FAC 67');
INSERT INTO `catentradas` VALUES ('122', '0002', '2010-10-04 16:12:55', 'Producto 2', '-50', '0', 'mikem', '0', 'FAC 67');
INSERT INTO `catentradas` VALUES ('123', '0001', '2010-10-04 16:32:01', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 68');
INSERT INTO `catentradas` VALUES ('124', '0002', '2010-10-04 16:32:01', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 68');
INSERT INTO `catentradas` VALUES ('125', '0003', '2010-10-04 16:32:01', 'Producto numero 3', '-1', '0', 'mikem', '0', 'FAC 68');
INSERT INTO `catentradas` VALUES ('126', 'AHACR', '2010-10-04 16:48:16', 'Amarillo Cromo Normal', '-1', '0', 'mikem', '0', 'FAC 69');
INSERT INTO `catentradas` VALUES ('127', 'AHPL', '2010-10-04 16:48:16', 'Plata Normal', '-1', '0', 'mikem', '0', 'FAC 69');
INSERT INTO `catentradas` VALUES ('128', 'AHRES', '2010-10-04 16:48:16', 'Rojo Escarlata Normal', '-1', '0', 'mikem', '0', 'FAC 69');
INSERT INTO `catentradas` VALUES ('129', 'FLVE', '2010-10-04 16:48:16', 'Verde Fluorescente', '-1', '0', 'mikem', '0', 'FAC 69');
INSERT INTO `catentradas` VALUES ('130', 'AHALI', '2010-10-04 17:03:25', 'Amarillo Limón Normal', '-1', '0', 'peraza', '0', 'FAC 70');
INSERT INTO `catentradas` VALUES ('131', 'AHPL', '2010-10-04 17:03:25', 'Plata Normal', '-0.5', '0', 'peraza', '0', 'FAC 70');
INSERT INTO `catentradas` VALUES ('132', 'AHBL', '2010-10-04 17:03:25', 'Blanco Normal', '-1', '0', 'peraza', '0', 'FAC 70');
INSERT INTO `catentradas` VALUES ('133', 'FLNA', '2010-10-04 17:03:25', 'Naranja Fluorescente', '-0.5', '0', 'peraza', '0', 'FAC 70');
INSERT INTO `catentradas` VALUES ('134', 'AHRES', '2010-10-04 17:08:46', 'Rojo Escarlata Normal', '-0.5', '0', 'peraza', '0', 'FAC 71');
INSERT INTO `catentradas` VALUES ('135', 'AHVEC', '2010-10-04 17:08:46', 'Verde Ecológico Normal', '-0.5', '0', 'peraza', '0', 'FAC 71');
INSERT INTO `catentradas` VALUES ('136', '0001', '2010-10-04 17:13:16', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 72');
INSERT INTO `catentradas` VALUES ('137', '0002', '2010-10-04 17:13:16', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 72');
INSERT INTO `catentradas` VALUES ('138', '0001', '2010-10-04 17:30:15', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 73');
INSERT INTO `catentradas` VALUES ('139', '0002', '2010-10-04 17:30:15', 'Producto 2', '-1', '0', 'mikem', '0', 'FAC 73');
INSERT INTO `catentradas` VALUES ('140', 'AHNE', '2010-10-04 17:36:01', 'Negro Normal', '-1', '0', 'peraza', '0', 'FAC 74');
INSERT INTO `catentradas` VALUES ('141', 'AHVEC', '2010-10-04 17:36:01', 'Verde Ecológico Normal', '-1', '0', 'peraza', '0', 'FAC 74');
INSERT INTO `catentradas` VALUES ('142', 'AHBL', '2010-10-04 17:46:39', 'Blanco Normal', '-1', '0', 'peraza', '0', 'FAC 75');
INSERT INTO `catentradas` VALUES ('143', 'AHACR', '2010-10-04 17:57:48', 'Amarillo Cromo Normal', '-1', '0', 'peraza', '0', 'FAC 76');
INSERT INTO `catentradas` VALUES ('144', 'AHRCL', '2010-10-04 18:13:27', 'Rojo Claro', '-1', '0', 'peraza', '0', 'FAC 77');
INSERT INTO `catentradas` VALUES ('145', 'AHNE', '2010-10-04 22:28:15', 'Negro Normal', '-1', '0', 'peraza', '0', 'FAC 78');
INSERT INTO `catentradas` VALUES ('146', '0001', '2010-10-14 17:24:28', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 86');
INSERT INTO `catentradas` VALUES ('152', '0001', '2010-10-14 18:02:51', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 92');
INSERT INTO `catentradas` VALUES ('158', '0003', '2010-10-14 18:11:21', 'Producto numero 3', '-1', '0', 'mikem', '0', 'FAC 98');
INSERT INTO `catentradas` VALUES ('159', '0001', '2010-10-14 18:18:00', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 99');
INSERT INTO `catentradas` VALUES ('160', '0001', '2010-10-14 18:24:42', 'Articulo 1', '-1', '0', 'peraza', '0', 'FAC 100');
INSERT INTO `catentradas` VALUES ('161', '0001', '2010-10-14 18:25:37', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 101');
INSERT INTO `catentradas` VALUES ('162', '0001', '2010-10-14 18:32:10', 'Articulo 1', '-1', '0', 'peraza', '0', 'FAC 102');
INSERT INTO `catentradas` VALUES ('163', 'AHALI', '2010-10-14 18:36:57', 'Amarillo Limón Normal', '-0.5', '0', 'peraza', '0', 'FAC 103');
INSERT INTO `catentradas` VALUES ('164', 'AHNE', '2010-10-14 18:36:57', 'Negro Normal', '-1', '0', 'peraza', '0', 'FAC 103');
INSERT INTO `catentradas` VALUES ('165', 'AHBT', '2010-10-14 18:36:57', 'Base Transparente', '-1', '0', 'peraza', '0', 'FAC 103');
INSERT INTO `catentradas` VALUES ('166', '0001', '2010-10-14 18:43:00', 'Articulo 1', '-1', '0', 'peraza', '0', 'FAC 104');
INSERT INTO `catentradas` VALUES ('167', '0003', '2010-10-14 18:45:46', 'Producto numero 3', '-1', '0', 'mikem', '0', 'FAC 106');
INSERT INTO `catentradas` VALUES ('168', 'AHACR', '2010-10-14 18:45:46', 'Amarillo Cromo Normal', '-1', '0', 'mikem', '0', 'FAC 106');
INSERT INTO `catentradas` VALUES ('169', '0001', '2010-10-14 18:45:46', 'Articulo 1', '-1', '0', 'mikem', '0', 'FAC 106');
INSERT INTO `catentradas` VALUES ('170', 'AHAT00001', '2010-10-14 18:57:48', 'Azul Turqueza Normal', '-1', '0', 'peraza', '0', 'FAC 107');
INSERT INTO `catentradas` VALUES ('171', 'AHRCR0001', '2010-10-14 18:57:48', 'Rojo Carmín Normal', '-1', '0', 'peraza', '0', 'FAC 107');
INSERT INTO `catentradas` VALUES ('172', 'AHAT00001', '2010-10-14 19:06:52', 'Azul Turqueza Normal', '-1', '0', 'mikem', '0', 'FAC 108');
INSERT INTO `catentradas` VALUES ('173', 'AHRCR0001', '2010-10-14 19:06:52', 'Rojo Carmï¿½n Normal', '-1', '0', 'mikem', '0', 'FAC 108');
INSERT INTO `catentradas` VALUES ('174', 'AHAT00001', '2010-10-14 19:13:49', 'Azul Turqueza Normal', '-1', '0', 'mikem', '0', 'FAC 109');
INSERT INTO `catentradas` VALUES ('175', 'AHRCR0001', '2010-10-14 19:13:49', 'Rojo Carmin Normal', '-1', '0', 'mikem', '0', 'FAC 109');
INSERT INTO `catentradas` VALUES ('176', 'AHAT00001', '2010-10-14 19:15:50', 'Azul Turqueza Normal', '-1', '0', 'peraza', '0', 'FAC 110');
INSERT INTO `catentradas` VALUES ('177', 'AHRCR0001', '2010-10-14 19:15:50', 'Rojo Carmin Normal', '-1', '0', 'peraza', '0', 'FAC 110');
INSERT INTO `catentradas` VALUES ('178', 'AHAT00001', '2010-10-14 19:17:58', 'Azul Turqueza Normal', '-1', '0', 'peraza', '0', 'FAC 111');
INSERT INTO `catentradas` VALUES ('179', 'AHRCR0001', '2010-10-14 19:17:58', 'Rojo Carmin Normal', '-1', '0', 'peraza', '0', 'FAC 111');
INSERT INTO `catentradas` VALUES ('180', 'AHAT00001', '2010-10-14 19:22:23', 'Azul Turqueza Normal', '6', '0', 'peraza', '1', '');
INSERT INTO `catentradas` VALUES ('181', 'AHAT00001', '2010-10-14 19:23:15', 'Azul Turqueza Normal', '-1', '0', 'peraza', '0', 'FAC 112');
INSERT INTO `catentradas` VALUES ('182', 'AHRCR0001', '2010-10-14 19:23:15', 'Rojo Carmin Normal', '-1', '0', 'peraza', '0', 'FAC 112');
INSERT INTO `catentradas` VALUES ('183', 'AHBL00001', '2010-11-17 23:44:48', 'Blanco Normal', '-1.5', '0', 'mikem', '0', 'NOT 19');
INSERT INTO `catentradas` VALUES ('184', 'OFVRU00001', '2010-11-17 23:44:48', 'Vede Rutland', '-2', '0', 'mikem', '0', 'NOT 19');
INSERT INTO `catentradas` VALUES ('185', '0001', '2010-11-22 23:03:28', 'Articulo 1', '5', '50', 'mikem', '1', 'test');
INSERT INTO `catentradas` VALUES ('189', '0001', '2010-11-22 23:13:29', 'Articulo 1', '-1', '-5.5', 'mikem', '0', 'NOT 20');
INSERT INTO `catentradas` VALUES ('190', '0001', '2010-11-22 23:15:57', 'Articulo 1', '-2', '-11', 'mikem', '0', 'NOT 21');
INSERT INTO `catentradas` VALUES ('191', '0001', '2010-11-22 23:22:50', 'Articulo 1', '-3', '-3.45', 'mikem', '0', 'NOT 22');
INSERT INTO `catentradas` VALUES ('192', '0001', '2010-11-22 23:24:39', 'Articulo 1', '-5', '-31.625', 'mikem', '0', 'NOT 23');

-- ----------------------------
-- Table structure for `catFacturas`
-- ----------------------------
DROP TABLE IF EXISTS `catFacturas`;
CREATE TABLE `catFacturas` (
  `IdFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroFactura` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `NumProductos` int(11) DEFAULT NULL,
  `Subtotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `EsCredito` int(1) NOT NULL DEFAULT '0',
  `Cancelada` int(1) NOT NULL DEFAULT '0',
  `usuario` varchar(50) DEFAULT NULL,
  `esfactura` int(1) NOT NULL DEFAULT '1',
  `estatus` int(11) NOT NULL,
  `entregado` float DEFAULT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  `cadenaoriginal` text,
  `sello` text,
  PRIMARY KEY (`IdFactura`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catFacturas
-- ----------------------------
INSERT INTO `catFacturas` VALUES ('76', '2', '65', '2010-10-04 13:22:54', '2', '28.5', '32.78', '0', '0', 'mikem', '1', '1', '32.78', 'mikem', '||2.0|ABCD|65|2010-10-04T13:22:54|49|2008|ingreso|UNA SOLA EXIBICION|28.50|0.00|32.78|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|1.00|pza|0002|Producto 2|23.00|23.00|IVA|15.00|4.28|4.28||', 'FMx/6fle2CFNzvcnwKA3IZ6JbJS5q6TkPIv4cVGyqDuya4PMWsyfCf2h8qfDIS2EFzEmDnIZvpj0C2JXntImLWZzRa77VS1V7pS86U+XgfoN4UG81AqCTHdtNWuXSkxA055hm/f6qQ+PWK+ynJPq9e1Ylbra8IBURonNpYsZFqo=');
INSERT INTO `catFacturas` VALUES ('77', '2', '66', '2010-10-04 13:53:36', '2', '235.5', '270.82', '0', '0', 'mikem', '1', '1', '270.82', 'mikem', '||2.0|ABCD|66|2010-10-04T13:53:36|49|2008|ingreso|UNA SOLA EXIBICION|235.50|0.00|270.82|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|10.00|pza|0002|Producto 2|23.00|230.00|IVA|15.00|35.32|35.32||', 'J2yxc4lkp7ONBH1ABR1GxI2iE1dcV1FpjwBvnxOuYn9moBkmm3R5Vz7pZM5D8EJxej/Jj4yduSpx0rgfVcKBmGWyBl6B4pNKCTJUEqp9uLAPOpD2M96VQmTGyK7tXCz6sqdIuAxvR+8yxuqL0Sq1h6q3MrQZsTIz/xdRA1cKY3k=');
INSERT INTO `catFacturas` VALUES ('78', '2', '67', '2010-10-04 16:12:55', '2', '1700', '1955', '0', '0', 'mikem', '1', '1', '1955', 'mikem', '||2.0|ABCD|67|2010-10-04T16:12:57|49|2008|ingreso|UNA SOLA EXIBICION|1700.00|0.00|1955.00|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|100.00|Pza|0001|Articulo 1|5.50|550.00|50.00|pza|0002|Producto 2|23.00|1150.00|IVA|15.00|255.00|255.00||', 'Vdz9NX+S/WZtUcCyNxAP1Dtlv3TAl9urmLP5QrAp3gyulx22bRe1RUPGlMUahid8IAHdme2Iip9HWSvlV4Ft4+KTMqzLvqFfVOOB2qVg+OyGXUQPWyMbjfYXY4MsMfJAi8sgv9I/GpciDVHz+scHF10LOyrdwDg/w+JkgwkLzXI=');
INSERT INTO `catFacturas` VALUES ('79', '2', '68', '2010-10-04 16:32:01', '3', '83.5', '96.02', '0', '0', 'mikem', '1', '1', '96.02', 'mikem', '||2.0|ABCD|68|2010-10-04T16:32:03|49|2008|ingreso|UNA SOLA EXIBICION|83.50|0.00|96.02|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|1.00|pza|0002|Producto 2|23.00|23.00|1.00|Pza|0003|Producto numero 3|55.00|55.00|IVA|15.00|12.52|12.52||', 'LjKpU44e4kHrg648YcBFG2PiqUEGvrBXG3N9XE+/lT2p4RqGlVm0RgJn27DHj59M2ovAsK9CTUJpQOw71zDXRsoUcUEru92cQSMMV2oTMqBO0QIKFLA75UAW6iLmBfsn73qBch3pDWVL3hkO5GO70qWcSz9xlvk3gPDYylBl9Gs=');
INSERT INTO `catFacturas` VALUES ('80', '2', '69', '2010-10-04 16:48:16', '4', '402.21', '466.56', '0', '0', 'mikem', '1', '1', '466.56', 'mikem', '||2.0|ABCD|69|2010-10-04T16:48:19|49|2008|ingreso|UNA SOLA EXIBICION|402.21|0.00|466.56|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHACR|Amarillo Cromo Normal|89.00|89.00|1.00|Kg|AHPL|Plata Normal|101.06|101.06|1.00|Kg|AHRES|Rojo Escarlata Normal|90.06|90.06|1.00|Kg|FLVE|Verde Fluorescente|122.09|122.09|IVA|16.00|64.35|64.35||', 'Qu+Lq2vV6Xlspm8p9XNAbIbMSTqdCSRim0SK2bYA2RSETbksnCGK9GatzLU9dkQPBy8g7ih54K3/KB5NigP7HWNiupGdNAyW9aT0keChz2hKPCci6xYpKd0Vu/oW5pVdit5nCKz+whMkxCdMBOCAOXofLyx1hXx4aQ5PKKEp+jE=');
INSERT INTO `catFacturas` VALUES ('81', '1', '70', '2010-10-04 17:03:25', '4', '277.56', '321.97', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|70|2010-10-04T17:03:27|49|2008|ingreso|UNA SOLA EXIBICION|277.56|0.00|321.97|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Kg|AHALI|Amarillo Limón Normal|92.00|92.00|0.50|Kg|AHPL|Plata Normal|101.06|50.53|1.00|Kg|AHBL|Blanco Normal|80.01|80.01|0.50|Kg|FLNA|Naranja Fluorescente|110.04|55.02|IVA|16.00|44.41|44.41||', 'aMctR91VPqzDQUHXqafLWTm8In4Nzd4LrH075LiO6qz79nYrDGZwQXi5Faw+nyvlJBIaMpizNG47OTr/7zwmWr7CIeMlyrhURzJoI65Quj8R9OnHttPhncVSXQyYZtt9kuejIKB/I3Isi4zuhG1zfz0qhH8gr3WQY5k5W0Em53s=');
INSERT INTO `catFacturas` VALUES ('82', '2', '71', '2010-10-04 17:08:46', '2', '89.54', '103.87', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|71|2010-10-04T17:08:48|49|2008|ingreso|UNA SOLA EXIBICION|89.54|0.00|103.87|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|0.50|Kg|AHRES|Rojo Escarlata Normal|90.06|45.03|0.50|Kg|AHVEC|Verde Ecológico Normal|89.03|44.51|IVA|16.00|14.33|14.33||', 'FDwONlAzZ02mMUgGyV+fo4FZvJ/wjj2kSOfvn0IVcH4mxPhd/4xWVuONLRmEmdH4jGOrX8d1U/5djYDiNijI1pkj13+o6bes4F1B0xiKxYcTOXJJQSdqzKO1AwjgYYylZBAQ243/Sq/dJ8fX955yMx1XOiBveaTNqIji1BkNeuc=');
INSERT INTO `catFacturas` VALUES ('83', '2', '72', '2010-10-04 17:13:16', '2', '28.5', '32.78', '0', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|72|2010-10-04T17:13:17|49|2008|ingreso|UNA SOLA EXIBICION|28.50|0.00|32.78|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|1.00|pza|0002|Producto 2|23.00|23.00|IVA|15.00|4.28|4.28||', 'EZtUmbQMQcc7Erb44lueohhB61TGj6qrMgvsmX+pAJYZ0nZ4ji148V4XYQan3WALDoBfb99EpNNt3oOd32Hj687gofCXUGdRusVoZ8nXq7LBKrqzQVgjPPVgcTuLpPP9XQUdkfJbPxbUuyYmx40hCYiOWLS9ewqOnN8AqLnMNV8=');
INSERT INTO `catFacturas` VALUES ('84', '2', '73', '2010-10-04 17:30:15', '2', '28.5', '32.78', '0', '0', 'mikem', '1', '1', '32.78', 'mikem', '||2.0|A|73|2010-10-04T17:30:17|49|2008|ingreso|UNA SOLA EXIBICION|28.50|0.00|32.78|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|1.00|pza|0002|Producto 2|23.00|23.00|IVA|15.00|4.28|4.28||', 'C8JXtnZ8kT3N0Ba+XPh4tWJHKVQwncDclKo3mw2mCFjP2ofjU5lNUmox4aXbufQ44MeapzIDZb3m0wOGzpUMBByjQUxEuEhPMiy95cVSDEKIG92aSWJ3Mlu+VJrq/pj4Kdzfu5T+MUIsEGgxxfRlRssKNKU75EASqNetHh72ld0=');
INSERT INTO `catFacturas` VALUES ('85', '2', '74', '2010-10-04 17:36:01', '2', '159.08', '184.53', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|74|2010-10-04T17:36:04|49|2008|ingreso|UNA SOLA EXIBICION|159.08|0.00|184.53|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00||AHNE|Negro Normal|70.05|70.05|1.00|Kg|AHVEC|Verde Ecológico Normal|89.03|89.03|IVA|16.00|25.45|25.45||', 'XyJ1LSy/cUEdQT3cGxuKpBKVKpi+96NVVBMs6k6koD2og8HrFsACj3BZrDMbf/AftRcj/vKBmByCjGVxIcCFwWfXQ/IX0VhDrFZlhlxsn0+6i/udZ9h0/GWuVF36Uo/sdT94173deR4cjLdaMF8bqNh0sM5Uy0YFhSC+bN7CkWo=');
INSERT INTO `catFacturas` VALUES ('86', '2', '75', '2010-10-04 17:46:39', '1', '80.01', '92.81', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|75|2010-10-04T17:46:41|49|2008|ingreso|UNA SOLA EXIBICION|80.01|0.00|92.81|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHBL|Blanco Normal|80.01|80.01|IVA|16.00|12.80|12.80||', 'DzQf7UfHSKifUXizbPtJajpgaGGRWOsOG5pY10vaqKOrp1/NIDFiaOOwgc1p/481wElefTukGjqrSdqWgj5uUgdU/SBbs0VGYkeEC6uVPuXW5zs6J6aJnLavesVFjJI1wUpzTkd/yInKGNZLj0lMWTuk6Qp93EB/FCzsdTzVUHc=');
INSERT INTO `catFacturas` VALUES ('87', '2', '76', '2010-10-04 17:57:48', '1', '89', '103.24', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|76|2010-10-04T17:57:49|49|2008|ingreso|UNA SOLA EXIBICION|89.00|0.00|103.24|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHACR|Amarillo Cromo Normal|89.00|89.00|IVA|16.00|14.24|14.24||', 'QHA9FijOodwNUvGLUrN1BGqzTMwmHs/5Xo+CDsL/nx4k+jY7JIiqz1qRPG7edjHR24txSucAAtGNlOdKxp9laaOVuLtQ7Muy8kuvwvx39Y4M9dcVRIs6qY81QzqbNPbqy1dyTqlS44NBiNuzDOFHXOIE3VP8J9r6L6eKULfKJv8=');
INSERT INTO `catFacturas` VALUES ('88', '2', '77', '2010-10-04 18:13:27', '1', '92.04', '106.77', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|77|2010-10-04T18:13:28|49|2008|ingreso|UNA SOLA EXIBICION|92.04|0.00|106.77|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHRCL|Rojo Claro|92.04|92.04|IVA|16.00|14.73|14.73||', 'gLEoBqGCSdyJhO3GSELhfmsF5DK3bhVtME2IFCLBErSb6fWOImfhSccbosi6KYSnONiHAaMmA1tl9O6MCOXl9g9QcVTR2412dknH5ILmW+w1snb0zeO4I02+WHv5o5qQpDjVOzVqhLT63SbkkDG0ofmHuYY5iRlsSW1bVPp7LqU=');
INSERT INTO `catFacturas` VALUES ('89', '2', '78', '2010-10-04 22:28:15', '1', '70.05', '81.26', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|78|2010-10-04T22:28:17|49|2008|ingreso|UNA SOLA EXIBICION|70.05|0.00|81.26|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00||AHNE|Negro Normal|70.05|70.05|IVA|16.00|11.21|11.21||', 'ol42dveCNHrdxxveEJYOlZSL5KavyQHf/VPvmeL3TpJy07NhX1Auo44BTOiTOF3t/o2Ga0RLyx001Dv7xk77FJfe8nWP7SKAj/ux4GzBnk2A7hBEJm7vHMtMiY6eFr1qnpDNlunxgJU8+5zCv5r3APMx+W0Lhkj4mg7gi2xXKeM=');
INSERT INTO `catFacturas` VALUES ('90', '2', '86', '2010-10-14 17:24:28', '1', '5.5', '6.32', '0', '0', 'mikem', '1', '1', '6.32', 'mikem', '||2.0|A|86|2010-10-14T17:24:29|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'AFNnDUo/a2UBfwjfj3hGsUZPdNQyEELuDo8Na9ySCUJC8sERNOm4/O/XM7LwrLmY8XBVKqVm6vuL+1lkhy2ucpo4A/BGKGkrO+9uVKzKQh05EnJINoCncfGtiTg95C/kV2beiU0Dk5euclsaHlkRJSXzrhaz9RZ38I7u6YIAweM=');
INSERT INTO `catFacturas` VALUES ('96', '2', '92', '2010-10-14 18:02:51', '1', '5.5', '6.32', '0', '0', 'mikem', '1', '1', '6.32', 'mikem', '||2.0|A|92|2010-10-14T18:03:03|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'iX/Qh3S/cOGzyTeC8n4vkeWlt4Zctq9rM2sYnrtBTMG0OcDeGvBNWUqK/wiT/cxdK8I9P0x3ghx0Wz5CegZl2IzAE7u/7nUsTyneEDRvVM1QZuQd0eODY6IhNTZ7HKkASLfAw+7lE9Ow2+PlIDamBuGdhRU+WI7/3OmA4xsESww=');
INSERT INTO `catFacturas` VALUES ('102', '1', '98', '2010-10-14 18:11:21', '1', '55', '63.25', '0', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|98|2010-10-14T18:11:23|49|2008|ingreso|UNA SOLA EXIBICION|55.00|0.00|63.25|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Pza|0003|Producto numero 3|55.00|55.00|IVA|15.00|8.25|8.25||', 'Bjj76wOLGlZ1zq6+SKJgOKs3AxV/it+Yw7Q6/FsCH1eO+fxHLupPd6bYqp8RjecXOsELd78GGJP51/qoUIjXTrQckIlGzVHKfcYkDnI54XySkuUYbscJ6lT/Fy9xTD1I17AVPMkGR2MKIRP5/hV3ZrCgMShPULciFea7kx/gcjw=');
INSERT INTO `catFacturas` VALUES ('103', '1', '99', '2010-10-14 18:18:00', '1', '5.5', '6.32', '0', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|99|2010-10-14T18:18:08|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'qah6j4Hdkd1FaZJyJsbFzk+7mI6tz72ETsK5WkLn2lB8LLC1Qk78vMbPNLLEkYDQ1Xnwia9FyscBzdHiSWEZendoE2fwsICs9k30U2SThBQqFXqLFuA+1k2xlvWNeYmC7ygMcuxCsY5bg3oMzBvajAzuzgEtf7wdJpz/XtaiYZo=');
INSERT INTO `catFacturas` VALUES ('104', '2', '100', '2010-10-14 18:24:42', '1', '5.5', '6.32', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|100|2010-10-14T18:24:43|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'tc4dpvvQlwVzRSfqc8YfKxUSd+1TgT3rZKSmtRC3UJE7cZnO8DcEiWoNbf439WWbtdDRvclsJr+l5kmduuEH6+t7RwHSjzHqFgwhqM+ke0IGX0bfAjYFhcJJxoyhOyt1QVW2lplxtYZhezIa1ZvNSD44yArWYoo+RGrStWPH1tA=');
INSERT INTO `catFacturas` VALUES ('105', '2', '101', '2010-10-14 18:25:37', '1', '5.5', '6.32', '0', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|101|2010-10-14T18:25:38|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'h23TfTKS2Ids5q8DwKM4Kz0EY6Ujnval4xTc/1+ZKEwMjBnEJPhR4rS1odTcFMz+QvaZ0L7EixxjJhkZ/QGQJDyDoDGZjCA65DMfmSVwoAZRK3EBZyHXMOQw0+xfqMBlZD4Pv7uw8lXFjopydjAMYlZUfVcYZ828uzEI8HpCHNk=');
INSERT INTO `catFacturas` VALUES ('106', '2', '102', '2010-10-14 18:32:10', '1', '5.5', '6.32', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|102|2010-10-14T18:32:12|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'mjO9BTRbb5ulS9QOvgRz8Piox0i6h+xsmmGAAJiYAdYJ0k6tFojESo7u6v5P+ydYV4NqAfKbgXsVmQ3/4+Wk+b3mAqIhYdKliTJCJ+Y6w0vfGkhH8DW71l2TaD+fiyQtBfUPnMdpcJ1IvWmgN8FQ+sSzyKaJUFZbYJdwk4kVr7w=');
INSERT INTO `catFacturas` VALUES ('107', '2', '103', '2010-10-14 18:36:57', '3', '197.08', '228.61', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|103|2010-10-14T18:36:59|49|2008|ingreso|UNA SOLA EXIBICION|197.08|0.00|228.61|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|0.50|Kg|AHALI|Amarillo Limón Normal|92.00|46.00|1.00||AHNE|Negro Normal|70.05|70.05|1.00|Kg|AHBT|Base Transparente|81.03|81.03|IVA|16.00|31.53|31.53||', 'O7UHuowvAdNfJD+MYVuK7gkzHLf0NQNB+sRQLfnwoGqZLq9rCz5Ax3EZPlS32mma0BqB6yUCcucdpg8qlEVmOyuBeEYQWtOi4GvHkD0z6ctxQjt1B8wuk4/f96tYt7X79CltNRBZ2evXOF8PvFVjMg9CebVvPwf9tn6ac3zSBBA=');
INSERT INTO `catFacturas` VALUES ('108', '2', '104', '2010-10-14 18:43:00', '1', '5.5', '6.32', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|104|2010-10-14T18:43:01|49|2008|ingreso|UNA SOLA EXIBICION|5.50|0.00|6.32|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|0.82|0.82||', 'iDmOfmdZahUx+5rE9ONXVBtt8nVik6cV+QShsJ6cv7DVVSDHSl266mXmxlTtjwkhXGx+R4OVzBp/h0z/XZtDcPc7s+khzlbUH4ZGbu7TK+bclC7i6rtXQxcOLPHeadDNjvTPLti83kr7V+KG9NmXNiEiKM8FP0sOW28SnZpukGs=');
INSERT INTO `catFacturas` VALUES ('109', '2', '106', '2010-10-14 18:45:46', '3', '149.5', '172.82', '0', '0', 'mikem', '1', '1', '172.82', 'mikem', '||2.0|A|106|2010-10-14T18:45:48|49|2008|ingreso|UNA SOLA EXIBICION|149.50|0.00|172.82|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Pza|0003|Producto numero 3|55.00|55.00|1.00|Kg|AHACR|Amarillo Cromo Normal|89.00|89.00|1.00|Pza|0001|Articulo 1|5.50|5.50|IVA|15.00|23.32|23.32||', 'Z7mFxW9Eh5lmmGi+zkiXuPkTJi06kcBXs2BHPPLzejFxdNuUZJ4cvatycja2lwZa2XDPu2PiW5ga7xm6Z1N1u6+lcESYc9ELcRbJSrXe3E0HYG+97CtP4ftAqpDkkfedQh2cQymORcqbRWfvKQQztcp4GzXhqlI4D6QbwlkruHc=');
INSERT INTO `catFacturas` VALUES ('110', '1', '107', '2010-10-14 18:57:48', '2', '171.07', '198.44', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|107|2010-10-14T18:57:50|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmín Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'k+T7DV2rfXMnQbhcbXCEin92gRSpJKzu7CzERcnB7I3Pg0/bLIFB8kcH/s+YmRj3wN2fFOkzBM3fs+wMAcZ+6F5KEGPHB1RLwLwohHxP3ec2yYo9cVX8gHYKxzIKOhfcD4TYR/UUDeI3F43nDok1dLABKfQEiwq8KxPMz4WiNBk=');
INSERT INTO `catFacturas` VALUES ('111', '1', '108', '2010-10-14 19:06:52', '2', '171.07', '198.44', '1', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|108|2010-10-14T19:06:54|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmï¿½n Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'mYjQu18CtpLc217ybn2LDOnhg58tswB9svOOKk479shpRQzCi+shSQMYYvAoBELRXMGopixqaKlSqry2bO2dR8EknAI4NHUbh8ochsa7KslTo1py1hh+sNy1Q19NF1Y+fJxRFGqr5ob5y4R5B2mf0K7xfM0LuHjboBWrDOknnSs=');
INSERT INTO `catFacturas` VALUES ('112', '2', '109', '2010-10-14 19:13:49', '2', '171.07', '198.44', '0', '0', 'mikem', '1', '0', '0', 'mikem', '||2.0|A|109|2010-10-14T19:13:51|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmin Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'vp+DuNAZD5XdQEZNl30t6t0nupB4G7dR45fJTDKO3vkoRgoLUoOLJX4n3nsEgW4L/qCCFYop+MLlKwpOLNjwJgwb66w6GatEYY7Y7/fKTMT4LhWqt4lfhw9w7QuDj1MUTXE/tYuZFVjzdtdO2dbvzlAFUrsKrKdoeqOC1VTNh8k=');
INSERT INTO `catFacturas` VALUES ('113', '1', '110', '2010-10-14 19:15:50', '2', '171.07', '198.44', '0', '0', 'peraza', '1', '1', '198.44', 'mikem', '||2.0|A|110|2010-10-14T19:15:52|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|NINGUNO|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmin Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'Ehw6dOGX+OgEtvDRyU47rT+AK7MKbb0+nMlnaS3Lc3Ap2ltcX4A731XZ1ibaZgXQq/rUqTMZdROcjfUeZh4sLTOMdP0W2TpawxXsZYQYr8D/EDNsg9TFP2l6C7wix+xxCt7w9aAxIsqubFjZyVJmDuwgCPee515YI+NSlOeaVRs=');
INSERT INTO `catFacturas` VALUES ('114', '2', '111', '2010-10-14 19:17:58', '2', '171.07', '198.44', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|111|2010-10-14T19:17:59|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmin Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'H14XZkYnv/cYDa6yDzAEofea3U60+iB8lxjyLVnT9IGk4IP2znONaaiTLan3hxiqUtvVRy6AaqcCsAZNG8XOA91g2eJ6NQbHpoobVU1ywTRaChP1Zs0pTINLtR2d2Ny7HQ9j6TzAUmn0uMnay9CofvahKMR5j8Md7BsGTPa21eY=');
INSERT INTO `catFacturas` VALUES ('115', '1', '112', '2010-10-14 19:23:15', '2', '171.07', '198.44', '0', '0', 'peraza', '1', '0', '0', 'peraza', '||2.0|A|112|2010-10-14T19:23:16|49|2008|ingreso|UNA SOLA EXIBICION|171.07|0.00|198.44|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ010101|CLIENTE DE MOSTRADOR|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|NINGUNO|1.00|Kg|AHAT00001|Azul Turqueza Normal|79.06|79.06|1.00|Kg|AHRCR0001|Rojo Carmin Normal|92.01|92.01|IVA|16.00|27.37|27.37||', 'QnzvlH8WiZd6h/yQUYEFQtCQp4zwGSe2J+xEXCwliOssZcYjRdCMlIBCdH1RYbaZ8Ucptt2vCGiN9HaBERLkNNyIA6W7uEAmyxYK+FYZLRiluIVJUZOyaIkqwGuObjuU3NWo5TUtpPDyI1jJeBvH8QbL2oQzvJYZ6zDgCv0ot+k=');
INSERT INTO `catFacturas` VALUES ('122', '2', '113', '2010-12-27 23:23:56', '2', '1205', '1385.75', '0', '0', 'mikem', '1', '1', '1', 'mikem', '||2.0|A|113|2010-12-27T23:23:59|49|2008|ingreso|UNA SOLA EXIBICION|1205.00|0.00|1385.75|PEAR720718AW5|RICARDO ARIEL PERAZA ALEJOS|29|329|Chuminopolis|Merida|Merida|Yucatan|Mexico|97117|MOGJ760131AB|JUAN MIGUEL MOTA GONZALEZ|23|329|Sodzil Norte|Merida|Merida|Yucatan|Mexico|97117|10.00|Pza|0001|Articulo 1|5.50|55.00|50.00|pza|0002|Producto 2|23.00|1150.00|IVA|1500.00|180.75|180.75||', 'cgHAFgqP398R8+gnX3gNlWEnoH5Ao+iIL1hYa9TUQumxVwLeR0yMzTrSK5S8yBD8gCj6UkfkQ8dKctb4DlUlgawALzmuZo5/zmHcUffppWP9nbfBbsooJstExII4/e3kAX+K+p0vkFR5WHMsev5oni+2atNCJ/FW2Odw6emuj3Y=');

-- ----------------------------
-- Table structure for `catFamilias`
-- ----------------------------
DROP TABLE IF EXISTS `catFamilias`;
CREATE TABLE `catFamilias` (
  `idFamilia` int(11) NOT NULL AUTO_INCREMENT,
  `Codigo` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `idPadre` int(11) DEFAULT NULL,
  PRIMARY KEY (`idFamilia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catFamilias
-- ----------------------------
INSERT INTO `catFamilias` VALUES ('1', 'F001', 'Familia 1', '0');
INSERT INTO `catFamilias` VALUES ('2', 'FX01', 'Familia 1.1', '1');

-- ----------------------------
-- Table structure for `catNotas`
-- ----------------------------
DROP TABLE IF EXISTS `catNotas`;
CREATE TABLE `catNotas` (
  `IdFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroFactura` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `NumProductos` int(11) DEFAULT NULL,
  `SubTotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `EsCredito` int(1) NOT NULL DEFAULT '0',
  `Cancelada` int(1) NOT NULL DEFAULT '0',
  `usuario` varchar(50) DEFAULT NULL,
  `esfactura` int(1) NOT NULL DEFAULT '0',
  `estatus` int(11) NOT NULL,
  `entregado` float DEFAULT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdFactura`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catNotas
-- ----------------------------
INSERT INTO `catNotas` VALUES ('9', '1', '15', '2010-10-04 13:48:05', '2', '28.5', '32.78', '0', '0', 'mikem', '0', '1', '32.78', 'mikem');
INSERT INTO `catNotas` VALUES ('10', '1', '16', '2010-10-04 13:50:05', '2', '1205', '1385.75', '0', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('11', '1', '17', '2010-10-04 13:51:25', '2', '28.5', '32.78', '0', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('12', '1', '18', '2010-10-04 16:00:35', '1', '23', '26.45', '0', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('13', '1', '19', '2010-11-17 23:44:48', '2', '170.02', '197.22', '1', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('14', '1', '20', '2010-11-22 23:13:29', '1', '5.5', '6.32', '0', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('15', '1', '21', '2010-11-22 23:15:57', '1', '11', '12.65', '1', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('16', '1', '22', '2010-11-22 23:22:50', '1', '16.5', '18.98', '1', '0', 'mikem', '0', '0', '0', 'mikem');
INSERT INTO `catNotas` VALUES ('17', '1', '23', '2010-11-22 23:24:39', '1', '27.5', '31.62', '0', '0', 'mikem', '0', '0', '0', 'mikem');

-- ----------------------------
-- Table structure for `catnotascred`
-- ----------------------------
DROP TABLE IF EXISTS `catnotascred`;
CREATE TABLE `catnotascred` (
  `IdNotaCred` int(11) NOT NULL AUTO_INCREMENT,
  `IdCliente` int(11) DEFAULT NULL,
  `NumeroNotaCred` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Concepto` varchar(255) DEFAULT NULL,
  `SubTotal` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `usuario` varchar(50) DEFAULT NULL,
  `estatus` int(1) NOT NULL,
  `Cancelada` int(1) NOT NULL,
  `usuarioventa` varchar(50) DEFAULT NULL,
  `cadenaoriginal` text,
  `sello` text,
  PRIMARY KEY (`IdNotaCred`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catnotascred
-- ----------------------------
INSERT INTO `catnotascred` VALUES ('18', '1', '1', '2011-01-28 19:31:40', 'Mi primera nota de credito', '100', '116', 'mikem', '1', '0', 'mikem', null, null);
INSERT INTO `catnotascred` VALUES ('19', '3', '2', '2011-01-30 19:31:40', 'Devolucion', '215.99', '250.55', 'mikem', '0', '0', 'mikem', null, null);
INSERT INTO `catnotascred` VALUES ('20', '1', '3', '2011-01-30 19:31:40', 'nc2', '43.1', '50', 'mikem', '0', '0', 'mikem', null, null);

-- ----------------------------
-- Table structure for `catProductos`
-- ----------------------------
DROP TABLE IF EXISTS `catProductos`;
CREATE TABLE `catProductos` (
  `IdProducto` int(11) NOT NULL AUTO_INCREMENT,
  `CodigoProd` varchar(255) DEFAULT NULL,
  `Codigo` varchar(255) DEFAULT NULL,
  `Descripcion` varchar(255) DEFAULT NULL,
  `Existencia` float DEFAULT NULL,
  `PrecioProveedor` float DEFAULT NULL,
  `PrecioalCliente` float DEFAULT NULL,
  `Proveedores` varchar(255) DEFAULT NULL,
  `Ubicacion` varchar(255) DEFAULT NULL,
  `UnidadVenta` varchar(255) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  `PtoReorden` int(11) DEFAULT NULL,
  `Observaciones` varchar(255) DEFAULT NULL,
  `PorcUtilidad` decimal(18,2) DEFAULT NULL,
  `Marca` varchar(255) DEFAULT NULL,
  `Linea` varchar(255) DEFAULT NULL,
  `idFamilia` int(11) DEFAULT NULL,
  `sfamilia` varchar(255) DEFAULT NULL,
  `dtRegModificado` datetime DEFAULT NULL,
  `PtoMaximo` int(11) DEFAULT NULL,
  `UsuarioModif` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=4671 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catProductos
-- ----------------------------
INSERT INTO `catProductos` VALUES ('1', '0001', '0001', 'Articulo 1', '1071', '5', '5.5', '', 'aa', 'Pza', '15', '100', '', '10.00', 'ge', '', '2', null, '2010-11-22 23:04:12', '10', 'mikem');
INSERT INTO `catProductos` VALUES ('2', '0002', '0002', 'Producto 2', '405', '20', '23', '', 'aa', 'pza', '15', '10', '', '15.00', 'ge', '', '2', null, '2010-09-27 21:38:16', '100', 'mikem');
INSERT INTO `catProductos` VALUES ('3', '0003', '0003', 'Producto numero 3', '4977', '50', '55', 'IPC', 'CC', 'Pza', '15', '100', '', '10.00', 'GE', '', '1', null, '2011-02-03 00:14:13', '200', 'mikem');
INSERT INTO `catProductos` VALUES ('4619', 'AHACR00001', 'AHACR00001', 'Amarillo Cromo Normal', '6', '75.4', '89', '', 'A13', 'Kg', '16', '3', '', '18.04', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '15', 'hector');
INSERT INTO `catProductos` VALUES ('4622', 'AHALI00001', 'AHALI00001', 'Amarillo Limón Normal', '4', '73.83', '92', '', 'A13', 'Kg', '16', '3', '', '24.61', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4624', 'AHAT00001', 'AHAT00001', 'Azul Turqueza Normal', '5', '76.09', '79.06', '', 'A13', 'Kg', '16', '3', '', '3.90', '', 'Normal', '0', 'NULL', '2010-10-14 19:22:35', '20', 'peraza');
INSERT INTO `catProductos` VALUES ('4625', 'AHAU00001', 'AHAU00001', 'Azul Ultra Normal', '0', '74.24', '90', 'IPC', 'A14', 'Kg', '16', '3', '', '21.23', '', 'Normal', '0', 'NULL', '2010-11-25 20:34:54', '20', 'mikem');
INSERT INTO `catProductos` VALUES ('4626', 'AHBT00001', 'AHBT00001', 'Base Transparente', '30', '68.96', '81.03', '', 'A13', 'Kg', '16', '3', '', '17.50', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4627', 'AHBL00001', 'AHBL00001', 'Blanco Normal', '22', '66.12', '80.01', '', 'A14', 'Kg', '16', '5', '', '21.00', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4628', 'AHNA00001', 'AHNA00001', 'Naranja Normal', '0', '66', '79.86', '', 'A16', 'Kg', '16', '5', '', '21.00', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4629', 'AHNE00001', 'AHNE00001', 'Negro Normal', '10.5', '60.49', '70.05', '', 'A13', '', '16', '5', '', '15.80', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4630', 'AHOV00001', 'AHOV00001', 'Oro Verdoso Normal', '2.9', '115.54', '134.03', '', 'A14', 'Kg', '16', '1', '', '16.00', '', 'Normal', '0', 'NULL', '2010-09-28 11:40:48', '15', 'hector');
INSERT INTO `catProductos` VALUES ('4631', 'AHPL00001', 'AHPL00001', 'Plata Normal', '2', '84.22', '101.06', '', 'A13', 'Kg', '16', '1', '', '20.00', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '15', 'hector');
INSERT INTO `catProductos` VALUES ('4632', 'AHRCR0001', 'AHRCR0001', 'Rojo Carmin Normal', '8', '69.13', '92.01', '', 'A14', 'Kg', '16', '3', '', '33.10', '', 'Normal', '0', 'NULL', '2010-10-14 19:12:34', '25', 'mikem');
INSERT INTO `catProductos` VALUES ('4633', 'AHRCL0001', 'AHRCL0001', 'Rojo Claro', '9', '70.58', '92.04', '', 'A14', 'Kg', '16', '5', '', '30.40', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4634', 'AHRES0001', 'AHRES0001', 'Rojo Escarlata Normal', '7', '74.12', '90.06', '', 'A14', 'Kg', '16', '5', '', '21.50', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4635', 'AHVEC0001', 'AHVEC0001', 'Verde Ecológico Normal', '8', '71.86', '89.03', '', 'A13', 'Kg', '16', '5', '', '23.90', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4636', 'AHVES0001', 'AHVES0001', 'Verde Esmeralda Normal', '7', '68.73', '88.04', '', 'A13', 'Kg', '16', '5', '', '28.10', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4637', 'AHVJA0001', 'AHVJA0001', 'Verde Jade Normal', '23', '71.63', '90.04', '', 'A13', 'Kg', '16', '5', '', '25.70', '', 'Normal', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4638', 'TRAM00001', 'TRAM00001', 'Amarillo Trico', '19.5', '69.02', '84', '', 'A12', 'Kg', '16', '5', '', '21.70', '', 'Selección', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4639', 'TRAZ00001', 'TRAZ00001', 'Azul Cyan Trico', '18', '69.36', '84.06', '', 'A12', 'Kg', '16', '5', '', '21.20', '', 'Selección', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4640', 'TRMA00001', 'TRMA00001', 'Rojo / Magenta Trico', '19', '71.8', '84.01', '', 'A12', 'Kg', '16', '5', '', '17.00', '', 'Selección', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4641', 'INBT00001', 'INBT00001', 'Base Transparente Inflable', '9', '113.98', '132.1', '', 'A15', 'Kg', '16', '3', '', '15.90', '', 'Inflable', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4642', 'INBL00001', 'INBL00001', 'Blanco Inflable', '17.25', '102.83', '120', '', 'A15', 'Kg', '16', '3', '', '16.70', '', 'Inflable', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4643', 'FLAM00001', 'FLAM00001', 'Amarillo Fluorescente', '7.5', '98.31', '113.06', '', 'A15', 'Kg', '16', '3', '', '15.00', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4644', 'FLAZ00001', 'FLAZ00001', 'Azul Fluorescente', '3.5', '79.81', '122.03', '', 'A11', 'Kg', '16', '3', '', '52.90', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4645', 'FLMA00001', 'FLMA00001', 'Magenta Fluorescente', '3', '94.08', '113.08', '', 'A11', 'Kg', '16', '3', '', '20.20', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4646', 'FLNA00001', 'FLNA00001', 'Naranja Fluorescente', '5', '91.17', '110.04', '', 'A11', 'Kg', '16', '3', '', '20.70', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4647', 'FLRS00001', 'FLRS00001', 'Rosa Fluorescente', '0', '76.1', '110.04', '', 'A11', 'Kg', '16', '3', '', '44.60', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4648', 'FLVE00001', 'FLVE00001', 'Verde Fluorescente', '2.55', '103.47', '122.09', '', 'A11', 'Kg', '16', '3', '', '18.00', '', 'Fluorescente', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4650', 'OPACR00001', 'OPACR00001', 'Amarillo Cromo Opaco', '2.75', '72.21', '85.06', '', 'A15', 'Kg', '16', '3', '', '17.80', '', 'Opaca', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4651', 'OPALI00001', 'OPALI00001', 'Amarillo Limón Opaco', '4.5', '78.94', '85.02', '', 'A15', 'Kg', '16', '3', '', '7.70', '', 'Opaca', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4653', 'OPAU00001', 'OPAU00001', 'Azul Ultra Opaco', '2.5', '83.29', '100.03', '', 'A15', 'Kg', '16', '3', '', '20.10', '', 'Opaca', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4654', 'OPRO00001', 'OPRO00001', 'Rojo Opaco', '2', '80.56', '100.06', '', 'A15', 'Kg', '16', '3', '', '24.20', '', 'Opaca', '0', 'NULL', '2010-09-30 16:54:27', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4655', 'OPVES00001', 'OPVES00001', 'Verde Esmeralda Opaco', '1', '75.05', '100.04', '', 'A15', 'Kg', '16', '3', '', '33.30', '', 'Opaca', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4656', 'OFCA00001', 'OFCA00001', 'Café', '1', '25', '25', '', 'Mostrador', 'Kg', '16', '2', '', '0.00', '', 'Oferta', '0', 'NULL', '0000-00-00 00:00:00', '10', 'hector');
INSERT INTO `catProductos` VALUES ('4657', 'OFVRU00001', 'OFVRU00001', 'Vede Rutland', '15', '25', '25', '', 'Mostrador', 'Kg', '16', '2', '', '0.00', '', 'Oferta', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4658', 'VMAMCR0001', 'VMAMCR0001', 'Amarillo Cromo Vinil Mate', '0', '66.84', '90.03', '', 'A34', 'Kg', '16', '3', '', '34.70', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4659', 'VMALU0001', 'VMALU0001', 'Aluminio Vinil Mate', '2', '66.84', '95.05', '', 'A37', 'Kg', '16', '3', '', '42.20', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4660', 'VMAMLI0001', 'VMAMLI0001', 'Amarillo Limón Vinil Mate', '1', '66.84', '85', '', 'A34', 'Kg', '16', '3', '', '27.17', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4661', 'VMAMTR0001', 'VMAMTR0001', 'Amarillo Trico Vinil Mate', '2.75', '66.84', '87.01', '', 'A34', 'Kg', '16', '3', '', '30.17', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4662', 'VMAZM0001', 'VMAZM0001', 'Azul Marino Vinil Mate', '0.75', '66.84', '104', '', 'A36', 'Kg', '16', '3', '', '55.60', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4663', 'VMAZTR0001', 'VMAZTR0001', 'Azul Trico Vinil Mate', '5', '66.84', '89', '', 'A36', 'Kg', '16', '3', '', '33.15', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4664', 'VMAZTU0001', 'VMAZTU0001', 'Azul Turqueza Vinil Mate', '0', '66.84', '87', '', 'A36', 'Kg', '16', '3', '', '30.16', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4665', 'VMAZUL0001', 'VMAZUL0001', 'Azul Ultra Vinil Mate', '0', '66.84', '80.07', '', 'A36', 'Kg', '16', '3', '', '19.80', '', 'Mate', '0', 'NULL', '0000-00-00 00:00:00', '20', 'hector');
INSERT INTO `catProductos` VALUES ('4666', 'VMBL00001', 'VMBL00001', 'Blanco Vinil Mate', '0', '66.84', '82', '', 'A37', 'Kg', '16', '3', '', '22.68', '', 'Mate', '0', null, '2010-09-28 13:29:58', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4667', 'VMNE00001', 'VMNE00001', 'Negro Vinil Mate', '0', '66.84', '66.84', '', 'A37', 'Kg', '16', '3', '', '0.00', '', 'Mate', '0', null, '2010-09-28 13:32:38', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4668', 'VMRO00001', 'VMRO00001', 'Rojo Vinil Mate', '0', '66.84', '113', '', 'A35', 'Kg', '16', '3', '', '69.06', '', 'Mate', '0', null, '2010-09-28 17:42:18', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4669', 'VMROTR0001', 'VMROTR0001', 'Rojo Trico Vinil Mate', '0.35', '66.84', '149', '', 'A35', 'Kg', '16', '3', '', '122.92', '', 'Mate', '0', null, '2010-09-28 17:45:39', '25', 'hector');
INSERT INTO `catProductos` VALUES ('4670', 'VMVES00001', 'VMVES00001', 'Verde Esmeralda Vinil Mate', '1', '66.84', '88', '', 'A35', 'Kg', '16', '3', '', '31.66', '', 'Mate', '0', null, '2010-09-28 17:48:41', '25', 'hector');

-- ----------------------------
-- Table structure for `catProveedores`
-- ----------------------------
DROP TABLE IF EXISTS `catProveedores`;
CREATE TABLE `catProveedores` (
  `IdProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(255) DEFAULT NULL,
  `Direccion` text,
  `Fax` varchar(50) DEFAULT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `RFC` varchar(50) DEFAULT NULL,
  `Fecha` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `contacto` text,
  `ciudad` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IdProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catProveedores
-- ----------------------------
INSERT INTO `catProveedores` VALUES ('1', 'IPC', 'xxx', 'none', 'none', 'IPC000000', '2010-09-27 00:00:00', 'ceo@ipc.com', '', '');

-- ----------------------------
-- Table structure for `catUsuarios`
-- ----------------------------
DROP TABLE IF EXISTS `catUsuarios`;
CREATE TABLE `catUsuarios` (
  `iidusuario` int(11) NOT NULL AUTO_INCREMENT,
  `clogin` varchar(64) NOT NULL,
  `cclave` varchar(64) DEFAULT NULL,
  `cnombre` varchar(64) DEFAULT NULL,
  `cacceso` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`iidusuario`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of catUsuarios
-- ----------------------------
INSERT INTO `catUsuarios` VALUES ('1', 'mikem', '123', 'Miguel Mota', 'Administrador');
INSERT INTO `catUsuarios` VALUES ('2', 'peraza', '1234', 'peraza', 'Administrador');

-- ----------------------------
-- Table structure for `confConsFactura`
-- ----------------------------
DROP TABLE IF EXISTS `confConsFactura`;
CREATE TABLE `confConsFactura` (
  `ConsFactura` int(11) DEFAULT NULL,
  `ConsNota` int(11) DEFAULT NULL,
  `ConsPago` int(11) DEFAULT NULL,
  `ConsNotaCred` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confConsFactura
-- ----------------------------
INSERT INTO `confConsFactura` VALUES ('114', '24', '11', '4');

-- ----------------------------
-- Table structure for `confDocsPrint`
-- ----------------------------
DROP TABLE IF EXISTS `confDocsPrint`;
CREATE TABLE `confDocsPrint` (
  `TipoDoc` varchar(50) NOT NULL DEFAULT '',
  `PosNombre` varchar(50) DEFAULT NULL,
  `PosDireccion` varchar(50) DEFAULT NULL,
  `PosCiudad` varchar(50) DEFAULT NULL,
  `PosRFC` varchar(50) DEFAULT NULL,
  `PosNumFact` varchar(50) DEFAULT NULL,
  `PosFecha` varchar(50) DEFAULT NULL,
  `PosCodigo` varchar(50) DEFAULT NULL,
  `PosCantidad` varchar(50) DEFAULT NULL,
  `PosDescripcion` varchar(50) DEFAULT NULL,
  `PosPrecio` varchar(50) DEFAULT NULL,
  `PosTotal` varchar(50) DEFAULT NULL,
  `PosSubtotal` varchar(50) DEFAULT NULL,
  `PosIVA` varchar(50) DEFAULT NULL,
  `PosGTotal` varchar(50) DEFAULT NULL,
  `PosGTotalLetras` varchar(50) DEFAULT NULL,
  `EspacioDetalle` varchar(50) DEFAULT NULL,
  `TamanioLetra` varchar(50) DEFAULT NULL,
  `Leyenda` text,
  `mensaje` varchar(50) DEFAULT NULL,
  `PosCadenaOriginal` varchar(50) DEFAULT NULL,
  `PosSello` varchar(50) DEFAULT NULL,
  `EncabezadoNota` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`TipoDoc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confDocsPrint
-- ----------------------------
INSERT INTO `confDocsPrint` VALUES ('001', '150,173', '147,205', '140,240', '640,173', '710,118', '550,240', '-1,-1', '45,320', '150,320', '530,320', '670,320', '670,900', '670,928', '670,960', '45,910', '12', '7', 'IPC', '....', '45,710', '45,810', '');
INSERT INTO `confDocsPrint` VALUES ('002', '10,110', '-1,-1', '-1,-1', '-1,-1', '190,130', '5,130', '1,150', '80,150', '120,150', '-1,-1', '230,150', '190,-2', '190,-2', '190,-2', '3,-2', '10', '8', 'AUTOREFACCIONARIA GONZALEZ', 'GRACIAS POR SU COMPRA', '-1,-1', '-1,-1', 'RICARDO ARIEL PERAZA ALEJOS|PEAR720718AW5|CURP PEAR720718HYNRLC02|CALLE 16 X 13 Y 15 NUM 89 B CHUMINOPOLIS YUCATAN 97158|Depto. 3 x 20  C.P 97175|Otra linea mas|Tel 9991671111');
INSERT INTO `confDocsPrint` VALUES ('003', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '0,0', '15', '7', 'Su empresa', '....', '-1,-1', '-1,-1', '');
INSERT INTO `confDocsPrint` VALUES ('NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', null, null, null);

-- ----------------------------
-- Table structure for `confEacturaElectronica`
-- ----------------------------
DROP TABLE IF EXISTS `confEacturaElectronica`;
CREATE TABLE `confEacturaElectronica` (
  `iidconfsystem` int(11) NOT NULL,
  `Version` varchar(16) DEFAULT NULL,
  `Serie` varchar(256) DEFAULT NULL,
  `Numero_de_Aprobacion` varchar(256) DEFAULT NULL,
  `Anio_Aprobacion` varchar(256) DEFAULT NULL,
  `Tipo_de_Comprobante` varchar(256) DEFAULT NULL,
  `RFC` varchar(256) DEFAULT NULL,
  `Razon_Social` varchar(256) DEFAULT NULL,
  `Calle` varchar(256) DEFAULT NULL,
  `Numero_Exterior` varchar(256) DEFAULT NULL,
  `Numero_Interior` varchar(256) DEFAULT NULL,
  `Colonia` varchar(256) DEFAULT NULL,
  `Localidad` varchar(256) DEFAULT NULL,
  `Referencia` varchar(256) DEFAULT NULL,
  `Municipio` varchar(256) DEFAULT NULL,
  `Estado` varchar(256) DEFAULT NULL,
  `Pais` varchar(256) DEFAULT NULL,
  `Codigo_Postal` varchar(256) DEFAULT NULL,
  `Numero_Certificado` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`iidconfsystem`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confEacturaElectronica
-- ----------------------------
INSERT INTO `confEacturaElectronica` VALUES ('1', '2.0', 'A', '49', '2008', 'ingreso', 'PEAR720718AW5', 'RICARDO ARIEL PERAZA ALEJOS', '29', '329', '329', 'Chuminopolis', 'Merida', '', 'Merida', 'Yucatan', 'Mexico', '97117', '20001000000100000377');

-- ----------------------------
-- Table structure for `confSystem`
-- ----------------------------
DROP TABLE IF EXISTS `confSystem`;
CREATE TABLE `confSystem` (
  `iidconfsystem` int(11) NOT NULL AUTO_INCREMENT,
  `CodTienda` varchar(50) NOT NULL,
  `IVA` varchar(50) DEFAULT NULL,
  `ClienteNotas` varchar(50) DEFAULT NULL,
  `clave` varchar(50) DEFAULT NULL,
  `CopiasFactura` int(11) DEFAULT NULL,
  `UsarIvaPorArtic` int(11) DEFAULT NULL,
  `ModeDocs` int(11) DEFAULT NULL,
  `DesglosarIva` int(11) DEFAULT NULL,
  `UsarFactElec` int(11) DEFAULT '0',
  `UsarExistencia0` int(11) DEFAULT '0',
  PRIMARY KEY (`iidconfsystem`,`CodTienda`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of confSystem
-- ----------------------------
INSERT INTO `confSystem` VALUES ('1', '001', '0.16', 'CLIENTE DE MOSTRADOR', null, '1', '1', '1', '1', '0', '1');

-- ----------------------------
-- Table structure for `detConsolidacionFactura`
-- ----------------------------
DROP TABLE IF EXISTS `detConsolidacionFactura`;
CREATE TABLE `detConsolidacionFactura` (
  `iidconsolidacion` int(11) NOT NULL,
  `iidnota` int(11) NOT NULL,
  PRIMARY KEY (`iidconsolidacion`,`iidnota`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detConsolidacionFactura
-- ----------------------------
INSERT INTO `detConsolidacionFactura` VALUES ('14', '10');

-- ----------------------------
-- Table structure for `detCorte`
-- ----------------------------
DROP TABLE IF EXISTS `detCorte`;
CREATE TABLE `detCorte` (
  `iidDetCorte` int(11) NOT NULL AUTO_INCREMENT,
  `iidCorte` int(11) NOT NULL,
  `IdFactura` int(11) NOT NULL,
  `cNumero` varchar(50) DEFAULT NULL,
  `dtFecha` datetime DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `esfactura` int(1) NOT NULL,
  PRIMARY KEY (`iidDetCorte`,`iidCorte`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detCorte
-- ----------------------------
INSERT INTO `detCorte` VALUES ('73', '23', '1', '4', '2010-09-27 15:54:01', '25.3', '1');
INSERT INTO `detCorte` VALUES ('74', '23', '2', '5', '2010-09-27 16:06:58', '37.95', '1');
INSERT INTO `detCorte` VALUES ('75', '23', '3', '6', '2010-09-27 16:31:17', '6.32', '1');
INSERT INTO `detCorte` VALUES ('76', '23', '4', '7', '2010-09-27 16:32:45', '18.98', '1');
INSERT INTO `detCorte` VALUES ('77', '23', '5', '8', '2010-09-27 16:33:43', '6.32', '1');
INSERT INTO `detCorte` VALUES ('78', '23', '7', '18', '2010-09-27 23:58:55', '32.78', '1');
INSERT INTO `detCorte` VALUES ('79', '23', '8', '19', '2010-09-28 00:24:51', '6.32', '1');
INSERT INTO `detCorte` VALUES ('80', '23', '9', '20', '2010-09-28 09:00:40', '32.78', '1');
INSERT INTO `detCorte` VALUES ('81', '23', '1', '2', '2010-09-27 16:13:41', '6.32', '0');
INSERT INTO `detCorte` VALUES ('82', '23', '2', '3', '2010-09-27 23:59:34', '6.32', '0');
INSERT INTO `detCorte` VALUES ('83', '23', '3', '4', '2010-09-28 00:26:12', '6.32', '0');
INSERT INTO `detCorte` VALUES ('84', '24', '10', '21', '2010-09-28 10:31:22', '6.32', '1');
INSERT INTO `detCorte` VALUES ('85', '25', '4', '5', '2010-09-28 10:32:04', '26.45', '0');
INSERT INTO `detCorte` VALUES ('86', '26', '11', '22', '2010-09-28 11:16:15', '5543', '1');
INSERT INTO `detCorte` VALUES ('87', '26', '12', '23', '2010-09-28 11:34:18', '1955', '1');
INSERT INTO `detCorte` VALUES ('88', '26', '13', '24', '2010-09-28 11:38:44', '195.5', '1');
INSERT INTO `detCorte` VALUES ('89', '27', '14', '25', '2010-09-29 08:45:42', '1265', '1');
INSERT INTO `detCorte` VALUES ('90', '27', '5', '6', '2010-09-28 15:29:20', '58.08', '0');
INSERT INTO `detCorte` VALUES ('91', '28', '76', '65', '2010-10-04 13:22:54', '32.78', '1');
INSERT INTO `detCorte` VALUES ('92', '28', '78', '67', '2010-10-04 16:12:55', '1955', '1');
INSERT INTO `detCorte` VALUES ('94', '29', '77', '66', '2010-10-04 13:53:36', '270.82', '1');
INSERT INTO `detCorte` VALUES ('95', '29', '79', '68', '2010-10-04 16:32:01', '96.02', '1');
INSERT INTO `detCorte` VALUES ('96', '29', '80', '69', '2010-10-04 16:48:16', '466.56', '1');
INSERT INTO `detCorte` VALUES ('98', '29', '90', '86', '2010-10-14 17:24:28', '6.32', '1');
INSERT INTO `detCorte` VALUES ('99', '29', '96', '92', '2010-10-14 18:02:51', '6.32', '1');
INSERT INTO `detCorte` VALUES ('101', '30', '113', '110', '2010-10-14 19:15:50', '198.44', '1');
INSERT INTO `detCorte` VALUES ('102', '30', '122', '113', '2010-12-27 23:23:56', '1385.75', '1');
INSERT INTO `detCorte` VALUES ('105', '30', '3', '', '2010-11-25 22:43:22', '8.98', '2');
INSERT INTO `detCorte` VALUES ('106', '30', '4', '', '2010-11-25 22:44:41', '2', '2');
INSERT INTO `detCorte` VALUES ('107', '30', '5', '', '2010-11-25 22:44:57', '-2', '2');
INSERT INTO `detCorte` VALUES ('108', '31', '84', '73', '2010-10-04 17:30:15', '32.78', '1');
INSERT INTO `detCorte` VALUES ('109', '31', '109', '106', '2010-10-14 18:45:46', '172.82', '1');
INSERT INTO `detCorte` VALUES ('110', '31', '9', '15', '2010-10-04 13:48:05', '32.78', '0');
INSERT INTO `detCorte` VALUES ('111', '31', '1', '', '2010-11-25 21:51:28', '1500', '2');
INSERT INTO `detCorte` VALUES ('112', '31', '2', '', '2010-11-25 21:51:28', '-200', '2');

-- ----------------------------
-- Table structure for `detFactura`
-- ----------------------------
DROP TABLE IF EXISTS `detFactura`;
CREATE TABLE `detFactura` (
  `IdDetFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdFactura` int(11) NOT NULL DEFAULT '0',
  `IdProducto` int(11) NOT NULL DEFAULT '0',
  `PrecioOriginal` float DEFAULT NULL,
  `PrecioDescuento` float DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `PrecioCalculado` float DEFAULT NULL,
  `DescuentoAplicado` float DEFAULT NULL,
  `unidaddeventa` varchar(50) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdDetFactura`,`IdFactura`,`IdProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detFactura
-- ----------------------------
INSERT INTO `detFactura` VALUES ('123', '76', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('124', '76', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('125', '77', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('126', '77', '2', '23', '23', '10', '230', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('127', '78', '1', '5.5', '5.5', '100', '550', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('128', '78', '2', '23', '23', '50', '1150', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('129', '79', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('130', '79', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('131', '79', '3', '55', '55', '1', '55', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('132', '80', '4619', '89', '89', '1', '89', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('133', '80', '4631', '101.06', '101.06', '1', '101.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('134', '80', '4634', '90.06', '90.06', '1', '90.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('135', '80', '4648', '122.09', '122.09', '1', '122.09', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('136', '81', '4622', '92', '92', '1', '92', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('137', '81', '4631', '101.06', '101.06', '0.5', '50.53', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('138', '81', '4627', '80.01', '80.01', '1', '80.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('139', '81', '4646', '110.04', '110.04', '0.5', '55.02', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('140', '82', '4634', '90.06', '90.06', '0.5', '45.03', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('141', '82', '4635', '89.03', '89.03', '0.5', '44.51', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('142', '83', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('143', '83', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('144', '84', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('145', '84', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detFactura` VALUES ('146', '85', '4629', '70.05', '70.05', '1', '70.05', '0', '', '16');
INSERT INTO `detFactura` VALUES ('147', '85', '4635', '89.03', '89.03', '1', '89.03', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('148', '86', '4627', '80.01', '80.01', '1', '80.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('149', '87', '4619', '89', '89', '1', '89', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('150', '88', '4633', '92.04', '92.04', '1', '92.04', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('151', '89', '4629', '70.05', '70.05', '1', '70.05', '0', '', '16');
INSERT INTO `detFactura` VALUES ('152', '90', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('158', '96', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('164', '102', '3', '55', '55', '1', '55', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('165', '103', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('166', '104', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('167', '105', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('168', '106', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('169', '107', '4622', '92', '92', '0.5', '46', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('170', '107', '4629', '70.05', '70.05', '1', '70.05', '0', '', '16');
INSERT INTO `detFactura` VALUES ('171', '107', '4626', '81.03', '81.03', '1', '81.03', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('172', '108', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('173', '109', '3', '55', '55', '1', '55', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('174', '109', '4619', '89', '89', '1', '89', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('175', '109', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('176', '110', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('177', '110', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('178', '111', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('179', '111', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('180', '112', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('181', '112', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('182', '113', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('183', '113', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('184', '114', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('185', '114', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('186', '115', '4624', '79.06', '79.06', '1', '79.06', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('187', '115', '4632', '92.01', '92.01', '1', '92.01', '0', 'Kg', '16');
INSERT INTO `detFactura` VALUES ('198', '122', '1', '5.5', '5.5', '10', '55', '0', 'Pza', '15');
INSERT INTO `detFactura` VALUES ('199', '122', '2', '23', '23', '50', '1150', '0', 'pza', '15');

-- ----------------------------
-- Table structure for `detFacturasProv`
-- ----------------------------
DROP TABLE IF EXISTS `detFacturasProv`;
CREATE TABLE `detFacturasProv` (
  `IdDetFacturaProv` int(11) NOT NULL AUTO_INCREMENT,
  `IdProveedor` int(11) NOT NULL,
  `Numero` varchar(50) NOT NULL,
  `Fecha` datetime DEFAULT NULL,
  `TotalFactura` float DEFAULT NULL,
  `Pagado` float DEFAULT NULL,
  `FechaPago` datetime DEFAULT NULL,
  PRIMARY KEY (`IdDetFacturaProv`,`IdProveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detFacturasProv
-- ----------------------------
INSERT INTO `detFacturasProv` VALUES ('1', '1', 'F0001', '2010-09-27 15:30:29', '1500', '800', '2010-09-27 15:30:29');
INSERT INTO `detFacturasProv` VALUES ('2', '1', 'F0002', '2010-09-27 17:59:46', '5000', '500', '2010-09-27 17:59:46');

-- ----------------------------
-- Table structure for `detNota`
-- ----------------------------
DROP TABLE IF EXISTS `detNota`;
CREATE TABLE `detNota` (
  `IdDetFactura` int(11) NOT NULL AUTO_INCREMENT,
  `IdFactura` int(11) NOT NULL,
  `IdProducto` int(11) DEFAULT NULL,
  `PrecioOriginal` float DEFAULT NULL,
  `PrecioDescuento` float DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `PrecioCalculado` float DEFAULT NULL,
  `DescuentoAplicado` float DEFAULT NULL,
  `unidaddeventa` varchar(50) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdDetFactura`,`IdFactura`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detNota
-- ----------------------------
INSERT INTO `detNota` VALUES ('10', '9', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('11', '9', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detNota` VALUES ('12', '10', '1', '5.5', '5.5', '10', '55', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('13', '10', '2', '23', '23', '50', '1150', '0', 'pza', '15');
INSERT INTO `detNota` VALUES ('14', '11', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('15', '11', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detNota` VALUES ('16', '12', '2', '23', '23', '1', '23', '0', 'pza', '15');
INSERT INTO `detNota` VALUES ('17', '13', '4627', '80.01', '80.01', '1.5', '120.02', '0', 'Kg', '16');
INSERT INTO `detNota` VALUES ('18', '13', '4657', '25', '25', '2', '50', '0', 'Kg', '16');
INSERT INTO `detNota` VALUES ('19', '14', '1', '5.5', '5.5', '1', '5.5', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('20', '15', '1', '5.5', '5.5', '2', '11', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('21', '16', '1', '5.5', '5.5', '3', '16.5', '0', 'Pza', '15');
INSERT INTO `detNota` VALUES ('22', '17', '1', '5.5', '5.5', '5', '27.5', '0', 'Pza', '15');

-- ----------------------------
-- Table structure for `detPagosFacturas`
-- ----------------------------
DROP TABLE IF EXISTS `detPagosFacturas`;
CREATE TABLE `detPagosFacturas` (
  `IdPago` int(11) NOT NULL AUTO_INCREMENT,
  `esfactura` int(11) NOT NULL DEFAULT '1',
  `IdFactura` int(11) NOT NULL,
  `NumeroPago` varchar(50) DEFAULT NULL,
  `FechaPago` datetime DEFAULT NULL,
  `Cantidad` float DEFAULT NULL,
  `Observaciones` varchar(128) DEFAULT NULL,
  `TipoPago` int(11) DEFAULT NULL,
  `cancelado` int(11) DEFAULT '0',
  `numeronotacred` int(11) DEFAULT NULL,
  PRIMARY KEY (`IdPago`,`esfactura`,`IdFactura`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of detPagosFacturas
-- ----------------------------
INSERT INTO `detPagosFacturas` VALUES ('2', '1', '2', '1', '2010-09-27 16:13:13', '5', '', '0', '0', null);
INSERT INTO `detPagosFacturas` VALUES ('3', '0', '13', '4', '2010-11-20 23:27:34', '97.22', '-----------------', '0', '0', null);
INSERT INTO `detPagosFacturas` VALUES ('4', '1', '111', '5', '2010-11-21 23:44:23', '18.44', '', '1', '0', null);
INSERT INTO `detPagosFacturas` VALUES ('5', '0', '13', '6', '2010-11-21 23:44:56', '50', '', '0', '0', null);
INSERT INTO `detPagosFacturas` VALUES ('6', '0', '13', '7', '2010-11-22 23:45:07', '10', '', '0', '1', null);
INSERT INTO `detPagosFacturas` VALUES ('7', '0', '16', '8', '2010-11-25 22:43:22', '8.98', 'Observaciones', '0', '0', null);
INSERT INTO `detPagosFacturas` VALUES ('8', '0', '16', '9', '2010-11-25 22:44:41', '2', '', '0', '1', null);
INSERT INTO `detPagosFacturas` VALUES ('9', '1', '111', '10', '2011-01-30 23:20:37', '116', 'Anticipo aplicado', '1', '0', '1');

-- ----------------------------
-- Table structure for `hoja2$_erroresdeimportación`
-- ----------------------------
DROP TABLE IF EXISTS `hoja2$_erroresdeimportación`;
CREATE TABLE `hoja2$_erroresdeimportación` (
  `Campo` varchar(255) DEFAULT NULL,
  `Error` varchar(255) DEFAULT NULL,
  `Fila` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of hoja2$_erroresdeimportación
-- ----------------------------

-- ----------------------------
-- Table structure for `relProductoProveedor`
-- ----------------------------
DROP TABLE IF EXISTS `relProductoProveedor`;
CREATE TABLE `relProductoProveedor` (
  `IdProducto` int(11) NOT NULL,
  `IdProveedor` int(11) NOT NULL,
  PRIMARY KEY (`IdProducto`,`IdProveedor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of relProductoProveedor
-- ----------------------------
INSERT INTO `relProductoProveedor` VALUES ('1', '2');
INSERT INTO `relProductoProveedor` VALUES ('2', '1');
INSERT INTO `relProductoProveedor` VALUES ('3', '1');
INSERT INTO `relProductoProveedor` VALUES ('4', '2');
INSERT INTO `relProductoProveedor` VALUES ('4', '3');
INSERT INTO `relProductoProveedor` VALUES ('4', '4');
INSERT INTO `relProductoProveedor` VALUES ('5', '2');
INSERT INTO `relProductoProveedor` VALUES ('5', '3');
INSERT INTO `relProductoProveedor` VALUES ('6', '3');
INSERT INTO `relProductoProveedor` VALUES ('7', '2');
INSERT INTO `relProductoProveedor` VALUES ('9', '2');
INSERT INTO `relProductoProveedor` VALUES ('10', '3');
INSERT INTO `relProductoProveedor` VALUES ('11', '3');
INSERT INTO `relProductoProveedor` VALUES ('12', '3');
INSERT INTO `relProductoProveedor` VALUES ('12', '4');
INSERT INTO `relProductoProveedor` VALUES ('13', '3');
INSERT INTO `relProductoProveedor` VALUES ('13', '4');
INSERT INTO `relProductoProveedor` VALUES ('14', '3');
INSERT INTO `relProductoProveedor` VALUES ('14', '4');
INSERT INTO `relProductoProveedor` VALUES ('15', '3');
INSERT INTO `relProductoProveedor` VALUES ('16', '5');
INSERT INTO `relProductoProveedor` VALUES ('16', '6');
INSERT INTO `relProductoProveedor` VALUES ('17', '5');
INSERT INTO `relProductoProveedor` VALUES ('17', '6');
INSERT INTO `relProductoProveedor` VALUES ('18', '7');
INSERT INTO `relProductoProveedor` VALUES ('19', '7');
INSERT INTO `relProductoProveedor` VALUES ('20', '4');
INSERT INTO `relProductoProveedor` VALUES ('21', '4');
INSERT INTO `relProductoProveedor` VALUES ('22', '4');
INSERT INTO `relProductoProveedor` VALUES ('23', '9');
INSERT INTO `relProductoProveedor` VALUES ('24', '9');
INSERT INTO `relProductoProveedor` VALUES ('25', '3');
INSERT INTO `relProductoProveedor` VALUES ('26', '6');
INSERT INTO `relProductoProveedor` VALUES ('27', '6');
INSERT INTO `relProductoProveedor` VALUES ('28', '4');
INSERT INTO `relProductoProveedor` VALUES ('29', '4');
INSERT INTO `relProductoProveedor` VALUES ('30', '4');
INSERT INTO `relProductoProveedor` VALUES ('31', '4');
INSERT INTO `relProductoProveedor` VALUES ('32', '2');
INSERT INTO `relProductoProveedor` VALUES ('33', '2');
INSERT INTO `relProductoProveedor` VALUES ('34', '2');
INSERT INTO `relProductoProveedor` VALUES ('35', '3');
INSERT INTO `relProductoProveedor` VALUES ('35', '4');
INSERT INTO `relProductoProveedor` VALUES ('35', '9');
INSERT INTO `relProductoProveedor` VALUES ('36', '3');
INSERT INTO `relProductoProveedor` VALUES ('36', '4');
INSERT INTO `relProductoProveedor` VALUES ('36', '9');
INSERT INTO `relProductoProveedor` VALUES ('37', '3');
INSERT INTO `relProductoProveedor` VALUES ('37', '4');
INSERT INTO `relProductoProveedor` VALUES ('37', '9');
INSERT INTO `relProductoProveedor` VALUES ('38', '3');
INSERT INTO `relProductoProveedor` VALUES ('38', '4');
INSERT INTO `relProductoProveedor` VALUES ('38', '9');
INSERT INTO `relProductoProveedor` VALUES ('39', '3');
INSERT INTO `relProductoProveedor` VALUES ('39', '4');
INSERT INTO `relProductoProveedor` VALUES ('39', '9');
INSERT INTO `relProductoProveedor` VALUES ('40', '3');
INSERT INTO `relProductoProveedor` VALUES ('40', '4');
INSERT INTO `relProductoProveedor` VALUES ('40', '9');
INSERT INTO `relProductoProveedor` VALUES ('41', '3');
INSERT INTO `relProductoProveedor` VALUES ('41', '4');
INSERT INTO `relProductoProveedor` VALUES ('41', '9');
INSERT INTO `relProductoProveedor` VALUES ('43', '3');
INSERT INTO `relProductoProveedor` VALUES ('43', '4');
INSERT INTO `relProductoProveedor` VALUES ('43', '9');
INSERT INTO `relProductoProveedor` VALUES ('44', '3');
INSERT INTO `relProductoProveedor` VALUES ('44', '4');
INSERT INTO `relProductoProveedor` VALUES ('44', '9');
INSERT INTO `relProductoProveedor` VALUES ('45', '2');
INSERT INTO `relProductoProveedor` VALUES ('46', '5');
INSERT INTO `relProductoProveedor` VALUES ('46', '6');
INSERT INTO `relProductoProveedor` VALUES ('47', '4');
INSERT INTO `relProductoProveedor` VALUES ('48', '4');
INSERT INTO `relProductoProveedor` VALUES ('49', '10');
INSERT INTO `relProductoProveedor` VALUES ('50', '2');
INSERT INTO `relProductoProveedor` VALUES ('50', '3');
INSERT INTO `relProductoProveedor` VALUES ('51', '2');
INSERT INTO `relProductoProveedor` VALUES ('51', '3');
INSERT INTO `relProductoProveedor` VALUES ('51', '4');
INSERT INTO `relProductoProveedor` VALUES ('52', '10');
INSERT INTO `relProductoProveedor` VALUES ('53', '2');
INSERT INTO `relProductoProveedor` VALUES ('53', '3');
INSERT INTO `relProductoProveedor` VALUES ('54', '2');
INSERT INTO `relProductoProveedor` VALUES ('54', '4');
INSERT INTO `relProductoProveedor` VALUES ('55', '2');
INSERT INTO `relProductoProveedor` VALUES ('55', '4');
INSERT INTO `relProductoProveedor` VALUES ('56', '2');
INSERT INTO `relProductoProveedor` VALUES ('57', '3');
INSERT INTO `relProductoProveedor` VALUES ('58', '11');
INSERT INTO `relProductoProveedor` VALUES ('59', '11');
INSERT INTO `relProductoProveedor` VALUES ('60', '11');
INSERT INTO `relProductoProveedor` VALUES ('61', '11');
INSERT INTO `relProductoProveedor` VALUES ('62', '4');
INSERT INTO `relProductoProveedor` VALUES ('63', '12');
INSERT INTO `relProductoProveedor` VALUES ('64', '3');
INSERT INTO `relProductoProveedor` VALUES ('65', '9');
INSERT INTO `relProductoProveedor` VALUES ('66', '12');
INSERT INTO `relProductoProveedor` VALUES ('67', '2');
INSERT INTO `relProductoProveedor` VALUES ('68', '13');
INSERT INTO `relProductoProveedor` VALUES ('69', '4');
INSERT INTO `relProductoProveedor` VALUES ('76', '2');
INSERT INTO `relProductoProveedor` VALUES ('76', '4');
INSERT INTO `relProductoProveedor` VALUES ('78', '3');
INSERT INTO `relProductoProveedor` VALUES ('78', '4');
INSERT INTO `relProductoProveedor` VALUES ('79', '2');
INSERT INTO `relProductoProveedor` VALUES ('80', '2');
INSERT INTO `relProductoProveedor` VALUES ('81', '2');
INSERT INTO `relProductoProveedor` VALUES ('82', '2');
INSERT INTO `relProductoProveedor` VALUES ('83', '10');
INSERT INTO `relProductoProveedor` VALUES ('84', '14');
INSERT INTO `relProductoProveedor` VALUES ('85', '14');
INSERT INTO `relProductoProveedor` VALUES ('86', '11');
INSERT INTO `relProductoProveedor` VALUES ('87', '11');
INSERT INTO `relProductoProveedor` VALUES ('88', '2');
INSERT INTO `relProductoProveedor` VALUES ('88', '11');
INSERT INTO `relProductoProveedor` VALUES ('89', '11');
INSERT INTO `relProductoProveedor` VALUES ('90', '2');
INSERT INTO `relProductoProveedor` VALUES ('90', '11');
INSERT INTO `relProductoProveedor` VALUES ('91', '3');
INSERT INTO `relProductoProveedor` VALUES ('91', '4');
INSERT INTO `relProductoProveedor` VALUES ('91', '15');
INSERT INTO `relProductoProveedor` VALUES ('92', '3');
INSERT INTO `relProductoProveedor` VALUES ('92', '4');
INSERT INTO `relProductoProveedor` VALUES ('93', '2');
INSERT INTO `relProductoProveedor` VALUES ('93', '3');
INSERT INTO `relProductoProveedor` VALUES ('93', '4');
INSERT INTO `relProductoProveedor` VALUES ('94', '3');
INSERT INTO `relProductoProveedor` VALUES ('94', '4');
INSERT INTO `relProductoProveedor` VALUES ('95', '3');
INSERT INTO `relProductoProveedor` VALUES ('95', '4');
INSERT INTO `relProductoProveedor` VALUES ('95', '15');
INSERT INTO `relProductoProveedor` VALUES ('96', '3');
INSERT INTO `relProductoProveedor` VALUES ('96', '4');
INSERT INTO `relProductoProveedor` VALUES ('96', '15');
INSERT INTO `relProductoProveedor` VALUES ('97', '3');
INSERT INTO `relProductoProveedor` VALUES ('97', '4');
INSERT INTO `relProductoProveedor` VALUES ('97', '15');
INSERT INTO `relProductoProveedor` VALUES ('98', '3');
INSERT INTO `relProductoProveedor` VALUES ('98', '4');
INSERT INTO `relProductoProveedor` VALUES ('99', '3');
INSERT INTO `relProductoProveedor` VALUES ('100', '2');
INSERT INTO `relProductoProveedor` VALUES ('100', '3');
INSERT INTO `relProductoProveedor` VALUES ('100', '4');
INSERT INTO `relProductoProveedor` VALUES ('101', '3');
INSERT INTO `relProductoProveedor` VALUES ('101', '4');
INSERT INTO `relProductoProveedor` VALUES ('101', '15');
INSERT INTO `relProductoProveedor` VALUES ('102', '3');
INSERT INTO `relProductoProveedor` VALUES ('102', '4');
INSERT INTO `relProductoProveedor` VALUES ('102', '15');
INSERT INTO `relProductoProveedor` VALUES ('103', '3');
INSERT INTO `relProductoProveedor` VALUES ('103', '4');
INSERT INTO `relProductoProveedor` VALUES ('103', '15');
INSERT INTO `relProductoProveedor` VALUES ('104', '3');
INSERT INTO `relProductoProveedor` VALUES ('104', '4');
INSERT INTO `relProductoProveedor` VALUES ('104', '15');
INSERT INTO `relProductoProveedor` VALUES ('105', '3');
INSERT INTO `relProductoProveedor` VALUES ('105', '4');
INSERT INTO `relProductoProveedor` VALUES ('105', '15');
INSERT INTO `relProductoProveedor` VALUES ('106', '3');
INSERT INTO `relProductoProveedor` VALUES ('106', '4');
INSERT INTO `relProductoProveedor` VALUES ('106', '15');
INSERT INTO `relProductoProveedor` VALUES ('107', '10');
INSERT INTO `relProductoProveedor` VALUES ('108', '2');
INSERT INTO `relProductoProveedor` VALUES ('109', '2');
INSERT INTO `relProductoProveedor` VALUES ('109', '4');
INSERT INTO `relProductoProveedor` VALUES ('109', '16');
INSERT INTO `relProductoProveedor` VALUES ('110', '3');
INSERT INTO `relProductoProveedor` VALUES ('111', '15');
INSERT INTO `relProductoProveedor` VALUES ('112', '15');
INSERT INTO `relProductoProveedor` VALUES ('113', '14');
INSERT INTO `relProductoProveedor` VALUES ('114', '14');
INSERT INTO `relProductoProveedor` VALUES ('115', '14');
INSERT INTO `relProductoProveedor` VALUES ('116', '14');
INSERT INTO `relProductoProveedor` VALUES ('117', '4');
INSERT INTO `relProductoProveedor` VALUES ('118', '4');
INSERT INTO `relProductoProveedor` VALUES ('119', '9');
INSERT INTO `relProductoProveedor` VALUES ('120', '7');
INSERT INTO `relProductoProveedor` VALUES ('122', '6');
INSERT INTO `relProductoProveedor` VALUES ('123', '2');
INSERT INTO `relProductoProveedor` VALUES ('124', '2');
INSERT INTO `relProductoProveedor` VALUES ('125', '2');
INSERT INTO `relProductoProveedor` VALUES ('126', '17');
INSERT INTO `relProductoProveedor` VALUES ('127', '17');
INSERT INTO `relProductoProveedor` VALUES ('128', '17');
INSERT INTO `relProductoProveedor` VALUES ('129', '17');
INSERT INTO `relProductoProveedor` VALUES ('130', '17');
INSERT INTO `relProductoProveedor` VALUES ('131', '17');
INSERT INTO `relProductoProveedor` VALUES ('132', '17');
INSERT INTO `relProductoProveedor` VALUES ('133', '18');
INSERT INTO `relProductoProveedor` VALUES ('134', '18');
INSERT INTO `relProductoProveedor` VALUES ('135', '18');
INSERT INTO `relProductoProveedor` VALUES ('136', '17');
INSERT INTO `relProductoProveedor` VALUES ('137', '17');
INSERT INTO `relProductoProveedor` VALUES ('138', '17');
INSERT INTO `relProductoProveedor` VALUES ('139', '17');
INSERT INTO `relProductoProveedor` VALUES ('140', '17');
INSERT INTO `relProductoProveedor` VALUES ('140', '18');
INSERT INTO `relProductoProveedor` VALUES ('141', '17');
INSERT INTO `relProductoProveedor` VALUES ('141', '18');
INSERT INTO `relProductoProveedor` VALUES ('142', '17');
INSERT INTO `relProductoProveedor` VALUES ('142', '18');
INSERT INTO `relProductoProveedor` VALUES ('143', '17');
INSERT INTO `relProductoProveedor` VALUES ('143', '18');
INSERT INTO `relProductoProveedor` VALUES ('144', '17');
INSERT INTO `relProductoProveedor` VALUES ('144', '18');
INSERT INTO `relProductoProveedor` VALUES ('145', '17');
INSERT INTO `relProductoProveedor` VALUES ('145', '18');
INSERT INTO `relProductoProveedor` VALUES ('146', '17');
INSERT INTO `relProductoProveedor` VALUES ('146', '18');
INSERT INTO `relProductoProveedor` VALUES ('147', '17');
INSERT INTO `relProductoProveedor` VALUES ('147', '18');
INSERT INTO `relProductoProveedor` VALUES ('148', '17');
INSERT INTO `relProductoProveedor` VALUES ('148', '18');
INSERT INTO `relProductoProveedor` VALUES ('149', '17');
INSERT INTO `relProductoProveedor` VALUES ('149', '19');
INSERT INTO `relProductoProveedor` VALUES ('150', '17');
INSERT INTO `relProductoProveedor` VALUES ('150', '19');
INSERT INTO `relProductoProveedor` VALUES ('153', '20');
INSERT INTO `relProductoProveedor` VALUES ('154', '3');
INSERT INTO `relProductoProveedor` VALUES ('154', '4');
INSERT INTO `relProductoProveedor` VALUES ('155', '3');
INSERT INTO `relProductoProveedor` VALUES ('155', '4');
INSERT INTO `relProductoProveedor` VALUES ('156', '3');
INSERT INTO `relProductoProveedor` VALUES ('156', '4');
INSERT INTO `relProductoProveedor` VALUES ('157', '21');
INSERT INTO `relProductoProveedor` VALUES ('158', '3');
INSERT INTO `relProductoProveedor` VALUES ('159', '2');
INSERT INTO `relProductoProveedor` VALUES ('159', '3');
INSERT INTO `relProductoProveedor` VALUES ('160', '2');
INSERT INTO `relProductoProveedor` VALUES ('160', '3');
INSERT INTO `relProductoProveedor` VALUES ('160', '4');
INSERT INTO `relProductoProveedor` VALUES ('161', '2');
INSERT INTO `relProductoProveedor` VALUES ('162', '3');
INSERT INTO `relProductoProveedor` VALUES ('163', '3');
INSERT INTO `relProductoProveedor` VALUES ('164', '3');
INSERT INTO `relProductoProveedor` VALUES ('165', '3');
INSERT INTO `relProductoProveedor` VALUES ('166', '2');
INSERT INTO `relProductoProveedor` VALUES ('166', '3');
INSERT INTO `relProductoProveedor` VALUES ('166', '4');
INSERT INTO `relProductoProveedor` VALUES ('167', '2');
INSERT INTO `relProductoProveedor` VALUES ('167', '3');
INSERT INTO `relProductoProveedor` VALUES ('169', '3');
INSERT INTO `relProductoProveedor` VALUES ('170', '3');
INSERT INTO `relProductoProveedor` VALUES ('171', '3');
INSERT INTO `relProductoProveedor` VALUES ('172', '3');
INSERT INTO `relProductoProveedor` VALUES ('173', '2');
INSERT INTO `relProductoProveedor` VALUES ('174', '2');
INSERT INTO `relProductoProveedor` VALUES ('176', '7');
INSERT INTO `relProductoProveedor` VALUES ('177', '7');
INSERT INTO `relProductoProveedor` VALUES ('178', '2');
INSERT INTO `relProductoProveedor` VALUES ('179', '2');
INSERT INTO `relProductoProveedor` VALUES ('180', '2');
INSERT INTO `relProductoProveedor` VALUES ('181', '20');
INSERT INTO `relProductoProveedor` VALUES ('182', '20');
INSERT INTO `relProductoProveedor` VALUES ('183', '4');
INSERT INTO `relProductoProveedor` VALUES ('184', '2');
INSERT INTO `relProductoProveedor` VALUES ('184', '4');
INSERT INTO `relProductoProveedor` VALUES ('185', '3');
INSERT INTO `relProductoProveedor` VALUES ('186', '3');
INSERT INTO `relProductoProveedor` VALUES ('187', '9');
INSERT INTO `relProductoProveedor` VALUES ('188', '3');
INSERT INTO `relProductoProveedor` VALUES ('189', '3');
INSERT INTO `relProductoProveedor` VALUES ('190', '3');
INSERT INTO `relProductoProveedor` VALUES ('191', '3');
INSERT INTO `relProductoProveedor` VALUES ('192', '21');
INSERT INTO `relProductoProveedor` VALUES ('193', '22');
INSERT INTO `relProductoProveedor` VALUES ('194', '22');
INSERT INTO `relProductoProveedor` VALUES ('195', '3');
INSERT INTO `relProductoProveedor` VALUES ('195', '22');
INSERT INTO `relProductoProveedor` VALUES ('196', '3');
INSERT INTO `relProductoProveedor` VALUES ('196', '22');
INSERT INTO `relProductoProveedor` VALUES ('197', '3');
INSERT INTO `relProductoProveedor` VALUES ('198', '22');
INSERT INTO `relProductoProveedor` VALUES ('199', '3');
INSERT INTO `relProductoProveedor` VALUES ('199', '22');
INSERT INTO `relProductoProveedor` VALUES ('200', '3');
INSERT INTO `relProductoProveedor` VALUES ('200', '22');
INSERT INTO `relProductoProveedor` VALUES ('201', '21');
INSERT INTO `relProductoProveedor` VALUES ('202', '3');
INSERT INTO `relProductoProveedor` VALUES ('203', '3');
INSERT INTO `relProductoProveedor` VALUES ('204', '22');
INSERT INTO `relProductoProveedor` VALUES ('205', '22');
INSERT INTO `relProductoProveedor` VALUES ('206', '22');
INSERT INTO `relProductoProveedor` VALUES ('207', '3');
INSERT INTO `relProductoProveedor` VALUES ('207', '22');
INSERT INTO `relProductoProveedor` VALUES ('208', '3');
INSERT INTO `relProductoProveedor` VALUES ('209', '20');
INSERT INTO `relProductoProveedor` VALUES ('210', '3');
INSERT INTO `relProductoProveedor` VALUES ('210', '4');
INSERT INTO `relProductoProveedor` VALUES ('211', '12');
INSERT INTO `relProductoProveedor` VALUES ('211', '23');
INSERT INTO `relProductoProveedor` VALUES ('212', '10');
INSERT INTO `relProductoProveedor` VALUES ('213', '24');
INSERT INTO `relProductoProveedor` VALUES ('214', '24');
INSERT INTO `relProductoProveedor` VALUES ('215', '24');
INSERT INTO `relProductoProveedor` VALUES ('216', '24');
INSERT INTO `relProductoProveedor` VALUES ('217', '4');
INSERT INTO `relProductoProveedor` VALUES ('218', '25');
INSERT INTO `relProductoProveedor` VALUES ('219', '25');
INSERT INTO `relProductoProveedor` VALUES ('220', '24');
INSERT INTO `relProductoProveedor` VALUES ('221', '3');
INSERT INTO `relProductoProveedor` VALUES ('221', '4');
INSERT INTO `relProductoProveedor` VALUES ('221', '10');
INSERT INTO `relProductoProveedor` VALUES ('222', '3');
INSERT INTO `relProductoProveedor` VALUES ('223', '3');
INSERT INTO `relProductoProveedor` VALUES ('223', '4');
INSERT INTO `relProductoProveedor` VALUES ('224', '10');
INSERT INTO `relProductoProveedor` VALUES ('225', '3');
INSERT INTO `relProductoProveedor` VALUES ('225', '4');
INSERT INTO `relProductoProveedor` VALUES ('226', '3');
INSERT INTO `relProductoProveedor` VALUES ('226', '4');
INSERT INTO `relProductoProveedor` VALUES ('227', '3');
INSERT INTO `relProductoProveedor` VALUES ('227', '4');
INSERT INTO `relProductoProveedor` VALUES ('227', '10');
INSERT INTO `relProductoProveedor` VALUES ('228', '4');
INSERT INTO `relProductoProveedor` VALUES ('228', '10');
INSERT INTO `relProductoProveedor` VALUES ('229', '3');
INSERT INTO `relProductoProveedor` VALUES ('229', '4');
INSERT INTO `relProductoProveedor` VALUES ('229', '26');
INSERT INTO `relProductoProveedor` VALUES ('230', '2');
INSERT INTO `relProductoProveedor` VALUES ('231', '3');
INSERT INTO `relProductoProveedor` VALUES ('231', '4');
INSERT INTO `relProductoProveedor` VALUES ('231', '26');
INSERT INTO `relProductoProveedor` VALUES ('232', '2');
INSERT INTO `relProductoProveedor` VALUES ('233', '3');
INSERT INTO `relProductoProveedor` VALUES ('233', '4');
INSERT INTO `relProductoProveedor` VALUES ('233', '26');
INSERT INTO `relProductoProveedor` VALUES ('234', '2');
INSERT INTO `relProductoProveedor` VALUES ('234', '3');
INSERT INTO `relProductoProveedor` VALUES ('236', '3');
INSERT INTO `relProductoProveedor` VALUES ('236', '4');
INSERT INTO `relProductoProveedor` VALUES ('236', '26');
INSERT INTO `relProductoProveedor` VALUES ('237', '3');
INSERT INTO `relProductoProveedor` VALUES ('237', '4');
INSERT INTO `relProductoProveedor` VALUES ('237', '26');
INSERT INTO `relProductoProveedor` VALUES ('238', '3');
INSERT INTO `relProductoProveedor` VALUES ('238', '4');
INSERT INTO `relProductoProveedor` VALUES ('238', '26');
INSERT INTO `relProductoProveedor` VALUES ('239', '3');
INSERT INTO `relProductoProveedor` VALUES ('239', '4');
INSERT INTO `relProductoProveedor` VALUES ('239', '26');
INSERT INTO `relProductoProveedor` VALUES ('240', '3');
INSERT INTO `relProductoProveedor` VALUES ('241', '3');
INSERT INTO `relProductoProveedor` VALUES ('241', '4');
INSERT INTO `relProductoProveedor` VALUES ('241', '26');
INSERT INTO `relProductoProveedor` VALUES ('243', '3');
INSERT INTO `relProductoProveedor` VALUES ('243', '4');
INSERT INTO `relProductoProveedor` VALUES ('243', '26');
INSERT INTO `relProductoProveedor` VALUES ('244', '2');
INSERT INTO `relProductoProveedor` VALUES ('244', '3');
INSERT INTO `relProductoProveedor` VALUES ('245', '3');
INSERT INTO `relProductoProveedor` VALUES ('245', '4');
INSERT INTO `relProductoProveedor` VALUES ('245', '26');
INSERT INTO `relProductoProveedor` VALUES ('246', '7');
INSERT INTO `relProductoProveedor` VALUES ('247', '7');
INSERT INTO `relProductoProveedor` VALUES ('248', '2');
INSERT INTO `relProductoProveedor` VALUES ('249', '3');
INSERT INTO `relProductoProveedor` VALUES ('249', '4');
INSERT INTO `relProductoProveedor` VALUES ('250', '3');
INSERT INTO `relProductoProveedor` VALUES ('250', '4');
INSERT INTO `relProductoProveedor` VALUES ('251', '2');
INSERT INTO `relProductoProveedor` VALUES ('251', '3');
INSERT INTO `relProductoProveedor` VALUES ('251', '4');
INSERT INTO `relProductoProveedor` VALUES ('252', '3');
INSERT INTO `relProductoProveedor` VALUES ('252', '4');
INSERT INTO `relProductoProveedor` VALUES ('253', '3');
INSERT INTO `relProductoProveedor` VALUES ('253', '4');
INSERT INTO `relProductoProveedor` VALUES ('254', '3');
INSERT INTO `relProductoProveedor` VALUES ('254', '4');
INSERT INTO `relProductoProveedor` VALUES ('255', '3');
INSERT INTO `relProductoProveedor` VALUES ('256', '3');
INSERT INTO `relProductoProveedor` VALUES ('256', '4');
INSERT INTO `relProductoProveedor` VALUES ('257', '3');
INSERT INTO `relProductoProveedor` VALUES ('257', '4');
INSERT INTO `relProductoProveedor` VALUES ('258', '3');
INSERT INTO `relProductoProveedor` VALUES ('259', '2');
INSERT INTO `relProductoProveedor` VALUES ('261', '3');
INSERT INTO `relProductoProveedor` VALUES ('262', '6');
INSERT INTO `relProductoProveedor` VALUES ('270', '27');
INSERT INTO `relProductoProveedor` VALUES ('272', '27');
INSERT INTO `relProductoProveedor` VALUES ('274', '2');
INSERT INTO `relProductoProveedor` VALUES ('274', '3');
INSERT INTO `relProductoProveedor` VALUES ('274', '4');
INSERT INTO `relProductoProveedor` VALUES ('275', '2');
INSERT INTO `relProductoProveedor` VALUES ('276', '3');
INSERT INTO `relProductoProveedor` VALUES ('276', '4');
INSERT INTO `relProductoProveedor` VALUES ('277', '2');
INSERT INTO `relProductoProveedor` VALUES ('277', '3');
INSERT INTO `relProductoProveedor` VALUES ('277', '4');
INSERT INTO `relProductoProveedor` VALUES ('278', '2');
INSERT INTO `relProductoProveedor` VALUES ('278', '3');
INSERT INTO `relProductoProveedor` VALUES ('278', '4');
INSERT INTO `relProductoProveedor` VALUES ('279', '2');
INSERT INTO `relProductoProveedor` VALUES ('279', '4');
INSERT INTO `relProductoProveedor` VALUES ('280', '3');
INSERT INTO `relProductoProveedor` VALUES ('280', '4');
INSERT INTO `relProductoProveedor` VALUES ('281', '3');
INSERT INTO `relProductoProveedor` VALUES ('281', '4');
INSERT INTO `relProductoProveedor` VALUES ('282', '4');
INSERT INTO `relProductoProveedor` VALUES ('283', '4');
INSERT INTO `relProductoProveedor` VALUES ('284', '28');
INSERT INTO `relProductoProveedor` VALUES ('285', '3');
INSERT INTO `relProductoProveedor` VALUES ('285', '4');
INSERT INTO `relProductoProveedor` VALUES ('285', '10');
INSERT INTO `relProductoProveedor` VALUES ('286', '7');
INSERT INTO `relProductoProveedor` VALUES ('287', '3');
INSERT INTO `relProductoProveedor` VALUES ('287', '12');
INSERT INTO `relProductoProveedor` VALUES ('288', '25');
INSERT INTO `relProductoProveedor` VALUES ('289', '25');
INSERT INTO `relProductoProveedor` VALUES ('290', '25');
INSERT INTO `relProductoProveedor` VALUES ('291', '25');
INSERT INTO `relProductoProveedor` VALUES ('291', '29');
INSERT INTO `relProductoProveedor` VALUES ('292', '25');
INSERT INTO `relProductoProveedor` VALUES ('292', '29');
INSERT INTO `relProductoProveedor` VALUES ('293', '29');
INSERT INTO `relProductoProveedor` VALUES ('294', '25');
INSERT INTO `relProductoProveedor` VALUES ('294', '29');
INSERT INTO `relProductoProveedor` VALUES ('295', '25');
INSERT INTO `relProductoProveedor` VALUES ('295', '29');
INSERT INTO `relProductoProveedor` VALUES ('296', '25');
INSERT INTO `relProductoProveedor` VALUES ('296', '29');
INSERT INTO `relProductoProveedor` VALUES ('297', '29');
INSERT INTO `relProductoProveedor` VALUES ('298', '29');
INSERT INTO `relProductoProveedor` VALUES ('299', '29');
INSERT INTO `relProductoProveedor` VALUES ('300', '3');
INSERT INTO `relProductoProveedor` VALUES ('300', '4');
INSERT INTO `relProductoProveedor` VALUES ('302', '2');
INSERT INTO `relProductoProveedor` VALUES ('302', '3');
INSERT INTO `relProductoProveedor` VALUES ('302', '4');
INSERT INTO `relProductoProveedor` VALUES ('303', '2');
INSERT INTO `relProductoProveedor` VALUES ('303', '3');
INSERT INTO `relProductoProveedor` VALUES ('303', '4');
INSERT INTO `relProductoProveedor` VALUES ('304', '2');
INSERT INTO `relProductoProveedor` VALUES ('304', '3');
INSERT INTO `relProductoProveedor` VALUES ('304', '4');
INSERT INTO `relProductoProveedor` VALUES ('305', '3');
INSERT INTO `relProductoProveedor` VALUES ('305', '4');
INSERT INTO `relProductoProveedor` VALUES ('306', '2');
INSERT INTO `relProductoProveedor` VALUES ('306', '3');
INSERT INTO `relProductoProveedor` VALUES ('306', '4');
INSERT INTO `relProductoProveedor` VALUES ('307', '2');
INSERT INTO `relProductoProveedor` VALUES ('307', '3');
INSERT INTO `relProductoProveedor` VALUES ('307', '4');
INSERT INTO `relProductoProveedor` VALUES ('308', '3');
INSERT INTO `relProductoProveedor` VALUES ('308', '4');
INSERT INTO `relProductoProveedor` VALUES ('309', '3');
INSERT INTO `relProductoProveedor` VALUES ('309', '4');
INSERT INTO `relProductoProveedor` VALUES ('310', '3');
INSERT INTO `relProductoProveedor` VALUES ('310', '4');
INSERT INTO `relProductoProveedor` VALUES ('312', '3');
INSERT INTO `relProductoProveedor` VALUES ('312', '4');
INSERT INTO `relProductoProveedor` VALUES ('313', '3');
INSERT INTO `relProductoProveedor` VALUES ('313', '4');
INSERT INTO `relProductoProveedor` VALUES ('314', '3');
INSERT INTO `relProductoProveedor` VALUES ('314', '4');
INSERT INTO `relProductoProveedor` VALUES ('315', '3');
INSERT INTO `relProductoProveedor` VALUES ('315', '4');
INSERT INTO `relProductoProveedor` VALUES ('316', '3');
INSERT INTO `relProductoProveedor` VALUES ('316', '4');
INSERT INTO `relProductoProveedor` VALUES ('317', '3');
INSERT INTO `relProductoProveedor` VALUES ('317', '4');
INSERT INTO `relProductoProveedor` VALUES ('318', '4');
INSERT INTO `relProductoProveedor` VALUES ('320', '4');
INSERT INTO `relProductoProveedor` VALUES ('321', '29');
INSERT INTO `relProductoProveedor` VALUES ('322', '4');
INSERT INTO `relProductoProveedor` VALUES ('339', '20');
INSERT INTO `relProductoProveedor` VALUES ('340', '2');
INSERT INTO `relProductoProveedor` VALUES ('340', '3');
INSERT INTO `relProductoProveedor` VALUES ('340', '4');
INSERT INTO `relProductoProveedor` VALUES ('341', '2');
INSERT INTO `relProductoProveedor` VALUES ('341', '3');
INSERT INTO `relProductoProveedor` VALUES ('341', '4');
INSERT INTO `relProductoProveedor` VALUES ('342', '2');
INSERT INTO `relProductoProveedor` VALUES ('342', '3');
INSERT INTO `relProductoProveedor` VALUES ('342', '4');
INSERT INTO `relProductoProveedor` VALUES ('343', '2');
INSERT INTO `relProductoProveedor` VALUES ('343', '3');
INSERT INTO `relProductoProveedor` VALUES ('343', '4');
INSERT INTO `relProductoProveedor` VALUES ('344', '2');
INSERT INTO `relProductoProveedor` VALUES ('344', '3');
INSERT INTO `relProductoProveedor` VALUES ('344', '4');
INSERT INTO `relProductoProveedor` VALUES ('345', '2');
INSERT INTO `relProductoProveedor` VALUES ('345', '3');
INSERT INTO `relProductoProveedor` VALUES ('345', '4');
INSERT INTO `relProductoProveedor` VALUES ('346', '2');
INSERT INTO `relProductoProveedor` VALUES ('346', '3');
INSERT INTO `relProductoProveedor` VALUES ('346', '4');
INSERT INTO `relProductoProveedor` VALUES ('347', '2');
INSERT INTO `relProductoProveedor` VALUES ('347', '3');
INSERT INTO `relProductoProveedor` VALUES ('347', '4');
INSERT INTO `relProductoProveedor` VALUES ('348', '2');
INSERT INTO `relProductoProveedor` VALUES ('348', '28');
INSERT INTO `relProductoProveedor` VALUES ('349', '2');
INSERT INTO `relProductoProveedor` VALUES ('349', '28');
INSERT INTO `relProductoProveedor` VALUES ('350', '2');
INSERT INTO `relProductoProveedor` VALUES ('350', '28');
INSERT INTO `relProductoProveedor` VALUES ('351', '28');
INSERT INTO `relProductoProveedor` VALUES ('352', '2');
INSERT INTO `relProductoProveedor` VALUES ('352', '28');
INSERT INTO `relProductoProveedor` VALUES ('353', '2');
INSERT INTO `relProductoProveedor` VALUES ('353', '3');
INSERT INTO `relProductoProveedor` VALUES ('353', '4');
INSERT INTO `relProductoProveedor` VALUES ('354', '3');
INSERT INTO `relProductoProveedor` VALUES ('354', '4');
INSERT INTO `relProductoProveedor` VALUES ('355', '28');
INSERT INTO `relProductoProveedor` VALUES ('356', '28');
INSERT INTO `relProductoProveedor` VALUES ('357', '2');
INSERT INTO `relProductoProveedor` VALUES ('357', '3');
INSERT INTO `relProductoProveedor` VALUES ('357', '4');
INSERT INTO `relProductoProveedor` VALUES ('358', '2');
INSERT INTO `relProductoProveedor` VALUES ('358', '3');
INSERT INTO `relProductoProveedor` VALUES ('358', '4');
INSERT INTO `relProductoProveedor` VALUES ('359', '2');
INSERT INTO `relProductoProveedor` VALUES ('359', '3');
INSERT INTO `relProductoProveedor` VALUES ('359', '4');
INSERT INTO `relProductoProveedor` VALUES ('360', '3');
INSERT INTO `relProductoProveedor` VALUES ('360', '4');
INSERT INTO `relProductoProveedor` VALUES ('361', '2');
INSERT INTO `relProductoProveedor` VALUES ('361', '3');
INSERT INTO `relProductoProveedor` VALUES ('361', '4');
INSERT INTO `relProductoProveedor` VALUES ('362', '2');
INSERT INTO `relProductoProveedor` VALUES ('362', '3');
INSERT INTO `relProductoProveedor` VALUES ('362', '4');
INSERT INTO `relProductoProveedor` VALUES ('363', '2');
INSERT INTO `relProductoProveedor` VALUES ('363', '3');
INSERT INTO `relProductoProveedor` VALUES ('363', '4');
INSERT INTO `relProductoProveedor` VALUES ('364', '3');
INSERT INTO `relProductoProveedor` VALUES ('364', '4');
INSERT INTO `relProductoProveedor` VALUES ('365', '2');
INSERT INTO `relProductoProveedor` VALUES ('365', '3');
INSERT INTO `relProductoProveedor` VALUES ('365', '4');
INSERT INTO `relProductoProveedor` VALUES ('366', '2');
INSERT INTO `relProductoProveedor` VALUES ('366', '3');
INSERT INTO `relProductoProveedor` VALUES ('366', '4');
INSERT INTO `relProductoProveedor` VALUES ('367', '3');
INSERT INTO `relProductoProveedor` VALUES ('367', '4');
INSERT INTO `relProductoProveedor` VALUES ('368', '3');
INSERT INTO `relProductoProveedor` VALUES ('368', '4');
INSERT INTO `relProductoProveedor` VALUES ('369', '3');
INSERT INTO `relProductoProveedor` VALUES ('369', '4');
INSERT INTO `relProductoProveedor` VALUES ('370', '3');
INSERT INTO `relProductoProveedor` VALUES ('370', '4');
INSERT INTO `relProductoProveedor` VALUES ('371', '3');
INSERT INTO `relProductoProveedor` VALUES ('371', '4');
INSERT INTO `relProductoProveedor` VALUES ('372', '3');
INSERT INTO `relProductoProveedor` VALUES ('372', '4');
INSERT INTO `relProductoProveedor` VALUES ('373', '3');
INSERT INTO `relProductoProveedor` VALUES ('373', '4');
INSERT INTO `relProductoProveedor` VALUES ('374', '21');
INSERT INTO `relProductoProveedor` VALUES ('376', '2');
INSERT INTO `relProductoProveedor` VALUES ('377', '3');
INSERT INTO `relProductoProveedor` VALUES ('377', '4');
INSERT INTO `relProductoProveedor` VALUES ('378', '3');
INSERT INTO `relProductoProveedor` VALUES ('378', '4');
INSERT INTO `relProductoProveedor` VALUES ('378', '10');
INSERT INTO `relProductoProveedor` VALUES ('379', '3');
INSERT INTO `relProductoProveedor` VALUES ('379', '4');
INSERT INTO `relProductoProveedor` VALUES ('379', '10');
INSERT INTO `relProductoProveedor` VALUES ('380', '22');
INSERT INTO `relProductoProveedor` VALUES ('381', '22');
INSERT INTO `relProductoProveedor` VALUES ('382', '30');
INSERT INTO `relProductoProveedor` VALUES ('383', '30');
INSERT INTO `relProductoProveedor` VALUES ('385', '3');
INSERT INTO `relProductoProveedor` VALUES ('386', '2');
INSERT INTO `relProductoProveedor` VALUES ('387', '2');
INSERT INTO `relProductoProveedor` VALUES ('388', '10');
INSERT INTO `relProductoProveedor` VALUES ('389', '20');
INSERT INTO `relProductoProveedor` VALUES ('390', '20');
INSERT INTO `relProductoProveedor` VALUES ('391', '20');
INSERT INTO `relProductoProveedor` VALUES ('392', '2');
INSERT INTO `relProductoProveedor` VALUES ('392', '3');
INSERT INTO `relProductoProveedor` VALUES ('392', '4');
INSERT INTO `relProductoProveedor` VALUES ('393', '9');
INSERT INTO `relProductoProveedor` VALUES ('394', '3');
INSERT INTO `relProductoProveedor` VALUES ('395', '3');
INSERT INTO `relProductoProveedor` VALUES ('396', '3');
INSERT INTO `relProductoProveedor` VALUES ('397', '7');
INSERT INTO `relProductoProveedor` VALUES ('399', '3');
INSERT INTO `relProductoProveedor` VALUES ('399', '4');
INSERT INTO `relProductoProveedor` VALUES ('400', '3');
INSERT INTO `relProductoProveedor` VALUES ('400', '4');
INSERT INTO `relProductoProveedor` VALUES ('401', '3');
INSERT INTO `relProductoProveedor` VALUES ('401', '4');
INSERT INTO `relProductoProveedor` VALUES ('404', '20');
INSERT INTO `relProductoProveedor` VALUES ('405', '2');
INSERT INTO `relProductoProveedor` VALUES ('406', '20');
INSERT INTO `relProductoProveedor` VALUES ('407', '20');
INSERT INTO `relProductoProveedor` VALUES ('409', '20');
INSERT INTO `relProductoProveedor` VALUES ('410', '20');
INSERT INTO `relProductoProveedor` VALUES ('411', '3');
INSERT INTO `relProductoProveedor` VALUES ('412', '3');
INSERT INTO `relProductoProveedor` VALUES ('413', '2');
INSERT INTO `relProductoProveedor` VALUES ('413', '3');
INSERT INTO `relProductoProveedor` VALUES ('413', '4');
INSERT INTO `relProductoProveedor` VALUES ('414', '2');
INSERT INTO `relProductoProveedor` VALUES ('414', '3');
INSERT INTO `relProductoProveedor` VALUES ('414', '4');
INSERT INTO `relProductoProveedor` VALUES ('415', '2');
INSERT INTO `relProductoProveedor` VALUES ('415', '3');
INSERT INTO `relProductoProveedor` VALUES ('415', '4');
INSERT INTO `relProductoProveedor` VALUES ('416', '2');
INSERT INTO `relProductoProveedor` VALUES ('416', '3');
INSERT INTO `relProductoProveedor` VALUES ('416', '4');
INSERT INTO `relProductoProveedor` VALUES ('417', '2');
INSERT INTO `relProductoProveedor` VALUES ('417', '3');
INSERT INTO `relProductoProveedor` VALUES ('417', '4');
INSERT INTO `relProductoProveedor` VALUES ('418', '3');
INSERT INTO `relProductoProveedor` VALUES ('418', '4');
INSERT INTO `relProductoProveedor` VALUES ('419', '3');
INSERT INTO `relProductoProveedor` VALUES ('419', '4');
INSERT INTO `relProductoProveedor` VALUES ('420', '2');
INSERT INTO `relProductoProveedor` VALUES ('421', '4');
INSERT INTO `relProductoProveedor` VALUES ('422', '4');
INSERT INTO `relProductoProveedor` VALUES ('423', '4');
INSERT INTO `relProductoProveedor` VALUES ('425', '4');
INSERT INTO `relProductoProveedor` VALUES ('426', '4');
INSERT INTO `relProductoProveedor` VALUES ('427', '4');
INSERT INTO `relProductoProveedor` VALUES ('428', '4');
INSERT INTO `relProductoProveedor` VALUES ('430', '20');
INSERT INTO `relProductoProveedor` VALUES ('431', '5');
INSERT INTO `relProductoProveedor` VALUES ('432', '5');
INSERT INTO `relProductoProveedor` VALUES ('433', '26');
INSERT INTO `relProductoProveedor` VALUES ('434', '3');
INSERT INTO `relProductoProveedor` VALUES ('434', '4');
INSERT INTO `relProductoProveedor` VALUES ('434', '26');
INSERT INTO `relProductoProveedor` VALUES ('435', '3');
INSERT INTO `relProductoProveedor` VALUES ('435', '4');
INSERT INTO `relProductoProveedor` VALUES ('436', '3');
INSERT INTO `relProductoProveedor` VALUES ('436', '4');
INSERT INTO `relProductoProveedor` VALUES ('437', '2');
INSERT INTO `relProductoProveedor` VALUES ('437', '4');
INSERT INTO `relProductoProveedor` VALUES ('437', '16');
INSERT INTO `relProductoProveedor` VALUES ('438', '3');
INSERT INTO `relProductoProveedor` VALUES ('438', '4');
INSERT INTO `relProductoProveedor` VALUES ('438', '26');
INSERT INTO `relProductoProveedor` VALUES ('439', '3');
INSERT INTO `relProductoProveedor` VALUES ('439', '4');
INSERT INTO `relProductoProveedor` VALUES ('439', '26');
INSERT INTO `relProductoProveedor` VALUES ('440', '3');
INSERT INTO `relProductoProveedor` VALUES ('440', '4');
INSERT INTO `relProductoProveedor` VALUES ('440', '26');
INSERT INTO `relProductoProveedor` VALUES ('441', '3');
INSERT INTO `relProductoProveedor` VALUES ('441', '4');
INSERT INTO `relProductoProveedor` VALUES ('441', '26');
INSERT INTO `relProductoProveedor` VALUES ('442', '3');
INSERT INTO `relProductoProveedor` VALUES ('442', '4');
INSERT INTO `relProductoProveedor` VALUES ('442', '26');
INSERT INTO `relProductoProveedor` VALUES ('443', '3');
INSERT INTO `relProductoProveedor` VALUES ('443', '4');
INSERT INTO `relProductoProveedor` VALUES ('443', '26');
INSERT INTO `relProductoProveedor` VALUES ('444', '26');
INSERT INTO `relProductoProveedor` VALUES ('445', '30');
INSERT INTO `relProductoProveedor` VALUES ('446', '31');
INSERT INTO `relProductoProveedor` VALUES ('447', '31');
INSERT INTO `relProductoProveedor` VALUES ('448', '30');
INSERT INTO `relProductoProveedor` VALUES ('449', '30');
INSERT INTO `relProductoProveedor` VALUES ('450', '30');
INSERT INTO `relProductoProveedor` VALUES ('451', '30');
INSERT INTO `relProductoProveedor` VALUES ('452', '30');
INSERT INTO `relProductoProveedor` VALUES ('453', '30');
INSERT INTO `relProductoProveedor` VALUES ('454', '30');
INSERT INTO `relProductoProveedor` VALUES ('455', '30');
INSERT INTO `relProductoProveedor` VALUES ('456', '30');
INSERT INTO `relProductoProveedor` VALUES ('457', '30');
INSERT INTO `relProductoProveedor` VALUES ('458', '30');
INSERT INTO `relProductoProveedor` VALUES ('459', '30');
INSERT INTO `relProductoProveedor` VALUES ('460', '31');
INSERT INTO `relProductoProveedor` VALUES ('461', '30');
INSERT INTO `relProductoProveedor` VALUES ('462', '30');
INSERT INTO `relProductoProveedor` VALUES ('463', '30');
INSERT INTO `relProductoProveedor` VALUES ('464', '30');
INSERT INTO `relProductoProveedor` VALUES ('465', '30');
INSERT INTO `relProductoProveedor` VALUES ('466', '30');
INSERT INTO `relProductoProveedor` VALUES ('467', '30');
INSERT INTO `relProductoProveedor` VALUES ('468', '30');
INSERT INTO `relProductoProveedor` VALUES ('469', '30');
INSERT INTO `relProductoProveedor` VALUES ('470', '30');
INSERT INTO `relProductoProveedor` VALUES ('471', '30');
INSERT INTO `relProductoProveedor` VALUES ('472', '31');
INSERT INTO `relProductoProveedor` VALUES ('473', '30');
INSERT INTO `relProductoProveedor` VALUES ('474', '30');
INSERT INTO `relProductoProveedor` VALUES ('475', '30');
INSERT INTO `relProductoProveedor` VALUES ('476', '22');
INSERT INTO `relProductoProveedor` VALUES ('477', '31');
INSERT INTO `relProductoProveedor` VALUES ('478', '30');
INSERT INTO `relProductoProveedor` VALUES ('479', '30');
INSERT INTO `relProductoProveedor` VALUES ('480', '30');
INSERT INTO `relProductoProveedor` VALUES ('481', '30');
INSERT INTO `relProductoProveedor` VALUES ('482', '4');
INSERT INTO `relProductoProveedor` VALUES ('482', '9');
INSERT INTO `relProductoProveedor` VALUES ('483', '4');
INSERT INTO `relProductoProveedor` VALUES ('483', '9');
INSERT INTO `relProductoProveedor` VALUES ('484', '4');
INSERT INTO `relProductoProveedor` VALUES ('484', '9');
INSERT INTO `relProductoProveedor` VALUES ('485', '9');
INSERT INTO `relProductoProveedor` VALUES ('486', '9');
INSERT INTO `relProductoProveedor` VALUES ('487', '9');
INSERT INTO `relProductoProveedor` VALUES ('489', '4');
INSERT INTO `relProductoProveedor` VALUES ('489', '9');
INSERT INTO `relProductoProveedor` VALUES ('490', '3');
INSERT INTO `relProductoProveedor` VALUES ('490', '4');
INSERT INTO `relProductoProveedor` VALUES ('491', '3');
INSERT INTO `relProductoProveedor` VALUES ('491', '4');
INSERT INTO `relProductoProveedor` VALUES ('492', '3');
INSERT INTO `relProductoProveedor` VALUES ('492', '4');
INSERT INTO `relProductoProveedor` VALUES ('493', '2');
INSERT INTO `relProductoProveedor` VALUES ('493', '3');
INSERT INTO `relProductoProveedor` VALUES ('494', '3');
INSERT INTO `relProductoProveedor` VALUES ('495', '5');
INSERT INTO `relProductoProveedor` VALUES ('496', '5');
INSERT INTO `relProductoProveedor` VALUES ('503', '3');
INSERT INTO `relProductoProveedor` VALUES ('503', '4');
INSERT INTO `relProductoProveedor` VALUES ('504', '3');
INSERT INTO `relProductoProveedor` VALUES ('504', '4');
INSERT INTO `relProductoProveedor` VALUES ('505', '3');
INSERT INTO `relProductoProveedor` VALUES ('506', '4');
INSERT INTO `relProductoProveedor` VALUES ('507', '3');
INSERT INTO `relProductoProveedor` VALUES ('508', '3');
INSERT INTO `relProductoProveedor` VALUES ('509', '3');
INSERT INTO `relProductoProveedor` VALUES ('510', '3');
INSERT INTO `relProductoProveedor` VALUES ('511', '4');
INSERT INTO `relProductoProveedor` VALUES ('512', '4');
INSERT INTO `relProductoProveedor` VALUES ('513', '4');
INSERT INTO `relProductoProveedor` VALUES ('514', '2');
INSERT INTO `relProductoProveedor` VALUES ('515', '3');
INSERT INTO `relProductoProveedor` VALUES ('516', '3');
INSERT INTO `relProductoProveedor` VALUES ('518', '2');
INSERT INTO `relProductoProveedor` VALUES ('520', '2');
INSERT INTO `relProductoProveedor` VALUES ('521', '2');
INSERT INTO `relProductoProveedor` VALUES ('523', '2');
INSERT INTO `relProductoProveedor` VALUES ('524', '3');
INSERT INTO `relProductoProveedor` VALUES ('524', '4');
INSERT INTO `relProductoProveedor` VALUES ('525', '2');
INSERT INTO `relProductoProveedor` VALUES ('525', '3');
INSERT INTO `relProductoProveedor` VALUES ('526', '3');
INSERT INTO `relProductoProveedor` VALUES ('527', '28');
INSERT INTO `relProductoProveedor` VALUES ('528', '28');
INSERT INTO `relProductoProveedor` VALUES ('529', '28');
INSERT INTO `relProductoProveedor` VALUES ('530', '28');
INSERT INTO `relProductoProveedor` VALUES ('531', '2');
INSERT INTO `relProductoProveedor` VALUES ('531', '3');
INSERT INTO `relProductoProveedor` VALUES ('533', '4');
INSERT INTO `relProductoProveedor` VALUES ('533', '28');
INSERT INTO `relProductoProveedor` VALUES ('534', '28');
INSERT INTO `relProductoProveedor` VALUES ('535', '2');
INSERT INTO `relProductoProveedor` VALUES ('536', '2');
INSERT INTO `relProductoProveedor` VALUES ('536', '3');
INSERT INTO `relProductoProveedor` VALUES ('538', '28');
INSERT INTO `relProductoProveedor` VALUES ('539', '28');
INSERT INTO `relProductoProveedor` VALUES ('541', '28');
INSERT INTO `relProductoProveedor` VALUES ('542', '28');
INSERT INTO `relProductoProveedor` VALUES ('543', '3');
INSERT INTO `relProductoProveedor` VALUES ('544', '2');
INSERT INTO `relProductoProveedor` VALUES ('545', '2');
INSERT INTO `relProductoProveedor` VALUES ('546', '2');
INSERT INTO `relProductoProveedor` VALUES ('546', '3');
INSERT INTO `relProductoProveedor` VALUES ('547', '2');
INSERT INTO `relProductoProveedor` VALUES ('547', '3');
INSERT INTO `relProductoProveedor` VALUES ('548', '28');
INSERT INTO `relProductoProveedor` VALUES ('549', '1');
INSERT INTO `relProductoProveedor` VALUES ('549', '3');
INSERT INTO `relProductoProveedor` VALUES ('549', '4');
INSERT INTO `relProductoProveedor` VALUES ('550', '1');
INSERT INTO `relProductoProveedor` VALUES ('550', '3');
INSERT INTO `relProductoProveedor` VALUES ('550', '4');
INSERT INTO `relProductoProveedor` VALUES ('551', '28');
INSERT INTO `relProductoProveedor` VALUES ('552', '28');
INSERT INTO `relProductoProveedor` VALUES ('553', '3');
INSERT INTO `relProductoProveedor` VALUES ('553', '4');
INSERT INTO `relProductoProveedor` VALUES ('554', '3');
INSERT INTO `relProductoProveedor` VALUES ('554', '4');
INSERT INTO `relProductoProveedor` VALUES ('556', '3');
INSERT INTO `relProductoProveedor` VALUES ('556', '4');
INSERT INTO `relProductoProveedor` VALUES ('557', '4');
INSERT INTO `relProductoProveedor` VALUES ('557', '28');
INSERT INTO `relProductoProveedor` VALUES ('558', '4');
INSERT INTO `relProductoProveedor` VALUES ('558', '28');
INSERT INTO `relProductoProveedor` VALUES ('559', '4');
INSERT INTO `relProductoProveedor` VALUES ('559', '28');
INSERT INTO `relProductoProveedor` VALUES ('560', '3');
INSERT INTO `relProductoProveedor` VALUES ('560', '4');
INSERT INTO `relProductoProveedor` VALUES ('561', '3');
INSERT INTO `relProductoProveedor` VALUES ('561', '4');
INSERT INTO `relProductoProveedor` VALUES ('562', '4');
INSERT INTO `relProductoProveedor` VALUES ('562', '28');
INSERT INTO `relProductoProveedor` VALUES ('563', '1');
INSERT INTO `relProductoProveedor` VALUES ('563', '3');
INSERT INTO `relProductoProveedor` VALUES ('563', '4');
INSERT INTO `relProductoProveedor` VALUES ('564', '1');
INSERT INTO `relProductoProveedor` VALUES ('564', '3');
INSERT INTO `relProductoProveedor` VALUES ('564', '4');
INSERT INTO `relProductoProveedor` VALUES ('565', '1');
INSERT INTO `relProductoProveedor` VALUES ('565', '3');
INSERT INTO `relProductoProveedor` VALUES ('565', '4');
INSERT INTO `relProductoProveedor` VALUES ('566', '2');
INSERT INTO `relProductoProveedor` VALUES ('566', '3');
INSERT INTO `relProductoProveedor` VALUES ('566', '4');
INSERT INTO `relProductoProveedor` VALUES ('567', '28');
INSERT INTO `relProductoProveedor` VALUES ('568', '1');
INSERT INTO `relProductoProveedor` VALUES ('568', '3');
INSERT INTO `relProductoProveedor` VALUES ('568', '4');
INSERT INTO `relProductoProveedor` VALUES ('569', '2');
INSERT INTO `relProductoProveedor` VALUES ('572', '2');
INSERT INTO `relProductoProveedor` VALUES ('574', '2');
INSERT INTO `relProductoProveedor` VALUES ('576', '2');
INSERT INTO `relProductoProveedor` VALUES ('577', '2');
INSERT INTO `relProductoProveedor` VALUES ('579', '2');
INSERT INTO `relProductoProveedor` VALUES ('581', '2');
INSERT INTO `relProductoProveedor` VALUES ('584', '2');
INSERT INTO `relProductoProveedor` VALUES ('584', '3');
INSERT INTO `relProductoProveedor` VALUES ('584', '4');
INSERT INTO `relProductoProveedor` VALUES ('585', '2');
INSERT INTO `relProductoProveedor` VALUES ('585', '3');
INSERT INTO `relProductoProveedor` VALUES ('585', '4');
INSERT INTO `relProductoProveedor` VALUES ('586', '15');
INSERT INTO `relProductoProveedor` VALUES ('587', '4');
INSERT INTO `relProductoProveedor` VALUES ('587', '15');
INSERT INTO `relProductoProveedor` VALUES ('588', '16');
INSERT INTO `relProductoProveedor` VALUES ('589', '3');
INSERT INTO `relProductoProveedor` VALUES ('590', '3');
INSERT INTO `relProductoProveedor` VALUES ('591', '3');
INSERT INTO `relProductoProveedor` VALUES ('592', '3');
INSERT INTO `relProductoProveedor` VALUES ('593', '3');
INSERT INTO `relProductoProveedor` VALUES ('593', '4');
INSERT INTO `relProductoProveedor` VALUES ('594', '2');
INSERT INTO `relProductoProveedor` VALUES ('594', '3');
INSERT INTO `relProductoProveedor` VALUES ('595', '3');
INSERT INTO `relProductoProveedor` VALUES ('596', '2');
INSERT INTO `relProductoProveedor` VALUES ('596', '3');
INSERT INTO `relProductoProveedor` VALUES ('596', '4');
INSERT INTO `relProductoProveedor` VALUES ('597', '2');
INSERT INTO `relProductoProveedor` VALUES ('598', '3');
INSERT INTO `relProductoProveedor` VALUES ('599', '3');
INSERT INTO `relProductoProveedor` VALUES ('599', '4');
INSERT INTO `relProductoProveedor` VALUES ('600', '2');
INSERT INTO `relProductoProveedor` VALUES ('600', '3');
INSERT INTO `relProductoProveedor` VALUES ('601', '2');
INSERT INTO `relProductoProveedor` VALUES ('602', '2');
INSERT INTO `relProductoProveedor` VALUES ('602', '3');
INSERT INTO `relProductoProveedor` VALUES ('603', '3');
INSERT INTO `relProductoProveedor` VALUES ('605', '3');
INSERT INTO `relProductoProveedor` VALUES ('606', '3');
INSERT INTO `relProductoProveedor` VALUES ('607', '2');
INSERT INTO `relProductoProveedor` VALUES ('607', '3');
INSERT INTO `relProductoProveedor` VALUES ('608', '3');
INSERT INTO `relProductoProveedor` VALUES ('608', '4');
INSERT INTO `relProductoProveedor` VALUES ('609', '3');
INSERT INTO `relProductoProveedor` VALUES ('609', '4');
INSERT INTO `relProductoProveedor` VALUES ('610', '3');
INSERT INTO `relProductoProveedor` VALUES ('611', '3');
INSERT INTO `relProductoProveedor` VALUES ('611', '4');
INSERT INTO `relProductoProveedor` VALUES ('612', '3');
INSERT INTO `relProductoProveedor` VALUES ('612', '4');
INSERT INTO `relProductoProveedor` VALUES ('613', '3');
INSERT INTO `relProductoProveedor` VALUES ('614', '3');
INSERT INTO `relProductoProveedor` VALUES ('615', '2');
INSERT INTO `relProductoProveedor` VALUES ('615', '3');
INSERT INTO `relProductoProveedor` VALUES ('615', '4');
INSERT INTO `relProductoProveedor` VALUES ('619', '2');
INSERT INTO `relProductoProveedor` VALUES ('621', '2');
INSERT INTO `relProductoProveedor` VALUES ('622', '3');
INSERT INTO `relProductoProveedor` VALUES ('622', '4');
INSERT INTO `relProductoProveedor` VALUES ('623', '4');
INSERT INTO `relProductoProveedor` VALUES ('624', '4');
INSERT INTO `relProductoProveedor` VALUES ('625', '4');
INSERT INTO `relProductoProveedor` VALUES ('626', '3');
INSERT INTO `relProductoProveedor` VALUES ('626', '4');
INSERT INTO `relProductoProveedor` VALUES ('627', '3');
INSERT INTO `relProductoProveedor` VALUES ('627', '4');
INSERT INTO `relProductoProveedor` VALUES ('628', '4');
INSERT INTO `relProductoProveedor` VALUES ('629', '3');
INSERT INTO `relProductoProveedor` VALUES ('629', '4');
INSERT INTO `relProductoProveedor` VALUES ('630', '3');
INSERT INTO `relProductoProveedor` VALUES ('630', '4');
INSERT INTO `relProductoProveedor` VALUES ('631', '3');
INSERT INTO `relProductoProveedor` VALUES ('631', '4');
INSERT INTO `relProductoProveedor` VALUES ('632', '3');
INSERT INTO `relProductoProveedor` VALUES ('632', '4');
INSERT INTO `relProductoProveedor` VALUES ('633', '3');
INSERT INTO `relProductoProveedor` VALUES ('633', '4');
INSERT INTO `relProductoProveedor` VALUES ('634', '3');
INSERT INTO `relProductoProveedor` VALUES ('634', '4');
INSERT INTO `relProductoProveedor` VALUES ('635', '4');
INSERT INTO `relProductoProveedor` VALUES ('636', '3');
INSERT INTO `relProductoProveedor` VALUES ('636', '4');
INSERT INTO `relProductoProveedor` VALUES ('637', '3');
INSERT INTO `relProductoProveedor` VALUES ('637', '4');
INSERT INTO `relProductoProveedor` VALUES ('638', '3');
INSERT INTO `relProductoProveedor` VALUES ('638', '4');
INSERT INTO `relProductoProveedor` VALUES ('639', '3');
INSERT INTO `relProductoProveedor` VALUES ('639', '4');
INSERT INTO `relProductoProveedor` VALUES ('640', '2');
INSERT INTO `relProductoProveedor` VALUES ('640', '3');
INSERT INTO `relProductoProveedor` VALUES ('640', '4');
INSERT INTO `relProductoProveedor` VALUES ('641', '2');
INSERT INTO `relProductoProveedor` VALUES ('641', '3');
INSERT INTO `relProductoProveedor` VALUES ('641', '4');
INSERT INTO `relProductoProveedor` VALUES ('642', '2');
INSERT INTO `relProductoProveedor` VALUES ('642', '3');
INSERT INTO `relProductoProveedor` VALUES ('642', '4');
INSERT INTO `relProductoProveedor` VALUES ('643', '4');
INSERT INTO `relProductoProveedor` VALUES ('644', '4');
INSERT INTO `relProductoProveedor` VALUES ('644', '5');
INSERT INTO `relProductoProveedor` VALUES ('644', '6');
INSERT INTO `relProductoProveedor` VALUES ('645', '3');
INSERT INTO `relProductoProveedor` VALUES ('645', '4');
INSERT INTO `relProductoProveedor` VALUES ('646', '4');
INSERT INTO `relProductoProveedor` VALUES ('647', '4');
INSERT INTO `relProductoProveedor` VALUES ('648', '3');
INSERT INTO `relProductoProveedor` VALUES ('649', '3');
INSERT INTO `relProductoProveedor` VALUES ('650', '4');
INSERT INTO `relProductoProveedor` VALUES ('651', '4');
INSERT INTO `relProductoProveedor` VALUES ('652', '4');
INSERT INTO `relProductoProveedor` VALUES ('653', '4');
INSERT INTO `relProductoProveedor` VALUES ('654', '4');
INSERT INTO `relProductoProveedor` VALUES ('655', '4');
INSERT INTO `relProductoProveedor` VALUES ('656', '4');
INSERT INTO `relProductoProveedor` VALUES ('657', '3');
INSERT INTO `relProductoProveedor` VALUES ('659', '3');
INSERT INTO `relProductoProveedor` VALUES ('660', '3');
INSERT INTO `relProductoProveedor` VALUES ('661', '10');
INSERT INTO `relProductoProveedor` VALUES ('662', '9');
INSERT INTO `relProductoProveedor` VALUES ('663', '2');
INSERT INTO `relProductoProveedor` VALUES ('663', '3');
INSERT INTO `relProductoProveedor` VALUES ('664', '2');
INSERT INTO `relProductoProveedor` VALUES ('664', '3');
INSERT INTO `relProductoProveedor` VALUES ('665', '2');
INSERT INTO `relProductoProveedor` VALUES ('665', '3');
INSERT INTO `relProductoProveedor` VALUES ('666', '3');
INSERT INTO `relProductoProveedor` VALUES ('667', '3');
INSERT INTO `relProductoProveedor` VALUES ('668', '3');
INSERT INTO `relProductoProveedor` VALUES ('669', '3');
INSERT INTO `relProductoProveedor` VALUES ('670', '3');
INSERT INTO `relProductoProveedor` VALUES ('672', '3');
INSERT INTO `relProductoProveedor` VALUES ('672', '4');
INSERT INTO `relProductoProveedor` VALUES ('673', '6');
INSERT INTO `relProductoProveedor` VALUES ('674', '6');
INSERT INTO `relProductoProveedor` VALUES ('675', '2');
INSERT INTO `relProductoProveedor` VALUES ('675', '3');
INSERT INTO `relProductoProveedor` VALUES ('675', '4');
INSERT INTO `relProductoProveedor` VALUES ('676', '32');
INSERT INTO `relProductoProveedor` VALUES ('677', '2');
INSERT INTO `relProductoProveedor` VALUES ('677', '3');
INSERT INTO `relProductoProveedor` VALUES ('677', '4');
INSERT INTO `relProductoProveedor` VALUES ('679', '5');
INSERT INTO `relProductoProveedor` VALUES ('682', '5');
INSERT INTO `relProductoProveedor` VALUES ('683', '2');
INSERT INTO `relProductoProveedor` VALUES ('684', '13');
INSERT INTO `relProductoProveedor` VALUES ('685', '13');
INSERT INTO `relProductoProveedor` VALUES ('686', '13');
INSERT INTO `relProductoProveedor` VALUES ('691', '13');
INSERT INTO `relProductoProveedor` VALUES ('692', '13');
INSERT INTO `relProductoProveedor` VALUES ('693', '13');
INSERT INTO `relProductoProveedor` VALUES ('694', '21');
INSERT INTO `relProductoProveedor` VALUES ('695', '2');
INSERT INTO `relProductoProveedor` VALUES ('697', '4');
INSERT INTO `relProductoProveedor` VALUES ('698', '3');
INSERT INTO `relProductoProveedor` VALUES ('698', '4');
INSERT INTO `relProductoProveedor` VALUES ('699', '3');
INSERT INTO `relProductoProveedor` VALUES ('699', '4');
INSERT INTO `relProductoProveedor` VALUES ('700', '3');
INSERT INTO `relProductoProveedor` VALUES ('700', '4');
INSERT INTO `relProductoProveedor` VALUES ('701', '3');
INSERT INTO `relProductoProveedor` VALUES ('701', '4');
INSERT INTO `relProductoProveedor` VALUES ('702', '3');
INSERT INTO `relProductoProveedor` VALUES ('702', '4');
INSERT INTO `relProductoProveedor` VALUES ('703', '4');
INSERT INTO `relProductoProveedor` VALUES ('704', '3');
INSERT INTO `relProductoProveedor` VALUES ('704', '4');
INSERT INTO `relProductoProveedor` VALUES ('705', '3');
INSERT INTO `relProductoProveedor` VALUES ('705', '4');
INSERT INTO `relProductoProveedor` VALUES ('706', '3');
INSERT INTO `relProductoProveedor` VALUES ('706', '4');
INSERT INTO `relProductoProveedor` VALUES ('707', '3');
INSERT INTO `relProductoProveedor` VALUES ('707', '4');
INSERT INTO `relProductoProveedor` VALUES ('708', '3');
INSERT INTO `relProductoProveedor` VALUES ('708', '4');
INSERT INTO `relProductoProveedor` VALUES ('709', '3');
INSERT INTO `relProductoProveedor` VALUES ('709', '4');
INSERT INTO `relProductoProveedor` VALUES ('710', '3');
INSERT INTO `relProductoProveedor` VALUES ('710', '4');
INSERT INTO `relProductoProveedor` VALUES ('711', '3');
INSERT INTO `relProductoProveedor` VALUES ('711', '4');
INSERT INTO `relProductoProveedor` VALUES ('712', '4');
INSERT INTO `relProductoProveedor` VALUES ('713', '3');
INSERT INTO `relProductoProveedor` VALUES ('713', '4');
INSERT INTO `relProductoProveedor` VALUES ('714', '3');
INSERT INTO `relProductoProveedor` VALUES ('714', '4');
INSERT INTO `relProductoProveedor` VALUES ('715', '3');
INSERT INTO `relProductoProveedor` VALUES ('715', '4');
INSERT INTO `relProductoProveedor` VALUES ('716', '3');
INSERT INTO `relProductoProveedor` VALUES ('716', '4');
INSERT INTO `relProductoProveedor` VALUES ('717', '3');
INSERT INTO `relProductoProveedor` VALUES ('717', '4');
INSERT INTO `relProductoProveedor` VALUES ('718', '3');
INSERT INTO `relProductoProveedor` VALUES ('718', '4');
INSERT INTO `relProductoProveedor` VALUES ('719', '2');
INSERT INTO `relProductoProveedor` VALUES ('720', '2');
INSERT INTO `relProductoProveedor` VALUES ('721', '2');
INSERT INTO `relProductoProveedor` VALUES ('721', '3');
INSERT INTO `relProductoProveedor` VALUES ('722', '2');
INSERT INTO `relProductoProveedor` VALUES ('723', '2');
INSERT INTO `relProductoProveedor` VALUES ('724', '2');
INSERT INTO `relProductoProveedor` VALUES ('725', '2');
INSERT INTO `relProductoProveedor` VALUES ('726', '13');
INSERT INTO `relProductoProveedor` VALUES ('726', '33');
INSERT INTO `relProductoProveedor` VALUES ('727', '13');
INSERT INTO `relProductoProveedor` VALUES ('728', '4');
INSERT INTO `relProductoProveedor` VALUES ('729', '4');
INSERT INTO `relProductoProveedor` VALUES ('730', '2');
INSERT INTO `relProductoProveedor` VALUES ('731', '2');
INSERT INTO `relProductoProveedor` VALUES ('732', '2');
INSERT INTO `relProductoProveedor` VALUES ('733', '2');
INSERT INTO `relProductoProveedor` VALUES ('733', '3');
INSERT INTO `relProductoProveedor` VALUES ('733', '4');
INSERT INTO `relProductoProveedor` VALUES ('734', '2');
INSERT INTO `relProductoProveedor` VALUES ('734', '4');
INSERT INTO `relProductoProveedor` VALUES ('735', '4');
INSERT INTO `relProductoProveedor` VALUES ('737', '4');
INSERT INTO `relProductoProveedor` VALUES ('738', '3');
INSERT INTO `relProductoProveedor` VALUES ('738', '4');
INSERT INTO `relProductoProveedor` VALUES ('739', '3');
INSERT INTO `relProductoProveedor` VALUES ('739', '4');
INSERT INTO `relProductoProveedor` VALUES ('741', '5');
INSERT INTO `relProductoProveedor` VALUES ('742', '2');
INSERT INTO `relProductoProveedor` VALUES ('742', '4');
INSERT INTO `relProductoProveedor` VALUES ('743', '30');
INSERT INTO `relProductoProveedor` VALUES ('744', '30');
INSERT INTO `relProductoProveedor` VALUES ('745', '4');
INSERT INTO `relProductoProveedor` VALUES ('746', '2');
INSERT INTO `relProductoProveedor` VALUES ('746', '4');
INSERT INTO `relProductoProveedor` VALUES ('747', '4');
INSERT INTO `relProductoProveedor` VALUES ('748', '4');
INSERT INTO `relProductoProveedor` VALUES ('749', '30');
INSERT INTO `relProductoProveedor` VALUES ('750', '30');
INSERT INTO `relProductoProveedor` VALUES ('751', '30');
INSERT INTO `relProductoProveedor` VALUES ('752', '2');
INSERT INTO `relProductoProveedor` VALUES ('752', '4');
INSERT INTO `relProductoProveedor` VALUES ('753', '30');
INSERT INTO `relProductoProveedor` VALUES ('754', '2');
INSERT INTO `relProductoProveedor` VALUES ('754', '4');
INSERT INTO `relProductoProveedor` VALUES ('756', '2');
INSERT INTO `relProductoProveedor` VALUES ('756', '4');
INSERT INTO `relProductoProveedor` VALUES ('757', '4');
INSERT INTO `relProductoProveedor` VALUES ('758', '9');
INSERT INTO `relProductoProveedor` VALUES ('759', '4');
INSERT INTO `relProductoProveedor` VALUES ('760', '9');
INSERT INTO `relProductoProveedor` VALUES ('761', '4');
INSERT INTO `relProductoProveedor` VALUES ('762', '9');
INSERT INTO `relProductoProveedor` VALUES ('763', '2');
INSERT INTO `relProductoProveedor` VALUES ('763', '4');
INSERT INTO `relProductoProveedor` VALUES ('764', '7');
INSERT INTO `relProductoProveedor` VALUES ('766', '3');
INSERT INTO `relProductoProveedor` VALUES ('766', '4');
INSERT INTO `relProductoProveedor` VALUES ('766', '26');
INSERT INTO `relProductoProveedor` VALUES ('767', '2');
INSERT INTO `relProductoProveedor` VALUES ('768', '20');
INSERT INTO `relProductoProveedor` VALUES ('769', '3');
INSERT INTO `relProductoProveedor` VALUES ('769', '10');
INSERT INTO `relProductoProveedor` VALUES ('771', '3');
INSERT INTO `relProductoProveedor` VALUES ('772', '3');
INSERT INTO `relProductoProveedor` VALUES ('773', '25');
INSERT INTO `relProductoProveedor` VALUES ('774', '25');
INSERT INTO `relProductoProveedor` VALUES ('775', '25');
INSERT INTO `relProductoProveedor` VALUES ('776', '6');
INSERT INTO `relProductoProveedor` VALUES ('777', '2');
INSERT INTO `relProductoProveedor` VALUES ('778', '2');
INSERT INTO `relProductoProveedor` VALUES ('779', '2');
INSERT INTO `relProductoProveedor` VALUES ('779', '3');
INSERT INTO `relProductoProveedor` VALUES ('779', '4');
INSERT INTO `relProductoProveedor` VALUES ('780', '10');
INSERT INTO `relProductoProveedor` VALUES ('781', '2');
INSERT INTO `relProductoProveedor` VALUES ('781', '16');
INSERT INTO `relProductoProveedor` VALUES ('782', '4');
INSERT INTO `relProductoProveedor` VALUES ('782', '26');
INSERT INTO `relProductoProveedor` VALUES ('784', '3');
INSERT INTO `relProductoProveedor` VALUES ('784', '4');
INSERT INTO `relProductoProveedor` VALUES ('785', '3');
INSERT INTO `relProductoProveedor` VALUES ('785', '4');
INSERT INTO `relProductoProveedor` VALUES ('788', '2');
INSERT INTO `relProductoProveedor` VALUES ('789', '2');
INSERT INTO `relProductoProveedor` VALUES ('790', '2');
INSERT INTO `relProductoProveedor` VALUES ('790', '3');
INSERT INTO `relProductoProveedor` VALUES ('790', '4');
INSERT INTO `relProductoProveedor` VALUES ('791', '34');
INSERT INTO `relProductoProveedor` VALUES ('797', '2');
INSERT INTO `relProductoProveedor` VALUES ('798', '2');
INSERT INTO `relProductoProveedor` VALUES ('799', '9');
INSERT INTO `relProductoProveedor` VALUES ('800', '9');
INSERT INTO `relProductoProveedor` VALUES ('801', '9');
INSERT INTO `relProductoProveedor` VALUES ('802', '7');
INSERT INTO `relProductoProveedor` VALUES ('803', '7');
INSERT INTO `relProductoProveedor` VALUES ('804', '7');
INSERT INTO `relProductoProveedor` VALUES ('805', '9');
INSERT INTO `relProductoProveedor` VALUES ('806', '2');
INSERT INTO `relProductoProveedor` VALUES ('807', '9');
INSERT INTO `relProductoProveedor` VALUES ('808', '2');
INSERT INTO `relProductoProveedor` VALUES ('809', '3');
INSERT INTO `relProductoProveedor` VALUES ('809', '10');
INSERT INTO `relProductoProveedor` VALUES ('810', '3');
INSERT INTO `relProductoProveedor` VALUES ('810', '10');
INSERT INTO `relProductoProveedor` VALUES ('811', '2');
INSERT INTO `relProductoProveedor` VALUES ('812', '3');
INSERT INTO `relProductoProveedor` VALUES ('812', '4');
INSERT INTO `relProductoProveedor` VALUES ('813', '3');
INSERT INTO `relProductoProveedor` VALUES ('813', '4');
INSERT INTO `relProductoProveedor` VALUES ('814', '10');
INSERT INTO `relProductoProveedor` VALUES ('815', '2');
INSERT INTO `relProductoProveedor` VALUES ('816', '23');
INSERT INTO `relProductoProveedor` VALUES ('817', '23');
INSERT INTO `relProductoProveedor` VALUES ('818', '9');
INSERT INTO `relProductoProveedor` VALUES ('819', '9');
INSERT INTO `relProductoProveedor` VALUES ('821', '3');
INSERT INTO `relProductoProveedor` VALUES ('822', '9');
INSERT INTO `relProductoProveedor` VALUES ('823', '3');
INSERT INTO `relProductoProveedor` VALUES ('824', '9');
INSERT INTO `relProductoProveedor` VALUES ('825', '2');
INSERT INTO `relProductoProveedor` VALUES ('826', '2');
INSERT INTO `relProductoProveedor` VALUES ('827', '3');
INSERT INTO `relProductoProveedor` VALUES ('827', '4');
INSERT INTO `relProductoProveedor` VALUES ('828', '2');
INSERT INTO `relProductoProveedor` VALUES ('830', '10');
INSERT INTO `relProductoProveedor` VALUES ('831', '10');
INSERT INTO `relProductoProveedor` VALUES ('832', '3');
INSERT INTO `relProductoProveedor` VALUES ('832', '4');
INSERT INTO `relProductoProveedor` VALUES ('832', '10');
INSERT INTO `relProductoProveedor` VALUES ('833', '3');
INSERT INTO `relProductoProveedor` VALUES ('833', '4');
INSERT INTO `relProductoProveedor` VALUES ('834', '3');
INSERT INTO `relProductoProveedor` VALUES ('838', '3');
INSERT INTO `relProductoProveedor` VALUES ('839', '4');
INSERT INTO `relProductoProveedor` VALUES ('840', '2');
INSERT INTO `relProductoProveedor` VALUES ('840', '4');
INSERT INTO `relProductoProveedor` VALUES ('841', '3');
INSERT INTO `relProductoProveedor` VALUES ('841', '4');
INSERT INTO `relProductoProveedor` VALUES ('842', '4');
INSERT INTO `relProductoProveedor` VALUES ('843', '4');
INSERT INTO `relProductoProveedor` VALUES ('844', '2');
INSERT INTO `relProductoProveedor` VALUES ('845', '4');
INSERT INTO `relProductoProveedor` VALUES ('846', '3');
INSERT INTO `relProductoProveedor` VALUES ('846', '4');
INSERT INTO `relProductoProveedor` VALUES ('847', '3');
INSERT INTO `relProductoProveedor` VALUES ('847', '4');
INSERT INTO `relProductoProveedor` VALUES ('849', '3');
INSERT INTO `relProductoProveedor` VALUES ('849', '4');
INSERT INTO `relProductoProveedor` VALUES ('850', '3');
INSERT INTO `relProductoProveedor` VALUES ('850', '4');
INSERT INTO `relProductoProveedor` VALUES ('852', '2');
INSERT INTO `relProductoProveedor` VALUES ('852', '3');
INSERT INTO `relProductoProveedor` VALUES ('852', '4');
INSERT INTO `relProductoProveedor` VALUES ('854', '3');
INSERT INTO `relProductoProveedor` VALUES ('854', '4');
INSERT INTO `relProductoProveedor` VALUES ('855', '3');
INSERT INTO `relProductoProveedor` VALUES ('855', '4');
INSERT INTO `relProductoProveedor` VALUES ('856', '3');
INSERT INTO `relProductoProveedor` VALUES ('856', '4');
INSERT INTO `relProductoProveedor` VALUES ('857', '3');
INSERT INTO `relProductoProveedor` VALUES ('857', '4');
INSERT INTO `relProductoProveedor` VALUES ('858', '3');
INSERT INTO `relProductoProveedor` VALUES ('858', '4');
INSERT INTO `relProductoProveedor` VALUES ('859', '3');
INSERT INTO `relProductoProveedor` VALUES ('859', '4');
INSERT INTO `relProductoProveedor` VALUES ('860', '3');
INSERT INTO `relProductoProveedor` VALUES ('860', '4');
INSERT INTO `relProductoProveedor` VALUES ('861', '3');
INSERT INTO `relProductoProveedor` VALUES ('861', '4');
INSERT INTO `relProductoProveedor` VALUES ('862', '3');
INSERT INTO `relProductoProveedor` VALUES ('862', '4');
INSERT INTO `relProductoProveedor` VALUES ('863', '3');
INSERT INTO `relProductoProveedor` VALUES ('863', '4');
INSERT INTO `relProductoProveedor` VALUES ('864', '3');
INSERT INTO `relProductoProveedor` VALUES ('864', '4');
INSERT INTO `relProductoProveedor` VALUES ('865', '3');
INSERT INTO `relProductoProveedor` VALUES ('865', '4');
INSERT INTO `relProductoProveedor` VALUES ('866', '3');
INSERT INTO `relProductoProveedor` VALUES ('866', '4');
INSERT INTO `relProductoProveedor` VALUES ('867', '3');
INSERT INTO `relProductoProveedor` VALUES ('867', '4');
INSERT INTO `relProductoProveedor` VALUES ('868', '3');
INSERT INTO `relProductoProveedor` VALUES ('868', '4');
INSERT INTO `relProductoProveedor` VALUES ('869', '3');
INSERT INTO `relProductoProveedor` VALUES ('869', '4');
INSERT INTO `relProductoProveedor` VALUES ('870', '3');
INSERT INTO `relProductoProveedor` VALUES ('870', '4');
INSERT INTO `relProductoProveedor` VALUES ('871', '3');
INSERT INTO `relProductoProveedor` VALUES ('871', '4');
INSERT INTO `relProductoProveedor` VALUES ('872', '3');
INSERT INTO `relProductoProveedor` VALUES ('872', '4');
INSERT INTO `relProductoProveedor` VALUES ('873', '3');
INSERT INTO `relProductoProveedor` VALUES ('873', '4');
INSERT INTO `relProductoProveedor` VALUES ('874', '3');
INSERT INTO `relProductoProveedor` VALUES ('874', '4');
INSERT INTO `relProductoProveedor` VALUES ('875', '3');
INSERT INTO `relProductoProveedor` VALUES ('875', '4');
INSERT INTO `relProductoProveedor` VALUES ('876', '3');
INSERT INTO `relProductoProveedor` VALUES ('876', '4');
INSERT INTO `relProductoProveedor` VALUES ('881', '2');
INSERT INTO `relProductoProveedor` VALUES ('889', '3');
INSERT INTO `relProductoProveedor` VALUES ('889', '4');
INSERT INTO `relProductoProveedor` VALUES ('890', '3');
INSERT INTO `relProductoProveedor` VALUES ('890', '4');
INSERT INTO `relProductoProveedor` VALUES ('891', '3');
INSERT INTO `relProductoProveedor` VALUES ('891', '4');
INSERT INTO `relProductoProveedor` VALUES ('892', '3');
INSERT INTO `relProductoProveedor` VALUES ('892', '4');
INSERT INTO `relProductoProveedor` VALUES ('893', '3');
INSERT INTO `relProductoProveedor` VALUES ('893', '4');
INSERT INTO `relProductoProveedor` VALUES ('894', '3');
INSERT INTO `relProductoProveedor` VALUES ('894', '4');
INSERT INTO `relProductoProveedor` VALUES ('895', '3');
INSERT INTO `relProductoProveedor` VALUES ('895', '4');
INSERT INTO `relProductoProveedor` VALUES ('896', '3');
INSERT INTO `relProductoProveedor` VALUES ('896', '4');
INSERT INTO `relProductoProveedor` VALUES ('897', '3');
INSERT INTO `relProductoProveedor` VALUES ('897', '4');
INSERT INTO `relProductoProveedor` VALUES ('898', '3');
INSERT INTO `relProductoProveedor` VALUES ('898', '4');
INSERT INTO `relProductoProveedor` VALUES ('899', '3');
INSERT INTO `relProductoProveedor` VALUES ('899', '4');
INSERT INTO `relProductoProveedor` VALUES ('900', '3');
INSERT INTO `relProductoProveedor` VALUES ('900', '4');
INSERT INTO `relProductoProveedor` VALUES ('901', '2');
INSERT INTO `relProductoProveedor` VALUES ('901', '3');
INSERT INTO `relProductoProveedor` VALUES ('901', '4');
INSERT INTO `relProductoProveedor` VALUES ('902', '2');
INSERT INTO `relProductoProveedor` VALUES ('902', '3');
INSERT INTO `relProductoProveedor` VALUES ('902', '4');
INSERT INTO `relProductoProveedor` VALUES ('903', '2');
INSERT INTO `relProductoProveedor` VALUES ('903', '3');
INSERT INTO `relProductoProveedor` VALUES ('903', '4');
INSERT INTO `relProductoProveedor` VALUES ('904', '3');
INSERT INTO `relProductoProveedor` VALUES ('904', '4');
INSERT INTO `relProductoProveedor` VALUES ('905', '3');
INSERT INTO `relProductoProveedor` VALUES ('905', '4');
INSERT INTO `relProductoProveedor` VALUES ('906', '2');
INSERT INTO `relProductoProveedor` VALUES ('906', '3');
INSERT INTO `relProductoProveedor` VALUES ('906', '4');
INSERT INTO `relProductoProveedor` VALUES ('907', '3');
INSERT INTO `relProductoProveedor` VALUES ('907', '4');
INSERT INTO `relProductoProveedor` VALUES ('908', '3');
INSERT INTO `relProductoProveedor` VALUES ('908', '4');
INSERT INTO `relProductoProveedor` VALUES ('909', '14');
INSERT INTO `relProductoProveedor` VALUES ('910', '14');
INSERT INTO `relProductoProveedor` VALUES ('911', '14');
INSERT INTO `relProductoProveedor` VALUES ('912', '14');
INSERT INTO `relProductoProveedor` VALUES ('913', '14');
INSERT INTO `relProductoProveedor` VALUES ('914', '14');
INSERT INTO `relProductoProveedor` VALUES ('915', '14');
INSERT INTO `relProductoProveedor` VALUES ('916', '14');
INSERT INTO `relProductoProveedor` VALUES ('917', '14');
INSERT INTO `relProductoProveedor` VALUES ('918', '14');
INSERT INTO `relProductoProveedor` VALUES ('919', '14');
INSERT INTO `relProductoProveedor` VALUES ('920', '14');
INSERT INTO `relProductoProveedor` VALUES ('921', '14');
INSERT INTO `relProductoProveedor` VALUES ('922', '14');
INSERT INTO `relProductoProveedor` VALUES ('923', '14');
INSERT INTO `relProductoProveedor` VALUES ('924', '14');
INSERT INTO `relProductoProveedor` VALUES ('925', '14');
INSERT INTO `relProductoProveedor` VALUES ('926', '14');
INSERT INTO `relProductoProveedor` VALUES ('927', '2');
INSERT INTO `relProductoProveedor` VALUES ('928', '2');
INSERT INTO `relProductoProveedor` VALUES ('929', '35');
INSERT INTO `relProductoProveedor` VALUES ('930', '3');
INSERT INTO `relProductoProveedor` VALUES ('931', '3');
INSERT INTO `relProductoProveedor` VALUES ('933', '3');
INSERT INTO `relProductoProveedor` VALUES ('934', '4');
INSERT INTO `relProductoProveedor` VALUES ('935', '3');
INSERT INTO `relProductoProveedor` VALUES ('935', '4');
INSERT INTO `relProductoProveedor` VALUES ('936', '4');
INSERT INTO `relProductoProveedor` VALUES ('937', '3');
INSERT INTO `relProductoProveedor` VALUES ('937', '4');
INSERT INTO `relProductoProveedor` VALUES ('938', '3');
INSERT INTO `relProductoProveedor` VALUES ('939', '3');
INSERT INTO `relProductoProveedor` VALUES ('940', '3');
INSERT INTO `relProductoProveedor` VALUES ('941', '25');
INSERT INTO `relProductoProveedor` VALUES ('942', '25');
INSERT INTO `relProductoProveedor` VALUES ('942', '29');
INSERT INTO `relProductoProveedor` VALUES ('943', '3');
INSERT INTO `relProductoProveedor` VALUES ('944', '3');
INSERT INTO `relProductoProveedor` VALUES ('947', '20');
INSERT INTO `relProductoProveedor` VALUES ('948', '25');
INSERT INTO `relProductoProveedor` VALUES ('949', '3');
INSERT INTO `relProductoProveedor` VALUES ('949', '4');
INSERT INTO `relProductoProveedor` VALUES ('950', '3');
INSERT INTO `relProductoProveedor` VALUES ('950', '4');
INSERT INTO `relProductoProveedor` VALUES ('951', '3');
INSERT INTO `relProductoProveedor` VALUES ('951', '4');
INSERT INTO `relProductoProveedor` VALUES ('952', '3');
INSERT INTO `relProductoProveedor` VALUES ('952', '4');
INSERT INTO `relProductoProveedor` VALUES ('953', '3');
INSERT INTO `relProductoProveedor` VALUES ('953', '4');
INSERT INTO `relProductoProveedor` VALUES ('953', '26');
INSERT INTO `relProductoProveedor` VALUES ('954', '3');
INSERT INTO `relProductoProveedor` VALUES ('954', '4');
INSERT INTO `relProductoProveedor` VALUES ('955', '3');
INSERT INTO `relProductoProveedor` VALUES ('955', '4');
INSERT INTO `relProductoProveedor` VALUES ('956', '3');
INSERT INTO `relProductoProveedor` VALUES ('956', '4');
INSERT INTO `relProductoProveedor` VALUES ('957', '3');
INSERT INTO `relProductoProveedor` VALUES ('957', '4');
INSERT INTO `relProductoProveedor` VALUES ('958', '3');
INSERT INTO `relProductoProveedor` VALUES ('958', '4');
INSERT INTO `relProductoProveedor` VALUES ('959', '3');
INSERT INTO `relProductoProveedor` VALUES ('959', '4');
INSERT INTO `relProductoProveedor` VALUES ('959', '26');
INSERT INTO `relProductoProveedor` VALUES ('960', '3');
INSERT INTO `relProductoProveedor` VALUES ('960', '4');
INSERT INTO `relProductoProveedor` VALUES ('961', '3');
INSERT INTO `relProductoProveedor` VALUES ('961', '4');
INSERT INTO `relProductoProveedor` VALUES ('962', '3');
INSERT INTO `relProductoProveedor` VALUES ('962', '4');
INSERT INTO `relProductoProveedor` VALUES ('963', '3');
INSERT INTO `relProductoProveedor` VALUES ('963', '4');
INSERT INTO `relProductoProveedor` VALUES ('964', '3');
INSERT INTO `relProductoProveedor` VALUES ('964', '4');
INSERT INTO `relProductoProveedor` VALUES ('964', '26');
INSERT INTO `relProductoProveedor` VALUES ('965', '3');
INSERT INTO `relProductoProveedor` VALUES ('965', '4');
INSERT INTO `relProductoProveedor` VALUES ('966', '3');
INSERT INTO `relProductoProveedor` VALUES ('966', '4');
INSERT INTO `relProductoProveedor` VALUES ('967', '3');
INSERT INTO `relProductoProveedor` VALUES ('967', '4');
INSERT INTO `relProductoProveedor` VALUES ('968', '3');
INSERT INTO `relProductoProveedor` VALUES ('968', '4');
INSERT INTO `relProductoProveedor` VALUES ('969', '36');
INSERT INTO `relProductoProveedor` VALUES ('971', '9');
INSERT INTO `relProductoProveedor` VALUES ('972', '3');
INSERT INTO `relProductoProveedor` VALUES ('973', '3');
INSERT INTO `relProductoProveedor` VALUES ('974', '3');
INSERT INTO `relProductoProveedor` VALUES ('974', '25');
INSERT INTO `relProductoProveedor` VALUES ('975', '3');
INSERT INTO `relProductoProveedor` VALUES ('975', '25');
INSERT INTO `relProductoProveedor` VALUES ('976', '3');
INSERT INTO `relProductoProveedor` VALUES ('976', '25');
INSERT INTO `relProductoProveedor` VALUES ('977', '4');
INSERT INTO `relProductoProveedor` VALUES ('978', '29');
INSERT INTO `relProductoProveedor` VALUES ('979', '3');
INSERT INTO `relProductoProveedor` VALUES ('979', '25');
INSERT INTO `relProductoProveedor` VALUES ('981', '3');
INSERT INTO `relProductoProveedor` VALUES ('981', '25');
INSERT INTO `relProductoProveedor` VALUES ('982', '3');
INSERT INTO `relProductoProveedor` VALUES ('982', '25');
INSERT INTO `relProductoProveedor` VALUES ('983', '3');
INSERT INTO `relProductoProveedor` VALUES ('983', '25');
INSERT INTO `relProductoProveedor` VALUES ('984', '29');
INSERT INTO `relProductoProveedor` VALUES ('985', '37');
INSERT INTO `relProductoProveedor` VALUES ('986', '29');
INSERT INTO `relProductoProveedor` VALUES ('987', '29');
INSERT INTO `relProductoProveedor` VALUES ('988', '3');
INSERT INTO `relProductoProveedor` VALUES ('988', '25');
INSERT INTO `relProductoProveedor` VALUES ('989', '29');
INSERT INTO `relProductoProveedor` VALUES ('990', '4');
INSERT INTO `relProductoProveedor` VALUES ('991', '29');
INSERT INTO `relProductoProveedor` VALUES ('992', '25');
INSERT INTO `relProductoProveedor` VALUES ('992', '29');
INSERT INTO `relProductoProveedor` VALUES ('994', '25');
INSERT INTO `relProductoProveedor` VALUES ('995', '25');
INSERT INTO `relProductoProveedor` VALUES ('996', '29');
INSERT INTO `relProductoProveedor` VALUES ('997', '29');
INSERT INTO `relProductoProveedor` VALUES ('999', '38');
INSERT INTO `relProductoProveedor` VALUES ('1000', '38');
INSERT INTO `relProductoProveedor` VALUES ('1001', '38');
INSERT INTO `relProductoProveedor` VALUES ('1002', '38');
INSERT INTO `relProductoProveedor` VALUES ('1003', '2');
INSERT INTO `relProductoProveedor` VALUES ('1004', '2');
INSERT INTO `relProductoProveedor` VALUES ('1005', '3');
INSERT INTO `relProductoProveedor` VALUES ('1006', '38');
INSERT INTO `relProductoProveedor` VALUES ('1007', '38');
INSERT INTO `relProductoProveedor` VALUES ('1008', '38');
INSERT INTO `relProductoProveedor` VALUES ('1009', '38');
INSERT INTO `relProductoProveedor` VALUES ('1010', '38');
INSERT INTO `relProductoProveedor` VALUES ('1011', '38');
INSERT INTO `relProductoProveedor` VALUES ('1012', '38');
INSERT INTO `relProductoProveedor` VALUES ('1013', '38');
INSERT INTO `relProductoProveedor` VALUES ('1014', '38');
INSERT INTO `relProductoProveedor` VALUES ('1015', '38');
INSERT INTO `relProductoProveedor` VALUES ('1016', '38');
INSERT INTO `relProductoProveedor` VALUES ('1017', '38');
INSERT INTO `relProductoProveedor` VALUES ('1018', '38');
INSERT INTO `relProductoProveedor` VALUES ('1019', '38');
INSERT INTO `relProductoProveedor` VALUES ('1020', '38');
INSERT INTO `relProductoProveedor` VALUES ('1022', '38');
INSERT INTO `relProductoProveedor` VALUES ('1023', '38');
INSERT INTO `relProductoProveedor` VALUES ('1024', '38');
INSERT INTO `relProductoProveedor` VALUES ('1025', '38');
INSERT INTO `relProductoProveedor` VALUES ('1026', '38');
INSERT INTO `relProductoProveedor` VALUES ('1027', '38');
INSERT INTO `relProductoProveedor` VALUES ('1029', '4');
INSERT INTO `relProductoProveedor` VALUES ('1030', '4');
INSERT INTO `relProductoProveedor` VALUES ('1031', '38');
INSERT INTO `relProductoProveedor` VALUES ('1032', '38');
INSERT INTO `relProductoProveedor` VALUES ('1033', '38');
INSERT INTO `relProductoProveedor` VALUES ('1034', '38');
INSERT INTO `relProductoProveedor` VALUES ('1035', '38');
INSERT INTO `relProductoProveedor` VALUES ('1036', '38');
INSERT INTO `relProductoProveedor` VALUES ('1037', '38');
INSERT INTO `relProductoProveedor` VALUES ('1038', '3');
INSERT INTO `relProductoProveedor` VALUES ('1039', '38');
INSERT INTO `relProductoProveedor` VALUES ('1040', '38');
INSERT INTO `relProductoProveedor` VALUES ('1041', '3');
INSERT INTO `relProductoProveedor` VALUES ('1042', '38');
INSERT INTO `relProductoProveedor` VALUES ('1044', '3');
INSERT INTO `relProductoProveedor` VALUES ('1044', '4');
INSERT INTO `relProductoProveedor` VALUES ('1045', '3');
INSERT INTO `relProductoProveedor` VALUES ('1045', '4');
INSERT INTO `relProductoProveedor` VALUES ('1046', '3');
INSERT INTO `relProductoProveedor` VALUES ('1046', '4');
INSERT INTO `relProductoProveedor` VALUES ('1047', '3');
INSERT INTO `relProductoProveedor` VALUES ('1047', '4');
INSERT INTO `relProductoProveedor` VALUES ('1048', '3');
INSERT INTO `relProductoProveedor` VALUES ('1048', '4');
INSERT INTO `relProductoProveedor` VALUES ('1049', '3');
INSERT INTO `relProductoProveedor` VALUES ('1049', '4');
INSERT INTO `relProductoProveedor` VALUES ('1050', '9');
INSERT INTO `relProductoProveedor` VALUES ('1058', '32');
INSERT INTO `relProductoProveedor` VALUES ('1060', '2');
INSERT INTO `relProductoProveedor` VALUES ('1064', '32');
INSERT INTO `relProductoProveedor` VALUES ('1065', '32');
INSERT INTO `relProductoProveedor` VALUES ('1068', '32');
INSERT INTO `relProductoProveedor` VALUES ('1070', '39');
INSERT INTO `relProductoProveedor` VALUES ('1072', '23');
INSERT INTO `relProductoProveedor` VALUES ('1072', '32');
INSERT INTO `relProductoProveedor` VALUES ('1073', '32');
INSERT INTO `relProductoProveedor` VALUES ('1074', '32');
INSERT INTO `relProductoProveedor` VALUES ('1078', '23');
INSERT INTO `relProductoProveedor` VALUES ('1086', '32');
INSERT INTO `relProductoProveedor` VALUES ('1087', '32');
INSERT INTO `relProductoProveedor` VALUES ('1088', '32');
INSERT INTO `relProductoProveedor` VALUES ('1089', '32');
INSERT INTO `relProductoProveedor` VALUES ('1095', '2');
INSERT INTO `relProductoProveedor` VALUES ('1096', '2');
INSERT INTO `relProductoProveedor` VALUES ('1097', '40');
INSERT INTO `relProductoProveedor` VALUES ('1098', '40');
INSERT INTO `relProductoProveedor` VALUES ('1100', '39');
INSERT INTO `relProductoProveedor` VALUES ('1101', '32');
INSERT INTO `relProductoProveedor` VALUES ('1104', '32');
INSERT INTO `relProductoProveedor` VALUES ('1105', '23');
INSERT INTO `relProductoProveedor` VALUES ('1106', '32');
INSERT INTO `relProductoProveedor` VALUES ('1107', '41');
INSERT INTO `relProductoProveedor` VALUES ('1108', '32');
INSERT INTO `relProductoProveedor` VALUES ('1109', '40');
INSERT INTO `relProductoProveedor` VALUES ('1110', '40');
INSERT INTO `relProductoProveedor` VALUES ('1111', '32');
INSERT INTO `relProductoProveedor` VALUES ('1112', '32');
INSERT INTO `relProductoProveedor` VALUES ('1113', '32');
INSERT INTO `relProductoProveedor` VALUES ('1114', '23');
INSERT INTO `relProductoProveedor` VALUES ('1116', '32');
INSERT INTO `relProductoProveedor` VALUES ('1117', '32');
INSERT INTO `relProductoProveedor` VALUES ('1119', '2');
INSERT INTO `relProductoProveedor` VALUES ('1120', '2');
INSERT INTO `relProductoProveedor` VALUES ('1121', '32');
INSERT INTO `relProductoProveedor` VALUES ('1122', '32');
INSERT INTO `relProductoProveedor` VALUES ('1123', '32');
INSERT INTO `relProductoProveedor` VALUES ('1124', '32');
INSERT INTO `relProductoProveedor` VALUES ('1125', '32');
INSERT INTO `relProductoProveedor` VALUES ('1126', '39');
INSERT INTO `relProductoProveedor` VALUES ('1128', '39');
INSERT INTO `relProductoProveedor` VALUES ('1129', '32');
INSERT INTO `relProductoProveedor` VALUES ('1130', '23');
INSERT INTO `relProductoProveedor` VALUES ('1131', '32');
INSERT INTO `relProductoProveedor` VALUES ('4625', '1');
