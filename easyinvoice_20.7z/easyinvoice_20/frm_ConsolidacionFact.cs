using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using clsFactElectronica;

namespace EasyInvoice
{
    public partial class frm_ConsolidacionFact : Form
    {
		private List<int> mIdNotas = new List<int>();
		private int mClientId = -1;
		public string mNumFact = "";
		
        string mpRfcCliente = "";
        string mpRazonSocialCliente = "";
        string mpCalleCliente = "";
        string mpNumeroExtCliente = "";
        string mpNumeroIntCliente = "";
        string mpColoniaCliente = "";
        string mpLocalidadCliente = "";
        string mpReferenciaCliente = "";
        string mpMunicipioCliente = "";
        string mpEstadoCliente = "";
        string mpPaisCliente = "";
        string mpCodigoPostalCliente = "";		
		
        private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();
		
		private System.Drawing.Printing.PrintDocument printDocument1;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;		
		private string mpIdFactura = "-1";
		
        private System.String m_cadena_original = "";
        private System.String m_sello = "";

        public frm_Facturaslist mParent = null;

        private void LoadData()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

            lConn.Open();
            System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

            if (lReader.Read())
            {
                this.mConfFact.Version = lReader["Version"].ToString();
                this.mConfFact.Serie = lReader["Serie"].ToString();
                this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
                this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
                this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
                this.mConfFact.RFC = lReader["RFC"].ToString();
                this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
                this.mConfFact.Calle = lReader["Calle"].ToString();
                this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
                this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
                this.mConfFact.Colonia = lReader["Colonia"].ToString();
                this.mConfFact.Localidad = lReader["Localidad"].ToString();
                this.mConfFact.Referencia = lReader["Referencia"].ToString();
                this.mConfFact.Municipio = lReader["Municipio"].ToString();
                this.mConfFact.Estado = lReader["Estado"].ToString();
                this.mConfFact.Pais = lReader["Pais"].ToString();
                this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
            }

            lConn.Close();
        }		
		
        public frm_ConsolidacionFact()
        {
            InitializeComponent();
			
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();			
			
            // 
            // printDocument1
            // 
            this.printDocument1.DocumentName = "Factura";
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;			
        }
		
		public void AgregarNota(int pIdNota,string pDescription)
		{
			if( this.mIdNotas.Contains(pIdNota) == false )
			{
				this.mIdNotas.Add(pIdNota);
				this.lbListaFacturas.Items.Add( pDescription );
			}
		}

		private void cmdRemover_Click(object sender, EventArgs e)
		{
			if( this.lbListaFacturas.SelectedItems.Count > 0 )
			{
				this.mIdNotas.RemoveAt( this.lbListaFacturas.SelectedIndex );
				this.lbListaFacturas.Items.Remove( this.lbListaFacturas.SelectedItems[0] );
			}
		}
		
		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			int l_desglosar_iva = this.DesglosarIVA();
			System.String l_key = this.mpIdFactura;

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;

			System.Data.Odbc.OdbcCommand l_cmd;
            System.Data.Odbc.OdbcCommand l_cmd2;
			System.Data.Odbc.OdbcDataReader l_reader;
			System.Data.Odbc.OdbcDataReader l_reader2;			    
			

                l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = l_conn;
                l_cmd.CommandText = "SELECT catFacturas.NumeroFactura, catFacturas.Fecha, catFacturas.Subtotal, catFacturas.Total, catClientes.Nombre, catClientes.Direccion, catClientes.RFC, catClientes.ciudad, catFacturas.cadenaoriginal, catFacturas.sello FROM catFacturas LEFT OUTER JOIN catClientes ON catFacturas.IdCliente = catClientes.IdCliente WHERE IdFactura = " + l_key + ";";

                l_cmd2 = new System.Data.Odbc.OdbcCommand();
                l_cmd2.Connection = l_conn;
                l_cmd2.CommandText = "SELECT detFactura.PrecioCalculado, detFactura.Cantidad, detFactura.PrecioDescuento, catProductos.CodigoProd, catProductos.Descripcion, detFactura.IdFactura, detFactura.unidaddeventa, detFactura.iva FROM detFactura LEFT OUTER JOIN catProductos ON detFactura.IdProducto = catProductos.IdProducto WHERE IdFactura = " + l_key + ";";


			l_conn.Open();
			l_reader = l_cmd.ExecuteReader();
			l_reader.Read();

			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Courier",this.mp_int_TamanioLetra);    
			System.Drawing.Font l_fontcant = new Font("Courier",this.mp_int_TamanioLetra);
            System.Drawing.Font l_fontcanorig = new Font("Arial", 7);
			System.Drawing.Font l_fontcanorighead = new Font("Arial", 7,FontStyle.Bold);

			

			//Numero
			//MessageBox.Show("antes del numero"); 
			if(this.mp_int_PosNumFactX != -1)
				e.Graphics.DrawString("No. " + l_reader["NumeroFactura"].ToString(),l_font,l_brush,this.mp_int_PosNumFactX,this.mp_int_PosNumFactY);   			 

			//Nombre
			//MessageBox.Show("antes del nombre"); 
			if(this.mp_int_PosNombreX != -1)
				e.Graphics.DrawString(l_reader["Nombre"].ToString(),l_font,l_brush,this.mp_int_PosNombreX,this.mp_int_PosNombreY);   			 

			//Dirección
			//MessageBox.Show("antes del direccion"); 
			if(this.mp_int_PosDireccionX != -1)
				e.Graphics.DrawString(l_reader["Direccion"].ToString(),l_font,l_brush,this.mp_int_PosDireccionX,this.mp_int_PosDireccionY);   			 

			//Ciudad
			//MessageBox.Show("antes del ciudad"); 
			if(this.mp_int_PosCiudadX != -1)
				e.Graphics.DrawString(l_reader["ciudad"].ToString(),l_font,l_brush,this.mp_int_PosCiudadX,this.mp_int_PosCiudadY);   			 

			//Fecha
			//MessageBox.Show("antes del fecha"); 
			if(this.mp_int_PosFechaX != -1)
                e.Graphics.DrawString( /*System.String.Format("{0:d}",l_reader.GetDateTime(1))*/l_reader.GetDateTime(1).ToString(), l_font, l_brush, this.mp_int_PosFechaX, this.mp_int_PosFechaY);   			 

			//RFC
			//MessageBox.Show("antes del rfc"); 
			if(this.mp_int_PosRFCX != -1)
				e.Graphics.DrawString(l_reader["RFC"].ToString(),l_font,l_brush,this.mp_int_PosRFCX,this.mp_int_PosRFCY);   		
	 

            	this.m_cadena_original = l_reader["cadenaoriginal"].ToString();	
		    	this.m_sello = l_reader["sello"].ToString();

			//Separar los centavos...
			System.Double l_centavos;
			System.Double l_total;

            l_total = Convert.ToDouble(l_reader[3]);

			l_total = l_total * 100;
			l_centavos = l_total % 100;
			l_total = l_total - l_centavos;
			l_total = l_total / 100;
			
			l_total = System.Math.Round(l_total,2);

			System.String l_cantidad;
			
			l_cantidad = this.GetStringValue(System.String.Format("{0:C}",l_total));
			
			if(l_centavos > 0)
			{
				System.String l_cantcent = System.String.Format(" {0}/100",System.Math.Round(l_centavos,2));
				l_cantidad = l_cantidad + l_cantcent;
			}

			l_cantidad = l_cantidad + " MN";
			if(this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY != -2)
				    e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,this.mp_int_PosGTotalLetrasX,this.mp_int_PosGTotalLetrasY);   			 		 
			//e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,150,485);   			 		 

            double l_subtotal_t = Convert.ToDouble(l_reader[2]);
            double l_iva_t = Convert.ToDouble(l_reader[3]) - Convert.ToDouble(l_reader[2]);
            double l_gtotal_t = Convert.ToDouble(l_reader[3]);
			
			l_reader.Close(); 

			l_reader2 = l_cmd2.ExecuteReader();

			System.Int32 i=0;
			System.Int32 l_pos = 0;

			System.Double l_d1,l_d2;
			System.String l_s1,l_s2;
 
			while(l_reader2.Read())
			{
				l_pos = i*12;

				if(this.mp_int_PosCodigoX != -1)
                    e.Graphics.DrawString(l_reader2[3].ToString(), l_font, l_brush, this.mp_int_PosCodigoX, this.mp_int_PosCodigoY + l_pos);
                //e.Graphics.DrawString( l_reader2.GetString(3) ,l_font,l_brush,this.mp_int_PosCodigoX,this.mp_int_PosCodigoY+l_pos);
				if(this.mp_int_PosCantidadX != -1)
                    e.Graphics.DrawString(l_reader2[1].ToString() + " " + l_reader2["unidaddeventa"].ToString(), l_font, l_brush, this.mp_int_PosCantidadX, this.mp_int_PosCantidadY + l_pos);
                //e.Graphics.DrawString(l_reader2.GetDouble(1).ToString() + " " + l_reader2["unidaddeventa"].ToString(), l_font, l_brush, this.mp_int_PosCantidadX, this.mp_int_PosCantidadY + l_pos);   		
				if(this.mp_int_PosDescripcionX != -1)//Aqui muevele rich
                    e.Graphics.DrawString(l_reader2[4].ToString().Length > 15 ? l_reader2[4].ToString().Substring(0, 15) : l_reader2[4].ToString(), l_font, l_brush, this.mp_int_PosDescripcionX, this.mp_int_PosDescripcionY + l_pos);
					//e.Graphics.DrawString( l_reader2.GetString(4) ,l_font,l_brush,this.mp_int_PosDescripcionX,this.mp_int_PosDescripcionY+l_pos);

				//MessageBox.Show("antes del precio 1"); 
                l_d1 = System.Convert.ToDouble(Convert.ToDouble(l_reader2[2]));  
				//MessageBox.Show("antes del precio 2"); 
                l_d2 = System.Convert.ToDouble(Convert.ToDouble(l_reader2[0]));

                if (l_desglosar_iva == 0)
                {
                    l_d1 = l_d1*(( Convert.ToDouble(l_reader2["iva"])/100 )+1);
                    l_d2 = l_d2 *(( Convert.ToDouble(l_reader2["iva"])/100 )+1);
                }

				l_s1 = System.String.Format("{0:C}",l_d1);
				l_s2 = System.String.Format("{0:C}",l_d2);
 		
				if(this.mp_int_PosPrecioX != -1)
					e.Graphics.DrawString(l_s1,l_font,l_brush,this.mp_int_PosPrecioX,this.mp_int_PosPrecioY+l_pos);   		
				if(this.mp_int_PosTotalX != -1)
					e.Graphics.DrawString(l_s2,l_font,l_brush,this.mp_int_PosTotalX,this.mp_int_PosTotalY+l_pos);

				i++;

			}
			

			l_reader2.Close();

            if (l_desglosar_iva == 1)
            {

                if (this.mp_int_PosSubTotalX != -1)
                {
                    if (this.mp_int_PosSubTotalY == -2)
                    {
                        l_pos += 20;
                        e.Graphics.DrawString("SUBTOTAL", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_subtotal_t), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        l_pos += this.mp_int_EspacioDetalle;
                    }
                    else
                    {
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_subtotal_t), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosSubTotalY);
                    }
                }

                if (this.mp_int_PosIVAX != -1)
                {
                    if (this.mp_int_PosIVAY == -2)
                    {
                        e.Graphics.DrawString("IVA", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva_t), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
                        l_pos += this.mp_int_EspacioDetalle;
                    }
                    else
                    {
                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva_t), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosIVAY);
                    }
                }
            }
            else
            {
                l_pos += this.mp_int_EspacioDetalle;
            }

			if(this.mp_int_PosGTotalX != -1)
			{
				if(this.mp_int_PosGTotalY == -2)
				{
					e.Graphics.DrawString("TOTAL",l_font,l_brush,this.mp_int_PosSubTotalX - 100,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   			 
					e.Graphics.DrawString(System.String.Format("{0:C}",l_gtotal_t),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   		
				}
				else
				{
					e.Graphics.DrawString(System.String.Format("{0:C}",l_gtotal_t),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosGTotalY);   		
				}
			}

            //if (this.m_notas == false)
            {
                if (this.mp_int_PosCadenaOriginalX != -1)
                {
                    if (this.mp_int_PosCadenaOriginalY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
						e.Graphics.DrawString("Cadena Original",
                                l_fontcanorighead, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY );		
						
                        while (lPos < this.m_cadena_original.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_cadena_original.Length)
                                lPosEnd = this.m_cadena_original.Length;

                            e.Graphics.DrawString(this.m_cadena_original.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }

            //int mp_int_PosSelloX = 0;
            //int mp_int_PosSelloY = 0;

            //if (this.m_notas == false)
            {
                if (this.mp_int_PosSelloX != -1)
                {
                    if (this.mp_int_PosSelloY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
                            e.Graphics.DrawString("Sello Digital",
                                l_fontcanorighead, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY );							
						
                        while (lPos < this.m_sello.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_sello.Length)
                                lPosEnd = this.m_sello.Length;

                            e.Graphics.DrawString(this.m_sello.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }

            if (this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY == -2)
                    e.Graphics.DrawString(l_cantidad, l_fontcant, l_brush, this.mp_int_PosGTotalLetrasX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle + 13);   


			l_conn.Close();  			
		}
		
		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 

            string l_retval = "";

            clsUtils.cUtils l_utils = new clsUtils.cUtils();

            if (Convert.ToDouble(l_num) < 1)
                l_retval = "CERO PESOS " + l_utils.Transforma(l_num);
            else
                l_retval = l_utils.Transforma(l_num);

            return l_retval;

		}		
		
        private void cmdCliente_Click(object sender, EventArgs e)
        {
			if( MessageBox.Show("Va a crear la factura a un cliente existente?","Consolidar",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.No)
			{
				
				////////////////////////////////////
				//Agregar un cliente nuevo...
				frm_Clientes l_frm = new frm_Clientes(); 
				l_frm.ShowDialog(); 	
			
				if(l_frm.m_KeyRecord!=-1)
				{
					this.mClientId = l_frm.m_KeyRecord;
					this.label1.Text = "Notas Seleccionadas. Cliente : [" + this.GetClientString() + "]";				
				}				
				
			}
			else
			{
				//////////////////////////////////////
				//Buscar un cliente en la lista
				frm_ClientsList l_frmClientes = new frm_ClientsList();
				l_frmClientes.cmd_nuevo.Enabled = false;            
	            l_frmClientes.mp_toolbar.Buttons[1].Enabled = false;

	            l_frmClientes.mp_criteriousar = "";
				l_frmClientes.ShowDialog(); 
	
				if(l_frmClientes.m_KeyRecord!=-1)
				{
					//MessageBox.Show( l_frmClientes.m_KeyRecord.ToString() );
					
					this.mClientId = l_frmClientes.m_KeyRecord;
					this.label1.Text = "Notas Seleccionadas. Cliente : [" + this.GetClientString() + "]";
					
				}				
				//////////////////////////////////////
			}
        }
		
		private string GetClientString()
		{
			string lRetVal = "";
			
			try{
			
	        System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
	        l_conn.ConnectionString = frm_Main.mps_strconnection;
	
	        System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();	                
	        
	        l_conn.Open();
	        
	        l_cmd.Connection = l_conn;
	        l_cmd.CommandText = "select * from catClientes where IdCliente = " + this.mClientId.ToString();
	        l_cmd.CommandType = System.Data.CommandType.Text;
	        
	        System.Data.Odbc.OdbcDataReader lReader = l_cmd.ExecuteReader();
	        
	        if( lReader.Read() )
			{
				lRetVal = lReader["Nombre"].ToString() + ", " + lReader["RFC"].ToString();
					
				
	            this.mpRfcCliente = lReader["RFC"].ToString();
	            this.mpRazonSocialCliente = lReader["Nombre"].ToString();
	            this.mpCalleCliente = lReader["Calle"].ToString();
	            this.mpNumeroExtCliente = lReader["Numero"].ToString();
	            this.mpNumeroIntCliente = lReader["NumeroInt"].ToString();
	            this.mpColoniaCliente = lReader["Colonia"].ToString();
	            this.mpLocalidadCliente = lReader["ciudad"].ToString();
	            this.mpReferenciaCliente = lReader["Referencia"].ToString();
	            this.mpMunicipioCliente = lReader["Municipio"].ToString();
	            this.mpEstadoCliente = lReader["Estado"].ToString();
	            this.mpPaisCliente = lReader["Pais"].ToString();
	            this.mpCodigoPostalCliente = lReader["CodigoPostal"].ToString();
	            			
					
			}
	        
	        l_conn.Close();	  
			
			}
			catch( System.Exception ex)
			{
				MessageBox.Show("Error al leer el cliente : " + ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
				
			return lRetVal;
		}

        private void cmdConsolidar_Click(object sender, EventArgs e)
        {
			if( this.mClientId == -1 )
			{
				MessageBox.Show("Es necesario seleccionar el cliente para la factura.","Consolidar",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return;
			}
			
			if( this.mIdNotas.Count == 0 )
			{
				MessageBox.Show("No ha seleccionado notas para consolidar.","Consolidar",MessageBoxButtons.OK,MessageBoxIcon.Information);
				return;
			}
			
			this.LoadData();
			this.LoadDocPositions();
			this.ConsolidarNotas();
        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
			this.Visible = false;
        }
		
        private void HandleHandleClosing (object sender, System.ComponentModel.CancelEventArgs e)
        {
        	e.Cancel = true;
			this.Visible = false;
        }
		
		private void ConsolidarNotas()
		{	
			int lCount = 1;
			double lSubTotal = 0;
			double lTotal = 0;
			double lIVA = 0;
			double lIvaValue = 0;
			
			System.Collections.Generic.List<string> lDetailDataArr = new System.Collections.Generic.List<string>();
			
			System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
			l_conn.ConnectionString = frm_Main.mps_strconnection;
			System.Data.Odbc.OdbcTransaction l_trans = null;
			
			try
			{
				/////////////////////////////////////////////////////////////////////
				l_conn.Open();
				l_trans = l_conn.BeginTransaction();		
					
				this.mNumFact = GetNumFac(true,l_conn,l_trans);
				System.Data.DataTable lDetalle = this.GetArticulosFactura(l_conn,l_trans);
				
				//Calcular el total y el subtotal
                lCount = 1;
				foreach(DataRow lRow in lDetalle.Rows)
				{
					lIVA = ( (Convert.ToDouble(lRow["iva"])/100)+1 );
					lSubTotal += ( Convert.ToDouble(lRow["PrecioCalculado"]) );
					lTotal = lSubTotal*lIVA;
					lTotal = System.Math.Round(lTotal,2);
					lIvaValue = Convert.ToDouble(lRow["iva"]);
				}				
				
				System.Data.Odbc.OdbcCommand l_insertf = new System.Data.Odbc.OdbcCommand();
				l_insertf.Connection = l_conn;
				l_insertf.CommandText = "INSERT INTO catFacturas(IdCliente,NumeroFactura,Fecha,NumProductos,SubTotal,Total,EsCredito,usuario,estatus,entregado,usuarioventa) VALUES(?,?,?,?,?,?,?,?,?,?,?);";
				
	            System.Data.Odbc.OdbcParameter l_p1 = new System.Data.Odbc.OdbcParameter("@IdCliente", System.Data.Odbc.OdbcType.Int);
	            l_p1.Value = this.mClientId;
	            l_insertf.Parameters.Add(l_p1);
	
	            System.Data.Odbc.OdbcParameter l_p2 = new System.Data.Odbc.OdbcParameter("@NumeroFactura", System.Data.Odbc.OdbcType.VarChar);
	            l_p2.Value = this.mNumFact;
	            l_insertf.Parameters.Add(l_p2);
	
	            System.Data.Odbc.OdbcParameter l_p3 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
	            l_p3.Value = DateTime.Now;
	            l_insertf.Parameters.Add(l_p3);
				
				/////////////////////////////
				
	            System.Data.Odbc.OdbcParameter l_p4 = new System.Data.Odbc.OdbcParameter("@NumProductos", System.Data.Odbc.OdbcType.Int);
	            l_p4.Value = this.GetNumArticulos(l_conn,l_trans);
				l_insertf.Parameters.Add(l_p4);
	
	            System.Data.Odbc.OdbcParameter l_p5 = new System.Data.Odbc.OdbcParameter("@SubTotal", System.Data.Odbc.OdbcType.Double);
	            l_p5.Value = System.Math.Round(lSubTotal,2);
				l_insertf.Parameters.Add(l_p5);
	
	            System.Data.Odbc.OdbcParameter l_p6 = new System.Data.Odbc.OdbcParameter("@Total", System.Data.Odbc.OdbcType.Double);
	            l_p6.Value = System.Math.Round(lTotal,2);
				l_insertf.Parameters.Add(l_p6);
	
	            System.Data.Odbc.OdbcParameter l_p7_ = new System.Data.Odbc.OdbcParameter("@EsCredito", System.Data.Odbc.OdbcType.Bit);
	            l_p7_.Value = this.chkEsCredito.Checked;
				l_insertf.Parameters.Add(l_p7_);
	
	            System.Data.Odbc.OdbcParameter l_p8_ = new System.Data.Odbc.OdbcParameter("@usuario", System.Data.Odbc.OdbcType.VarChar);
	            l_p8_.Value = frm_Main.mps_usuario;
				l_insertf.Parameters.Add(l_p8_);
	
	            System.Data.Odbc.OdbcParameter l_p9_ = new System.Data.Odbc.OdbcParameter("@estatus", System.Data.Odbc.OdbcType.Int);
	            l_p9_.Value = 1;
				l_insertf.Parameters.Add(l_p9_);
	
	            System.Data.Odbc.OdbcParameter l_p10_ = new System.Data.Odbc.OdbcParameter("@entregado",System.Data.Odbc.OdbcType.Double);
	            l_p10_.Value = 1;
				l_insertf.Parameters.Add(l_p10_);
	
	            System.Data.Odbc.OdbcParameter l_p11_ = new System.Data.Odbc.OdbcParameter("@usuarioventa",System.Data.Odbc.OdbcType.VarChar);
	            l_p11_.Value = frm_Main.mps_usuario;		
				l_insertf.Parameters.Add(l_p11_);
				
				l_insertf.Transaction = l_trans;
				l_insertf.ExecuteNonQuery();
				l_insertf.Dispose();
				
				//Obtener el id insertado...
				System.Data.Odbc.OdbcCommand lLastID = new System.Data.Odbc.OdbcCommand();
				lLastID.Connection = l_conn;
                lLastID.Transaction = l_trans;
                lLastID.CommandText = "SELECT LAST_INSERT_ID() as lastid;";
				System.Data.Odbc.OdbcDataReader lRdrLastID = lLastID.ExecuteReader();
				
				lRdrLastID.Read();
				
				int l_keyf = Convert.ToInt32(lRdrLastID["lastid"]);
				
				//Insertar el detalle de la nueva factura...
				double lDescuento = 0;
				foreach(DataRow lRow in lDetalle.Rows)		
				{
	                System.Text.StringBuilder lDetailData = new System.Text.StringBuilder();
	
	                ////////////////////////////////////////////////
	                //Detalle para la factura electronica
					
	                lDetailData.Append( string.Format("{0:0.00}", Math.Round(Convert.ToDouble(lRow["Cantidad"]), 2)) );
	                lDetailData.Append("|");
	                lDetailData.Append(lRow["unidaddeventa"].ToString());
	                lDetailData.Append("|");
	                lDetailData.Append(lRow["Codigo"].ToString());
	                lDetailData.Append("|");
	                lDetailData.Append(lRow["Descripcion"].ToString());
	                lDetailData.Append("|");
	                lDetailData.Append(string.Format("{0:0.00}", Math.Round(Convert.ToDouble(lRow["PrecioDescuento"]), 2)));
	                lDetailData.Append("|");
	                lDetailData.Append(string.Format("{0:0.00}", Math.Round(Convert.ToDouble(lRow["PrecioCalculado"]), 2)));
	                lDetailDataArr.Add(lDetailData.ToString());
	                
	                ////////////////////////////////////////////////				
					
					System.Data.Odbc.OdbcCommand l_insertd = new System.Data.Odbc.OdbcCommand();
					l_insertd.Connection = l_conn;
					l_insertd.Transaction = l_trans;
					l_insertd.CommandText = "INSERT INTO detFactura(IdFactura,IdProducto,PrecioOriginal,PrecioDescuento,Cantidad,PrecioCalculado,DescuentoAplicado,unidaddeventa,iva) VALUES(?,?,?,?,?,?,?,?,?);";
					
	                l_insertd.Parameters.AddWithValue("@IdFactura", l_keyf);
	                l_insertd.Parameters.AddWithValue("@IdProducto", System.Convert.ToInt32(lRow["IdProducto"]));
	                l_insertd.Parameters.AddWithValue("@PrecioOriginal", System.Convert.ToDouble( lRow["PrecioOriginal"] ));
	                l_insertd.Parameters.AddWithValue("@PrecioDescuento", System.Convert.ToDouble( lRow["PrecioDescuento"] ));
	
	                lDescuento += (System.Convert.ToDouble(lRow["PrecioOriginal"]) - System.Convert.ToDouble(lRow["PrecioDescuento"]));
	
	                l_insertd.Parameters.AddWithValue("@Cantidad", System.Convert.ToDouble(lRow["Cantidad"]));
	                l_insertd.Parameters.AddWithValue("@PrecioCalculado", System.Convert.ToDouble(lRow["PrecioCalculado"]));
	                l_insertd.Parameters.AddWithValue("@DescuentoAplicado", System.Convert.ToDouble(lRow["DescuentoAplicado"]));
	                l_insertd.Parameters.AddWithValue("@unidaddeventa", lRow["unidaddeventa"].ToString());
	
	                l_insertd.Parameters.AddWithValue("@iva", Convert.ToInt32(lRow["iva"]));	
					
					//try
					//{
						l_insertd.ExecuteNonQuery();
						l_insertd.Dispose();	
					//}
					//catch(System.Exception ex)
					//{
					//	System.Console.WriteLine(ex.Message);
					//}
				}
				
				//Generar la cadena original...
		        //////////////////
				/*
				clsFactElectronica.clsFactElec lFE = new clsFactElectronica.clsFactElec();
					                
	            //Almacenar la cadena original y el sello
				string lFecha = DateTime.Now.Year.ToString() + "-" + ( DateTime.Now.Month.ToString().Length == 2 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString() );
				lFecha += "-" + ( DateTime.Now.Day.ToString().Length == 2 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString() );
				lFecha += "T" + ( DateTime.Now.Hour.ToString().Length == 2 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString() );
				lFecha += ":" + ( DateTime.Now.Minute.ToString().Length == 2 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString() );
				lFecha += ":" + ( DateTime.Now.Second.ToString().Length == 2 ? DateTime.Now.Second.ToString() : "0" + DateTime.Now.Second.ToString() );
				
	            string lCadenaOriginal = lFE.GenerarCadenaOriginal(this.mConfFact, this.mNumFact, lFecha,
	                "UNA SOLA EXIBICION",
	                string.Format("{0:0.00}", Math.Round(lSubTotal, 2)),
	                string.Format("{0:0.00}", Math.Round(lDescuento, 2)),
	                string.Format("{0:0.00}", Math.Round(lTotal, 2)),
	                this.mpRfcCliente,
	                this.mpRazonSocialCliente,
	                this.mpCalleCliente,
	                this.mpNumeroExtCliente,
	                this.mpNumeroIntCliente,
	                this.mpColoniaCliente,
	                this.mpLocalidadCliente,
	                this.mpReferenciaCliente,
	                this.mpMunicipioCliente,
	                this.mpEstadoCliente,
	                this.mpPaisCliente,
	                this.mpCodigoPostalCliente,
	                string.Format("{0:0.00}", Math.Round(lIvaValue*100, 2)),
	                string.Format("{0:0.00}", Math.Round(lTotal - lSubTotal, 2)),
	                lDetailDataArr);
	
	            //this.mp_IVA
	            lFE.mOpenSSLPath = ConfigurationSettings.AppSettings["opensslpath"];
				
				string lKeyFile = "";
				try
				{
					lKeyFile = System.IO.File.ReadAllText("keyfile.txt").Trim();
				}
				catch(Exception ex)
				{
					throw new Exception("Es necesario importar el archivo llave de facturacion electronica antes de generar una factura.");						
				}
	            string lSello = lFE.GenerarSello(lCadenaOriginal, lKeyFile);
	
				///////////////////////
	            //Actualizar la factura
	            System.Data.Odbc.OdbcCommand lCmdEND = new System.Data.Odbc.OdbcCommand();
	            lCmdEND.Connection = l_conn;
	            lCmdEND.Transaction = l_trans;
	            lCmdEND.CommandText = "UPDATE catFacturas SET cadenaoriginal = ?,sello = ? where IdFactura = ?";
	
	            lCmdEND.Parameters.AddWithValue("@cadenaoriginal", lCadenaOriginal);
	            lCmdEND.Parameters.AddWithValue("@sello", lSello);
	            lCmdEND.Parameters.AddWithValue("@IdFactura", l_keyf);
	
	            lCmdEND.ExecuteNonQuery();
				lCmdEND.Dispose();
				*/
	            //////////////////	
				
				//Insertar en el catalogo de consolidacion
	            System.Data.Odbc.OdbcCommand lCmdEND = new System.Data.Odbc.OdbcCommand();
	            lCmdEND.Connection = l_conn;
	            lCmdEND.Transaction = l_trans;
	            lCmdEND.CommandText = "INSERT INTO catConsolidacionFactura(iidfactura) VALUES(" + l_keyf.ToString() + ")";			
				lCmdEND.ExecuteNonQuery();
				lCmdEND.Dispose();
				
				//Obtener el id insertado...
				lLastID = new System.Data.Odbc.OdbcCommand();
				lLastID.Connection = l_conn;
				lLastID.Transaction = l_trans;
				lLastID.CommandText = "SELECT LAST_INSERT_ID() as lastid;";
				lRdrLastID = lLastID.ExecuteReader();
				
				lRdrLastID.Read();
				
				int l_keyCons = Convert.ToInt32(lRdrLastID["lastid"]);		
				lLastID.Dispose();
				
				//Insertar el detalle de notas...
				foreach(int lIdNota in this.mIdNotas)
				{
					//Insertar en el catalogo de consolidacion
		            lCmdEND = new System.Data.Odbc.OdbcCommand();
		            lCmdEND.Connection = l_conn;
		            lCmdEND.Transaction = l_trans;
		            lCmdEND.CommandText = "INSERT INTO detConsolidacionFactura(iidconsolidacion,iidnota) VALUES(" + l_keyCons.ToString() + "," + lIdNota.ToString() + ")";			
					lCmdEND.ExecuteNonQuery();
					lCmdEND.Dispose();				
				}
			
				l_trans.Commit();
				
				this.lbListaFacturas.Items.Clear();
				this.mIdNotas.Clear();
				this.Visible = false;			
				this.mClientId = -1;
				this.label1.Text = "Notas Seleccionadas";
                this.mParent.FillDataset();

				if( MessageBox.Show("La(s) nota(s) seleccionada(s) han sido consolidadas en la factura " + this.mNumFact + ". Desea visualizar la factura?","Consolidar",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
				{
				
					this.mpIdFactura = l_keyf.ToString();
	                this.printPreviewDialog1.WindowState = FormWindowState.Maximized;
	                this.printPreviewDialog1.ShowDialog();		
					
				}
				
				//////////////////////////////////////////////////////////////////////////
			}
			catch(System.Exception ex)
			{
                if (l_trans != null)
                    l_trans.Rollback();
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);				
			}
            finally
            {                

                if (l_conn.State == System.Data.ConnectionState.Open)
                    l_conn.Close();

            }			
			
			//l_conn.Close();
			
			this.Text = "Consolidacion de Notas";
			
		}
		
        private int DesglosarIVA()
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            int l_result = Convert.ToInt32(l_reader["DesglosarIva"]);

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
        }		
		
		private DataTable GetArticulosFactura(System.Data.Odbc.OdbcConnection pConn,System.Data.Odbc.OdbcTransaction pTrans)
		{
			string lNotas = "";
			
			foreach(int lIdNota in this.mIdNotas)
			{
				if( lNotas == "" )
				{
					lNotas = lIdNota.ToString();
				}
				else
				{	
					lNotas += ( "," + lIdNota.ToString() );
				}
			}		
			
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcConnection l_conn = pConn;			
			
			l_getnum = new System.Data.Odbc.OdbcCommand();
			l_getnum.Connection = l_conn;
			l_getnum.Transaction = pTrans;
			l_getnum.CommandText = "select detNota.IdProducto,detNota.iva,detNota.unidaddeventa,sum(PrecioOriginal) as PrecioOriginal,sum(PrecioDescuento) as PrecioDescuento,sum(Cantidad) as Cantidad,sum(PrecioCalculado) as PrecioCalculado,sum(DescuentoAplicado) as DescuentoAplicado,cp.Descripcion,cp.Codigo from detNota inner join catProductos cp on detNota.IdProducto = cp.IdProducto  where IdFactura in (" + lNotas + ") group by IdProducto,iva,unidaddeventa;";			
			
			//System.Console.WriteLine( l_getnum.CommandText );
			
			System.Data.Odbc.OdbcDataAdapter lDa = new System.Data.Odbc.OdbcDataAdapter();
			lDa.SelectCommand = l_getnum;
			
			System.Data.DataTable lDetalleFactura = new System.Data.DataTable();
			
			lDa.Fill(lDetalleFactura);
			
			return lDetalleFactura;
		}
		
		private int GetNumArticulos(System.Data.Odbc.OdbcConnection pConn,System.Data.Odbc.OdbcTransaction pTrans)
		{
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcConnection l_conn = pConn;
			
			string lNotas = "";
			
			foreach(int lIdNota in this.mIdNotas)
			{
				if( lNotas == "" )
				{
					lNotas = lIdNota.ToString();
				}
				else
				{	
					lNotas += ( "," + lIdNota.ToString() );
				}
			}
  
			l_getnum = new System.Data.Odbc.OdbcCommand();
 
			l_getnum.Connection = l_conn;
			l_getnum.Transaction = pTrans;
			l_getnum.CommandText = "select count(IdProducto) as total from ( select distinct IdProducto from detNota where IdFactura in (" + lNotas + ") )query1;";

			//System.Console.WriteLine( l_getnum.CommandText );
			
			System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();   
			l_reader.Read();
 
			int l_numero = Convert.ToInt32(l_reader["total"]); 

			l_reader.Close();
  
			return l_numero;			
		}
		
		private System.String GetNumFac(bool p_increase,System.Data.Odbc.OdbcConnection pConn,System.Data.Odbc.OdbcTransaction pTrans)
		{
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcCommand l_increase;
			System.Data.Odbc.OdbcConnection l_conn = pConn;
  
			l_getnum = new System.Data.Odbc.OdbcCommand();
 
			l_getnum.Connection = l_conn;
			l_getnum.Transaction = pTrans;
			l_getnum.CommandText = "SELECT consFactura FROM confConsFactura;";

			System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();   

			l_reader.Read();
 
			System.String l_numero = l_reader.GetInt32(0).ToString();  

			l_reader.Close();

            if (p_increase == true)
            {
                l_increase = new System.Data.Odbc.OdbcCommand();
                l_increase.Connection = l_conn;
                l_increase.Transaction = pTrans;
                l_increase.CommandText = "UPDATE confConsFactura SET consFactura = consFactura + 1;";
                l_increase.ExecuteNonQuery();
            }

  
			return l_numero;
		}
		
		int mp_int_PosNombreX = 0;        
		int mp_int_PosNombreY = 0;        
	
		int mp_int_PosDireccionX = 0;        
		int mp_int_PosDireccionY = 0;        

		int mp_int_PosCiudadX = 0;        
		int mp_int_PosCiudadY = 0;        

		int mp_int_PosRFCX = 0;        
		int mp_int_PosRFCY = 0;        

		int mp_int_PosNumFactX = 0;        
		int mp_int_PosNumFactY = 0;        

		int mp_int_PosFechaX = 0;        
		int mp_int_PosFechaY = 0;        
		
		int mp_int_PosCodigoX = 0;        
		int mp_int_PosCodigoY = 0;        

		int mp_int_PosCantidadX = 0;        
		int mp_int_PosCantidadY = 0;        

		int mp_int_PosDescripcionX = 0;        
		int mp_int_PosDescripcionY = 0;        

		int mp_int_PosPrecioX = 0;        
		int mp_int_PosPrecioY = 0;        
		
		int mp_int_PosTotalX = 0;        
		int mp_int_PosTotalY = 0;        
		
		int mp_int_PosSubTotalX = 0;        
		int mp_int_PosSubTotalY = 0;        
		
		int mp_int_PosIVAX = 0;        
		int mp_int_PosIVAY = 0;        

		int mp_int_PosGTotalX = 0;        
		int mp_int_PosGTotalY = 0;

        int mp_int_PosCadenaOriginalX = 0;
        int mp_int_PosCadenaOriginalY = 0;

        int mp_int_PosSelloX = 0;
        int mp_int_PosSelloY = 0; 

		int mp_int_PosGTotalLetrasX = 0;        
		int mp_int_PosGTotalLetrasY = 0;        
		
		int mp_int_EspacioDetalle = 0;
		int mp_int_TamanioLetra = 0;		
		
		string mp_string_Leyenda = "";
        string mp_string_mensaje = "";
		
		System.Data.Odbc.OdbcConnection m_conn = new System.Data.Odbc.OdbcConnection();
		
		private void LoadDocPositions()
		{
			try
			{

                this.m_conn.ConnectionString = frm_Main.mps_strconnection;


                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '001'";


				this.m_conn.Open();
                System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//PosNombre					
					l_temp = l_reader["PosNombre"].ToString().Split(',');
					this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);
					
					//PosDireccion
					l_temp = l_reader["PosDireccion"].ToString().Split(',');
					this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);
					
					//PosCiudad
					l_temp = l_reader["PosCiudad"].ToString().Split(',');
					this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);
					
					//PosRFC
					l_temp = l_reader["PosRFC"].ToString().Split(',');
					this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);
					
					//PosNumFact
					l_temp = l_reader["PosNumFact"].ToString().Split(',');
					this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);
					
					//PosFecha
					l_temp = l_reader["PosFecha"].ToString().Split(',');
					this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);
					
					//PosCodigo
					l_temp = l_reader["PosCodigo"].ToString().Split(',');
					this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);
					
					//PosCantidad
					l_temp = l_reader["PosCantidad"].ToString().Split(',');
					this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);
					
					//PosDescripcion
					l_temp = l_reader["PosDescripcion"].ToString().Split(',');
					this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);
					
					//PosPrecio
					l_temp = l_reader["PosPrecio"].ToString().Split(',');
					this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);
					
					//PosTotal
					l_temp = l_reader["PosTotal"].ToString().Split(',');
					this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosSubtotal
					l_temp = l_reader["PosSubtotal"].ToString().Split(',');
					this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosIVA
					l_temp = l_reader["PosIVA"].ToString().Split(',');
					this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotal
					l_temp = l_reader["PosGTotal"].ToString().Split(',');
					this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);

                    //PosCadenaOriginal
                    l_temp = l_reader["PosCadenaOriginal"].ToString().Split(',');
                    this.mp_int_PosCadenaOriginalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCadenaOriginalY = Convert.ToInt32(l_temp[1]);

                    //PosSello
                    l_temp = l_reader["PosSello"].ToString().Split(',');
                    this.mp_int_PosSelloX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSelloY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotalLetras
					l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
					this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);
					
					//EspacioDetalle
					this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());
					
					//TamanioLetra
					this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());
					
					//Leyenda
					this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                    //Mensaje
                    this.mp_string_mensaje = l_reader["mensaje"].ToString();
					
					//MessageBox.Show("Loaded");
					
				}
				
				l_reader.Close();				
			
			}
			catch(System.Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}
					
		
    }
}
