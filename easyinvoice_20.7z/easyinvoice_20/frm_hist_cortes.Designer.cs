﻿namespace EasyInvoice
{
    partial class frm_hist_cortes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_hist_cortes));
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.cmd_close = new System.Windows.Forms.Button();
            this.cmd_reporte = new System.Windows.Forms.Button();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.mp_pdcorte = new System.Drawing.Printing.PrintDocument();
            this.mp_ppvw = new System.Windows.Forms.PrintPreviewDialog();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(12, 12);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(444, 315);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Fecha";
            this.columnHeader1.Width = 153;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Total";
            this.columnHeader2.Width = 87;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Usuario";
            this.columnHeader3.Width = 185;
            // 
            // cmd_close
            // 
            this.cmd_close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmd_close.Image = global::EasyInvoice.Properties.Resources.exit;
            this.cmd_close.Location = new System.Drawing.Point(377, 334);
            this.cmd_close.Name = "cmd_close";
            this.cmd_close.Size = new System.Drawing.Size(79, 23);
            this.cmd_close.TabIndex = 1;
            this.cmd_close.Text = "Cerrar";
            this.cmd_close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_close.UseVisualStyleBackColor = true;
            this.cmd_close.Click += new System.EventHandler(this.cmd_close_Click);
            // 
            // cmd_reporte
            // 
            this.cmd_reporte.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmd_reporte.Location = new System.Drawing.Point(12, 333);
            this.cmd_reporte.Name = "cmd_reporte";
            this.cmd_reporte.Size = new System.Drawing.Size(105, 23);
            this.cmd_reporte.TabIndex = 2;
            this.cmd_reporte.Text = "Ver Reporte";
            this.cmd_reporte.UseVisualStyleBackColor = true;
            this.cmd_reporte.Click += new System.EventHandler(this.cmd_reporte_Click);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "id";
            this.columnHeader4.Width = 0;
            // 
            // mp_pdcorte
            // 
            this.mp_pdcorte.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.mp_pdcorte_PrintPage);
            // 
            // mp_ppvw
            // 
            this.mp_ppvw.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.mp_ppvw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.mp_ppvw.ClientSize = new System.Drawing.Size(400, 300);
            this.mp_ppvw.Document = this.mp_pdcorte;
            this.mp_ppvw.Enabled = true;
            this.mp_ppvw.Icon = ((System.Drawing.Icon)(resources.GetObject("mp_ppvw.Icon")));
            this.mp_ppvw.Name = "mp_ppvw";
            this.mp_ppvw.ShowIcon = false;
            this.mp_ppvw.Visible = false;
            // 
            // frm_hist_cortes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(468, 369);
            this.Controls.Add(this.cmd_reporte);
            this.Controls.Add(this.cmd_close);
            this.Controls.Add(this.listView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_hist_cortes";
            this.Text = "Historial de Cortes de Caja";
            this.Load += new System.EventHandler(this.frm_hist_cortes_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button cmd_close;
        private System.Windows.Forms.Button cmd_reporte;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Drawing.Printing.PrintDocument mp_pdcorte;
        private System.Windows.Forms.PrintPreviewDialog mp_ppvw;
    }
}