using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.Odbc;

namespace EasyInvoice
{
    public partial class frm_nuevafactprv : Form
    {

        public int mp_int32_KeyRecord = -1;

        public frm_nuevafactprv()
        {
            InitializeComponent();
        }

        private void frm_nuevafactprv_Load(object sender, EventArgs e)
        {
            
        }

        private void cmd_cancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void cmd_agregar_Click(object sender, EventArgs e)
        {
            if (this.txt_numero.Text.Trim() == "")
            {
                MessageBox.Show("Es necesario proporcionar el n�mero de la factura", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (this.txt_cantidad.Text.Trim() == "")
            {
                MessageBox.Show("Es necesario proporcionar el monto de la factura", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsNumeric(this.txt_cantidad.Text.Trim() ) )
            {
                MessageBox.Show("cantidad incorrecta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();

            try
            {
                l_conn.ConnectionString = frm_Main.mps_strconnection;
                l_conn.Open();

                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                l_cmd.Connection = l_conn;
                l_cmd.CommandText = "INSERT INTO catFacturasProv(IdProveedor,Numero,Fecha,TotalFactura,Pagado,FechaPago) VALUES(?,?,?,?,?,?)";

                //@IdProveedor,@Numero,@Fecha,@TotalFactura,@Pagado                
                System.Data.Odbc.OdbcParameter l_p1 = new System.Data.Odbc.OdbcParameter("@IdProveedor", System.Data.Odbc.OdbcType.Int);
                l_p1.Value = this.mp_int32_KeyRecord;
                l_cmd.Parameters.Add(l_p1);

                System.Data.Odbc.OdbcParameter l_p2 = new System.Data.Odbc.OdbcParameter("@Numero", System.Data.Odbc.OdbcType.VarChar);
                l_p2.Value = this.txt_numero.Text.Trim();
                l_cmd.Parameters.Add(l_p2);

                System.Data.Odbc.OdbcParameter l_p3 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
                l_p3.Value = this.dateTimePicker1.Value;
                l_cmd.Parameters.Add(l_p3);

                System.Data.Odbc.OdbcParameter l_p4 = new System.Data.Odbc.OdbcParameter("@TotalFactura", System.Data.Odbc.OdbcType.Double);
                l_p4.Value = System.Math.Round(Convert.ToDouble(this.txt_cantidad.Text),2);
                l_cmd.Parameters.Add(l_p4);

                System.Data.Odbc.OdbcParameter l_p5 = new System.Data.Odbc.OdbcParameter("@Pagado", System.Data.Odbc.OdbcType.Double);
                l_p5.Value = 0.0;
                l_cmd.Parameters.Add(l_p5);

                System.Data.Odbc.OdbcParameter l_p6 = new System.Data.Odbc.OdbcParameter("@FechaPago", System.Data.Odbc.OdbcType.DateTime);
                l_p6.Value = this.dateTimePicker2.Value;
                l_cmd.Parameters.Add(l_p6);


                l_cmd.ExecuteNonQuery();

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show("Error al agregar la nueva factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al agregar la nueva factura : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
            	if( l_conn.State == ConnectionState.Open )
            		l_conn.Close();
            }

        }

        private void frm_nuevafactprv_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Escape:
                    this.DialogResult = DialogResult.Cancel;
                    this.Close();
                    break;
            }
        }

        private bool IsNumeric(String str)
        {
            if (str == null)
                return false;
            if (str.Length == 0)
                return false;
            try
            {
                double x = Convert.ToDouble(str);
                return true;
            }
            catch
            {
                return false;
            }

        }


    }
}
