using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_factura.
	/// </summary>
	public class frm_factura : System.Windows.Forms.Form
	{

		private System.Data.DataSet m_detail = new System.Data.DataSet();    
		private System.Int32 m_idproduct; 
		private System.Int32 m_idclient; 
		private System.String m_ciudad;
		private System.String m_tel;
		private System.DateTime m_now;
		private System.String m_numfac;
	
		private System.Double m_subtotal;
		private System.Double m_total;

		private System.Data.Odbc.OdbcConnection m_conn;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txt_dir;
		private System.Windows.Forms.TextBox txt_rfc;
		private System.Windows.Forms.TextBox txt_nombre;
		private System.Windows.Forms.Label lbl_direccion;
		private System.Windows.Forms.Label lbl_rfc;
		private System.Windows.Forms.Label lbl_Nombre;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button cmd_nuevo;
		private System.Windows.Forms.Button cmd_buscar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button cmd_agregar;
		private System.Windows.Forms.Button cmd_findproduct;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txt_descripcion;
		private System.Double m_curprice;
		private System.Double m_orprice;
		private System.Windows.Forms.TextBox txt_cantidad;
		private System.Windows.Forms.TextBox txt_descuento;
		private System.Windows.Forms.TextBox txt_total;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txt_totaliva;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txt_codigo;
		private System.Windows.Forms.Button cmd_borrar;
		private System.Windows.Forms.Label lbl_totaliva;
		private System.Windows.Forms.Label lbl_total;
		private System.Windows.Forms.Button cdm_cerrar;
		private System.Windows.Forms.Button cmd_generar;
		private System.Drawing.Printing.PrintDocument printdoc;
		private System.Windows.Forms.PrintPreviewDialog printpw;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txt_numfact;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frm_factura()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.m_curprice = 0.0;
			this.m_orprice = 0.0;
			this.m_idproduct = -1; 
			this.m_idclient = -1;
			this.txt_total.Text = this.m_curprice.ToString();  

			this.m_detail.Tables.Add("detail");
			this.m_detail.Tables[0].Columns.Add("Secuencia");    
			this.m_detail.Tables[0].Columns.Add("ID");    
			this.m_detail.Tables[0].Columns.Add("C�digo");
			this.m_detail.Tables[0].Columns.Add("Descripci�n");
			this.m_detail.Tables[0].Columns.Add("Precio");    
			this.m_detail.Tables[0].Columns.Add("PrecioDesc");    
			this.m_detail.Tables[0].Columns.Add("Cantidad");    
			this.m_detail.Tables[0].Columns.Add("Descuento");    
			this.m_detail.Tables[0].Columns.Add("Total");    

			this.dataGrid1.DataSource = this.m_detail.Tables[0];
   
			

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frm_factura));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cmd_buscar = new System.Windows.Forms.Button();
			this.cmd_nuevo = new System.Windows.Forms.Button();
			this.txt_dir = new System.Windows.Forms.TextBox();
			this.txt_rfc = new System.Windows.Forms.TextBox();
			this.txt_nombre = new System.Windows.Forms.TextBox();
			this.lbl_direccion = new System.Windows.Forms.Label();
			this.lbl_rfc = new System.Windows.Forms.Label();
			this.lbl_Nombre = new System.Windows.Forms.Label();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.txt_descripcion = new System.Windows.Forms.TextBox();
			this.txt_cantidad = new System.Windows.Forms.TextBox();
			this.txt_descuento = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txt_total = new System.Windows.Forms.TextBox();
			this.cmd_agregar = new System.Windows.Forms.Button();
			this.cmd_findproduct = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.txt_totaliva = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txt_codigo = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.cmd_borrar = new System.Windows.Forms.Button();
			this.lbl_totaliva = new System.Windows.Forms.Label();
			this.lbl_total = new System.Windows.Forms.Label();
			this.cdm_cerrar = new System.Windows.Forms.Button();
			this.cmd_generar = new System.Windows.Forms.Button();
			this.printdoc = new System.Drawing.Printing.PrintDocument();
			this.printpw = new System.Windows.Forms.PrintPreviewDialog();
			this.label8 = new System.Windows.Forms.Label();
			this.txt_numfact = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.txt_numfact);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.cmd_buscar);
			this.groupBox1.Controls.Add(this.cmd_nuevo);
			this.groupBox1.Controls.Add(this.txt_dir);
			this.groupBox1.Controls.Add(this.txt_rfc);
			this.groupBox1.Controls.Add(this.txt_nombre);
			this.groupBox1.Controls.Add(this.lbl_direccion);
			this.groupBox1.Controls.Add(this.lbl_rfc);
			this.groupBox1.Controls.Add(this.lbl_Nombre);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(944, 144);
			this.groupBox1.TabIndex = 18;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Cliente";
			this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
			// 
			// cmd_buscar
			// 
			this.cmd_buscar.Location = new System.Drawing.Point(608, 112);
			this.cmd_buscar.Name = "cmd_buscar";
			this.cmd_buscar.Size = new System.Drawing.Size(88, 23);
			this.cmd_buscar.TabIndex = 25;
			this.cmd_buscar.Text = "Buscar";
			this.cmd_buscar.Click += new System.EventHandler(this.cmd_buscar_Click);
			// 
			// cmd_nuevo
			// 
			this.cmd_nuevo.Location = new System.Drawing.Point(608, 80);
			this.cmd_nuevo.Name = "cmd_nuevo";
			this.cmd_nuevo.Size = new System.Drawing.Size(88, 23);
			this.cmd_nuevo.TabIndex = 24;
			this.cmd_nuevo.Text = "Nuevo";
			this.cmd_nuevo.Click += new System.EventHandler(this.cmd_nuevo_Click);
			// 
			// txt_dir
			// 
			this.txt_dir.Enabled = false;
			this.txt_dir.Location = new System.Drawing.Point(248, 88);
			this.txt_dir.Multiline = true;
			this.txt_dir.Name = "txt_dir";
			this.txt_dir.Size = new System.Drawing.Size(344, 40);
			this.txt_dir.TabIndex = 3;
			this.txt_dir.Text = "";
			// 
			// txt_rfc
			// 
			this.txt_rfc.Enabled = false;
			this.txt_rfc.Location = new System.Drawing.Point(248, 56);
			this.txt_rfc.Name = "txt_rfc";
			this.txt_rfc.Size = new System.Drawing.Size(344, 20);
			this.txt_rfc.TabIndex = 2;
			this.txt_rfc.Text = "";
			// 
			// txt_nombre
			// 
			this.txt_nombre.Enabled = false;
			this.txt_nombre.Location = new System.Drawing.Point(248, 24);
			this.txt_nombre.Name = "txt_nombre";
			this.txt_nombre.Size = new System.Drawing.Size(344, 20);
			this.txt_nombre.TabIndex = 1;
			this.txt_nombre.Text = "";
			// 
			// lbl_direccion
			// 
			this.lbl_direccion.Location = new System.Drawing.Point(176, 88);
			this.lbl_direccion.Name = "lbl_direccion";
			this.lbl_direccion.Size = new System.Drawing.Size(72, 16);
			this.lbl_direccion.TabIndex = 20;
			this.lbl_direccion.Text = "Direcci�n";
			// 
			// lbl_rfc
			// 
			this.lbl_rfc.Location = new System.Drawing.Point(176, 56);
			this.lbl_rfc.Name = "lbl_rfc";
			this.lbl_rfc.Size = new System.Drawing.Size(72, 16);
			this.lbl_rfc.TabIndex = 19;
			this.lbl_rfc.Text = "RFC";
			// 
			// lbl_Nombre
			// 
			this.lbl_Nombre.Location = new System.Drawing.Point(176, 24);
			this.lbl_Nombre.Name = "lbl_Nombre";
			this.lbl_Nombre.Size = new System.Drawing.Size(72, 16);
			this.lbl_Nombre.TabIndex = 18;
			this.lbl_Nombre.Text = "Nombre";
			// 
			// dataGrid1
			// 
			this.dataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(8, 224);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.PreferredColumnWidth = 100;
			this.dataGrid1.ReadOnly = true;
			this.dataGrid1.Size = new System.Drawing.Size(944, 272);
			this.dataGrid1.TabIndex = 11;
			this.dataGrid1.Navigate += new System.Windows.Forms.NavigateEventHandler(this.dataGrid1_Navigate);
			// 
			// txt_descripcion
			// 
			this.txt_descripcion.Enabled = false;
			this.txt_descripcion.Location = new System.Drawing.Point(224, 176);
			this.txt_descripcion.Name = "txt_descripcion";
			this.txt_descripcion.Size = new System.Drawing.Size(232, 20);
			this.txt_descripcion.TabIndex = 6;
			this.txt_descripcion.Text = "";
			// 
			// txt_cantidad
			// 
			this.txt_cantidad.Location = new System.Drawing.Point(488, 176);
			this.txt_cantidad.Name = "txt_cantidad";
			this.txt_cantidad.Size = new System.Drawing.Size(48, 20);
			this.txt_cantidad.TabIndex = 7;
			this.txt_cantidad.Text = "1";
			this.txt_cantidad.TextChanged += new System.EventHandler(this.txt_cantidad_TextChanged);
			// 
			// txt_descuento
			// 
			this.txt_descuento.Location = new System.Drawing.Point(544, 176);
			this.txt_descuento.Name = "txt_descuento";
			this.txt_descuento.Size = new System.Drawing.Size(24, 20);
			this.txt_descuento.TabIndex = 8;
			this.txt_descuento.Text = "0";
			this.txt_descuento.TextChanged += new System.EventHandler(this.txt_descuento_TextChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(224, 160);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 25;
			this.label1.Text = "Descripci�n";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(488, 160);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(32, 16);
			this.label2.TabIndex = 26;
			this.label2.Text = "Cant.";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(544, 160);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 16);
			this.label3.TabIndex = 27;
			this.label3.Text = "Desc.";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(584, 160);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 16);
			this.label4.TabIndex = 28;
			this.label4.Text = "Total";
			// 
			// txt_total
			// 
			this.txt_total.Enabled = false;
			this.txt_total.Location = new System.Drawing.Point(584, 176);
			this.txt_total.Name = "txt_total";
			this.txt_total.Size = new System.Drawing.Size(88, 20);
			this.txt_total.TabIndex = 9;
			this.txt_total.Text = "0";
			this.txt_total.TextChanged += new System.EventHandler(this.txt_total_TextChanged);
			// 
			// cmd_agregar
			// 
			this.cmd_agregar.Enabled = false;
			this.cmd_agregar.Location = new System.Drawing.Point(688, 200);
			this.cmd_agregar.Name = "cmd_agregar";
			this.cmd_agregar.Size = new System.Drawing.Size(88, 23);
			this.cmd_agregar.TabIndex = 27;
			this.cmd_agregar.Text = "Agregar";
			this.cmd_agregar.Click += new System.EventHandler(this.cmd_agregar_Click);
			// 
			// cmd_findproduct
			// 
			this.cmd_findproduct.Enabled = false;
			this.cmd_findproduct.Location = new System.Drawing.Point(456, 176);
			this.cmd_findproduct.Name = "cmd_findproduct";
			this.cmd_findproduct.Size = new System.Drawing.Size(24, 23);
			this.cmd_findproduct.TabIndex = 23;
			this.cmd_findproduct.Text = "...";
			this.cmd_findproduct.Click += new System.EventHandler(this.cmd_findproduct_Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(568, 184);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(16, 16);
			this.label5.TabIndex = 29;
			this.label5.Text = "%";
			// 
			// txt_totaliva
			// 
			this.txt_totaliva.Enabled = false;
			this.txt_totaliva.Location = new System.Drawing.Point(680, 176);
			this.txt_totaliva.Name = "txt_totaliva";
			this.txt_totaliva.Size = new System.Drawing.Size(96, 20);
			this.txt_totaliva.TabIndex = 10;
			this.txt_totaliva.Text = "0";
			this.txt_totaliva.Visible = false;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(680, 160);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 16);
			this.label6.TabIndex = 31;
			this.label6.Text = "Total + IVA";
			this.label6.Visible = false;
			// 
			// txt_codigo
			// 
			this.txt_codigo.Enabled = false;
			this.txt_codigo.Location = new System.Drawing.Point(128, 176);
			this.txt_codigo.Name = "txt_codigo";
			this.txt_codigo.Size = new System.Drawing.Size(88, 20);
			this.txt_codigo.TabIndex = 5;
			this.txt_codigo.Text = "";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(128, 160);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 16);
			this.label7.TabIndex = 33;
			this.label7.Text = "C�digo";
			// 
			// cmd_borrar
			// 
			this.cmd_borrar.Enabled = false;
			this.cmd_borrar.Location = new System.Drawing.Point(592, 200);
			this.cmd_borrar.Name = "cmd_borrar";
			this.cmd_borrar.Size = new System.Drawing.Size(88, 23);
			this.cmd_borrar.TabIndex = 28;
			this.cmd_borrar.Text = "Borrar";
			this.cmd_borrar.Click += new System.EventHandler(this.cmd_borrar_Click);
			// 
			// lbl_totaliva
			// 
			this.lbl_totaliva.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.lbl_totaliva.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbl_totaliva.Location = new System.Drawing.Point(456, 504);
			this.lbl_totaliva.Name = "lbl_totaliva";
			this.lbl_totaliva.Size = new System.Drawing.Size(320, 32);
			this.lbl_totaliva.TabIndex = 35;
			// 
			// lbl_total
			// 
			this.lbl_total.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbl_total.Location = new System.Drawing.Point(96, 504);
			this.lbl_total.Name = "lbl_total";
			this.lbl_total.Size = new System.Drawing.Size(352, 32);
			this.lbl_total.TabIndex = 36;
			// 
			// cdm_cerrar
			// 
			this.cdm_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cdm_cerrar.Location = new System.Drawing.Point(752, 544);
			this.cdm_cerrar.Name = "cdm_cerrar";
			this.cdm_cerrar.Size = new System.Drawing.Size(128, 23);
			this.cdm_cerrar.TabIndex = 13;
			this.cdm_cerrar.Text = "Salir";
			this.cdm_cerrar.Click += new System.EventHandler(this.cdm_cerrar_Click);
			// 
			// cmd_generar
			// 
			this.cmd_generar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cmd_generar.Enabled = false;
			this.cmd_generar.Location = new System.Drawing.Point(280, 544);
			this.cmd_generar.Name = "cmd_generar";
			this.cmd_generar.Size = new System.Drawing.Size(344, 24);
			this.cmd_generar.TabIndex = 12;
			this.cmd_generar.Text = "G E N E R A R   F A C T U R A";
			this.cmd_generar.Click += new System.EventHandler(this.cmd_generar_Click);
			// 
			// printdoc
			// 
			this.printdoc.DocumentName = "Factura";
			this.printdoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printdoc_PrintPage);
			// 
			// printpw
			// 
			this.printpw.AutoScrollMargin = new System.Drawing.Size(0, 0);
			this.printpw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
			this.printpw.ClientSize = new System.Drawing.Size(400, 300);
			this.printpw.Document = this.printdoc;
			this.printpw.Enabled = true;
			this.printpw.Icon = ((System.Drawing.Icon)(resources.GetObject("printpw.Icon")));
			this.printpw.Location = new System.Drawing.Point(119, 20);
			this.printpw.MinimumSize = new System.Drawing.Size(375, 250);
			this.printpw.Name = "printpw";
			this.printpw.TransparencyKey = System.Drawing.Color.Empty;
			this.printpw.Visible = false;
			this.printpw.Load += new System.EventHandler(this.printpw_Load);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(632, 24);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(104, 23);
			this.label8.TabIndex = 26;
			this.label8.Text = "N�mero de Factura";
			// 
			// txt_numfact
			// 
			this.txt_numfact.Location = new System.Drawing.Point(736, 24);
			this.txt_numfact.Name = "txt_numfact";
			this.txt_numfact.TabIndex = 4;
			this.txt_numfact.Text = "0000";
			// 
			// frm_factura
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(960, 574);
			this.Controls.Add(this.cmd_generar);
			this.Controls.Add(this.cdm_cerrar);
			this.Controls.Add(this.lbl_total);
			this.Controls.Add(this.lbl_totaliva);
			this.Controls.Add(this.cmd_borrar);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.txt_codigo);
			this.Controls.Add(this.txt_totaliva);
			this.Controls.Add(this.txt_total);
			this.Controls.Add(this.txt_descuento);
			this.Controls.Add(this.txt_cantidad);
			this.Controls.Add(this.txt_descripcion);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.cmd_findproduct);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.cmd_agregar);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frm_factura";
			this.Text = "Nueva Factura";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.frm_factura_Load);
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void cmd_nuevo_Click(object sender, System.EventArgs e)
		{
			frm_Clientes l_frm = new frm_Clientes(); 
			l_frm.ShowDialog(); 	
		
			if(l_frm.m_KeyRecord!=-1)
			{
				System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdCliente",l_frm.m_KeyRecord )  );
				this.m_idclient = l_frm.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);   


				l_reader.Close();
				this.m_conn.Close();
  
				this.cmd_findproduct.Enabled = true; 


			}

		}

		private void groupBox1_Enter(object sender, System.EventArgs e)
		{
		
		}

		private void frm_factura_Load(object sender, System.EventArgs e)
		{
			this.m_conn = new System.Data.Odbc.OdbcConnection(); 
			this.m_conn.ConnectionString = @"dsn=easy;";		
		}

		private void cmd_buscar_Click(object sender, System.EventArgs e)
		{
			frm_ClientsList l_frmClientes = new frm_ClientsList();
			l_frmClientes.cmd_nuevo.Enabled = false; 
			l_frmClientes.ShowDialog(); 

			if(l_frmClientes.m_KeyRecord!=-1)
			{
				System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdCliente",l_frmClientes.m_KeyRecord )  );
				this.m_idclient = l_frmClientes.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);   


				l_reader.Close();
				this.m_conn.Close();  
				this.cmd_findproduct.Enabled = true; 

			}

		}

		private void dataGrid1_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
		
		}

		private System.Boolean HayInventario(System.Int32 p_Key,System.Int32 p_cant)
		{
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT existencia FROM catProductos WHERE IdProducto = " + p_Key.ToString() + ";";
			
			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();   

			l_reader.Read();
 
			System.Int32 l_inv = l_reader.GetInt32(0); 

			l_reader.Close();
			this.m_conn.Close();  

			if(p_cant <= l_inv)
				return true;
			else
				return false;

		}

		private void cmd_agregar_Click(object sender, System.EventArgs e)
		{
			System.String l_temp;

			l_temp = this.txt_total.Text;
 
			l_temp = l_temp.Trim(); 

			if( l_temp == "" )
			{
				MessageBox.Show("No voy a agregar un art�culo sin precio total!!!","Error!",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
				return;
			}

			System.Int32 i;
			System.Double l_total=0;
			System.Data.DataRow l_row = this.m_detail.Tables[0].NewRow();   
    
			l_row[0] = this.m_detail.Tables[0].Rows.Count+1;  
			l_row[1] = this.m_idproduct.ToString();  
			l_row[2] = this.txt_codigo.Text;  
			l_row[3] = this.txt_descripcion.Text;  
			l_row[4] = this.m_orprice.ToString();    
			l_row[5] = this.m_curprice.ToString();    
			l_row[6] = this.txt_cantidad.Text; 
			l_row[7] = this.txt_descuento.Text; 
			l_row[8] = this.txt_total.Text; 

			//Verificar Inventario....
			if( this.HayInventario(this.m_idproduct,System.Convert.ToInt32(this.txt_cantidad.Text)) == false )
			{
				MessageBox.Show("No hay existencias suficientes de este art�culo WARRIOR!!! :-)","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error); 
				return;
			}
 
			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				if( this.m_detail.Tables[0].Rows[i][2].ToString() == this.txt_codigo.Text.ToString() )
				{
					MessageBox.Show("Imposible duplicar un art�culo en la factura WARRIOR!!! :-)","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error); 
					return;
				}
			}

			this.m_detail.Tables[0].Rows.Add(l_row);  

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

			l_total = System.Math.Round(l_total,2);  
			this.m_subtotal = l_total;

			this.lbl_total.Text = "Total " + System.String.Format("{0:C}",l_total); 
			l_total = (l_total*1.15);
			this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}",l_total); 

			l_total = System.Math.Round(l_total,2);  
			this.m_total = l_total;

			this.cmd_borrar.Enabled = true; 			
			this.cmd_generar.Enabled = true; 
			this.cmd_findproduct.Focus();     
		}

		private void cmd_findproduct_Click(object sender, System.EventArgs e)
		{			
			frm_productoslist l_frmProductos = new frm_productoslist(); 
			l_frmProductos.cmd_nuevo.Enabled = false; 
			l_frmProductos.ShowDialog(); 

			if(l_frmProductos.m_KeyRecord!=-1)
			{
				System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catProductos WHERE IdProducto = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdProducto",l_frmProductos.m_KeyRecord )  );
				this.m_idproduct = l_frmProductos.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_descripcion.Text = l_reader.GetString(2); 
				this.m_curprice = l_reader.GetDouble(5); 
				this.m_orprice = l_reader.GetDouble(5); 
				this.txt_codigo.Text =  l_reader.GetString(1); 

				l_reader.Close();
				this.m_conn.Close();  

				this.txt_cantidad.Text = "1"; 
				this.txt_descuento.Text = "0";

				this.m_curprice = System.Math.Round(this.m_curprice,2);  
				this.m_orprice = System.Math.Round(this.m_orprice,2);  

				System.Double l_total = this.m_curprice;  
				l_total = System.Math.Round(l_total,2);  
				this.txt_total.Text = l_total.ToString(); 

				this.cmd_agregar.Enabled = true; 

			}


		}

		private void txt_cantidad_TextChanged(object sender, System.EventArgs e)
		{
			System.String l_temp;

			l_temp = this.txt_cantidad.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			l_temp = this.txt_descuento.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			try
			{
				System.Double l_total = this.m_curprice*System.Convert.ToDouble(this.txt_cantidad.Text);  
				l_total = System.Math.Round(l_total,2);
				this.txt_total.Text = l_total.ToString(); 

				//txt_descuento_TextChanged(null,null);
			}
			catch(System.Exception ee)
			{
				//MessageBox.Show(ee.ToString()); 
			}
		
		}

		private void txt_descuento_TextChanged(object sender, System.EventArgs e)
		{

			System.String l_temp;

			l_temp = this.txt_cantidad.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			l_temp = this.txt_descuento.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			try
			{
				this.m_curprice = this.m_orprice; 

				this.m_curprice = this.m_curprice - (this.m_curprice*(System.Convert.ToDouble(this.txt_descuento.Text)/100)); 
				this.m_curprice = System.Math.Round(this.m_curprice,2);  
				System.Double l_total = this.m_curprice*System.Convert.ToDouble(this.txt_cantidad.Text);  
				l_total = System.Math.Round(l_total,2);
				this.txt_total.Text = l_total.ToString(); 
			}
			catch(System.Exception ee)
			{
				//MessageBox.Show(ee.ToString()); 
			}
		
		}

		private void txt_total_TextChanged(object sender, System.EventArgs e)
		{
			try
			{
				//System.Double l_total = System.Convert.ToDouble(this.txt_total.Text)*(1.15);  
				//this.txt_totaliva.Text = l_total.ToString(); 
			}
			catch(System.Exception ee)
			{
				//MessageBox.Show(ee.ToString()); 
			}		
		}

		private void cmd_borrar_Click(object sender, System.EventArgs e)
		{
			System.Int32 i;
			System.Double l_total=0;

			this.m_detail.Tables[0].Rows[this.dataGrid1.CurrentRowIndex].Delete();       

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

			l_total = System.Math.Round(l_total,2);  
			this.m_subtotal = l_total;

			this.lbl_total.Text = "Total " + System.String.Format("{0:C}",l_total); 
			l_total = (l_total*1.15);
			this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}",l_total); 

			l_total = System.Math.Round(l_total,2);  
			this.m_total = l_total;

			if( this.m_detail.Tables[0].Rows.Count == 0 )
			{
				this.cmd_borrar.Enabled = false; 
				this.cmd_generar.Enabled = false; 
			}

		}

		private void cdm_cerrar_Click(object sender, System.EventArgs e)
		{
			this.Close(); 
		}

		private System.String GetNumFac()
		{
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcCommand l_increase;
  
			l_getnum = new System.Data.Odbc.OdbcCommand();
 
			l_getnum.Connection = this.m_conn;
			l_getnum.CommandText = "SELECT consFactura FROM confConsFactura;";

			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();   

			l_reader.Read();
 
			System.String l_numero = l_reader.GetInt32(0).ToString();  

			l_reader.Close(); 

			l_increase = new System.Data.Odbc.OdbcCommand();
			l_increase.Connection = this.m_conn;
			l_increase.CommandText = "UPDATE confConsFactura SET consFactura = consFactura + 1;";
			l_increase.ExecuteNonQuery(); 

			this.m_conn.Close();
  
			return l_numero;
		}

		private void cmd_generar_Click(object sender, System.EventArgs e)
		{		
			//Insertar la factura nueva....
			System.Data.Odbc.OdbcCommand l_insertf = new System.Data.Odbc.OdbcCommand();
			System.Data.Odbc.OdbcCommand l_getf = new System.Data.Odbc.OdbcCommand();
			System.Data.Odbc.OdbcCommand l_insertd;
			System.Int32 l_keyf;
			System.Int32 i;
			//System.String l_numfac = GetNumFac();
			System.String l_numfac = this.txt_numfact.Text;
			//System.DateTime l_time;

			this.m_numfac = l_numfac;

			if( MessageBox.Show("�Confirma que desea generar la factura?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
				return;


			try
			{

				this.cmd_generar.Enabled = false; 

				this.m_now = System.DateTime.Now;
	  
				l_insertf.Connection = this.m_conn;
				l_insertf.CommandText = "INSERT INTO catFacturas(IdCliente,NumeroFactura,Fecha,NumProductos,SubTotal,Total) VALUES(?,?,?,?,?,?);";

				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdCliente",this.m_idclient)  );			
				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@NumeroFactura",l_numfac)  );			  
				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Fecha",this.m_now)  );			  
				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@NumProductos",this.m_detail.Tables[0].Rows.Count)  );			  
				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@SubTotal",this.m_subtotal)  );			  
				l_insertf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Total",this.m_total)  );			  

				this.m_conn.Open(); 
				l_insertf.ExecuteNonQuery(); 
				this.m_conn.Close();

				l_getf.Connection = this.m_conn;
				l_getf.CommandText = "SELECT * FROM catFacturas WHERE IdCliente=? and NumeroFactura = ? and Fecha = ? and NumProductos = ?;";
				l_getf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdCliente",this.m_idclient)  );			
				l_getf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@NumeroFactura",l_numfac)  );			  
				l_getf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Fecha",this.m_now)  );			  
				l_getf.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@NumProductos",this.m_detail.Tables[0].Rows.Count)  );			  

				this.m_conn.Open(); 

				System.Data.Odbc.OdbcDataReader l_reader = l_getf.ExecuteReader(); 

				l_reader.Read(); 
				
				//MessageBox.Show("Antes del error"); 
				l_keyf = l_reader.GetInt32(0); 
				//MessageBox.Show("despues del error"); 

				this.m_conn.Close();  
 
				for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
				{
					l_insertd = new System.Data.Odbc.OdbcCommand();

					l_insertd.Connection = this.m_conn;
					l_insertd.CommandText = "INSERT INTO detFactura(IdFactura,IdProducto,PrecioOriginal,PrecioDescuento,Cantidad,PrecioCalculado,DescuentoAplicado) VALUES(?,?,?,?,?,?,?);";
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdFactura",l_keyf)  );			
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdProducto",System.Convert.ToInt32(m_detail.Tables[0].Rows[i][1].ToString()))  );			  
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@PrecioOriginal",System.Convert.ToDouble(m_detail.Tables[0].Rows[i][4].ToString()))  );			  
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@PrecioDescuento",System.Convert.ToDouble(m_detail.Tables[0].Rows[i][5].ToString()))  );			  
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Cantidad",System.Convert.ToInt32(m_detail.Tables[0].Rows[i][6].ToString()))  );			  
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@PrecioCalculado",System.Convert.ToDouble(m_detail.Tables[0].Rows[i][8].ToString()))  );			  
					l_insertd.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@DescuentoAplicado",System.Convert.ToDouble(m_detail.Tables[0].Rows[i][7].ToString()))  );			  
										
					this.DeducirInventario(System.Convert.ToInt32(m_detail.Tables[0].Rows[i][1]),System.Convert.ToInt32(m_detail.Tables[0].Rows[i][6])); 

					this.m_conn.Open(); 
					l_insertd.ExecuteNonQuery(); 
					this.m_conn.Close();

				}

			}
			catch(System.Exception ee)
			{
				MessageBox.Show(ee.ToString()); 
			}


			this.ImprimirFactura(); 
			this.Close(); 

		}

		private void DeducirInventario(System.Int32 p_Key,System.Int32 p_cant)
		{
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "UPDATE catProductos SET existencia = existencia - " + p_cant.ToString() + " WHERE IdProducto = " + p_Key.ToString() + ";";
			
			this.m_conn.Open(); 

			l_cmd.ExecuteNonQuery(); 

			this.m_conn.Close();  

			return;
		}

		private void ImprimirFactura()
		{
			this.printpw.WindowState = FormWindowState.Maximized;  
			this.printpw.ShowDialog(); 
		}

		private void printdoc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Arial",8);    
			System.Drawing.Font l_fontcant = new Font("Arial",8);    

			//Nombre
			e.Graphics.DrawString(this.txt_nombre.Text,l_font,l_brush,125,93);   			 

			//Direcci�n
			e.Graphics.DrawString(this.txt_dir.Text,l_font,l_brush,125,113);   			 

			//Ciudad
			e.Graphics.DrawString(this.m_ciudad,l_font,l_brush,125,135);   			 

			//Fecha
			e.Graphics.DrawString( /*this.m_now.ToString()*/ System.String.Format("{0:d}",this.m_now)  ,l_font,l_brush,700,113);   			 

			//RFC
			e.Graphics.DrawString(this.txt_rfc.Text,l_font,l_brush,550,133);   			 
	 
			
			System.Int32 i;
			System.Int32 l_pos;

			System.Double l_d1,l_d2;
			System.String l_s1,l_s2;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_pos = i*12;

				e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][2].ToString(),l_font,l_brush,40,190+l_pos);   		
				e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][6].ToString(),l_font,l_brush,140,190+l_pos);   		
				e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][3].ToString(),l_font,l_brush,180,190+l_pos);  

				l_d1 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][5].ToString());  
				l_d2 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][8].ToString());  

				l_s1 = System.String.Format("{0:C}",l_d1);
				l_s2 = System.String.Format("{0:C}",l_d2);
 		
				e.Graphics.DrawString(l_s1,l_font,l_brush,650,190+l_pos);   		
				e.Graphics.DrawString(l_s2,l_font,l_brush,750,190+l_pos);   		
			}

			System.Double l_total=0;
			System.Double l_iva;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

			//subtotal
			e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,750,470);   			 

			//Iva
			l_iva = l_total*0.15;
			l_iva = System.Math.Round(l_iva,2);  
			e.Graphics.DrawString(System.String.Format("{0:C}",l_iva),l_font,l_brush,750,485);   			 

			//Total
			l_total = l_total + l_iva;
			l_total = System.Math.Round(l_total,2);  
			e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,750,500);   		

			//Total en letras

			//Separar los centavos...
			System.Double l_centavos;

			l_total = l_total * 100;
			l_centavos = l_total % 100;
            l_total = l_total - l_centavos;
			l_total = l_total / 100;

			l_total = System.Math.Round(l_total,2);

			System.String l_cantidad;

			l_cantidad = this.GetStringValue(System.String.Format("{0:C}",l_total));

			if(l_centavos > 0)
			{
				System.String l_cantcent = System.String.Format(" {0}/100",System.Math.Round(l_centavos,2));
				l_cantidad = l_cantidad + l_cantcent;
			}

			l_cantidad = l_cantidad + " MN";
			e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,150,485);   			 		 
			
		}

		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 

			clsUtils.cUtils l_utils = new clsUtils.cUtils(); 

			return l_utils.Transforma(l_num); 

		}

		private void printpw_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
