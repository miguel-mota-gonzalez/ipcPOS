﻿namespace EasyInvoice
{
    partial class frm_corte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_corte));
            this.cmd_generar = new System.Windows.Forms.Button();
            this.m_pb = new System.Windows.Forms.ProgressBar();
            this.lbl_msg = new System.Windows.Forms.Label();
            this.mp_pdcorte = new System.Drawing.Printing.PrintDocument();
            this.mp_ppvw = new System.Windows.Forms.PrintPreviewDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmd_close = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmd_generar
            // 
            this.cmd_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd_generar.Location = new System.Drawing.Point(103, 98);
            this.cmd_generar.Name = "cmd_generar";
            this.cmd_generar.Size = new System.Drawing.Size(190, 23);
            this.cmd_generar.TabIndex = 0;
            this.cmd_generar.Text = "Generar Corte";
            this.cmd_generar.UseVisualStyleBackColor = true;
            this.cmd_generar.Click += new System.EventHandler(this.cmd_generar_Click);
            // 
            // m_pb
            // 
            this.m_pb.Location = new System.Drawing.Point(12, 53);
            this.m_pb.Name = "m_pb";
            this.m_pb.Size = new System.Drawing.Size(361, 23);
            this.m_pb.TabIndex = 2;
            // 
            // lbl_msg
            // 
            this.lbl_msg.AutoSize = true;
            this.lbl_msg.Location = new System.Drawing.Point(12, 79);
            this.lbl_msg.Name = "lbl_msg";
            this.lbl_msg.Size = new System.Drawing.Size(16, 13);
            this.lbl_msg.TabIndex = 3;
            this.lbl_msg.Text = "...";
            // 
            // mp_pdcorte
            // 
            this.mp_pdcorte.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.mp_pdcorte_PrintPage);
            // 
            // mp_ppvw
            // 
            this.mp_ppvw.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.mp_ppvw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.mp_ppvw.ClientSize = new System.Drawing.Size(400, 300);
            this.mp_ppvw.Document = this.mp_pdcorte;
            this.mp_ppvw.Enabled = true;
            this.mp_ppvw.Icon = ((System.Drawing.Icon)(resources.GetObject("mp_ppvw.Icon")));
            this.mp_ppvw.Name = "mp_ppvw";
            this.mp_ppvw.ShowIcon = false;
            this.mp_ppvw.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(327, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // cmd_close
            // 
            this.cmd_close.Image = global::EasyInvoice.Properties.Resources.exit;
            this.cmd_close.Location = new System.Drawing.Point(294, 132);
            this.cmd_close.Name = "cmd_close";
            this.cmd_close.Size = new System.Drawing.Size(79, 23);
            this.cmd_close.TabIndex = 1;
            this.cmd_close.Text = "Cerrar";
            this.cmd_close.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_close.UseVisualStyleBackColor = true;
            this.cmd_close.Click += new System.EventHandler(this.cmd_close_Click);
            // 
            // frm_corte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(385, 167);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_msg);
            this.Controls.Add(this.m_pb);
            this.Controls.Add(this.cmd_close);
            this.Controls.Add(this.cmd_generar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_corte";
            this.Text = "Corte";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.PictureBox pictureBox1;

        #endregion

        private System.Windows.Forms.Button cmd_generar;
        private System.Windows.Forms.Button cmd_close;
        private System.Windows.Forms.ProgressBar m_pb;
        private System.Windows.Forms.Label lbl_msg;
        private System.Drawing.Printing.PrintDocument mp_pdcorte;
        private System.Windows.Forms.PrintPreviewDialog mp_ppvw;
    }
}