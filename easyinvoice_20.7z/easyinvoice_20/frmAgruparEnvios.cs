﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyInvoice
{
    public partial class frmAgruparEnvios : Form
    {
        /*
        mysql> describe catPedidosWeb;
        +---------------+--------------+------+-----+---------+----------------+
        | Field         | Type         | Null | Key | Default | Extra          |
        +---------------+--------------+------+-----+---------+----------------+
        | idPedidoWeb   | int(11)      | NO   | PRI | NULL    | auto_increment |
        | idAlmacenOrig | int(11)      | NO   |     | NULL    |                |
        | Fecha         | datetime     | NO   |     | NULL    |                |
        | Observaciones | varchar(255) | NO   |     |         |                |
        | usuario       | varchar(50)  | YES  |     | NULL    |                |
        | idPedido      | int(11)      | YES  |     | NULL    |                |
        +---------------+--------------+------+-----+---------+----------------+
        6 rows in set (0.00 sec)

        mysql> describe detPedidosWeb;
        +----------------+---------+------+-----+---------+----------------+
        | Field          | Type    | Null | Key | Default | Extra          |
        +----------------+---------+------+-----+---------+----------------+
        | idDetPedidoWeb | int(11) | NO   | PRI | NULL    | auto_increment |
        | idPedidoWeb    | int(11) | NO   |     | NULL    |                |
        | idProducto     | int(11) | NO   |     | NULL    |                |
        | Cantidad       | float   | NO   |     | NULL    |                |
        | idAlmacenDest  | int(11) | NO   |     | NULL    |                |
        | Solicitado     | float   | YES  |     | 0       |                |
        | Estado         | char(1) | YES  |     | NULL    |                |
        +----------------+---------+------+-----+---------+----------------+
        7 rows in set (0.00 sec)

        mysql> describe catPorte;
        +-----------------+-----------------+------+-----+-------------------+-----------------------------+
        | Field           | Type            | Null | Key | Default           | Extra                       |
        +-----------------+-----------------+------+-----+-------------------+-----------------------------+
        | idPorte         | int(6) unsigned | NO   | PRI | NULL              | auto_increment              |
        | idalmacenorigen | int(6) unsigned | NO   |     | NULL              |                             |
        | dtFecha         | timestamp       | NO   |     | CURRENT_TIMESTAMP | on update CURRENT_TIMESTAMP |
        | formapago       | varchar(32)     | NO   |     | NULL              |                             |
        | condpago        | varchar(32)     | NO   |     | NULL              |                             |
        | moneda          | varchar(32)     | NO   |     | NULL              |                             |
        | valordeclarado  | varchar(32)     | NO   |     | NULL              |                             |
        | usoCFDI         | varchar(128)    | NO   |     | NULL              |                             |
        | metodopago      | varchar(32)     | NO   |     | NULL              |                             |
        | tipo            | varchar(32)     | NO   |     | NULL              |                             |
        | poliza          | varchar(128)    | NO   |     | NULL              |                             |
        | observaciones   | varchar(1024)   | NO   |     | NULL              |                             |
        +-----------------+-----------------+------+-----+-------------------+-----------------------------+
        12 rows in set (0.00 sec)

        mysql> describe detPorte;
        +-------------+-----------------+------+-----+---------+----------------+
        | Field       | Type            | Null | Key | Default | Extra          |
        +-------------+-----------------+------+-----+---------+----------------+
        | iddetporte  | int(6) unsigned | NO   | PRI | NULL    | auto_increment |
        | idporte     | int(6) unsigned | NO   |     | NULL    |                |
        | idpedidoweb | int(6) unsigned | NO   |     | NULL    |                |
        | idpedido    | int(6) unsigned | NO   |     | NULL    |                |
        +-------------+-----------------+------+-----+---------+----------------+
        4 rows in set (0.00 sec)
         */

        private System.Data.Odbc.OdbcConnection m_conn;
        public frmAgruparEnvios()
        {
            InitializeComponent();

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
        }

        private void frmAgruparEnvios_Load(object sender, EventArgs e)
        {
            this.FillDataset();
        }

        private System.Data.DataSet m_dataset;
        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();

        private void FillDataset()
        {
            try
            {
                if (this.m_dataset != null)
                    this.m_dataset.Dispose();

                this.m_dataset = new System.Data.DataSet();

                System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
                l_conn.ConnectionString = frm_Main.mps_strconnection;

                System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
                System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

                l_select.Connection = l_conn;
                l_select.CommandText = "select idPorte,idalmacenorigen, dtFecha, valordeclarado, tipo, poliza, IF(estado=1,'ACTIVO','CANCELADO') as Estado from catPorte order by idPorte desc;";
                l_da.SelectCommand = l_select;

                l_da.Fill(m_dataset);

                this.m_dataset.Tables[0].TableName = "catPorte";
                this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;
                this.dgPorte.DataSource = this.mp_bs;
                this.dgPorte.DataSource = this.mp_bs;

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmdAgregar_Click(object sender, EventArgs e)
        {
            frmEditarPorte frmEdPorte = new frmEditarPorte();
            frmEdPorte.mNuevo = true;
            frmEdPorte.mIdEditar = -1;
            if (frmEdPorte.ShowDialog(this) == DialogResult.OK) {
                FillDataset();
            }
        }

        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // Borrar el seleccionado
            if (this.dgPorte.SelectedRows.Count > 0) {
                if (MessageBox.Show("Confirma que desea cancelar el porte #" + this.dgPorte.SelectedRows[0].Cells[0].Value.ToString() + " *** ESTA OPERACION NO PUEDE DESHACERSE ***", 
                                    "Atención!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {

                    try
                    {
                        this.m_conn.Open();

                        System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
                        l_cmd.Connection = this.m_conn;

                        l_cmd.CommandText = "update catPorte set estado=0 where idPorte = ?;";
                        l_cmd.Parameters.Clear();
                        l_cmd.Parameters.AddWithValue("@idPorte", this.dgPorte.SelectedRows[0].Cells[0].Value);

                        l_cmd.ExecuteNonQuery();

                        MessageBox.Show("Porte # " + this.dgPorte.SelectedRows[0].Cells[0].Value.ToString() + " cancelado.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FillDataset();
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message, "Error eliminado el registro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (this.m_conn.State == System.Data.ConnectionState.Open)
                            this.m_conn.Close();
                    }
                }
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (this.dgPorte.SelectedRows.Count > 0) {
                frmEditarPorte frmEdPorte = new frmEditarPorte();
                frmEdPorte.mNuevo = false;
                frmEdPorte.mIdEditar = Convert.ToInt32(this.dgPorte.SelectedRows[0].Cells[0].Value);
                frmEdPorte.ShowDialog(this);
            }
        }

        private void dgPorte_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            toolStripButton3_Click(sender, null);
        }
    }
}
