/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/26/2007
 * Time: 11:41 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace EasyInvoice
{
	partial class clsAcceso
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(clsAcceso));
            this.txt_acceso = new System.Windows.Forms.TextBox();
            this.lbl_clave = new System.Windows.Forms.Label();
            this.cmd_ok = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_msg = new System.Windows.Forms.Label();
            this.cmb_usuario = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // txt_acceso
            // 
            this.txt_acceso.Location = new System.Drawing.Point(12, 74);
            this.txt_acceso.Name = "txt_acceso";
            this.txt_acceso.PasswordChar = '*';
            this.txt_acceso.Size = new System.Drawing.Size(268, 20);
            this.txt_acceso.TabIndex = 2;
            this.txt_acceso.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_accesoKeyDown);
            this.txt_acceso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_accesoKeyPress);
            // 
            // lbl_clave
            // 
            this.lbl_clave.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_clave.Location = new System.Drawing.Point(12, 57);
            this.lbl_clave.Name = "lbl_clave";
            this.lbl_clave.Size = new System.Drawing.Size(61, 13);
            this.lbl_clave.TabIndex = 2;
            this.lbl_clave.Text = "Clave";
            // 
            // cmd_ok
            // 
            this.cmd_ok.BackColor = System.Drawing.Color.White;
            this.cmd_ok.Location = new System.Drawing.Point(205, 102);
            this.cmd_ok.Name = "cmd_ok";
            this.cmd_ok.Size = new System.Drawing.Size(75, 23);
            this.cmd_ok.TabIndex = 3;
            this.cmd_ok.Text = "Aceptar";
            this.cmd_ok.UseVisualStyleBackColor = false;
            this.cmd_ok.Click += new System.EventHandler(this.Cmd_okClick);
            // 
            // label1
            // 
            //this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario";
            // 
            // lbl_msg
            // 
            this.lbl_msg.AutoSize = true;
            this.lbl_msg.ForeColor = System.Drawing.Color.Yellow;
            this.lbl_msg.Location = new System.Drawing.Point(12, 112);
            this.lbl_msg.Name = "lbl_msg";
            this.lbl_msg.Size = new System.Drawing.Size(0, 13);
            this.lbl_msg.TabIndex = 4;
            // 
            // cmb_usuario
            // 
            this.cmb_usuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_usuario.FormattingEnabled = true;
            this.cmb_usuario.Items.AddRange(new object[] {
            "Administrador",
            "Caja",
            "Vendedor"});
            this.cmb_usuario.Location = new System.Drawing.Point(12, 34);
            this.cmb_usuario.Name = "cmb_usuario";
            this.cmb_usuario.Size = new System.Drawing.Size(268, 21);
            this.cmb_usuario.TabIndex = 1;
            // 
            // clsAcceso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(292, 137);
            this.Controls.Add(this.cmb_usuario);
            this.Controls.Add(this.lbl_msg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmd_ok);
            this.Controls.Add(this.lbl_clave);
            this.Controls.Add(this.txt_acceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "clsAcceso";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Acceso a EasyInvoice";
            this.Load += new System.EventHandler(this.clsAcceso_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.TextBox txt_acceso;
		private System.Windows.Forms.Button cmd_ok;
		private System.Windows.Forms.Label lbl_clave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_msg;
        private System.Windows.Forms.ComboBox cmb_usuario;
	}
}
