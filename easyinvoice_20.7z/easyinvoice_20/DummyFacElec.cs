﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EasyInvoice
{
    class DummyFacElec
    {
        ////////////////////////////////////////////////
        //'DATOS INICIALES DE LA EMPRESA
        private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();

        private void LoadData()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

            lConn.Open();
            System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

            if (lReader.Read())
            {
                this.mConfFact.Version = lReader["Version"].ToString();
                this.mConfFact.Serie = lReader["Serie"].ToString();
                this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
                this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
                this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
                this.mConfFact.RFC = lReader["RFC"].ToString();
                this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
                this.mConfFact.Calle = lReader["Calle"].ToString();
                this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
                this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
                this.mConfFact.Colonia = lReader["Colonia"].ToString();
                this.mConfFact.Localidad = lReader["Localidad"].ToString();
                this.mConfFact.Referencia = lReader["Referencia"].ToString();
                this.mConfFact.Municipio = lReader["Municipio"].ToString();
                this.mConfFact.Estado = lReader["Estado"].ToString();
                this.mConfFact.Pais = lReader["Pais"].ToString();
                this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
            }

            lConn.Close();
        }

        ////////////////////////////////////////////////
        //'DATOS DEL DETALLE DE LA FACTURA
        clsFactElectronica.clsFactElec lFE = new clsFactElectronica.clsFactElec();
			
       System.Collections.Generic.List<string> lDetailDataArr = new System.Collections.Generic.List<string>();

        for (i = 0; i < this.m_detail.Tables[0].Rows.Count; i++)
        {
            System.Text.StringBuilder lDetailData = new System.Text.StringBuilder();

            ////////////////////////////////////////////////
            //Detalle para la factura electronica
            //---Cantidad
            lDetailData.Append( string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][6].ToString()), 2)) );
            lDetailData.Append("|");
            //---Unidad
            lDetailData.Append(m_detail.Tables[0].Rows[i][10].ToString());
            lDetailData.Append("|");
            //---Codigo
            lDetailData.Append(m_detail.Tables[0].Rows[i][2].ToString());
            lDetailData.Append("|");
            //---Descripcion
            lDetailData.Append(m_detail.Tables[0].Rows[i][3].ToString());
            lDetailData.Append("|");
            //---Precio
            lDetailData.Append(string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][4].ToString()), 2)));
            lDetailData.Append("|");
            //---Total
            lDetailData.Append(string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][8].ToString()), 2)));
					
			//System.Console.WriteLine( lDetailData.ToString() );
					
            lDetailDataArr.Add(lDetailData.ToString());
            ////////////////////////////////////////////////
            // ...
            // Insert into detFactura
        }

	    //Almacenar la cadena original y el sello yyyy-MM-ddThh:mm:ss
		string lFecha = DateTime.Now.Year.ToString() + "-" + ( DateTime.Now.Month.ToString().Length == 2 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString() );
		lFecha += "-" + ( DateTime.Now.Day.ToString().Length == 2 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString() );
		lFecha += "T" + ( DateTime.Now.Hour.ToString().Length == 2 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString() );
		lFecha += ":" + ( DateTime.Now.Minute.ToString().Length == 2 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString() );
		lFecha += ":" + ( DateTime.Now.Second.ToString().Length == 2 ? DateTime.Now.Second.ToString() : "0" + DateTime.Now.Second.ToString() );
					
	    string lCadenaOriginal = lFE.GenerarCadenaOriginal(this.mConfFact, l_numfac, lFecha,
	                    "UNA SOLA EXIBICION",
	                    string.Format("{0:0.00}", Math.Round(this.m_subtotal, 2)),
	                    string.Format("{0:0.00}", Math.Round(lDescuento, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total, 2)),
	                    this.mpRfcCliente,
	                    this.mpRazonSocialCliente,
	                    this.mpCalleCliente,
	                    this.mpNumeroExtCliente,
	                    this.mpNumeroIntCliente,
	                    this.mpColoniaCliente,
	                    this.mpLocalidadCliente,
	                    this.mpReferenciaCliente,
	                    this.mpMunicipioCliente,
	                    this.mpEstadoCliente,
	                    this.mpPaisCliente,
	                    this.mpCodigoPostalCliente,
	                    string.Format("{0:0.00}", Math.Round(this.mp_IVA*100, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total - this.m_subtotal, 2)),
	                    lDetailDataArr);
				
	
	    //ruta del openssl.exe
	    lFE.mOpenSSLPath = ConfigurationSettings.AppSettings["opensslpath"];
					
		string lKeyFile = "";  //nombre del archivo con las llaves privadas (.key)
		try
		{
		    lKeyFile = System.IO.File.ReadAllText("keyfile.txt").Trim();
		}
		catch(Exception ex)
		{
		    throw new Exception("Es necesario importar el archivo llave de facturacion electronica antes de generar una factura.");						
		}
	    string lSello = lFE.GenerarSello(lCadenaOriginal, lKeyFile);
	
	    //Actualizar la factura
	    System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
	    lConn.ConnectionString = frm_Main.mps_strconnection;
	
	    System.Data.Odbc.OdbcCommand lCmdEND = new System.Data.Odbc.OdbcCommand();
	    lCmdEND.Connection = this.m_conn;
	    lCmdEND.Transaction = l_trans;
	    lCmdEND.CommandText = "UPDATE catFacturas SET cadenaoriginal = ?,sello = ? where IdFactura = ?";
	
	    lCmdEND.Parameters.AddWithValue("@cadenaoriginal", lCadenaOriginal);
	    lCmdEND.Parameters.AddWithValue("@sello", lSello);
	    lCmdEND.Parameters.AddWithValue("@IdFactura", l_keyf);
	
        lCmdEND.ExecuteNonQuery();
					
	
	    this.m_cadena_original = lCadenaOriginal;
	    this.m_sello = lSello;
	    //////////////////////////////////////////////////////////////////

        l_trans.Commit();
			

    }
}
