/*
 * Created by SharpDevelop.
 * User: 501475792
 * Date: 11/27/2007
 * Time: 12:59 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Collections.Generic;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_reportes.
	/// </summary>
	public partial class frm_reportes : Form
	{
		
		private System.Data.Odbc.OdbcConnection m_conn;
		private DataTable m_r1;
		private DataSet m_r2;
		
		public frm_reportes()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            this.LoadDocPositions();
			
		}
		
		void Frm_reportesLoad(object sender, EventArgs e)
		{
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT nombre FROM catClientes;";
			
			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();   

			while(l_reader.Read())
			{
				this.lb_clients.Items.Add(l_reader[0].ToString());
			}			

			l_reader.Close();
			this.m_conn.Close();  		
			
			//--------------------------------------
			
			this.rb_facturas.Checked = true;
			this.rb_facturasporcliente.Checked = false;
			
			this.lb_clients.Enabled = false;
			
			this.dp_desde.Value = System.DateTime.Today;
			this.dp_hasta.Value = System.DateTime.Today;
			
		}
		
		void Cmd_cancelClick(object sender, EventArgs e)
		{
			this.Close();
		}
		
		void Rb_facturasporclienteCheckedChanged(object sender, EventArgs e)
		{
			if( this.rb_facturasporcliente.Checked == true )
				this.lb_clients.Enabled = true;
			else
				this.lb_clients.Enabled = false;
		}
		
		void Cmd_okClick(object sender, EventArgs e)
		{
			if( this.rb_facturas.Checked == true )
			{
				cReporteFacturas l_rf = new cReporteFacturas();
				
				l_rf.m_start = this.dp_desde.Value;
				l_rf.m_end = this.dp_hasta.Value;		
				l_rf.m_canceladas = this.chk_canceladas.Checked;
				l_rf.m_notas = this.chk_notas.Checked;
				this.m_r1 = l_rf.GetReportData();
				
				if( this.m_r1 != null )
				{

					if(  this.m_r1.Rows.Count > 0 )
					{
						this.mp_rowcount = 0;
						this.m_tot1 = 0;
						this.m_tot2 = 0;
						this.m_tot3 = 0;
		                this.printPreviewDialog1.WindowState = FormWindowState.Maximized;
		                this.printPreviewDialog1.ShowDialog();
					}
					else
					{
						MessageBox.Show("No hay datos para imprimir","Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
					}
					
				}
				else
				{
					MessageBox.Show("No hay datos para imprimir","Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				
			}
			
			if( this.rb_facturasporcliente.Checked == true )
			{
				
				if(this.lb_clients.SelectedIndex == -1)
				{
					MessageBox.Show("Es necesario seleccionar un cliente para ejecutar este reporte","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return;
				}
				
				cReporteFacturasCliente l_rfc = new cReporteFacturasCliente();
				
				l_rfc.m_start = this.dp_desde.Value;
				l_rfc.m_end = this.dp_hasta.Value;		
				l_rfc.m_canceladas = this.chk_canceladas.Checked;
				l_rfc.m_notas = this.chk_notas.Checked;
				
				foreach(string l_item in this.lb_clients.SelectedItems)				
					l_rfc.m_clientes.Add(l_item);				
				
				this.m_r2 = l_rfc.GetReportData();
				
				if( this.m_r2 != null )
				{
					this.mp_factcount = 0;
					this.mp_rowcount = 0;
					this.m_tot1 = 0;
					this.m_tot2 = 0;
					this.m_tot3 = 0;					
	                this.printPreviewDialog2.WindowState = FormWindowState.Maximized;
	                this.printPreviewDialog2.ShowDialog();					
				}
				else
				{
					MessageBox.Show("No hay datos para imprimir","Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}								
			}
			
			if( this.rb_entradas.Checked == true)
			{
				this.printPreviewDialog3.WindowState = FormWindowState.Maximized;
				this.printPreviewDialog3.ShowDialog();
			}
			
		}
		
		private int mp_rowcount = 0;
		private int mp_factcount = 0;
		
		System.Double m_tot1 = 0;
		System.Double m_tot2 = 0;
		System.Double m_tot3 = 0;
		
		void PrintDocument1PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			int l_ypos = 140;						
			
			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Arial",this.mp_int_TamanioLetra, FontStyle.Regular);    
			System.Drawing.Font l_fonth = new Font("Arial",this.mp_int_TamanioLetra + 2, FontStyle.Bold);    			
			System.Drawing.Font l_fonth1 = new Font("Arial",this.mp_int_TamanioLetra, FontStyle.Bold | FontStyle.Italic);    			

			if(this.chk_notas.Checked == false)
				e.Graphics.DrawString("Listado de Facturas",l_fonth,l_brush,340,50);
			else
				e.Graphics.DrawString("Listado de Notas",l_fonth,l_brush,345,50);
			
			e.Graphics.DrawString("Desde " + this.dp_desde.Value.ToShortDateString() + " hasta " + this.dp_hasta.Value.ToShortDateString(),l_fonth1,l_brush,20,80);
			
			e.Graphics.DrawString("Numero",l_fonth1,l_brush,15,110);
			e.Graphics.DrawString("Fecha",l_fonth1,l_brush,60,110);
			e.Graphics.DrawString("Cliente",l_fonth1,l_brush,120,110);
			e.Graphics.DrawString("Importe",l_fonth1,l_brush,500,110);
			e.Graphics.DrawString("IVA",l_fonth1,l_brush,620,110);
			e.Graphics.DrawString("Total",l_fonth1,l_brush,740,110);
			
			e.Graphics.DrawString(System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString() ,l_font,l_brush,700,15);
			
			e.Graphics.DrawLine(System.Drawing.Pens.Black,15,125,835,125);
			
			if( this.m_r1.Rows.Count > 0 )
			{					
				int k = 0;				
				
				if(this.mp_rowcount != 0)
					this.mp_rowcount++;
				
				//foreach(DataRow l_row in this.m_r1.Rows)
				for( ; this.mp_rowcount < this.m_r1.Rows.Count; this.mp_rowcount++ )
				{
					DataRow l_row = this.m_r1.Rows[this.mp_rowcount];
						
					//int i;										
					//for(i=0;i<50;i++)
					//{					
					e.Graphics.DrawString(l_row[0].ToString(),l_font,l_brush,15,l_ypos);
					e.Graphics.DrawString( System.Convert.ToDateTime(l_row[1]).ToShortDateString() ,l_font,l_brush,60,l_ypos);
					e.Graphics.DrawString(l_row[2].ToString(),l_font,l_brush,120,l_ypos);
					e.Graphics.DrawString( System.String.Format("{0:C}",l_row[3]),l_font,l_brush,500,l_ypos);
					e.Graphics.DrawString( System.String.Format("{0:C}",l_row[4]),l_font,l_brush,620,l_ypos);
					e.Graphics.DrawString( System.String.Format("{0:C}",l_row[5]),l_font,l_brush,740,l_ypos);
					
					this.m_tot1 += System.Convert.ToDouble( l_row[3] );
					this.m_tot2 += System.Convert.ToDouble( l_row[4] );
					this.m_tot3 += System.Convert.ToDouble( l_row[5] );
					
					l_ypos += this.mp_int_EspacioDetalle; 
					k++;
					
					if( k == 60 )
					{		
						e.HasMorePages = true;
						return;
					}					
					//}
				}
				
				e.HasMorePages = false;
				//e.PageSettings.Color = true;
				e.Graphics.DrawLine(System.Drawing.Pens.Black,15,l_ypos + this.mp_int_TamanioLetra ,835,l_ypos + this.mp_int_TamanioLetra);
				
				l_ypos += this.mp_int_TamanioLetra;
				
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot1),l_fonth1,l_brush,500,l_ypos + this.mp_int_TamanioLetra);
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot2),l_fonth1,l_brush,620,l_ypos + this.mp_int_TamanioLetra);
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot3),l_fonth1,l_brush,740,l_ypos + this.mp_int_TamanioLetra);																				
				
				//System.Diagnostics.Debug.WriteLine("Fin de la impresion");
				this.mp_rowcount = 0;
				this.m_tot1 = 0;
				this.m_tot2 = 0;
				this.m_tot3 = 0;				
				
			}
		}
		
		void PrintDocument2PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			int l_ypos = 140;						
			
			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
			System.Drawing.Font l_font = new Font("Arial",this.mp_int_TamanioLetra, FontStyle.Regular);    
			System.Drawing.Font l_fontc = new Font("Arial",this.mp_int_TamanioLetra, FontStyle.Bold);    
			System.Drawing.Font l_fonth = new Font("Arial",this.mp_int_TamanioLetra + 2, FontStyle.Bold);    			
			System.Drawing.Font l_fonth1 = new Font("Arial",this.mp_int_TamanioLetra, FontStyle.Bold | FontStyle.Italic);    			

			if(this.chk_notas.Checked==false)
				e.Graphics.DrawString("Facturas por cliente",l_fonth,l_brush,340,50);
			else
				e.Graphics.DrawString("Notas por cliente",l_fonth,l_brush,345,50);
			
			e.Graphics.DrawString("Desde " + this.dp_desde.Value.ToShortDateString() + " hasta " + this.dp_hasta.Value.ToShortDateString(),l_fonth1,l_brush,20,80);
			
			e.Graphics.DrawString(System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString() ,l_font,l_brush,700,15);
			
			e.Graphics.DrawLine(System.Drawing.Pens.Black,15,125,835,125);
			
			e.Graphics.DrawString("Cliente",l_fonth1,l_brush,25,110);
			
			e.Graphics.DrawString( "Numero",l_fonth1,l_brush,100,110);
			e.Graphics.DrawString( "Fecha",l_fonth1,l_brush,200,110);
			e.Graphics.DrawString( "Importe",l_fonth1,l_brush,500,110);
			e.Graphics.DrawString( "IVA",l_fonth1,l_brush,620,110);
			e.Graphics.DrawString( "Total",l_fonth1,l_brush,740,110);														
			
			
			if( this.m_r2.Tables[0].Rows.Count > 0 )
			{
				int k = 0;												
				
				//foreach(DataRow l_row in this.m_r1.Rows)
				for( ; this.mp_rowcount < this.m_r2.Tables[0].Rows.Count; this.mp_rowcount++ )
				{				
					DataRow l_row = this.m_r2.Tables[0].Rows[this.mp_rowcount];
					
					this.m_r2.Tables[1].DefaultView.RowFilter = "idCliente = " + l_row[0].ToString();	
					this.m_r2.Tables[1].DefaultView.Sort = "IdFactura";
										
					e.Graphics.DrawString(l_row[1].ToString(),l_font,l_brush,25,l_ypos);		
					e.Graphics.DrawLine(System.Drawing.Pens.Black,25,l_ypos + this.mp_int_TamanioLetra + 3,835,l_ypos + this.mp_int_TamanioLetra + 3);
					
					//Facturas...															
					if(this.m_r2.Tables[1].DefaultView.ToTable().Rows.Count > 0)
					{
						//for(int i=0;i<12;i++)
						//{
						//foreach(DataRow l_frow in this.m_r2.Tables[1].DefaultView.ToTable().Rows)
						for(;this.mp_factcount < this.m_r2.Tables[1].DefaultView.ToTable().Rows.Count; this.mp_factcount++ )
						{
							DataRow l_frow = this.m_r2.Tables[1].DefaultView.ToTable().Rows[this.mp_factcount];
							
							if( k == 60 )
							{		
								e.HasMorePages = true;
								return;
							}					
														
							l_ypos += this.mp_int_EspacioDetalle;
							k++;							
							
							e.Graphics.DrawString(l_frow[2].ToString(),l_font,l_brush,100,l_ypos);
							e.Graphics.DrawString(System.Convert.ToDateTime(l_frow[3]).ToShortDateString(),l_font,l_brush,200,l_ypos);
							e.Graphics.DrawString( System.String.Format("{0:C}",l_frow[5]),l_font,l_brush,500,l_ypos);
							e.Graphics.DrawString( System.String.Format("{0:C}",Convert.ToDouble(l_frow[6]) - Convert.ToDouble(l_frow[5])),l_font,l_brush,620,l_ypos);
							e.Graphics.DrawString( System.String.Format("{0:C}",l_frow[6]),l_font,l_brush,740,l_ypos);														
							
							this.m_tot1 += System.Convert.ToDouble( l_frow[5] );
							this.m_tot2 += (System.Convert.ToDouble( l_frow[6] ) - System.Convert.ToDouble( l_frow[5] )) ;
							this.m_tot3 += System.Convert.ToDouble( l_frow[6] );						
							
						}
						//}
					}
					else
					{
						l_ypos += this.mp_int_EspacioDetalle;
						k++;							
						e.Graphics.DrawString("No hay facturas para este cliente en el período seleccionado.",l_font,l_brush,100,l_ypos);
					}
					//this.m_r2.Tables[1].DefaultView.RowFilter = "";
					this.mp_factcount = 0;					
					k++;
					l_ypos += this.mp_int_EspacioDetalle;
				}								
				
				e.HasMorePages = false;
				e.Graphics.DrawLine(System.Drawing.Pens.Black,15,l_ypos + this.mp_int_TamanioLetra ,835,l_ypos + this.mp_int_TamanioLetra);
				
				l_ypos += this.mp_int_TamanioLetra;
				
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot1),l_fonth1,l_brush,500,l_ypos + this.mp_int_TamanioLetra);
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot2),l_fonth1,l_brush,620,l_ypos + this.mp_int_TamanioLetra);
				e.Graphics.DrawString( System.String.Format("{0:C}",this.m_tot3),l_fonth1,l_brush,740,l_ypos + this.mp_int_TamanioLetra);																				
				
				System.Diagnostics.Debug.WriteLine("Fin de la impresion");
				this.mp_rowcount = 0;
				this.mp_factcount = 0;
				this.m_tot1 = 0;
				this.m_tot2 = 0;
				this.m_tot3 = 0;								
				
			}
			
		}		
		
        ////////////////////////////////////////////////     
        #region Posiciones de la factura...
		int mp_int_PosNombreX = 0;        
		int mp_int_PosNombreY = 0;        
	
		int mp_int_PosDireccionX = 0;        
		int mp_int_PosDireccionY = 0;        

		int mp_int_PosCiudadX = 0;        
		int mp_int_PosCiudadY = 0;        

		int mp_int_PosRFCX = 0;        
		int mp_int_PosRFCY = 0;        

		int mp_int_PosNumFactX = 0;        
		int mp_int_PosNumFactY = 0;        

		int mp_int_PosFechaX = 0;        
		int mp_int_PosFechaY = 0;        
		
		int mp_int_PosCodigoX = 0;        
		int mp_int_PosCodigoY = 0;        

		int mp_int_PosCantidadX = 0;        
		int mp_int_PosCantidadY = 0;        

		int mp_int_PosDescripcionX = 0;        
		int mp_int_PosDescripcionY = 0;        

		int mp_int_PosPrecioX = 0;        
		int mp_int_PosPrecioY = 0;        
		
		int mp_int_PosTotalX = 0;        
		int mp_int_PosTotalY = 0;        
		
		int mp_int_PosSubTotalX = 0;        
		int mp_int_PosSubTotalY = 0;        
		
		int mp_int_PosIVAX = 0;        
		int mp_int_PosIVAY = 0;        

		int mp_int_PosGTotalX = 0;        
		int mp_int_PosGTotalY = 0;        
		
		int mp_int_PosGTotalLetrasX = 0;        
		int mp_int_PosGTotalLetrasY = 0;        
		
		int mp_int_EspacioDetalle = 0;
		int mp_int_TamanioLetra = 0;		
		
		string mp_string_Leyenda = "";				
		
		#endregion
		
		private void LoadDocPositions()
		{
			try
			{

                this.m_conn.ConnectionString = frm_Main.mps_strconnection;
				
				
				System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				
				l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '003'";
					

				this.m_conn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//PosNombre					
					l_temp = l_reader["PosNombre"].ToString().Split(',');
					this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);
					
					//PosDireccion
					l_temp = l_reader["PosDireccion"].ToString().Split(',');
					this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);
					
					//PosCiudad
					l_temp = l_reader["PosCiudad"].ToString().Split(',');
					this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);
					
					//PosRFC
					l_temp = l_reader["PosRFC"].ToString().Split(',');
					this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);
					
					//PosNumFact
					l_temp = l_reader["PosNumFact"].ToString().Split(',');
					this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);
					
					//PosFecha
					l_temp = l_reader["PosFecha"].ToString().Split(',');
					this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);
					
					//PosCodigo
					l_temp = l_reader["PosCodigo"].ToString().Split(',');
					this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);
					
					//PosCantidad
					l_temp = l_reader["PosCantidad"].ToString().Split(',');
					this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);
					
					//PosDescripcion
					l_temp = l_reader["PosDescripcion"].ToString().Split(',');
					this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);
					
					//PosPrecio
					l_temp = l_reader["PosPrecio"].ToString().Split(',');
					this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);
					
					//PosTotal
					l_temp = l_reader["PosTotal"].ToString().Split(',');
					this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosSubtotal
					l_temp = l_reader["PosSubtotal"].ToString().Split(',');
					this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosIVA
					l_temp = l_reader["PosIVA"].ToString().Split(',');
					this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotal
					l_temp = l_reader["PosGTotal"].ToString().Split(',');
					this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotalLetras
					l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
					this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);
					
					//EspacioDetalle
					this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());
					
					//TamanioLetra
					this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());
					
					//Leyenda
					this.mp_string_Leyenda = l_reader["Leyenda"].ToString();
					
				}
				
				l_reader.Close();				
			
			}
			catch(OleDbException ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}				
		
		void Frm_reportesKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Escape )
				this.Close();
		}
					
		
		void Dp_desdeValueChanged(object sender, EventArgs e)
		{
			if(this.dp_desde.Value > this.dp_hasta.Value)
				this.dp_hasta.Value = this.dp_desde.Value;
		}
		
		//----------------------------------
		int mp_identrada = 0;
		void PrintDocument3PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
            int l_ypos = 140;						
            System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
            System.Drawing.Font l_fonth = new Font("Arial", this.mp_int_TamanioLetra + 2, FontStyle.Bold);
            System.Drawing.Font l_fonth1 = new Font("Arial", this.mp_int_TamanioLetra - 1, FontStyle.Bold | FontStyle.Italic);
            System.Drawing.Font l_font = new Font("Arial", this.mp_int_TamanioLetra - 1, FontStyle.Regular);    

            e.Graphics.DrawString("Entrada de artículos", l_fonth, l_brush, 350, 50);
            e.Graphics.DrawString( this.dp_desde.Value.ToShortDateString() + " - " + this.dp_hasta.Value.ToShortDateString() , l_fonth1, l_brush, 15, 70);            

            e.Graphics.DrawString("Codigo", l_fonth1, l_brush, 15, 110);
            e.Graphics.DrawString("Descripcion", l_fonth1, l_brush, 100, 110);
            e.Graphics.DrawString("Fecha", l_fonth1, l_brush, 350, 110);
            e.Graphics.DrawString("Cantidad", l_fonth1, l_brush, 500, 110);
            e.Graphics.DrawString("Usuario", l_fonth1, l_brush, 600, 110);

            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, 125, 835, 125);

            //Imprimir el detalle
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            this.m_conn.Open();
            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT catEntradas.iidEntrada,catEntradas.ccodigo,catEntradas.cdescripcion,catEntradas.dtfecha,catEntradas.icantidad,catUsuarios.cnombre FROM catEntradas INNER JOIN catUsuarios ON catEntradas.clogin = catUsuarios.clogin WHERE catEntradas.iidEntrada > " + this.mp_identrada.ToString() + " ORDER BY catEntradas.iidEntrada";
            
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            int k = 0;            
            while (l_reader.Read())
            {
                e.Graphics.DrawString(l_reader["ccodigo"].ToString(), l_font, l_brush, 15, l_ypos);
                e.Graphics.DrawString(l_reader["cdescripcion"].ToString(), l_font, l_brush, 100, l_ypos);                
                e.Graphics.DrawString(System.Convert.ToDateTime(l_reader["dtFecha"]).ToString(), l_font, l_brush, 350, l_ypos);
                e.Graphics.DrawString(l_reader["icantidad"].ToString(), l_font, l_brush, 500, l_ypos);  
                e.Graphics.DrawString(l_reader["cnombre"].ToString(), l_font, l_brush, 600, l_ypos);  

                this.mp_identrada = Convert.ToInt32( l_reader["iidEntrada"] );
                l_ypos += this.mp_int_EspacioDetalle;
                k++;

                if (k == 60)
                {
                    e.HasMorePages = true;
                    l_reader.Close();
                    this.m_conn.Close();
                    return;
                }					

            }

            l_reader.Close();
            this.m_conn.Close();

            e.HasMorePages = false;
            e.Graphics.DrawLine(System.Drawing.Pens.Black, 15, l_ypos + this.mp_int_TamanioLetra, 835, l_ypos + this.mp_int_TamanioLetra);

            l_ypos += this.mp_int_TamanioLetra;
               		
		}
		//----------------------------------
	}


	public class cReporteFacturas
	{
		private System.Data.Odbc.OdbcConnection m_conn;
		public System.DateTime m_start = System.DateTime.Now;
		public System.DateTime m_end = System.DateTime.Now;		
		public bool m_canceladas = false;
		public bool m_notas = false;
		
		public cReporteFacturas()
		{
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
		}		
		
		public System.Data.DataTable GetReportData()
		{
			System.Data.DataTable l_table = new DataTable();
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			if(this.m_notas==false)
				l_cmd.CommandText = "SELECT catFacturas.NumeroFactura, catFacturas.Fecha, catClientes.Nombre, catFacturas.Subtotal, catFacturas.Total - catFacturas.Subtotal as IVA,catFacturas.Total FROM catClientes INNER JOIN catFacturas ON catClientes.IdCliente = catFacturas.IdCliente WHERE catFacturas.Fecha >= ? and catFacturas.Fecha <= ? and catFacturas.Cancelada = ? ORDER BY catFacturas.IdFactura ASC";
			else
				l_cmd.CommandText = "SELECT catNotas.NumeroFactura, catNotas.Fecha, catClientes.Nombre, catNotas.Subtotal, catNotas.Total - catNotas.Subtotal as IVA,catNotas.Total FROM catClientes INNER JOIN catNotas ON catClientes.IdCliente = catNotas.IdCliente WHERE catNotas.Fecha >= ? and catNotas.Fecha <= ? and catNotas.Cancelada = ? ORDER BY catNotas.IdFactura ASC";
			
			l_cmd.Parameters.AddWithValue("@start",this.m_start);
			l_cmd.Parameters.AddWithValue("@end",this.m_end.AddHours(23).AddMinutes(59).AddSeconds(59));
			l_cmd.Parameters.AddWithValue("@cancelada",this.m_canceladas);
			
			l_cmd.CommandType = CommandType.Text;
			
			System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();

			l_da.SelectCommand = l_cmd;
			
			l_da.Fill( l_table );
			
			l_da.Dispose();
									
			return l_table;
		}
		
	}
	
	public class cReporteFacturasCliente
	{		
		private System.Data.Odbc.OdbcConnection m_conn;
		public System.DateTime m_start = System.DateTime.Now;
		public System.DateTime m_end = System.DateTime.Now;		
		public System.Collections.Generic.List<string> m_clientes = new List<string>();
		public bool m_canceladas = false;
		public bool m_notas = false;
		
		public cReporteFacturasCliente()
		{
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
		}
		
		public System.Data.DataSet GetReportData()
		{
			System.Data.DataTable l_ds = new DataTable();
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT * FROM catClientes";
			
			if( this.m_clientes.Count > 0 )
			{
				int l_paramindex = 0;
				bool l_first = true;
				
				l_cmd.CommandText += " WHERE Nombre IN (";
				
				foreach(string l_nombre in this.m_clientes)
				{
					if( l_first != true )
						l_cmd.CommandText += ",";					
					l_first = false;					
					l_cmd.CommandText += "?";	
					
					l_cmd.Parameters.AddWithValue("param" + l_paramindex.ToString(),l_nombre);
					
					l_paramindex++;
				}				
				
				l_cmd.CommandText += ") ORDER by Nombre";						
			}						
						
			l_cmd.CommandType = CommandType.Text;			
			System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
			l_da.SelectCommand = l_cmd;			
			l_da.Fill( l_ds );	
			
			//Facturas
			System.Data.DataTable l_ds1 = new DataTable();
			System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();
			l_cmd1.Connection = this.m_conn;
			if(this.m_notas==false)
				l_cmd1.CommandText = "SELECT * FROM catFacturas WHERE Fecha >= ? and Fecha <= ? and Cancelada = ? ORDER BY NumeroFactura" ;
			else
				l_cmd1.CommandText = "SELECT * FROM catNotas WHERE Fecha >= ? and Fecha <= ? and Cancelada = ? ORDER BY NumeroFactura" ;
			l_cmd1.CommandType = CommandType.Text;		
			
			l_cmd1.Parameters.AddWithValue("@start",this.m_start);
			l_cmd1.Parameters.AddWithValue("@end",this.m_end.AddHours(23).AddMinutes(59).AddSeconds(59));
			l_cmd1.Parameters.AddWithValue("@cancelada",this.m_canceladas);
			
			l_da.SelectCommand = l_cmd1;			
			l_da.Fill( l_ds1 );				
			
			l_da.Dispose();
			
			DataSet l_retval = new DataSet();
			
			l_retval.Tables.Add( l_ds );
			l_retval.Tables.Add( l_ds1 );
									
			return l_retval;
		}			
		
	}
	
}
