﻿namespace EasyInvoice
{
    partial class frm_config
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_config));
            this.txt_copias = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_iva = new System.Windows.Forms.TextBox();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_iva = new System.Windows.Forms.Label();
            this.lbl_Nombre = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.cmd_save = new System.Windows.Forms.Button();
            this.cmd_cerrar = new System.Windows.Forms.Button();
            this.txt_facturasig = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_notasig = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.txt_pagosig = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_ncsig = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_ordencomprasig = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_copias
            // 
            this.txt_copias.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_copias.Location = new System.Drawing.Point(171, 160);
            this.txt_copias.Name = "txt_copias";
            this.txt_copias.Size = new System.Drawing.Size(122, 20);
            this.txt_copias.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 27);
            this.label2.TabIndex = 14;
            this.label2.Text = "No. copias al imprimir notas y facturas";
            // 
            // txt_iva
            // 
            this.txt_iva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_iva.Location = new System.Drawing.Point(171, 130);
            this.txt_iva.Name = "txt_iva";
            this.txt_iva.Size = new System.Drawing.Size(122, 20);
            this.txt_iva.TabIndex = 13;
            // 
            // txt_nombre
            // 
            this.txt_nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_nombre.Location = new System.Drawing.Point(171, 100);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(344, 20);
            this.txt_nombre.TabIndex = 11;
            // 
            // lbl_iva
            // 
            this.lbl_iva.Location = new System.Drawing.Point(12, 132);
            this.lbl_iva.Name = "lbl_iva";
            this.lbl_iva.Size = new System.Drawing.Size(72, 16);
            this.lbl_iva.TabIndex = 12;
            this.lbl_iva.Text = "IVA";
            // 
            // lbl_Nombre
            // 
            this.lbl_Nombre.Location = new System.Drawing.Point(12, 102);
            this.lbl_Nombre.Name = "lbl_Nombre";
            this.lbl_Nombre.Size = new System.Drawing.Size(163, 16);
            this.lbl_Nombre.TabIndex = 10;
            this.lbl_Nombre.Text = "Criterio default de busq. clientes";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.Location = new System.Drawing.Point(12, 202);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(128, 17);
            this.checkBox1.TabIndex = 16;
            this.checkBox1.Text = "Usar iva por producto";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "delete2.ico");
            this.imageList1.Images.SetKeyName(1, "disk_blue.ico");
            this.imageList1.Images.SetKeyName(2, "exit.ico");
            // 
            // cmd_save
            // 
            this.cmd_save.ImageKey = "disk_blue.ico";
            this.cmd_save.ImageList = this.imageList1;
            this.cmd_save.Location = new System.Drawing.Point(429, 239);
            this.cmd_save.Name = "cmd_save";
            this.cmd_save.Size = new System.Drawing.Size(119, 23);
            this.cmd_save.TabIndex = 19;
            this.cmd_save.Text = "&Guardar y cerrar";
            this.cmd_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_save.Click += new System.EventHandler(this.cmd_save_Click);
            // 
            // cmd_cerrar
            // 
            this.cmd_cerrar.ImageIndex = 2;
            this.cmd_cerrar.ImageList = this.imageList1;
            this.cmd_cerrar.Location = new System.Drawing.Point(551, 239);
            this.cmd_cerrar.Name = "cmd_cerrar";
            this.cmd_cerrar.Size = new System.Drawing.Size(75, 23);
            this.cmd_cerrar.TabIndex = 20;
            this.cmd_cerrar.Text = "&Cancelar";
            this.cmd_cerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cmd_cerrar.Click += new System.EventHandler(this.cmd_cerrar_Click);
            // 
            // txt_facturasig
            // 
            this.txt_facturasig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_facturasig.Location = new System.Drawing.Point(171, 38);
            this.txt_facturasig.Name = "txt_facturasig";
            this.txt_facturasig.Size = new System.Drawing.Size(122, 20);
            this.txt_facturasig.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "No. factura siguiente";
            // 
            // txt_notasig
            // 
            this.txt_notasig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_notasig.Location = new System.Drawing.Point(171, 12);
            this.txt_notasig.Name = "txt_notasig";
            this.txt_notasig.Size = new System.Drawing.Size(122, 20);
            this.txt_notasig.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(12, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "No. nota siguiente";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox2.Location = new System.Drawing.Point(460, 202);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(163, 17);
            this.checkBox2.TabIndex = 18;
            this.checkBox2.Text = "Usar Facturación Electrónica";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox3.Location = new System.Drawing.Point(171, 202);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(266, 17);
            this.checkBox3.TabIndex = 17;
            this.checkBox3.Text = "Permitir movimientos de productos con existencia 0";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // txt_pagosig
            // 
            this.txt_pagosig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_pagosig.Location = new System.Drawing.Point(501, 38);
            this.txt_pagosig.Name = "txt_pagosig";
            this.txt_pagosig.Size = new System.Drawing.Size(122, 20);
            this.txt_pagosig.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(342, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "No. pago siguiente";
            // 
            // txt_ncsig
            // 
            this.txt_ncsig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ncsig.Location = new System.Drawing.Point(501, 10);
            this.txt_ncsig.Name = "txt_ncsig";
            this.txt_ncsig.Size = new System.Drawing.Size(122, 20);
            this.txt_ncsig.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(342, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "No. nota de crédito siguiente";
            // 
            // txt_ordencomprasig
            // 
            this.txt_ordencomprasig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ordencomprasig.Location = new System.Drawing.Point(171, 64);
            this.txt_ordencomprasig.Name = "txt_ordencomprasig";
            this.txt_ordencomprasig.Size = new System.Drawing.Size(122, 20);
            this.txt_ordencomprasig.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(12, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "No. orden de compra siguiente";
            // 
            // frm_config
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(635, 267);
            this.Controls.Add(this.txt_ordencomprasig);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_ncsig);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_pagosig);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.txt_facturasig);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_notasig);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmd_save);
            this.Controls.Add(this.cmd_cerrar);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.txt_copias);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_iva);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_iva);
            this.Controls.Add(this.lbl_Nombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frm_config";
            this.Text = "Configuración";
            this.Load += new System.EventHandler(this.frm_config_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_copias;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_iva;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lbl_iva;
        private System.Windows.Forms.Label lbl_Nombre;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button cmd_save;
        private System.Windows.Forms.Button cmd_cerrar;
        private System.Windows.Forms.TextBox txt_facturasig;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_notasig;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.TextBox txt_pagosig;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_ncsig;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_ordencomprasig;
        private System.Windows.Forms.Label label6;
    }
}