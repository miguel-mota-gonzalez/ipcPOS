﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
CREATE TABLE `catPorte` (
  `idPorte` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `idalmacenorigen` int(6) unsigned NOT NULL,
  `dtFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `formapago` varchar(32) NOT NULL,
  `condpago` varchar(32) NOT NULL,
  `moneda` varchar(32) NOT NULL,
  `valordeclarado` varchar(32) NOT NULL,
  `usoCFDI` varchar(128) NOT NULL,
  `metodopago` varchar(32) NOT NULL,
  `tipo` varchar(32) NOT NULL,
  `poliza` varchar(128) NOT NULL,
  `observaciones` varchar(1024) NOT NULL,
  PRIMARY KEY (`idPorte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `detPorte` (
  `iddetporte` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `idporte` int(6) unsigned NOT NULL,
  `idpedidoweb` int(6) unsigned NOT NULL,
  `idpedido` int(6) unsigned NOT NULL,
  PRIMARY KEY (`iddetporte`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE catPorte
ADD COLUMN asguradora VARCHAR(256) AFTER poliza;
*/

namespace EasyInvoice
{
    public partial class frmPrecios : Form
    {
        public bool mNuevo = false;
        public int mIdEditar = -1;
        private Button cmdCancelar;
        private ListBox lbStores;
        private Button cmdAceptar;
        private System.Data.Odbc.OdbcConnection m_conn;
        public frmPrecios()
        {
            InitializeComponent();

            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
        }

        private void frmPrecios_Load(object sender, EventArgs e)
        {
            //Load stores
            System.Data.Odbc.OdbcCommand l_cmd1 = new System.Data.Odbc.OdbcCommand();

            l_cmd1.Connection = this.m_conn;
            l_cmd1.CommandText = "select id, cDescripcion from catLocacion where dtFechaBaja is null";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader1 = l_cmd1.ExecuteReader();

            this.lbStores.BeginUpdate();
            while (l_reader1.Read())
            {
                this.lbStores.Items.Add(l_reader1.GetInt32(0).ToString() + " - " + l_reader1.GetString(1));
            }
            this.lbStores.EndUpdate();

            l_reader1.Close();
            this.m_conn.Close();
        }

        private void cmdCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdGuardar_Click(object sender, EventArgs e)
        {

        }

        private void InitializeComponent()
        {
            this.cmdCancelar = new System.Windows.Forms.Button();
            this.lbStores = new System.Windows.Forms.ListBox();
            this.cmdAceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdCancelar
            // 
            this.cmdCancelar.Location = new System.Drawing.Point(512, 337);
            this.cmdCancelar.Name = "cmdCancelar";
            this.cmdCancelar.Size = new System.Drawing.Size(75, 23);
            this.cmdCancelar.TabIndex = 0;
            this.cmdCancelar.Text = "Cancelar";
            this.cmdCancelar.UseVisualStyleBackColor = true;
            this.cmdCancelar.Click += new System.EventHandler(this.cmdCancelar_Click_1);
            // 
            // lbStores
            // 
            this.lbStores.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lbStores.FormattingEnabled = true;
            this.lbStores.Location = new System.Drawing.Point(12, 12);
            this.lbStores.Name = "lbStores";
            this.lbStores.Size = new System.Drawing.Size(223, 342);
            this.lbStores.TabIndex = 1;
            // 
            // cmdAceptar
            // 
            this.cmdAceptar.Location = new System.Drawing.Point(431, 337);
            this.cmdAceptar.Name = "cmdAceptar";
            this.cmdAceptar.Size = new System.Drawing.Size(75, 23);
            this.cmdAceptar.TabIndex = 2;
            this.cmdAceptar.Text = "Aceptar";
            this.cmdAceptar.UseVisualStyleBackColor = true;
            // 
            // frmPrecios
            // 
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(599, 372);
            this.Controls.Add(this.cmdAceptar);
            this.Controls.Add(this.lbStores);
            this.Controls.Add(this.cmdCancelar);
            this.Name = "frmPrecios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Precios";
            this.Load += new System.EventHandler(this.frmPrecios_Load);
            this.ResumeLayout(false);

        }

        private void cmdCancelar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
