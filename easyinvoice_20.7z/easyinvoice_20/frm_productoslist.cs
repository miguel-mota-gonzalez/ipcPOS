using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_productoslist.
	/// </summary>
	public class frm_productoslist : System.Windows.Forms.Form
    {
        
        private System.Data.DataSet m_dataset;
        public System.Int32 m_KeyRecord;
        private System.Windows.Forms.Label lbl_curcel;
        private IContainer components;

        private DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource mp_bs = new BindingSource();
        public Button cmd_nuevo;
        private ToolBar toolBar1;
        private ToolBarButton cmdt_nuevo;
        private ToolBarButton cmdt_editar;
        private ToolBarButton cmdt_actualizar;
        private ToolBarButton cmdt_cerrar;
        private ToolBarButton toolBarButton5;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
        private ComboBox cmb_criterios;
        private TextBox txt_criterio;

        public Int32 p_Result;
        public Int32 p_currentId;
        private string strSqlProductos;
        private bool boolFirstFilter=true;

        private System.Data.Odbc.OdbcConnection OdbcConnection1 = new System.Data.Odbc.OdbcConnection();
        public string p_ConnStr2 = null;
        private ToolBarButton cmdt_familias;
        private ToolBarButton cmdt_proveedores;  // SVM jul2014 conexion a otra base de datos 
        public int p_IdAlmacen2 = -1;  // SVM jul2014 id de otro almacen para no usar el asignado al usuario

		public frm_productoslist()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_KeyRecord = -1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_productoslist));
            this.lbl_curcel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cmd_nuevo = new System.Windows.Forms.Button();
            this.toolBar1 = new System.Windows.Forms.ToolBar();
            this.cmdt_nuevo = new System.Windows.Forms.ToolBarButton();
            this.cmdt_editar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_actualizar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_cerrar = new System.Windows.Forms.ToolBarButton();
            this.cmdt_familias = new System.Windows.Forms.ToolBarButton();
            this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_criterios = new System.Windows.Forms.ComboBox();
            this.txt_criterio = new System.Windows.Forms.TextBox();
            this.cmdt_proveedores = new System.Windows.Forms.ToolBarButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_curcel
            // 
            this.lbl_curcel.Location = new System.Drawing.Point(592, 8);
            this.lbl_curcel.Name = "lbl_curcel";
            this.lbl_curcel.Size = new System.Drawing.Size(64, 24);
            this.lbl_curcel.TabIndex = 6;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.PowderBlue;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.MidnightBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 50);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1026, 421);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DataGridView1RowsAdded);
            this.dataGridView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dataGridView1_KeyDown);
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            // 
            // cmd_nuevo
            // 
            this.cmd_nuevo.Location = new System.Drawing.Point(38, 119);
            this.cmd_nuevo.Name = "cmd_nuevo";
            this.cmd_nuevo.Size = new System.Drawing.Size(75, 23);
            this.cmd_nuevo.TabIndex = 8;
            this.cmd_nuevo.Text = "button1";
            this.cmd_nuevo.UseVisualStyleBackColor = true;
            this.cmd_nuevo.Visible = false;
            this.cmd_nuevo.Click += new System.EventHandler(this.cmd_nuevo_Click);
            // 
            // toolBar1
            // 
            this.toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
            this.toolBar1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
            this.cmdt_nuevo,
            this.cmdt_editar,
            this.cmdt_actualizar,
            this.cmdt_cerrar,
            this.cmdt_familias,
            this.cmdt_proveedores,
            this.toolBarButton5});
            this.toolBar1.ButtonSize = new System.Drawing.Size(55, 45);
            this.toolBar1.DropDownArrows = true;
            this.toolBar1.ImageList = this.imageList1;
            this.toolBar1.Location = new System.Drawing.Point(0, 0);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.ShowToolTips = true;
            this.toolBar1.Size = new System.Drawing.Size(1027, 51);
            this.toolBar1.TabIndex = 0;
            this.toolBar1.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // cmdt_nuevo
            // 
            this.cmdt_nuevo.ImageIndex = 0;
            this.cmdt_nuevo.Name = "cmdt_nuevo";
            this.cmdt_nuevo.Text = "Agregar";
            this.cmdt_nuevo.ToolTipText = "Agregar un nuevo producto";
            // 
            // cmdt_editar
            // 
            this.cmdt_editar.ImageIndex = 1;
            this.cmdt_editar.Name = "cmdt_editar";
            this.cmdt_editar.Text = "Editar";
            this.cmdt_editar.ToolTipText = "Editar el producto seleccionado de la lista";
            // 
            // cmdt_actualizar
            // 
            this.cmdt_actualizar.ImageIndex = 2;
            this.cmdt_actualizar.Name = "cmdt_actualizar";
            this.cmdt_actualizar.Text = "Actualizar";
            this.cmdt_actualizar.ToolTipText = "Actualizar la lista de productos";
            // 
            // cmdt_cerrar
            // 
            this.cmdt_cerrar.ImageIndex = 3;
            this.cmdt_cerrar.Name = "cmdt_cerrar";
            this.cmdt_cerrar.Text = "Cerrar";
            this.cmdt_cerrar.ToolTipText = "Cerrar esta ventana...";
            // 
            // cmdt_familias
            // 
            this.cmdt_familias.ImageIndex = 1;
            this.cmdt_familias.Name = "cmdt_familias";
            this.cmdt_familias.Text = "Familias";
            // 
            // toolBarButton5
            // 
            this.toolBarButton5.Name = "toolBarButton5";
            this.toolBarButton5.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "cube_blue_new.ico");
            this.imageList1.Images.SetKeyName(1, "edit.ico");
            this.imageList1.Images.SetKeyName(2, "refresh.ico");
            this.imageList1.Images.SetKeyName(3, "exit.ico");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(418, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(687, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "criterio:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(415, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Buscar por";
            // 
            // cmb_criterios
            // 
            this.cmb_criterios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_criterios.Location = new System.Drawing.Point(488, 22);
            this.cmb_criterios.Name = "cmb_criterios";
            this.cmb_criterios.Size = new System.Drawing.Size(182, 21);
            this.cmb_criterios.TabIndex = 3;
            // 
            // txt_criterio
            // 
            this.txt_criterio.Location = new System.Drawing.Point(741, 23);
            this.txt_criterio.Name = "txt_criterio";
            this.txt_criterio.Size = new System.Drawing.Size(274, 20);
            this.txt_criterio.TabIndex = 5;
            this.txt_criterio.TextChanged += new System.EventHandler(this.txt_criterio_TextChanged);
            this.txt_criterio.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_criterio_KeyDown);
            this.txt_criterio.Validating += new System.ComponentModel.CancelEventHandler(this.txt_criterio_Validating);
            // 
            // cmdt_proveedores
            // 
            this.cmdt_proveedores.ImageIndex = 1;
            this.cmdt_proveedores.Name = "cmdt_proveedores";
            this.cmdt_proveedores.Text = "Proveedores";
            // 
            // frm_productoslist
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(1027, 470);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_criterios);
            this.Controls.Add(this.txt_criterio);
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.cmd_nuevo);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbl_curcel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_productoslist";
            this.Text = "Lista de Productos";
            this.Load += new System.EventHandler(this.frm_ClientsList_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_productoslist_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void frm_ClientsList_Load(object sender, System.EventArgs e)
		{
            this.FillDataset();

            if (m_dataset.Tables.Count > 0)
            {

                foreach (System.Data.DataColumn l_col in m_dataset.Tables[0].Columns)
                {
                    if (l_col.DataType.Name == "String")
                        this.cmb_criterios.Items.Add(l_col.ColumnName);
                }

                this.cmb_criterios.Text = "Codigo";

                this.dataGridView1.Columns[3].Width = 250;
                this.dataGridView1.Columns[4].Width = 70;
                //this.dataGridView1.Columns[5].Visible = false;
                this.dataGridView1.Columns[7].Visible = false;
                this.dataGridView1.Columns["Proveedores"].Visible = false;
            }

            if(EasyInvoice.frm_Main.mps_strcatalogsnoaccess.Contains("PRODUCTOS") || frm_Main.mps_acceso!="Administrador")
            {
                this.toolBar1.Buttons[0].Visible = false;
                //this.toolBar1.Buttons[1].Visible = false;
            }

            //Oct 2017 : Sync version
            if (frm_Main.m_RunConfiguration != 1)
            {
                this.toolBar1.Buttons[0].Visible = false;
            }
		}

		private int GetTipoIva()
		{
            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;
            if (!string.IsNullOrEmpty(p_ConnStr2))
                l_conn.ConnectionString = p_ConnStr2;
			
			int l_copias = 1;
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = l_conn;            
			l_cmd.CommandText = "SELECT UsarIvaPorArtic FROM confSystem;";		
 
			try
			{
			l_conn.Open();
			l_copias = (int)l_cmd.ExecuteScalar();
			
			l_conn.Close();
			}
			catch
			{
			}
			finally
			{
				if(l_conn.State == System.Data.ConnectionState.Open)
					l_conn.Close();
			}

			return l_copias;			
		}		
		
        private void FillDataset()
        {
            try
            {
                if (frm_Main.mp_idAlmacen > 0)
                {
                    int idAlm = frm_Main.mp_idAlmacen;
                    if (this.p_IdAlmacen2 > 0)
                        idAlm = this.p_IdAlmacen2;
                    if (this.GetTipoIva() == 0)
                        strSqlProductos = "select catProductos.IdProducto as Consecutivo,CodigoProd,Codigo,Descripcion," +
                            "catProductos.Existencia,catExistencias.Existencia as Exist_Almacen, " +
                            "PrecioAlCliente*(SELECT ( 1.00 + IVA ) FROM confSystem WHERE CodTienda='001') as Precio, catExistencias.Ubicacion,Marca,Proveedores,Observaciones " +
                            "from catProductos left join catExistencias on catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=" + idAlm.ToString();
                    else
                        strSqlProductos = "select catProductos.IdProducto as Consecutivo,CodigoProd,Codigo,Descripcion," +
                            "catProductos.Existencia,catExistencias.Existencia as Exist_Almacen, " +
                            "PrecioAlCliente*(1 + ( iva /100)) as Precio, catExistencias.Ubicacion,Marca,Proveedores,Observaciones " +
                            "from catProductos left join catExistencias on catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=" + idAlm.ToString();
                }
                else
                {
                    if (this.GetTipoIva() == 0)
                        strSqlProductos = "select catProductos.IdProducto as Consecutivo,CodigoProd,Codigo,Descripcion," + 
                            "catProductos.Existencia,0 as Exist_Almacen, " + 
                            "PrecioAlCliente*(SELECT ( 1.00 + IVA ) FROM confSystem WHERE CodTienda='001') as Precio, Ubicacion,Marca,Proveedores,Observaciones " +
                            "from catProductos";
                    else
                        strSqlProductos = "select catProductos.IdProducto as Consecutivo,CodigoProd,Codigo,Descripcion," +
                            "catProductos.Existencia,0 as Exist_Almacen, " +
                            "PrecioAlCliente*(1 + ( iva /100)) as Precio,Ubicacion,Marca,Proveedores,Observaciones "+
                            "from catProductos";
                }
                if (boolFirstFilter)
                {
                    this.FillDatasetProductos(strSqlProductos + " WHERE catProductos.IdProducto=-1;");
                }
                else
                {
                    this.FillDatasetProductos(strSqlProductos + ";");
                    try
                    {
                        this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
                    }
                    catch (System.Exception ex)
                    {
                        MessageBox.Show("Error al filtrar : " + ex.Message);
                    }
                }

                this.dataGridView1.DataSource = this.mp_bs;

                this.dataGridView1.Columns[0].Visible = false;
                this.dataGridView1.Columns[6].DefaultCellStyle.Format = "###,##0.00";

                this.dataGridView1.Columns[5].HeaderText = "Exist.Almacen";
                this.dataGridView1.Columns[5].Visible = (frm_Main.mp_idAlmacen > 0);
                
				/*
                this.dataGridView1.Columns[3].Width = (int)(this.dataGridView1.Columns[3].Width * 0.60);
                for (int i = 1; i < this.dataGridView1.Columns.Count; i++)
                    this.dataGridView1.Columns[i].Width = (int)(this.dataGridView1.Columns[i].Width * 0.80);*/

            }
            catch (System.Data.OleDb.OleDbException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FillDatasetProductos(string strFilter)
        {
            if (this.m_dataset != null)
                this.m_dataset.Dispose();

            this.m_dataset = new System.Data.DataSet();

            System.Data.Odbc.OdbcConnection l_conn = new System.Data.Odbc.OdbcConnection();
            l_conn.ConnectionString = frm_Main.mps_strconnection;
            if (!string.IsNullOrEmpty(p_ConnStr2))
                l_conn.ConnectionString = p_ConnStr2;

            System.Data.Odbc.OdbcDataAdapter l_da = new System.Data.Odbc.OdbcDataAdapter();
            System.Data.Odbc.OdbcCommand l_select = new System.Data.Odbc.OdbcCommand();

            l_select.Connection = l_conn;

            l_select.CommandText = strFilter;
            l_da.SelectCommand = l_select;

            l_da.Fill(m_dataset);

            this.m_dataset.Tables[0].TableName = "productos";
            this.mp_bs.DataSource = m_dataset.Tables[0].DefaultView;

            l_conn.Close();

        }

        private void txt_criterio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }        	
        }

        private void frm_productoslist_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                this.Close();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (this.cmd_nuevo.Enabled == true)
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        /*
                        frm_productos l_frm1 = new frm_productos(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                        l_frm1.ShowDialog();
                        this.FillDataset();
                         * */
                        this.LoadProducto(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value)); 
                    }
                }
                else
                {
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                        this.Close();
                    }
                }
            }

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.cmd_nuevo.Enabled == true)
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    /*
                    frm_productos l_frm1 = new frm_productos(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    l_frm1.ShowDialog();
                    this.FillDataset();
                     */
                    this.LoadProducto(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                }
            }
            else
            {
                if (this.dataGridView1.SelectedRows.Count > 0)
                {
                    this.m_KeyRecord = Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value);
                    this.Close();
                }
            }

        }

        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {
            if (frm_Main.mps_acceso == "Caja")
                return;

            switch (e.Button.Text)
            {
                case "Agregar":
                    /*
                    frm_productos l_frm = new frm_productos();
                    l_frm.ShowDialog();
                    this.FillDataset();
                     */
                    this.LoadProducto(-1);
                    break;
                case "Editar":
                    if (this.dataGridView1.SelectedRows.Count > 0)
                    {
                        /*
                        frm_productos l_frm1 = new frm_productos(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                        l_frm1.ShowDialog();
                        this.FillDataset();
                         */
                        this.LoadProducto(Convert.ToInt32(this.dataGridView1.SelectedRows[0].Cells[0].Value));
                    }
                    break;

                case "Familias":
                     frm_familias l_frm = new frm_familias();
                     /*l_frm.MdiParent = this;*/
                     l_frm.Show();
                    break;

                case "Proveedores":
                    frm_ProveedoresList l_frmProveedores = new frm_ProveedoresList();
                    /*l_frm.MdiParent = this;*/
                    l_frmProveedores.Show();
                    
                    break;

                case "Actualizar":
                    this.FillDataset();
                    break;
                case "Cerrar":
                    this.Close();
                    break;

            }
        }

        private void txt_criterio_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.dataGridView1.Focus();
            }
        }


		
		void DataGridView1RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
		{
			for(int i = e.RowIndex; i < e.RowIndex + e.RowCount; i++)
			{
				try
				{
					System.Double l_p_iva = Convert.ToDouble(this.dataGridView1.Rows[i].Cells[4].Value);
					l_p_iva = System.Math.Round(l_p_iva,2);
					this.dataGridView1.Rows[i].Cells[4].Value = l_p_iva;
				}
				catch
				{
				
				}
			}
		}

        void LoadProducto(Int32 pID)
        {
            frm_productos l_frm1;

            if (pID<=0 && (EasyInvoice.frm_Main.mps_strcatalogsnoaccess.Contains("PRODUCTOS") || frm_Main.mps_acceso != "Administrador"))
            {
                return;
            }

            if(pID>0)
                l_frm1 = new frm_productos(pID);
            else
                l_frm1 = new frm_productos();

            l_frm1.frm_ProdPrin = this;
            l_frm1.ShowDialog();
            if (this.p_Result==1)
            {
                this.boolFirstFilter = false;
                this.FillDataset();
                if (this.p_currentId > 0)
                {
                    foreach (DataGridViewRow row in this.dataGridView1.Rows)
                    {
                        if ((Int32)row.Cells[0].Value == this.p_currentId)
                        {
                            row.Selected = true;
                            OnScroll(new ScrollEventArgs(ScrollEventType.LargeIncrement, row.Index));
                            this.dataGridView1.SelectedRows[0].Cells[1].Selected = true;
                            break;
                        }
                    }
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_criterio_Validating(object sender, CancelEventArgs e)
        {
            if (boolFirstFilter)
            {
                this.FillDatasetProductos(strSqlProductos + ";");
                boolFirstFilter = false;
            }
            try
            {
                this.mp_bs.Filter = "[" + this.cmb_criterios.Text + "]" + " LIKE '%" + this.txt_criterio.Text + "%'";
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error al filtrar : " + ex.Message);
            }   
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cmd_nuevo_Click(object sender, EventArgs e)
        {

        }
	}
}
