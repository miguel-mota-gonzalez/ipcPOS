using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.OleDb;
using clsFactElectronica;
using System.Configuration;


namespace EasyInvoice
{
	/// <summary>
	/// Summary description for frm_factura.
	/// </summary>
	public class frm_factura : System.Windows.Forms.Form
	{

		private System.Data.DataSet m_detail = new System.Data.DataSet();    
		private System.Int32 m_idproduct; 
		private System.Int32 m_idclient; 
		private System.String m_ciudad;
		private System.String m_tel;
		private System.DateTime m_now;
		private System.String m_numfac;
	
		private System.Double m_subtotal;
		private System.Double m_total;
        private System.String m_cadena_original = "";
        private System.String m_sello = "";

        //SVM Nov2009
        private System.Int32  m_mode_docs;

		private System.Data.Odbc.OdbcConnection m_conn;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txt_dir;
		private System.Windows.Forms.TextBox txt_rfc;
		private System.Windows.Forms.TextBox txt_nombre;
		private System.Windows.Forms.Label lbl_direccion;
		private System.Windows.Forms.Label lbl_rfc;
        private System.Windows.Forms.Label lbl_Nombre;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txt_descripcion;
		private System.Double m_curprice;
		private System.Double m_orprice;
		private System.Windows.Forms.TextBox txt_cantidad;
		private System.Windows.Forms.TextBox txt_descuento;
		private System.Windows.Forms.TextBox txt_total;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txt_totaliva;
		private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_codigo;
		private System.Windows.Forms.Label lbl_totaliva;
        private System.Windows.Forms.Label lbl_total;
		private System.Drawing.Printing.PrintDocument printdoc;
		private System.Windows.Forms.PrintPreviewDialog printpw;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txt_numfact;
        private LinkLabel ll_buscar;
        private LinkLabel ll_nuevo;
        private LinkLabel ll_agregar;
        private LinkLabel ll_borrar;
        private LinkLabel ll_producto;
        private DataGridView dataGridView1;
        private LinkLabel ll_generar;
        private LinkLabel ll_cancelar;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public bool m_bool_EsNota = false;
        private CheckBox chk_credito;
		private System.Windows.Forms.Label lbl_unidadventa = new Label();
		private string m_lastvalid_code = "";
        private Label label9;
        private Label lbl_Existencia;

        private int mp_iva_to_store = 15;
		
		public frm_factura()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			//
			this.m_curprice = 0.0;
			this.m_orprice = 0.0;
			this.m_idproduct = -1; 
			this.m_idclient = -1;
			this.txt_total.Text = this.m_curprice.ToString();  

			this.m_detail.Tables.Add("detail");
			this.m_detail.Tables[0].Columns.Add("Secuencia");    
			this.m_detail.Tables[0].Columns.Add("ID");    
			this.m_detail.Tables[0].Columns.Add("Codigo");
			this.m_detail.Tables[0].Columns.Add("Descripcion");
			this.m_detail.Tables[0].Columns.Add("Precio");    
			this.m_detail.Tables[0].Columns.Add("PrecioDesc");    
			this.m_detail.Tables[0].Columns.Add("Cantidad");    
			this.m_detail.Tables[0].Columns.Add("Descuento");    
			this.m_detail.Tables[0].Columns.Add("Total");    
			this.m_detail.Tables[0].Columns.Add("Total mas IVA");
            this.m_detail.Tables[0].Columns.Add("unidad");
            this.m_detail.Tables[0].Columns.Add("iva");
			
            this.dataGridView1.DataSource = this.m_detail.Tables[0];
            this.dataGridView1.Columns[11].Visible = false;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_factura));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ll_buscar = new System.Windows.Forms.LinkLabel();
            this.ll_nuevo = new System.Windows.Forms.LinkLabel();
            this.txt_numfact = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_rfc = new System.Windows.Forms.TextBox();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.lbl_rfc = new System.Windows.Forms.Label();
            this.lbl_Nombre = new System.Windows.Forms.Label();
            this.txt_descripcion = new System.Windows.Forms.TextBox();
            this.txt_cantidad = new System.Windows.Forms.TextBox();
            this.txt_descuento = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_totaliva = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_totaliva = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.printdoc = new System.Drawing.Printing.PrintDocument();
            this.printpw = new System.Windows.Forms.PrintPreviewDialog();
            this.ll_agregar = new System.Windows.Forms.LinkLabel();
            this.ll_borrar = new System.Windows.Forms.LinkLabel();
            this.ll_producto = new System.Windows.Forms.LinkLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ll_generar = new System.Windows.Forms.LinkLabel();
            this.ll_cancelar = new System.Windows.Forms.LinkLabel();
            this.chk_credito = new System.Windows.Forms.CheckBox();
            this.lnk_directprice = new System.Windows.Forms.LinkLabel();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_Existencia = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.ll_buscar);
            this.groupBox1.Controls.Add(this.ll_nuevo);
            this.groupBox1.Controls.Add(this.txt_numfact);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_dir);
            this.groupBox1.Controls.Add(this.txt_rfc);
            this.groupBox1.Controls.Add(this.txt_nombre);
            this.groupBox1.Controls.Add(this.lbl_direccion);
            this.groupBox1.Controls.Add(this.lbl_rfc);
            this.groupBox1.Controls.Add(this.lbl_Nombre);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(8, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(944, 144);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cliente";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // ll_buscar
            // 
            this.ll_buscar.AutoSize = true;
            this.ll_buscar.Location = new System.Drawing.Point(642, 104);
            this.ll_buscar.Name = "ll_buscar";
            this.ll_buscar.Size = new System.Drawing.Size(238, 13);
            this.ll_buscar.TabIndex = 1;
            this.ll_buscar.TabStop = true;
            this.ll_buscar.Text = "Buscar un cliente dado de alta en el sistema {F7}";
            this.ll_buscar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_buscar_LinkClicked);
            // 
            // ll_nuevo
            // 
            this.ll_nuevo.AutoSize = true;
            this.ll_nuevo.Location = new System.Drawing.Point(642, 76);
            this.ll_nuevo.Name = "ll_nuevo";
            this.ll_nuevo.Size = new System.Drawing.Size(198, 13);
            this.ll_nuevo.TabIndex = 0;
            this.ll_nuevo.TabStop = true;
            this.ll_nuevo.Text = "Agregar un nuevo cliente al sistema {F6}";
            this.ll_nuevo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_nuevo_LinkClicked);
            // 
            // txt_numfact
            // 
            this.txt_numfact.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_numfact.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_numfact.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_numfact.Location = new System.Drawing.Point(768, 24);
            this.txt_numfact.Name = "txt_numfact";
            this.txt_numfact.Size = new System.Drawing.Size(136, 17);
            this.txt_numfact.TabIndex = 105;
            this.txt_numfact.Text = "0000";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(628, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(134, 23);
            this.label8.TabIndex = 26;
            this.label8.Text = "Numero de Factura";
            // 
            // txt_dir
            // 
            this.txt_dir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_dir.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_dir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dir.Location = new System.Drawing.Point(109, 88);
            this.txt_dir.Multiline = true;
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.ReadOnly = true;
            this.txt_dir.Size = new System.Drawing.Size(484, 40);
            this.txt_dir.TabIndex = 104;
            // 
            // txt_rfc
            // 
            this.txt_rfc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_rfc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_rfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rfc.Location = new System.Drawing.Point(109, 56);
            this.txt_rfc.Name = "txt_rfc";
            this.txt_rfc.ReadOnly = true;
            this.txt_rfc.Size = new System.Drawing.Size(484, 17);
            this.txt_rfc.TabIndex = 103;
            // 
            // txt_nombre
            // 
            this.txt_nombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(255)))), ((int)(((byte)(220)))));
            this.txt_nombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nombre.Location = new System.Drawing.Point(109, 24);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.ReadOnly = true;
            this.txt_nombre.Size = new System.Drawing.Size(484, 17);
            this.txt_nombre.TabIndex = 102;
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(37, 88);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(72, 16);
            this.lbl_direccion.TabIndex = 20;
            this.lbl_direccion.Text = "Direccion";
            // 
            // lbl_rfc
            // 
            this.lbl_rfc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rfc.Location = new System.Drawing.Point(37, 56);
            this.lbl_rfc.Name = "lbl_rfc";
            this.lbl_rfc.Size = new System.Drawing.Size(72, 16);
            this.lbl_rfc.TabIndex = 19;
            this.lbl_rfc.Text = "RFC";
            // 
            // lbl_Nombre
            // 
            this.lbl_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nombre.Location = new System.Drawing.Point(37, 24);
            this.lbl_Nombre.Name = "lbl_Nombre";
            this.lbl_Nombre.Size = new System.Drawing.Size(72, 16);
            this.lbl_Nombre.TabIndex = 18;
            this.lbl_Nombre.Text = "Nombre";
            // 
            // txt_descripcion
            // 
            this.txt_descripcion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_descripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_descripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descripcion.Location = new System.Drawing.Point(8, 210);
            this.txt_descripcion.Name = "txt_descripcion";
            this.txt_descripcion.ReadOnly = true;
            this.txt_descripcion.Size = new System.Drawing.Size(593, 17);
            this.txt_descripcion.TabIndex = 101;
            // 
            // txt_cantidad
            // 
            this.txt_cantidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cantidad.ForeColor = System.Drawing.Color.Blue;
            this.txt_cantidad.Location = new System.Drawing.Point(450, 172);
            this.txt_cantidad.Name = "txt_cantidad";
            this.txt_cantidad.Size = new System.Drawing.Size(48, 24);
            this.txt_cantidad.TabIndex = 102;
            this.txt_cantidad.Text = "1";
            this.txt_cantidad.TextChanged += new System.EventHandler(this.txt_cantidad_TextChanged);
            this.txt_cantidad.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_cantidadKeyDown);
            this.txt_cantidad.Enter += new System.EventHandler(this.Txt_cantidadEnter);
            // 
            // txt_descuento
            // 
            this.txt_descuento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_descuento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_descuento.ForeColor = System.Drawing.Color.Red;
            this.txt_descuento.Location = new System.Drawing.Point(529, 172);
            this.txt_descuento.Name = "txt_descuento";
            this.txt_descuento.Size = new System.Drawing.Size(24, 24);
            this.txt_descuento.TabIndex = 103;
            this.txt_descuento.Text = "0";
            this.txt_descuento.TextChanged += new System.EventHandler(this.txt_descuento_TextChanged);
            this.txt_descuento.Enter += new System.EventHandler(this.Txt_descuentoEnter);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 180);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Descripcion";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(450, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "Cant.";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(523, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 27;
            this.label3.Text = "Desc.";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(572, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "Total";
            // 
            // txt_total
            // 
            this.txt_total.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt_total.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.HideSelection = false;
            this.txt_total.Location = new System.Drawing.Point(572, 174);
            this.txt_total.Name = "txt_total";
            this.txt_total.ReadOnly = true;
            this.txt_total.Size = new System.Drawing.Size(126, 17);
            this.txt_total.TabIndex = 9;
            this.txt_total.Text = "0";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(553, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 16);
            this.label5.TabIndex = 29;
            this.label5.Text = "%";
            // 
            // txt_totaliva
            // 
            this.txt_totaliva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt_totaliva.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_totaliva.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_totaliva.Location = new System.Drawing.Point(704, 174);
            this.txt_totaliva.Name = "txt_totaliva";
            this.txt_totaliva.ReadOnly = true;
            this.txt_totaliva.Size = new System.Drawing.Size(145, 17);
            this.txt_totaliva.TabIndex = 10;
            this.txt_totaliva.Text = "0";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(704, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 16);
            this.label6.TabIndex = 31;
            this.label6.Text = "Total + IVA";
            // 
            // txt_codigo
            // 
            this.txt_codigo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_codigo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_codigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_codigo.Location = new System.Drawing.Point(291, 178);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(153, 17);
            this.txt_codigo.TabIndex = 100;
            this.txt_codigo.TextChanged += new System.EventHandler(this.Txt_codigoTextChanged);
            this.txt_codigo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_codigoKeyDown);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(288, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 19);
            this.label7.TabIndex = 33;
            this.label7.Text = "Codigo";
            // 
            // lbl_totaliva
            // 
            this.lbl_totaliva.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totaliva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_totaliva.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totaliva.ForeColor = System.Drawing.Color.Red;
            this.lbl_totaliva.Location = new System.Drawing.Point(626, 517);
            this.lbl_totaliva.Name = "lbl_totaliva";
            this.lbl_totaliva.Size = new System.Drawing.Size(326, 32);
            this.lbl_totaliva.TabIndex = 35;
            // 
            // lbl_total
            // 
            this.lbl_total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_total.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_total.ForeColor = System.Drawing.Color.Blue;
            this.lbl_total.Location = new System.Drawing.Point(286, 517);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(334, 32);
            this.lbl_total.TabIndex = 36;
            // 
            // printdoc
            // 
            this.printdoc.DocumentName = "Factura";
            this.printdoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printdoc_PrintPage);
            // 
            // printpw
            // 
            this.printpw.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printpw.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printpw.ClientSize = new System.Drawing.Size(400, 300);
            this.printpw.Document = this.printdoc;
            this.printpw.Enabled = true;
            this.printpw.Icon = ((System.Drawing.Icon)(resources.GetObject("printpw.Icon")));
            this.printpw.Name = "printpw";
            this.printpw.Visible = false;
            // 
            // ll_agregar
            // 
            this.ll_agregar.AutoSize = true;
            this.ll_agregar.Location = new System.Drawing.Point(609, 214);
            this.ll_agregar.Name = "ll_agregar";
            this.ll_agregar.Size = new System.Drawing.Size(135, 13);
            this.ll_agregar.TabIndex = 106;
            this.ll_agregar.TabStop = true;
            this.ll_agregar.Text = "Agregar este producto {F2}";
            this.ll_agregar.Visible = false;
            this.ll_agregar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_agregar_LinkClicked);
            // 
            // ll_borrar
            // 
            this.ll_borrar.AutoSize = true;
            this.ll_borrar.Location = new System.Drawing.Point(756, 212);
            this.ll_borrar.Name = "ll_borrar";
            this.ll_borrar.Size = new System.Drawing.Size(184, 13);
            this.ll_borrar.TabIndex = 107;
            this.ll_borrar.TabStop = true;
            this.ll_borrar.Text = "Eliminar el registro seleccionado {Del}";
            this.ll_borrar.Visible = false;
            this.ll_borrar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_borrar_LinkClicked);
            // 
            // ll_producto
            // 
            this.ll_producto.AutoSize = true;
            this.ll_producto.Location = new System.Drawing.Point(168, 182);
            this.ll_producto.Name = "ll_producto";
            this.ll_producto.Size = new System.Drawing.Size(108, 13);
            this.ll_producto.TabIndex = 104;
            this.ll_producto.TabStop = true;
            this.ll_producto.Text = "Buscar producto {F1}";
            this.ll_producto.Visible = false;
            this.ll_producto.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_producto_LinkClicked);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(8, 233);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(944, 281);
            this.dataGridView1.TabIndex = 7;
            // 
            // ll_generar
            // 
            this.ll_generar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ll_generar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ll_generar.Location = new System.Drawing.Point(382, 560);
            this.ll_generar.Name = "ll_generar";
            this.ll_generar.Size = new System.Drawing.Size(283, 17);
            this.ll_generar.TabIndex = 109;
            this.ll_generar.TabStop = true;
            this.ll_generar.Text = "<< GENERAR LA FACTURA >> {F10}";
            this.ll_generar.Visible = false;
            this.ll_generar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_generar_LinkClicked);
            // 
            // ll_cancelar
            // 
            this.ll_cancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ll_cancelar.AutoSize = true;
            this.ll_cancelar.Location = new System.Drawing.Point(672, 560);
            this.ll_cancelar.Name = "ll_cancelar";
            this.ll_cancelar.Size = new System.Drawing.Size(243, 13);
            this.ll_cancelar.TabIndex = 110;
            this.ll_cancelar.TabStop = true;
            this.ll_cancelar.Text = "Cerrar esta ventana y descartar esta factura {Esc}";
            this.ll_cancelar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ll_cancelar_LinkClicked);
            // 
            // chk_credito
            // 
            this.chk_credito.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chk_credito.AutoSize = true;
            this.chk_credito.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_credito.ForeColor = System.Drawing.Color.Red;
            this.chk_credito.Location = new System.Drawing.Point(48, 532);
            this.chk_credito.Name = "chk_credito";
            this.chk_credito.Size = new System.Drawing.Size(206, 21);
            this.chk_credito.TabIndex = 108;
            this.chk_credito.Text = "Se pagara a credito {F8}";
            this.chk_credito.UseVisualStyleBackColor = true;
            // 
            // lnk_directprice
            // 
            this.lnk_directprice.AutoSize = true;
            this.lnk_directprice.Location = new System.Drawing.Point(609, 194);
            this.lnk_directprice.Name = "lnk_directprice";
            this.lnk_directprice.Size = new System.Drawing.Size(145, 13);
            this.lnk_directprice.TabIndex = 105;
            this.lnk_directprice.TabStop = true;
            this.lnk_directprice.Text = "Capturar precio manualmente";
            this.lnk_directprice.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Lnk_directpriceLinkClicked);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(855, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 16);
            this.label9.TabIndex = 111;
            this.label9.Text = "Existenc.";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Existencia
            // 
            this.lbl_Existencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Existencia.Location = new System.Drawing.Point(855, 174);
            this.lbl_Existencia.Name = "lbl_Existencia";
            this.lbl_Existencia.Size = new System.Drawing.Size(93, 16);
            this.lbl_Existencia.TabIndex = 112;
            this.lbl_Existencia.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frm_factura
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(960, 587);
            this.Controls.Add(this.lbl_Existencia);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lnk_directprice);
            this.Controls.Add(this.chk_credito);
            this.Controls.Add(this.ll_cancelar);
            this.Controls.Add(this.ll_generar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ll_producto);
            this.Controls.Add(this.ll_borrar);
            this.Controls.Add(this.ll_agregar);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_totaliva);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.txt_totaliva);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_descuento);
            this.Controls.Add(this.txt_cantidad);
            this.Controls.Add(this.txt_descripcion);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frm_factura";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Nueva Factura";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_factura_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frm_factura_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.LinkLabel lnk_directprice;
		#endregion

		private void cmd_nuevo_Click(object sender, System.EventArgs e)
		{
			frm_Clientes l_frm = new frm_Clientes(); 
			l_frm.ShowDialog(); 	
		
			if(l_frm.m_KeyRecord!=-1)
			{
				System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",l_frm.m_KeyRecord )  );
				this.m_idclient = l_frm.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);

                //////////////////
                this.mpRfcCliente = l_reader["RFC"].ToString();
                this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
                this.mpCalleCliente = l_reader["Calle"].ToString();
                this.mpNumeroExtCliente = l_reader["Numero"].ToString();
                this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
                this.mpColoniaCliente = l_reader["Colonia"].ToString();
                this.mpLocalidadCliente = l_reader["ciudad"].ToString();
                this.mpReferenciaCliente = l_reader["Referencia"].ToString();
                this.mpMunicipioCliente = l_reader["Municipio"].ToString();
                this.mpEstadoCliente = l_reader["Estado"].ToString();
                this.mpPaisCliente = l_reader["Pais"].ToString();
                this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
                //////////////////

				l_reader.Close();
				this.m_conn.Close();
  
				this.ll_producto.Visible = true; 

			}

		}

		private void frm_factura_Load(object sender, System.EventArgs e)
		{			 
			
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;
            
            this.LoadSystemValues();                        

            this.dataGridView1.Columns[0].Visible = false;
            this.dataGridView1.Columns[1].Visible = false;
            this.dataGridView1.Columns[2].Width = 150;
            this.dataGridView1.Columns[3].Width = 340;

            //this.txt_numfact.Text = this.GetNumFac(false);
			this.txt_numfact.Text = "";
            
            //La etiqueta de la unidad de venta...
            this.lbl_unidadventa.Location = new System.Drawing.Point(499, 180);
            this.lbl_unidadventa.AutoSize = true;
            this.lbl_unidadventa.Text = "";            
            
            this.Controls.Add(this.lbl_unidadventa);

            this.dataGridView1.Columns[10].Visible = false;
            
            if(this.m_bool_EsNota == true)
            {
            	this.BackColor = Color.LightYellow;
            	this.dataGridView1.BackColor = Color.LightYellow;
            	this.dataGridView1.DefaultCellStyle.BackColor = Color.LightYellow;
            	this.label8.Text = "Numero de Nota";
            	this.Text = "Nueva Nota";
            	this.ll_generar.Text = "<< GENERAR LA NOTA >> {F10}";
            	this.ll_generar.Top = this.Height - 70;
               // SVM Dic2010  ahora las notas tambien funcionan a credito
                //this.chk_credito.Visible = false;
                                
            }

            //SVM Nov2009 leer modo de generacion de notas/facturas
            System.Data.Odbc.OdbcCommand l_recconf = new System.Data.Odbc.OdbcCommand();
            l_recconf.Connection = this.m_conn;
            l_recconf.CommandText = "SELECT ModeDocs FROM confSystem;";
            //this.m_mode_docs = 0;

            this.m_conn.Open();

            try
            {
                this.m_mode_docs = (System.Int32)l_recconf.ExecuteScalar();
            }
            catch
            {
                this.m_mode_docs = 0;
            }
            finally 
            {
                l_recconf = null;
            }
 

            //Poner el cliente de mostrador como el cliente actual...
            System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
			l_recid.Connection = this.m_conn;
			l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
			l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",1 )  );
			this.m_idclient = 1;

			System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

			l_reader.Read(); 

			this.txt_nombre.Text = l_reader.GetString(1); 
			this.txt_dir.Text = l_reader.GetString(2); 
			this.txt_rfc.Text = l_reader.GetString(5);   
			this.m_ciudad = l_reader.GetString(9);   
			this.m_tel = l_reader.GetString(4);

            //////////////////
            this.mpRfcCliente = l_reader["RFC"].ToString();
            this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
            this.mpCalleCliente = l_reader["Calle"].ToString();
            this.mpNumeroExtCliente = l_reader["Numero"].ToString();
            this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
            this.mpColoniaCliente = l_reader["Colonia"].ToString();
            this.mpLocalidadCliente = l_reader["ciudad"].ToString();
            this.mpReferenciaCliente = l_reader["Referencia"].ToString();
            this.mpMunicipioCliente = l_reader["Municipio"].ToString();
            this.mpEstadoCliente = l_reader["Estado"].ToString();
            this.mpPaisCliente = l_reader["Pais"].ToString();
            this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
            //////////////////

			l_reader.Close();
			this.m_conn.Close();  
			this.ll_producto.Visible = true;                 
            
			this.txt_codigo.Focus();

            if (frm_Main.mp_idAlmacen > 0)
                this.Text = this.Text + " - " + frm_Main.mp_strAlmacen; 

            this.SetVisibleCore(true);

		}

        string mpRfcCliente = "";
        string mpRazonSocialCliente = "";
        string mpCalleCliente = "";
        string mpNumeroExtCliente = "";
        string mpNumeroIntCliente = "";
        string mpColoniaCliente = "";
        string mpLocalidadCliente = "";
        string mpReferenciaCliente = "";
        string mpMunicipioCliente = "";
        string mpEstadoCliente = "";
        string mpPaisCliente = "";
        string mpCodigoPostalCliente = "";

		private void cmd_buscar_Click(object sender, System.EventArgs e)
		{
			frm_ClientsList l_frmClientes = new frm_ClientsList();
			l_frmClientes.cmd_nuevo.Enabled = false;            
            l_frmClientes.mp_toolbar.Buttons[1].Enabled = false;
            if(this.m_bool_EsNota == true)
            	l_frmClientes.mp_criteriousar = this.mp_clientenotas;
            else
            	l_frmClientes.mp_criteriousar = "";
			l_frmClientes.ShowDialog(); 

			if(l_frmClientes.m_KeyRecord!=-1)
			{
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
				l_recid.CommandText = "SELECT * FROM catClientes WHERE IdCliente = ?;";
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter ("@IdCliente",l_frmClientes.m_KeyRecord )  );
				this.m_idclient = l_frmClientes.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read(); 

				this.txt_nombre.Text = l_reader.GetString(1); 
				this.txt_dir.Text = l_reader.GetString(2); 
				this.txt_rfc.Text = l_reader.GetString(5);   
				this.m_ciudad = l_reader.GetString(9);   
				this.m_tel = l_reader.GetString(4);   

                //////////////////
                this.mpRfcCliente = l_reader["RFC"].ToString();
                this.mpRazonSocialCliente = l_reader["Nombre"].ToString();
                this.mpCalleCliente = l_reader["Calle"].ToString();
                this.mpNumeroExtCliente = l_reader["Numero"].ToString();
                this.mpNumeroIntCliente = l_reader["NumeroInt"].ToString();
                this.mpColoniaCliente = l_reader["Colonia"].ToString();
                this.mpLocalidadCliente = l_reader["ciudad"].ToString();
                this.mpReferenciaCliente = l_reader["Referencia"].ToString();
                this.mpMunicipioCliente = l_reader["Municipio"].ToString();
                this.mpEstadoCliente = l_reader["Estado"].ToString();
                this.mpPaisCliente = l_reader["Pais"].ToString();
                this.mpCodigoPostalCliente = l_reader["CodigoPostal"].ToString();
                //////////////////

				l_reader.Close();
				this.m_conn.Close();  
				this.ll_producto.Visible = true; 

			}

		}

        private System.Decimal LeeInventarioAlmacen(System.Int32 p_Key)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            if (frm_Main.mp_idAlmacen <= 0)
            {
                l_cmd.CommandText = "SELECT existencia FROM catProductos WHERE IdProducto = ?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
            }
            else
            {
                l_cmd.CommandText = "SELECT Existencia from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
                l_cmd.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
            }

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            System.Decimal l_inv = 0;
            try
            {
                l_inv = Convert.ToDecimal(l_reader[0]);
            }
            catch
            {
                l_inv = 0;
            }

            l_reader.Close();
            this.m_conn.Close();

            return l_inv;
        }

        private System.Boolean HayInventarioAlmacen(System.Int32 p_Key, System.Decimal p_cant)
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            if (frm_Main.mp_idAlmacen <= 0)
            {
                l_cmd.CommandText = "SELECT existencia FROM catProductos WHERE IdProducto = ?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
            }
            else
            {
                l_cmd.CommandText = "SELECT Existencia from catExistencias WHERE IdProducto=? AND IdAlmacen=?;";
                l_cmd.Parameters.AddWithValue("@IdProducto", p_Key);
                l_cmd.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
            }

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            System.Decimal l_inv = 0; 
            try
            {
                l_inv = Convert.ToDecimal(l_reader[0]);
            }
            catch
            {
                l_inv = 0;
            }

            l_reader.Close();
            this.m_conn.Close();

            if (p_cant <= l_inv)
                return true;
            else
                return false;

        }

		private System.Boolean HayInventario_obsoleto(System.Int32 p_Key,System.Double p_cant)
		{
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;
			l_cmd.CommandText = "SELECT existencia FROM catProductos WHERE IdProducto = " + p_Key.ToString() + ";";
			
			this.m_conn.Open(); 
			System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();   

			l_reader.Read();
 
			System.Double l_inv = Convert.ToDouble(l_reader[0]); 

			l_reader.Close();
			this.m_conn.Close();  

			if(p_cant <= l_inv)
				return true;
			else
				return false;

		}

		private void cmd_agregar_Click(object sender, System.EventArgs e)
		{
			System.String l_temp;

            if (this.txt_descripcion.Text.Trim() == "")
            {
                MessageBox.Show("Seleccione un producto!!!", "Error!", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
                return;
            }

			l_temp = this.txt_total.Text;
 
			l_temp = l_temp.Trim(); 

			if( l_temp == "" )
			{
				MessageBox.Show("No voy a agregar un art�culo sin precio total!!!","Error!",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
				return;
			}
			
			//MessageBox.Show("step1");

			System.Int32 i;
			System.Double l_total=0;
			System.Double l_total_iva=0;
			System.Data.DataRow l_row = this.m_detail.Tables[0].NewRow();   
			double l_tmptotalmasiva = 0.0;
    
			l_row[0] = this.m_detail.Tables[0].Rows.Count+1;  
			l_row[1] = this.m_idproduct.ToString();
            l_row[2] = /*this.m_lastvalid_code*/this.txt_codigo.Text;  
			l_row[3] = this.txt_descripcion.Text;  
			l_row[4] = this.m_orprice.ToString();    
			l_row[5] = this.m_curprice.ToString();    
			l_row[6] = this.txt_cantidad.Text; 
			l_row[7] = this.txt_descuento.Text; 
			l_row[8] = this.txt_total.Text; 
			
			l_tmptotalmasiva = Convert.ToDouble(this.txt_total.Text)*(1 + this.mp_IVA);
			//l_tmptotalmasiva = System.Math.Round(l_tmptotalmasiva,2);
			
			l_row[9] = l_tmptotalmasiva.ToString();
            l_row[10] = this.lbl_unidadventa.Text;
            l_row[11] = this.mp_iva_to_store;
			
			//MessageBox.Show("step2");
			
            if(this.mp_usa_existencia0==0)
            {
			    //if( this.HayInventario(this.m_idproduct,System.Convert.ToDouble(this.txt_cantidad.Text)) == false )
                if (this.HayInventarioAlmacen(this.m_idproduct, System.Convert.ToDecimal(this.txt_cantidad.Text)) == false)
			    {
                    if(frm_Main.mp_idAlmacen>0)
                        MessageBox.Show("No hay existencias suficientes de este articulo en el almacen " + frm_Main.mp_strAlmacen + "!!!", "Error", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error); 
                    else
				        MessageBox.Show("No hay existencias suficientes de este articulo!!!","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error); 
				    return;
			    }
            }
 
			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				if( this.m_detail.Tables[0].Rows[i][2].ToString() == this.txt_codigo.Text.ToString() )
				{
					MessageBox.Show("Imposible duplicar un articulo en la factura!!!","Error",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error); 
					return;
				}
			}

			this.dataGridView1.DataSource = null;
			this.m_detail.Tables[0].Rows.Add(l_row);  
			this.m_detail.Tables[0].AcceptChanges();
			this.dataGridView1.DataSource = this.m_detail.Tables[0];
			
			//MessageBox.Show("step3 " + this.m_detail.Tables[0].Rows.Count.ToString());
			
			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				//MessageBox.Show( this.m_detail.Tables[0].Rows[i][8].ToString() );
				
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				l_total_iva = l_total_iva + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][9].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

			//l_total = System.Math.Round(l_total,2);  
			this.m_subtotal = l_total;

			this.lbl_total.Text = "Total " + System.String.Format("{0:C}",l_total); 
			//l_total = (l_total* (1 + this.mp_IVA) );
			l_total = l_total_iva;
			this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}",l_total_iva); 
			
			l_total = System.Math.Round(l_total,2);  
			this.m_total = l_total;
			
			//MessageBox.Show("step4");
			
			this.ll_borrar.Visible = true; 			
			this.ll_generar.Visible = true; 
			//this.ll_producto.Focus();     
			this.txt_codigo.Focus();
			this.txt_codigo.SelectAll();
		}

		private void cmd_findproduct_Click(object sender, System.EventArgs e)
		{			
			frm_productoslist l_frmProductos = new frm_productoslist(); 
			l_frmProductos.cmd_nuevo.Enabled = false; 
			l_frmProductos.ShowDialog(); 

			if(l_frmProductos.m_KeyRecord!=-1)
			{
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
                l_recid.CommandText = "SELECT catProductos.*, catExistencias.Existencia as existenc_almacen FROM catProductos LEFT JOIN catExistencias ON catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=?  WHERE catProductos.IdProducto = ?;";
                l_recid.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@IdProducto",l_frmProductos.m_KeyRecord )  );
				this.m_idproduct = l_frmProductos.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				l_reader.Read();

                this.txt_descripcion.Text = l_reader["Descripcion"].ToString();  //l_reader.GetString(3); 
                this.m_curprice = Convert.ToDouble(l_reader["PrecioalCliente"]);   //l_reader.GetDouble(5); 
                this.m_orprice = Convert.ToDouble(l_reader["PrecioalCliente"]);    //l_reader.GetDouble(5); 
                this.txt_codigo.Text = l_reader["CodigoProd"].ToString();   //l_reader.GetString(1); 
                this.m_lastvalid_code = l_reader["Codigo"].ToString();   //l_reader.GetString(1); 
                if (frm_Main.mp_idAlmacen <= 0)
                {
                    this.lbl_Existencia.Text = Convert.ToDecimal(l_reader["Existencia"]).ToString("####,##0.00");
                }
                else
                {
                    try
                    {
                        this.lbl_Existencia.Text = Convert.ToDecimal(l_reader["existenc_almacen"]).ToString("####,##0.00");
                    }
                    catch
                    {
                        this.lbl_Existencia.Text = "0.00";
                    }
                }

                if (this.mp_usa_iva_por_articulo == 1)
                {
                    this.mp_IVA = Convert.ToDouble(l_reader["iva"]);
                    this.mp_IVA = this.mp_IVA / 100;
                    this.mp_iva_to_store = Convert.ToInt32(l_reader["iva"]);
                }

				this.lbl_unidadventa.Text = l_reader["UnidadVenta"].ToString();

				l_reader.Close();
				this.m_conn.Close();  

				this.txt_cantidad.Text = "1"; 
				this.txt_descuento.Text = "0";

				//this.m_curprice = System.Math.Round(this.m_curprice,2);  
				//this.m_orprice = System.Math.Round(this.m_orprice,2);  

				System.Double l_total = this.m_curprice;  
				//l_total = System.Math.Round(l_total,2);  
				this.txt_total.Text = l_total.ToString();

                //this.txt_totaliva.Text = Convert.ToString(System.Math.Round(this.m_curprice * (1 + this.mp_IVA), 2));
                this.txt_totaliva.Text = Convert.ToString(this.m_curprice * (1 + this.mp_IVA));

				this.ll_agregar.Visible = true; 
				this.txt_cantidad.Focus();
				this.txt_cantidad.SelectAll();

			}


		}

		private void txt_cantidad_TextChanged(object sender, System.EventArgs e)
		{
			System.String l_temp;

			l_temp = this.txt_cantidad.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			l_temp = this.txt_descuento.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			try
			{
                this.txt_totaliva.Text = "";

				System.Double l_total = this.m_curprice*System.Convert.ToDouble(this.txt_cantidad.Text);  
				l_total = System.Math.Round(l_total,2);
				this.txt_total.Text = l_total.ToString();
                
                this.txt_totaliva.Text = Convert.ToString(System.Math.Round(this.m_curprice * System.Convert.ToDouble(this.txt_cantidad.Text) * (1 + this.mp_IVA), 2));

				//txt_descuento_TextChanged(null,null);
			}
			catch
			{
				//MessageBox.Show(ee.ToString()); 
			}
		
		}

		private void txt_descuento_TextChanged(object sender, System.EventArgs e)
		{

			System.String l_temp;

			l_temp = this.txt_cantidad.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			l_temp = this.txt_descuento.Text; 

			l_temp = l_temp.Trim();

			if( l_temp == "" )
			{
				txt_total.Text = "";
			}

			try
			{
                this.txt_totaliva.Text = "";

				this.m_curprice = this.m_orprice; 

				this.m_curprice = this.m_curprice / ( 1 + (System.Convert.ToDouble(this.txt_descuento.Text)/100)); 
				this.m_curprice = System.Math.Round(this.m_curprice,2);  
				System.Double l_total = this.m_curprice*System.Convert.ToDouble(this.txt_cantidad.Text);  
				l_total = System.Math.Round(l_total,2);
				this.txt_total.Text = l_total.ToString();

                this.txt_totaliva.Text = Convert.ToString(System.Math.Round(this.m_curprice * System.Convert.ToDouble(this.txt_cantidad.Text) * (1 + this.mp_IVA), 2));

			}
			catch
			{
				//MessageBox.Show(ee.ToString()); 
			}
		
		}

		private void cmd_borrar_Click(object sender, System.EventArgs e)
		{
			System.Int32 i;
			System.Double l_total=0;
			
			if(this.dataGridView1.CurrentRow == null)
				return;
			
			if(this.dataGridView1.CurrentRow.Index == -1)
				return;

			this.m_detail.Tables[0].Rows[this.dataGridView1.CurrentRow.Index].Delete();       
			
			this.m_detail.Tables[0].AcceptChanges();

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

			l_total = System.Math.Round(l_total,2);  
			this.m_subtotal = l_total;

			this.lbl_total.Text = "Total " + System.String.Format("{0:C}",l_total); 
			l_total = (l_total*  (1 + this.mp_IVA)  );
			this.lbl_totaliva.Text = "Total + IVA " + System.String.Format("{0:C}",l_total); 

			l_total = System.Math.Round(l_total,2);  
			this.m_total = l_total;

			if( this.m_detail.Tables[0].Rows.Count == 0 )
			{
				this.ll_borrar.Visible = false; 
				this.ll_generar.Visible = false; 
			}

		}

		private void cdm_cerrar_Click(object sender, System.EventArgs e)
		{
			this.Close(); 
		}

		private System.String GetNumFac(bool p_increase,System.Data.Odbc.OdbcConnection pConn,System.Data.Odbc.OdbcTransaction pTrans)
		{
			System.Data.Odbc.OdbcCommand l_getnum;
			System.Data.Odbc.OdbcCommand l_increase;
  
			l_getnum = new System.Data.Odbc.OdbcCommand();
 
			l_getnum.Connection = pConn;
			if(this.m_bool_EsNota == true)
				l_getnum.CommandText = "SELECT consNota FROM confConsFactura;";
			else
				l_getnum.CommandText = "SELECT consFactura FROM confConsFactura;";

			l_getnum.Transaction = pTrans;
			System.Data.Odbc.OdbcDataReader l_reader = l_getnum.ExecuteReader();   

			l_reader.Read();
 
			System.String l_numero = l_reader.GetInt32(0).ToString();  

			l_reader.Close();

            if (p_increase == true)
            {
                l_increase = new System.Data.Odbc.OdbcCommand();
                l_increase.Connection = this.m_conn;
                l_increase.Transaction = pTrans;
                if(this.m_bool_EsNota == true)
                	l_increase.CommandText = "UPDATE confConsFactura SET consNota = consNota + 1;";
                else
                	l_increase.CommandText = "UPDATE confConsFactura SET consFactura = consFactura + 1;";
                l_increase.ExecuteNonQuery();
            }

			//this.m_conn.Close();
  
			return l_numero;
		}

		private void cmd_generar_Click(object sender, System.EventArgs e)
		{
            //frm_cambio l_cambio = new frm_cambio();
            //l_cambio.m_total = this.m_total;
            //l_cambio.ShowDialog();
            this.LoadData();

            clsFactElectronica.clsFactElec lFE = new clsFactElectronica.clsFactElec();
			
			if(ConfigurationSettings.AppSettings["os"] != null)
			{
				//MessageBox.Show( ConfigurationSettings.AppSettings["os"] );
				lFE.mLinux = ConfigurationSettings.AppSettings["os"] == "linux" ? true : false;
			}
				
			//if(lFE.mLinux == false)
			//	MessageBox.Show("No es linux");
			
            System.Collections.Generic.List<string> lDetailDataArr = new System.Collections.Generic.List<string>();

			//Insertar la factura nueva....
			System.Data.Odbc.OdbcCommand l_insertf = new System.Data.Odbc.OdbcCommand();
			System.Data.Odbc.OdbcCommand l_getf = new System.Data.Odbc.OdbcCommand();
			System.Data.Odbc.OdbcCommand l_insertd;
			System.Int32 l_keyf;
			System.Int32 i;
			System.String l_numfac = "";
			//System.String l_numfac = GetNumFac(true);		
			//this.m_numfac = l_numfac;
			
			if(this.dataGridView1.Rows.Count == 1)
			{
				if(this.m_bool_EsNota == false)
					MessageBox.Show("Imposible generar una factura vac�a!","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				else
					MessageBox.Show("Imposible generar una nota vac�a!","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			if(this.m_bool_EsNota == false)
			{
				if( MessageBox.Show("�Confirma que desea generar la factura?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
					return;
			}
			else
			{
				if( MessageBox.Show("�Confirma que desea generar la nota?","A T E N C I O N",System.Windows.Forms.MessageBoxButtons.YesNo,System.Windows.Forms.MessageBoxIcon.Warning ) == System.Windows.Forms.DialogResult.No)
					return;				
			}

            System.Data.Odbc.OdbcTransaction l_trans = null;

            try
            {
				
                this.m_conn.Open();
                l_trans = this.m_conn.BeginTransaction();			
				
				l_numfac = GetNumFac(true,this.m_conn,l_trans);		
				this.m_numfac = l_numfac;				

                this.ll_generar.Visible = false;

                this.m_now = System.DateTime.Now;

                l_insertf.Connection = this.m_conn;
                
                if(this.m_bool_EsNota == false)
                    l_insertf.CommandText = "INSERT INTO catFacturas(IdCliente,NumeroFactura,Fecha,NumProductos,SubTotal,Total,EsCredito,usuario,estatus,entregado,usuarioventa) VALUES(?,?,?,?,?,?,?,?,?,?,?);";
                else
                    l_insertf.CommandText = "INSERT INTO catNotas(IdCliente,NumeroFactura,Fecha,NumProductos,SubTotal,Total,EsCredito,usuario,estatus,entregado,usuarioventa) VALUES(?,?,?,?,?,?,?,?,?,?,?);";

				
                System.Data.Odbc.OdbcParameter l_p1 = new System.Data.Odbc.OdbcParameter("@IdCliente", System.Data.Odbc.OdbcType.Int);
                l_p1.Value = this.m_idclient;
                l_insertf.Parameters.Add(l_p1);

                System.Data.Odbc.OdbcParameter l_p2 = new System.Data.Odbc.OdbcParameter("@NumeroFactura", System.Data.Odbc.OdbcType.VarChar);
                l_p2.Value = l_numfac;
                l_insertf.Parameters.Add(l_p2);

                System.Data.Odbc.OdbcParameter l_p3 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
                l_p3.Value = this.m_now;
                l_insertf.Parameters.Add(l_p3);

                System.Data.Odbc.OdbcParameter l_p4 = new System.Data.Odbc.OdbcParameter("@NumProductos", System.Data.Odbc.OdbcType.Int);
                l_p4.Value = this.m_detail.Tables[0].Rows.Count;
                l_insertf.Parameters.Add(l_p4);

                System.Data.Odbc.OdbcParameter l_p5 = new System.Data.Odbc.OdbcParameter("@SubTotal", System.Data.Odbc.OdbcType.Double);
                l_p5.Value = System.Math.Round(this.m_subtotal,2);
                l_insertf.Parameters.Add(l_p5);

                System.Data.Odbc.OdbcParameter l_p6 = new System.Data.Odbc.OdbcParameter("@Total", System.Data.Odbc.OdbcType.Double);
                l_p6.Value = System.Math.Round(this.m_total,2);
                l_insertf.Parameters.Add(l_p6);

                System.Data.Odbc.OdbcParameter l_p6_ = new System.Data.Odbc.OdbcParameter("@EsCredito", System.Data.Odbc.OdbcType.Bit);
                l_p6_.Value = this.chk_credito.Checked;
                l_insertf.Parameters.Add(l_p6_);

                System.Data.Odbc.OdbcParameter l_p7_ = new System.Data.Odbc.OdbcParameter("@usuario", System.Data.Odbc.OdbcType.VarChar);
                l_p7_.Value = frm_Main.mps_usuario;
                l_insertf.Parameters.Add(l_p7_);

                System.Data.Odbc.OdbcParameter l_p8_ = new System.Data.Odbc.OdbcParameter("@estatus", System.Data.Odbc.OdbcType.Int);
                if (this.m_mode_docs == 1)   //Modo nuevo, se tiene que asentar el docto
                    l_p8_.Value = 0; // movi rich
                else
                    l_p8_.Value = 1;
                l_insertf.Parameters.Add(l_p8_);

                System.Data.Odbc.OdbcParameter l_p9_ = new System.Data.Odbc.OdbcParameter("@entregado",/*OleDbType.Double*/ System.Data.Odbc.OdbcType.Double);
                l_p9_.Value = 0;
                l_insertf.Parameters.Add(l_p9_);

                System.Data.Odbc.OdbcParameter l_p10_ = new System.Data.Odbc.OdbcParameter("@usuarioventa",/*OleDbType.VarWChar*/System.Data.Odbc.OdbcType.VarChar);
                l_p10_.Value = frm_Main.mps_usuario;
                l_insertf.Parameters.Add(l_p10_);
				
                //this.m_conn.Open();
                //l_trans = this.m_conn.BeginTransaction();

				l_insertf.Transaction = l_trans;
				l_insertf.ExecuteNonQuery();                
				
				l_getf.Connection = this.m_conn;
                l_getf.Transaction = l_trans;
                
                if(this.m_bool_EsNota == false)
                    l_getf.CommandText = "SELECT idFactura FROM catFacturas WHERE IdCliente=? and NumeroFactura = ? and Fecha = ? and NumProductos = ? and EsCredito = ?;";
                else
                    l_getf.CommandText = "SELECT idFactura FROM catNotas WHERE IdCliente=? and NumeroFactura = ? and Fecha = ? and NumProductos = ? and EsCredito = ?;";

                System.Data.Odbc.OdbcParameter l_p7 = new System.Data.Odbc.OdbcParameter("@IdCliente", System.Data.Odbc.OdbcType.Int);
                l_p7.Value = this.m_idclient;
                l_getf.Parameters.Add(l_p7);

                System.Data.Odbc.OdbcParameter l_p8 = new System.Data.Odbc.OdbcParameter("@NumeroFactura", System.Data.Odbc.OdbcType.VarChar);
                l_p8.Value = l_numfac;
                l_getf.Parameters.Add(l_p8);

                System.Data.Odbc.OdbcParameter l_p9 = new System.Data.Odbc.OdbcParameter("@Fecha", System.Data.Odbc.OdbcType.DateTime);
                l_p9.Value = this.m_now;
                l_getf.Parameters.Add(l_p9);

                System.Data.Odbc.OdbcParameter l_p10 = new System.Data.Odbc.OdbcParameter("@NumProductos", System.Data.Odbc.OdbcType.Int);
                l_p10.Value = Convert.ToInt32(this.m_detail.Tables[0].Rows.Count);
                l_getf.Parameters.Add(l_p10);

                System.Data.Odbc.OdbcParameter l_p11 = new System.Data.Odbc.OdbcParameter("@EsCredito", System.Data.Odbc.OdbcType.Bit);
                l_p11.Value = this.chk_credito.Checked;
                l_getf.Parameters.Add(l_p11);

                l_getf.Transaction = l_trans;
                l_keyf = (System.Int32)l_getf.ExecuteScalar();
                
                double lDescuento = 0;
				
				for (i = 0; i < this.m_detail.Tables[0].Rows.Count; i++)
                {
                    System.Text.StringBuilder lDetailData = new System.Text.StringBuilder();

                    ////////////////////////////////////////////////
                    //Detalle para la factura electronica
                    lDetailData.Append( string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][6].ToString()), 2)) );
                    lDetailData.Append("|");
                    lDetailData.Append(m_detail.Tables[0].Rows[i][10].ToString());
                    lDetailData.Append("|");
                    lDetailData.Append(m_detail.Tables[0].Rows[i][2].ToString());
                    lDetailData.Append("|");
                    lDetailData.Append(m_detail.Tables[0].Rows[i][3].ToString());
                    lDetailData.Append("|");
                    lDetailData.Append(string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][4].ToString()), 2)));
                    lDetailData.Append("|");
                    lDetailData.Append(string.Format("{0:0.00}", Math.Round(System.Convert.ToDouble(m_detail.Tables[0].Rows[i][8].ToString()), 2)));
					
					//System.Console.WriteLine( lDetailData.ToString() );
					
                    lDetailDataArr.Add(lDetailData.ToString());
                    ////////////////////////////////////////////////

                    l_insertd = new System.Data.Odbc.OdbcCommand();

                    l_insertd.Connection = this.m_conn;
                    l_insertd.Transaction = l_trans;

                    if(this.m_bool_EsNota == false)
                        l_insertd.CommandText = "INSERT INTO detFactura(IdFactura,IdProducto,PrecioOriginal,PrecioDescuento,Cantidad,PrecioCalculado,DescuentoAplicado,unidaddeventa,iva) VALUES(?,?,?,?,?,?,?,?,?);";
                    else
                        l_insertd.CommandText = "INSERT INTO detNota(IdFactura,IdProducto,PrecioOriginal,PrecioDescuento,Cantidad,PrecioCalculado,DescuentoAplicado,unidaddeventa,iva) VALUES(?,?,?,?,?,?,?,?,?);";
                    
                    l_insertd.Parameters.AddWithValue("@IdFactura", l_keyf);
                    l_insertd.Parameters.AddWithValue("@IdProducto", System.Convert.ToInt32(m_detail.Tables[0].Rows[i][1].ToString()));
                    l_insertd.Parameters.AddWithValue("@PrecioOriginal", System.Convert.ToDouble(m_detail.Tables[0].Rows[i][4].ToString()));
                    l_insertd.Parameters.AddWithValue("@PrecioDescuento", System.Convert.ToDouble(m_detail.Tables[0].Rows[i][5].ToString()));

                    lDescuento += (System.Convert.ToDouble(m_detail.Tables[0].Rows[i][4].ToString()) - System.Convert.ToDouble(m_detail.Tables[0].Rows[i][5].ToString()));

                    l_insertd.Parameters.AddWithValue("@Cantidad", System.Convert.ToDouble(m_detail.Tables[0].Rows[i][6].ToString()));
                    l_insertd.Parameters.AddWithValue("@PrecioCalculado", System.Convert.ToDouble(m_detail.Tables[0].Rows[i][8].ToString()));
                    l_insertd.Parameters.AddWithValue("@DescuentoAplicado", System.Convert.ToDouble(m_detail.Tables[0].Rows[i][7].ToString()));
                    l_insertd.Parameters.AddWithValue("@unidaddeventa", m_detail.Tables[0].Rows[i][10].ToString());

                    l_insertd.Parameters.AddWithValue("@iva", Convert.ToInt32(m_detail.Tables[0].Rows[i][11]));

                    //PrecioCalculado * (1.0 + iva / 100.0 ))
                    double impte = System.Convert.ToDouble(m_detail.Tables[0].Rows[i][8]) * (1.0 + (Convert.ToDouble(m_detail.Tables[0].Rows[i][11]) / 100.0));
                    if (this.mp_usa_existencia0 == 0)
                    {
                        this.DeducirInventario(System.Convert.ToInt32(m_detail.Tables[0].Rows[i][1]), System.Convert.ToDouble(m_detail.Tables[0].Rows[i][6]), impte, this.m_conn, l_trans, m_detail.Tables[0].Rows[i]);
                    }

                    l_insertd.Transaction = l_trans;
                    l_insertd.ExecuteNonQuery();                   

                }

				if(this.m_bool_EsNota == false)
				{
	                //////////////////////////////////////////////////////////////////
	                //Almacenar la cadena original y el sello
					/*
					string lFecha = DateTime.Now.Year.ToString() + "-" + ( DateTime.Now.Month.ToString().Length == 2 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString() );
					lFecha += "-" + ( DateTime.Now.Day.ToString().Length == 2 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString() );
					lFecha += "T" + ( DateTime.Now.Hour.ToString().Length == 2 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString() );
					lFecha += ":" + ( DateTime.Now.Minute.ToString().Length == 2 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString() );
					lFecha += ":" + ( DateTime.Now.Second.ToString().Length == 2 ? DateTime.Now.Second.ToString() : "0" + DateTime.Now.Second.ToString() );
					
	                string lCadenaOriginal = lFE.GenerarCadenaOriginal(this.mConfFact, l_numfac, lFecha,
	                    "UNA SOLA EXIBICION",
	                    string.Format("{0:0.00}", Math.Round(this.m_subtotal, 2)),
	                    string.Format("{0:0.00}", Math.Round(lDescuento, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total, 2)),
	                    this.mpRfcCliente,
	                    this.mpRazonSocialCliente,
	                    this.mpCalleCliente,
	                    this.mpNumeroExtCliente,
	                    this.mpNumeroIntCliente,
	                    this.mpColoniaCliente,
	                    this.mpLocalidadCliente,
	                    this.mpReferenciaCliente,
	                    this.mpMunicipioCliente,
	                    this.mpEstadoCliente,
	                    this.mpPaisCliente,
	                    this.mpCodigoPostalCliente,
	                    string.Format("{0:0.00}", Math.Round(this.mp_IVA*100, 2)),
	                    string.Format("{0:0.00}", Math.Round(this.m_total - this.m_subtotal, 2)),
	                    lDetailDataArr);
	
	                //this.mp_IVA
	                lFE.mOpenSSLPath = ConfigurationSettings.AppSettings["opensslpath"];
					
					string lKeyFile = "";
					try
					{
						lKeyFile = System.IO.File.ReadAllText("keyfile.txt").Trim();
					}
					catch(Exception ex)
					{
						throw new Exception("Es necesario importar el archivo llave de facturacion electronica antes de generar una factura.");						
					}
	                string lSello = lFE.GenerarSello(lCadenaOriginal, lKeyFile);
	
	                //Actualizar la factura
	                System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
	                lConn.ConnectionString = frm_Main.mps_strconnection;
	
	                System.Data.Odbc.OdbcCommand lCmdEND = new System.Data.Odbc.OdbcCommand();
	                lCmdEND.Connection = this.m_conn;
	                lCmdEND.Transaction = l_trans;
	                lCmdEND.CommandText = "UPDATE catFacturas SET cadenaoriginal = ?,sello = ? where IdFactura = ?";
	
	                lCmdEND.Parameters.AddWithValue("@cadenaoriginal", lCadenaOriginal);
	                lCmdEND.Parameters.AddWithValue("@sello", lSello);
	                lCmdEND.Parameters.AddWithValue("@IdFactura", l_keyf);
	
	                lCmdEND.ExecuteNonQuery();
	
	                this.m_cadena_original = lCadenaOriginal;
	                this.m_sello = lSello;
	                */
	                //////////////////////////////////////////////////////////////////
				}

                l_trans.Commit();

                //SVM Nov2009
                if (this.m_mode_docs == 1)
                {
                    //informa de la nota generada
                    frm_factura_info l_facinfo = new frm_factura_info();
                    l_facinfo.m_esnota = this.m_bool_EsNota;
                    l_facinfo.m_docto = l_numfac;
                    l_facinfo.ShowDialog();
                }
                else
                {
                    frm_cambio l_cambio = new frm_cambio();
                    l_cambio.m_esnota = this.m_bool_EsNota;
                    l_cambio.m_docto = l_numfac;
                    l_cambio.m_total = this.m_total;
                    l_cambio.m_mode_docs = this.m_mode_docs;
                    l_cambio.ShowDialog();
                }
                
            }
            catch (Exception ee)
            {
                if (l_trans != null)
                    l_trans.Rollback();
                MessageBox.Show(ee.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {                

                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();

            }

			
            this.ImprimirFactura();
			this.Close(); 

		}

        private clsConfFacturaElectronica mConfFact = new clsConfFacturaElectronica();

        private void LoadData()
        {
            System.Data.Odbc.OdbcConnection lConn = new System.Data.Odbc.OdbcConnection();
            lConn.ConnectionString = frm_Main.mps_strconnection;

            System.Data.Odbc.OdbcCommand lCmd = new System.Data.Odbc.OdbcCommand();
            lCmd.Connection = lConn;
            lCmd.CommandText = "SELECT * FROM confFacturaElectronica WHERE iidconfsystem = 1";

            lConn.Open();
            System.Data.Odbc.OdbcDataReader lReader = lCmd.ExecuteReader();

            if (lReader.Read())
            {
                this.mConfFact.Version = lReader["Version"].ToString();
                this.mConfFact.Serie = lReader["Serie"].ToString();
                this.mConfFact.Numero_de_Aprobacion = lReader["Numero_de_Aprobacion"].ToString();
                this.mConfFact.Anio_Aprobacion = lReader["Anio_Aprobacion"].ToString();
                this.mConfFact.Tipo_de_Comprobante = lReader["Tipo_de_Comprobante"].ToString();
                this.mConfFact.RFC = lReader["RFC"].ToString();
                this.mConfFact.Razon_Social = lReader["Razon_Social"].ToString();
                this.mConfFact.Calle = lReader["Calle"].ToString();
                this.mConfFact.Numero_Exterior = lReader["Numero_Exterior"].ToString();
                this.mConfFact.Numero_Interior = lReader["Numero_Interior"].ToString();
                this.mConfFact.Colonia = lReader["Colonia"].ToString();
                this.mConfFact.Localidad = lReader["Localidad"].ToString();
                this.mConfFact.Referencia = lReader["Referencia"].ToString();
                this.mConfFact.Municipio = lReader["Municipio"].ToString();
                this.mConfFact.Estado = lReader["Estado"].ToString();
                this.mConfFact.Pais = lReader["Pais"].ToString();
                this.mConfFact.Codigo_Postal = lReader["Codigo_Postal"].ToString();
            }

            lConn.Close();
        }

        private void DeducirInventario(System.Int32 p_Key, System.Double p_cant, System.Double p_impte, System.Data.Odbc.OdbcConnection p_conn, System.Data.Odbc.OdbcTransaction p_trans, System.Data.DataRow oRow)
		{
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
            string strMess;
  
			l_cmd.Connection = p_conn;
            l_cmd.Transaction = p_trans;
			l_cmd.CommandText = "UPDATE catProductos SET existencia = existencia - " + p_cant.ToString() + " WHERE IdProducto = " + p_Key.ToString() + ";";		

			l_cmd.ExecuteNonQuery();

            frm_productos.Save_Existencias_Almacen(p_Key, (decimal)(-1 * p_cant), p_conn, p_trans,  out strMess);

            l_cmd.CommandText = "INSERT INTO catEntradas(ccodigo,dtfecha,cdescripcion,icantidad,iimporte,clogin,entrada,observaciones,idAlmacen) VALUES(?,?,?,?,?,?,?,?,?);";
            l_cmd.Parameters.Clear();
            l_cmd.Parameters.AddWithValue("@ccodigo", oRow[2]);
            l_cmd.Parameters.AddWithValue("@dtfecha", this.m_now);
            l_cmd.Parameters.AddWithValue("@cdescripcion", oRow[3]);
            l_cmd.Parameters.AddWithValue("@icantidad", -1*p_cant);
            l_cmd.Parameters.AddWithValue("@iimporte", -1 * System.Math.Round(p_impte,2));
            l_cmd.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
            l_cmd.Parameters.AddWithValue("@entrada", 0);
            if (this.m_bool_EsNota == false)
                l_cmd.Parameters.AddWithValue("@observaciones", "FAC " + this.m_numfac);
            else
                l_cmd.Parameters.AddWithValue("@observaciones", "NOT " + this.m_numfac);
            l_cmd.Parameters.AddWithValue("@idAlmacen", frm_Main.mp_idAlmacen);

            l_cmd.ExecuteNonQuery();


			return;
		}

		private int GetCopiasFactura()
		{
			int l_copias = 1;
			System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
  
			l_cmd.Connection = this.m_conn;            
			l_cmd.CommandText = "SELECT CopiasFactura FROM confSystem;";		
 
			try
			{
			this.m_conn.Open();
			l_copias = (int)l_cmd.ExecuteScalar();
			
			this.m_conn.Close();
			}
			catch
			{
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}

			return l_copias;			
		}
		
		private void ImprimirFactura()
		{
            try
            {
                //this.printpw.WindowState = FormWindowState.Maximized;

                if (MessageBox.Show("�Desea imprimir ahora?", "Imprimir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                	int l_copias = this.GetCopiasFactura();
                	int i;
                	
                	for(i=0;i<l_copias;i++)
                    	this.printdoc.Print();
                }
                //else
                //{                       
                //    this.printpw.ShowDialog();
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
		}
		
		private string GetEncabezadoNota()
		{
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '002';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            string l_result = l_reader["EncabezadoNota"].ToString();

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
		}		

		private void printdoc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			this.LoadDocPositions();

            int l_desglosar_iva = this.DesglosarIVA();
			int lStart = 30;
			
			System.Drawing.Brush l_brush = System.Drawing.Brushes.Black;
            System.Drawing.Font l_font = new Font("Courier", this.mp_int_TamanioLetra);
            System.Drawing.Font l_fontcant = new Font("Courier", this.mp_int_TamanioLetra);
            System.Drawing.Font l_fontcanorig = new Font("Arial", 7);
			System.Drawing.Font l_fontcanorighead = new Font("Arial", 7,FontStyle.Bold);

            if (this.m_bool_EsNota == true)
                e.Graphics.DrawString("*******************************************************", l_font, l_brush, 1, 0);

			//Leyenda...
			if(this.mp_string_Leyenda.Trim()!="")
				e.Graphics.DrawString(this.mp_string_Leyenda,l_font,l_brush,5,5);

            if (this.m_bool_EsNota == true)
            {
				string[] lLineas = this.GetEncabezadoNota().Split('|');
				
				foreach(string lLine in lLineas)
				{
					if( lLine.Trim() == "" )
						continue;
					
					e.Graphics.DrawString(lLine, l_font, l_brush, 5, lStart);
					lStart+=20;
				}

                e.Graphics.DrawString("*******************************************************", l_font, l_brush, 1, 100);
				lStart += 20;
            }

			if( this.m_bool_EsNota == false )
			{
            	if (this.mp_int_PosNumFactX != -1)
                	e.Graphics.DrawString("No. " + this.m_numfac, l_font, l_brush, this.mp_int_PosNumFactX, this.mp_int_PosNumFactY);   
			}
			else
			{
				e.Graphics.DrawString( DateTime.Now.ToString(), l_font, l_brush, this.mp_int_PosFechaX, lStart);  
				e.Graphics.DrawString("No. " + this.m_numfac,l_font,l_brush,this.mp_int_PosNumFactX,lStart);
				lStart += (this.mp_int_EspacioDetalle*2);				
			}

			//Nombre
			if(this.mp_int_PosNombreX != -1)
				e.Graphics.DrawString(this.txt_nombre.Text,l_font,l_brush,this.mp_int_PosNombreX,this.mp_int_PosNombreY);   			 

			//Direcci�n
			if(this.mp_int_PosDireccionX != -1)
				e.Graphics.DrawString(this.txt_dir.Text,l_font,l_brush,this.mp_int_PosDireccionX,this.mp_int_PosDireccionY);   			 

			//Ciudad
			if(this.mp_int_PosCiudadX != -1)
				e.Graphics.DrawString(this.m_ciudad,l_font,l_brush,this.mp_int_PosCiudadX,this.mp_int_PosCiudadY);   			 

			//Fecha
			if(this.mp_int_PosFechaX != -1)
				e.Graphics.DrawString( this.m_now.ToString()  ,l_font,l_brush,this.mp_int_PosFechaX,this.mp_int_PosFechaY);   			 

			//RFC
			if(this.mp_int_PosRFCX != -1)
				e.Graphics.DrawString(this.txt_rfc.Text,l_font,l_brush,this.mp_int_PosRFCX,this.mp_int_PosRFCY);   			 
	 
			
			System.Int32 i;
			System.Int32 l_pos = 0;

			System.Double l_d1,l_d2;
			System.String l_s1,l_s2;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				//l_pos = i*this.mp_int_EspacioDetalle;

				if(this.m_bool_EsNota == true)
				{
					this.mp_int_PosDescripcionY = 0;
					this.mp_int_PosCodigoY = 0;
					this.mp_int_PosCantidadY = 0;
					this.mp_int_PosPrecioY = 0;
					this.mp_int_PosTotalY = 0;
					l_pos = lStart;
					l_pos += (i*(this.mp_int_EspacioDetalle*2));
				}
				else
				{
					l_pos = i*(this.mp_int_EspacioDetalle*2);
				}
				
				//Descripci�n
                if (this.mp_int_PosDescripcionX != -1)//Aqui muevele rich
                {
                    //if (this.m_detail.Tables[0].Rows[i][3].ToString().Length>15)
                    //    e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][3].ToString().Substring(0, 15), l_font, l_brush, this.mp_int_PosDescripcionX, this.mp_int_PosDescripcionY + l_pos);
                    //else
                        e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][3].ToString(), l_font, l_brush, this.mp_int_PosDescripcionX, this.mp_int_PosDescripcionY + l_pos);
                    
                }			
				
                if (this.m_bool_EsNota == true)
                    l_pos += this.mp_int_EspacioDetalle;				
				
				//C�digo
				if(this.mp_int_PosCodigoX != -1)
					e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][2].ToString(),l_font,l_brush,this.mp_int_PosCodigoX,this.mp_int_PosCodigoY+l_pos);   		
				//Cantidad
				if(this.mp_int_PosCantidadX != -1)
                    e.Graphics.DrawString(this.m_detail.Tables[0].Rows[i][6].ToString() + " " + this.m_detail.Tables[0].Rows[i][10].ToString(), l_font, l_brush, this.mp_int_PosCantidadX, this.mp_int_PosCantidadY + l_pos);   		

				l_d1 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][5].ToString());  
				l_d2 = System.Convert.ToDouble(this.m_detail.Tables[0].Rows[i][8].ToString());  

				l_s1 = System.String.Format("{0:C}",l_d1);
				l_s2 = System.String.Format("{0:C}",l_d2);
 		
				//Precio
				if(this.mp_int_PosPrecioX != -1)
					e.Graphics.DrawString(l_s1,l_font,l_brush,this.mp_int_PosPrecioX,this.mp_int_PosPrecioY+l_pos);   		
				//Total
				if(this.mp_int_PosTotalX != -1)
					e.Graphics.DrawString(l_s2,l_font,l_brush,this.mp_int_PosTotalX,this.mp_int_PosTotalY+l_pos);   		
			}
			
			if(this.m_bool_EsNota == true)
				l_pos += (this.mp_int_EspacioDetalle*2);			

			System.Double l_total=0;
			System.Double l_iva=0;

			for(i=0;i<this.m_detail.Tables[0].Rows.Count;i++)
			{
				l_total = l_total + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				l_iva = l_iva + ( System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][9].ToString() ) - System.Convert.ToDouble( this.m_detail.Tables[0].Rows[i][8].ToString() ) );
				this.m_detail.Tables[0].Rows[i][0] = i+1;
			}

            if (l_desglosar_iva == 1)
            {

                //subtotal
                if (this.mp_int_PosSubTotalX != -1)
                {
                    if (this.mp_int_PosSubTotalY == -2)
                    {
						if(l_desglosar_iva == 1 & this.m_bool_EsNota == false)
						{
	                        l_pos += 50;
	                        e.Graphics.DrawString("SUBTOTAL", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
	                        e.Graphics.DrawString(System.String.Format("{0:C}", l_total), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
	                        l_pos += this.mp_int_EspacioDetalle;
						}
                    }
                    else
                    {
						if(l_desglosar_iva == 1 & this.m_bool_EsNota == false)
                        	e.Graphics.DrawString(System.String.Format("{0:C}", l_total), l_font, l_brush, this.mp_int_PosSubTotalX, this.mp_int_PosSubTotalY);
                    }
                }

                //Iva
                //l_iva = l_total*this.mp_IVA;
                //l_iva = System.Math.Round(l_iva,2);  
                if (this.mp_int_PosIVAX != -1)
                {
                    if (this.mp_int_PosIVAY == -2)
                    {
						if(l_desglosar_iva == 1 & this.m_bool_EsNota == false)
						{
	                        e.Graphics.DrawString("IVA", l_font, l_brush, this.mp_int_PosSubTotalX - 100, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
	                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);
	                        l_pos += this.mp_int_EspacioDetalle;
						}
                    }
                    else
                    {
						if(l_desglosar_iva == 1 & this.m_bool_EsNota == false)
						{
	                        e.Graphics.DrawString(System.String.Format("{0:C}", l_iva), l_font, l_brush, this.mp_int_PosIVAX, this.mp_int_PosIVAY);
	                        //l_pos += this.mp_int_EspacioDetalle;
						}
                    }
                }

            }
            else 
            {
                l_pos += this.mp_int_EspacioDetalle;
            }

			//Total
			l_total = l_total + l_iva;
			l_total = System.Math.Round(l_total,2);  
			if(this.mp_int_PosGTotalX != -1)
			{
				if(this.mp_int_PosGTotalY == -2)
				{
					e.Graphics.DrawString("TOTAL",l_font,l_brush,this.mp_int_PosSubTotalX - 100,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   			 
					e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle);   		
				}
				else
				{
					e.Graphics.DrawString(System.String.Format("{0:C}",l_total),l_font,l_brush,this.mp_int_PosGTotalX,this.mp_int_PosGTotalY);   		
				}
			}

            if (this.m_bool_EsNota == false)
            {
                if (this.mp_int_PosCadenaOriginalX != -1)
                {
                    if (this.mp_int_PosCadenaOriginalY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
						e.Graphics.DrawString("Cadena Original",
                                l_fontcanorighead, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY );
						
                        while (lPos < this.m_cadena_original.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_cadena_original.Length)
                                lPosEnd = this.m_cadena_original.Length;

                            e.Graphics.DrawString(this.m_cadena_original.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosCadenaOriginalX, this.mp_int_PosCadenaOriginalY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }

        //int mp_int_PosSelloX = 0;
        //int mp_int_PosSelloY = 0; 

            if (this.m_bool_EsNota == false)
            {
                if (this.mp_int_PosSelloX != -1)
                {
                    if (this.mp_int_PosSelloY != -1)
                    {
                        int lPos = 0;
                        int lSpace = 8;
						
                            e.Graphics.DrawString("Sello Digital",
                                l_fontcanorighead, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY );						
						
                        while (lPos < this.m_sello.Length)
                        {
                            int lPosEnd = lPos + 100;
                            if (lPosEnd > this.m_sello.Length)
                                lPosEnd = this.m_sello.Length;

                            e.Graphics.DrawString(this.m_sello.Substring(lPos, lPosEnd - lPos),
                                l_fontcanorig, l_brush, this.mp_int_PosSelloX, this.mp_int_PosSelloY + lSpace);
                            lPos = lPosEnd;
                            lSpace += 8;
                        }
                    }
                }
            }


            /*
            if (this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY == -2)
                    e.Graphics.DrawString(l_cantidad, l_fontcant, l_brush, this.mp_int_PosGTotalLetrasX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle + 13); 
            */
            if (this.m_bool_EsNota == true)
                e.Graphics.DrawString("PAGO EN UNA SOLA EXHIBICION", l_font, l_brush, 3, this.mp_int_PosTotalY + l_pos + 70);

            if (this.mp_string_mensaje != "" && this.m_bool_EsNota == true)
                e.Graphics.DrawString(this.mp_string_mensaje, l_font, l_brush, 3, this.mp_int_PosTotalY + l_pos + 90); 

            /////////////////////////////////////////////////////////
            //Factura electronica
            if (this.m_bool_EsNota == false)
            {
 
            }
            /////////////////////////////////////////////////////////

			//Total en letras

			//Separar los centavos...
			System.Double l_centavos;

			l_total = l_total * 100;
			l_centavos = l_total % 100;
            l_total = l_total - l_centavos;
			l_total = l_total / 100;

			l_total = System.Math.Round(l_total,2);

			System.String l_cantidad;

			l_cantidad = this.GetStringValue(System.String.Format("{0:C}",l_total));

			if(l_centavos > 0)
			{
				System.String l_cantcent = System.String.Format(" {0}/100",System.Math.Round(l_centavos,2));
				l_cantidad = l_cantidad + l_cantcent;
			}

			l_cantidad = l_cantidad + " MN";
			if(this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY != -2)
				    e.Graphics.DrawString(l_cantidad,l_fontcant,l_brush,this.mp_int_PosGTotalLetrasX,this.mp_int_PosGTotalLetrasY);


            if (this.mp_int_PosGTotalLetrasX != -1)
                if (this.mp_int_PosGTotalY == -2)
                    e.Graphics.DrawString(l_cantidad, l_fontcant, l_brush, this.mp_int_PosGTotalLetrasX, this.mp_int_PosTotalY + l_pos + this.mp_int_EspacioDetalle + 33); 
			
		}

        private int DesglosarIVA()
        {
            System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();

            l_cmd.Connection = this.m_conn;
            l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001';";

            this.m_conn.Open();
            System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();

            l_reader.Read();

            int l_result = Convert.ToInt32(l_reader["DesglosarIva"]);

            l_reader.Close();
            this.m_conn.Close();

            return l_result;
        }

		private System.String GetStringValue(System.String  p_total)
		{
			System.String l_num;
			System.Int32 i,size;

			l_num = p_total.Remove(0,1);

			size = l_num.Length; 

			for(i=0;i<size;i++)
			{
				if( l_num.Substring(i,1) == "," )
				{
					l_num = l_num.Remove(i,1); 
					size = l_num.Length; 
				}

			}

			//MessageBox.Show(l_num); 
            string l_retval = "";

			clsUtils.cUtils l_utils = new clsUtils.cUtils();

            if ( Convert.ToDouble(l_num) < 1 )
                l_retval = "CERO PESOS " + l_utils.Transforma(l_num);
            else
			    l_retval = l_utils.Transforma(l_num);

            return l_retval;
		}

        private void ll_nuevo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_nuevo_Click(sender, e);
        }

        private void ll_buscar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_buscar_Click(sender, e);
        }

        private void ll_agregar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.txt_nombre.Text.Trim() == "")
            {
                MessageBox.Show("Seleccione primero un cliente!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.cmd_agregar_Click(sender, e);
        }

        private void ll_borrar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_borrar_Click(sender, e);
        }

        private void ll_producto_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.txt_nombre.Text.Trim() == "")
            {
                MessageBox.Show("Seleccione primero un cliente!","Atenci�n",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }

            this.cmd_findproduct_Click(sender, e);
            this.txt_cantidad.SelectAll();
            this.txt_cantidad.Focus();
        }

        private void ll_generar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cmd_generar_Click(sender, e);
        }

        private void ll_cancelar_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.cdm_cerrar_Click(sender, e);
        }

        private void frm_factura_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
            	case Keys.Delete:
            		this.cmd_borrar_Click(sender, e);
            		e.Handled = true;
            		break;
                case Keys.F1:
                    this.ll_producto_LinkClicked(sender, null);
                    this.txt_cantidad.SelectAll();
                    this.txt_cantidad.Focus();
                    break;
                case Keys.F2:
                    this.ll_agregar_LinkClicked(sender, null);
                    break;
                case Keys.F6:
                    this.cmd_nuevo_Click(sender, e);
                    break;
                case Keys.F7:
                    this.ll_buscar_LinkClicked(sender, null);
                    break;
                case Keys.F8:
                    this.chk_credito.Checked = !this.chk_credito.Checked;
                    /*
                    // SVM Dic2010  ahora las notas tambien funcionan a credito
                    if (this.m_bool_EsNota == false)
                        this.chk_credito.Checked = !this.chk_credito.Checked;
                    */
                    break;
                case Keys.F10:
                    this.ll_generar_LinkClicked(sender, null);
                    break;
                case Keys.Escape:
                    if (MessageBox.Show("Desea salir?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        this.Close();
                    }
                    break;
            }
        }
	        
        #region posiciones de la factura...
        ////////////////////////////////////////////////     
        //Posiciones de la factura...
		int mp_int_PosNombreX = 0;        
		int mp_int_PosNombreY = 0;        
	
		int mp_int_PosDireccionX = 0;        
		int mp_int_PosDireccionY = 0;        

		int mp_int_PosCiudadX = 0;        
		int mp_int_PosCiudadY = 0;        

		int mp_int_PosRFCX = 0;        
		int mp_int_PosRFCY = 0;        

		int mp_int_PosNumFactX = 0;        
		int mp_int_PosNumFactY = 0;        

		int mp_int_PosFechaX = 0;        
		int mp_int_PosFechaY = 0;        
		
		int mp_int_PosCodigoX = 0;        
		int mp_int_PosCodigoY = 0;        

		int mp_int_PosCantidadX = 0;        
		int mp_int_PosCantidadY = 0;        

		int mp_int_PosDescripcionX = 0;        
		int mp_int_PosDescripcionY = 0;        

		int mp_int_PosPrecioX = 0;        
		int mp_int_PosPrecioY = 0;        
		
		int mp_int_PosTotalX = 0;        
		int mp_int_PosTotalY = 0;        
		
		int mp_int_PosSubTotalX = 0;        
		int mp_int_PosSubTotalY = 0;        
		
		int mp_int_PosIVAX = 0;        
		int mp_int_PosIVAY = 0;        

		int mp_int_PosGTotalX = 0;        
		int mp_int_PosGTotalY = 0;

        int mp_int_PosCadenaOriginalX = 0;
        int mp_int_PosCadenaOriginalY = 0;

        int mp_int_PosSelloX = 0;
        int mp_int_PosSelloY = 0; 
		
		int mp_int_PosGTotalLetrasX = 0;        
		int mp_int_PosGTotalLetrasY = 0;        
		
		int mp_int_EspacioDetalle = 0;
		int mp_int_TamanioLetra = 0;		
		
		string mp_string_Leyenda = "";
		
		#endregion

        string mp_string_mensaje = "";

		private void LoadDocPositions()
		{
			try
			{
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				
				if(this.m_bool_EsNota == false)
					l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '001'";
				else
					l_cmd.CommandText = "SELECT * FROM confDocsPrint WHERE TipoDoc = '002'";

				this.m_conn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//PosNombre					
					l_temp = l_reader["PosNombre"].ToString().Split(',');
					this.mp_int_PosNombreX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNombreY = Convert.ToInt32(l_temp[1]);
					
					//PosDireccion
					l_temp = l_reader["PosDireccion"].ToString().Split(',');
					this.mp_int_PosDireccionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDireccionY = Convert.ToInt32(l_temp[1]);
					
					//PosCiudad
					l_temp = l_reader["PosCiudad"].ToString().Split(',');
					this.mp_int_PosCiudadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCiudadY = Convert.ToInt32(l_temp[1]);
					
					//PosRFC
					l_temp = l_reader["PosRFC"].ToString().Split(',');
					this.mp_int_PosRFCX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosRFCY = Convert.ToInt32(l_temp[1]);
					
					//PosNumFact
					l_temp = l_reader["PosNumFact"].ToString().Split(',');
					this.mp_int_PosNumFactX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosNumFactY = Convert.ToInt32(l_temp[1]);
					
					//PosFecha
					l_temp = l_reader["PosFecha"].ToString().Split(',');
					this.mp_int_PosFechaX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosFechaY = Convert.ToInt32(l_temp[1]);
					
					//PosCodigo
					l_temp = l_reader["PosCodigo"].ToString().Split(',');
					this.mp_int_PosCodigoX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCodigoY = Convert.ToInt32(l_temp[1]);
					
					//PosCantidad
					l_temp = l_reader["PosCantidad"].ToString().Split(',');
					this.mp_int_PosCantidadX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosCantidadY = Convert.ToInt32(l_temp[1]);
					
					//PosDescripcion
					l_temp = l_reader["PosDescripcion"].ToString().Split(',');
					this.mp_int_PosDescripcionX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosDescripcionY = Convert.ToInt32(l_temp[1]);
					
					//PosPrecio
					l_temp = l_reader["PosPrecio"].ToString().Split(',');
					this.mp_int_PosPrecioX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosPrecioY = Convert.ToInt32(l_temp[1]);
					
					//PosTotal
					l_temp = l_reader["PosTotal"].ToString().Split(',');
					this.mp_int_PosTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosSubtotal
					l_temp = l_reader["PosSubtotal"].ToString().Split(',');
					this.mp_int_PosSubTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosSubTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosIVA
					l_temp = l_reader["PosIVA"].ToString().Split(',');
					this.mp_int_PosIVAX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosIVAY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotal
					l_temp = l_reader["PosGTotal"].ToString().Split(',');
					this.mp_int_PosGTotalX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalY = Convert.ToInt32(l_temp[1]);
					
					//PosGTotalLetras
					l_temp = l_reader["PosGTotalLetras"].ToString().Split(',');
					this.mp_int_PosGTotalLetrasX = Convert.ToInt32(l_temp[0]);
					this.mp_int_PosGTotalLetrasY = Convert.ToInt32(l_temp[1]);

                    //PosCadenaOriginal
                    l_temp = l_reader["PosCadenaOriginal"].ToString().Split(',');
                    this.mp_int_PosCadenaOriginalX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosCadenaOriginalY = Convert.ToInt32(l_temp[1]);

                    //PosSello
                    l_temp = l_reader["PosSello"].ToString().Split(',');
                    this.mp_int_PosSelloX = Convert.ToInt32(l_temp[0]);
                    this.mp_int_PosSelloY = Convert.ToInt32(l_temp[1]);
					
					//EspacioDetalle
					this.mp_int_EspacioDetalle = Convert.ToInt32(l_reader["EspacioDetalle"].ToString());
					
					//TamanioLetra
					this.mp_int_TamanioLetra = Convert.ToInt32(l_reader["TamanioLetra"].ToString());
					
					//Leyenda
					this.mp_string_Leyenda = l_reader["Leyenda"].ToString();

                    //Mensaje
                    this.mp_string_mensaje = l_reader["mensaje"].ToString();
					
				}
				
				l_reader.Close();				
			
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}
		
		double mp_IVA = 0.15;
		string mp_clientenotas = "";
        int mp_usa_iva_por_articulo = 0;
        int mp_usa_existencia0 = 0;
		
		private void LoadSystemValues()
		{
			try
			{
                System.Data.Odbc.OdbcCommand l_cmd = new System.Data.Odbc.OdbcCommand();
				
				l_cmd.Connection = this.m_conn;
				
				l_cmd.CommandText = "SELECT * FROM confSystem WHERE CodTienda = '001'";

				this.m_conn.Open();
				System.Data.Odbc.OdbcDataReader l_reader = l_cmd.ExecuteReader();
								
				if(l_reader.Read())
				{
					string[] l_temp = new string[2];
					
					//IVA					
					this.mp_IVA = Convert.ToDouble(l_reader["IVA"]);
                    this.mp_iva_to_store = Convert.ToInt32( Convert.ToDouble(l_reader["IVA"])*100 );
					
					//Cliente Notas
					this.mp_clientenotas = l_reader["ClienteNotas"].ToString();

                    //Usa Iva por articulo?
                    this.mp_usa_iva_por_articulo = Convert.ToInt32(l_reader["UsarIvaPorArtic"]);

                    //Usa Iva por articulo?
                    this.mp_usa_existencia0 = Convert.ToInt32(l_reader["UsarExistencia0"]);
					
				}
				
				l_reader.Close();				
			
			}
			catch(Exception ee)
			{
				MessageBox.Show(ee.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			finally
			{
				if(this.m_conn.State == System.Data.ConnectionState.Open)
					this.m_conn.Close();
			}
			
		}
		
		
		void Lnk_directpriceLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			
			if( this.txt_codigo.Text.Trim()=="" )
			{
				MessageBox.Show("Seleccione primero un articulo","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			
			frm_precio l_frm_price = new frm_precio();
			if( l_frm_price.ShowDialog() == DialogResult.OK )
			{
				//MessageBox.Show( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") );
				//this.txt_total.Text = Convert.ToDouble( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") ).ToString();
                this.txt_totaliva.Text = "";

                try
                {
                this.m_curprice = Convert.ToDouble( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") );
                this.m_orprice = this.m_curprice;
                System.Double l_total = Convert.ToDouble( l_frm_price.txt_precio.Text.Replace("$","").Replace(",","") ) * Convert.ToDouble( this.txt_cantidad.Text );
				l_total = System.Math.Round(l_total ,2);
				this.txt_total.Text = l_total.ToString();
                
                this.txt_totaliva.Text = Convert.ToString(System.Math.Round(l_total * (1 + this.mp_IVA), 2));
                }
                catch{}
				
			}
		}
		
		void Txt_codigoKeyDown(object sender, KeyEventArgs e)
		{
			if(e.KeyCode == Keys.Enter)
			{
				//Buscar el articulo...
                System.Data.Odbc.OdbcCommand l_recid = new System.Data.Odbc.OdbcCommand();
				l_recid.Connection = this.m_conn;
                l_recid.CommandText = "SELECT catProductos.*, catExistencias.Existencia as existenc_almacen FROM catProductos LEFT JOIN catExistencias ON catProductos.IdProducto=catExistencias.IdProducto AND catExistencias.IdAlmacen=?  WHERE catProductos.Codigo = ?;";
                l_recid.Parameters.AddWithValue("@IdAlmacen", frm_Main.mp_idAlmacen);
				l_recid.Parameters.Add(  new System.Data.Odbc.OdbcParameter("@Codigo",this.txt_codigo.Text )  );
				
				//this.m_idproduct = l_frmProductos.m_KeyRecord;

				this.m_conn.Open();  
				System.Data.Odbc.OdbcDataReader l_reader = l_recid.ExecuteReader(); 

				if(l_reader.Read()==false)
				{
					
					this.m_idproduct = -1; 
					this.txt_descripcion.Text = ""; 
					this.m_curprice = 0; 
					this.m_orprice = 0; 
					this.m_lastvalid_code = ""; 
					this.mp_IVA = 0;			
					this.txt_total.Text = "";
					this.txt_totaliva.Text = "";
					this.m_lastvalid_code = "";
                    this.lbl_Existencia.Text = "";
					
					l_reader.Close();
					this.m_conn.Close();  		
					return;
				}

				this.m_idproduct = l_reader.GetInt32(0); 
				this.txt_descripcion.Text = l_reader.GetString(3); 
				this.m_curprice = Convert.ToDouble(l_reader[6]);//l_reader.GetDouble(6); 
				this.m_orprice = Convert.ToDouble(l_reader[6]);//l_reader.GetDouble(6); 
				this.txt_codigo.Text =  l_reader.GetString(1); 
				this.m_lastvalid_code = l_reader.GetString(1);
                if (frm_Main.mp_idAlmacen <= 0)
                {
                    this.lbl_Existencia.Text = Convert.ToDecimal(l_reader["Existencia"]).ToString("####,##0.00");
                }
                else
                {
                    try
                    {
                        this.lbl_Existencia.Text = Convert.ToDecimal(l_reader["existenc_almacen"]).ToString("####,##0.00");
                    }
                    catch
                    {
                        this.lbl_Existencia.Text = "0.00";
                    }
                }

				//this.mp_IVA = Convert.ToDouble(l_reader["iva"]);
                if (this.mp_usa_iva_por_articulo == 1)
                {
                    this.mp_IVA = Convert.ToDouble(l_reader["iva"]);
                    this.mp_IVA = this.mp_IVA / 100;
                    this.mp_iva_to_store = Convert.ToInt32(l_reader["iva"]);
                }
				

                //this.mp_IVA = this.mp_IVA / 100;
				
				this.lbl_unidadventa.Text = l_reader["UnidadVenta"].ToString();

				l_reader.Close();
				this.m_conn.Close();  

				this.txt_cantidad.Text = "1"; 
				this.txt_descuento.Text = "0";

				//this.m_curprice = System.Math.Round(this.m_curprice,2);  
				//this.m_orprice = System.Math.Round(this.m_orprice,2);  

				System.Double l_total = this.m_curprice;  
				//l_total = System.Math.Round(l_total,2);  
				this.txt_total.Text = l_total.ToString();

                //this.txt_totaliva.Text = Convert.ToString(System.Math.Round(this.m_curprice * (1 + this.mp_IVA), 2));
                this.txt_totaliva.Text = Convert.ToString(this.m_curprice * (1 + this.mp_IVA));

				this.ll_agregar.Visible = true; 				
				
				//this.txt_codigo.Focus();
				//this.txt_codigo.SelectAll();
				this.txt_cantidad.Focus();
				this.txt_cantidad.SelectAll();
				
				
			}
		}
		
		void Txt_cantidadEnter(object sender, EventArgs e)
		{
			this.txt_cantidad.SelectAll();
		}
		
		void Txt_descuentoEnter(object sender, EventArgs e)
		{
			this.txt_descuento.SelectAll();
		}
		
		void Txt_cantidadKeyDown(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Enter )
			{
	            if (this.txt_nombre.Text.Trim() == "")
	            {
	                MessageBox.Show("Seleccione primero un cliente!", "Atenci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
	                return;
	            }
	
	            this.cmd_agregar_Click(sender, e);				
			}
		}
		
		void Txt_codigoTextChanged(object sender, EventArgs e)
		{
			
		}

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
	}
}