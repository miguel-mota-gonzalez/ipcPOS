/*
 * Creado por SharpDevelop.
 * Usuario: mikem
 * Fecha: 12/11/2008
 * Hora: 08:29 a.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificaci�n | Editar Encabezados Est�ndar
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_sysconf.
	/// </summary>
	public partial class frm_sysconf : Form
	{
		public frm_sysconf()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
