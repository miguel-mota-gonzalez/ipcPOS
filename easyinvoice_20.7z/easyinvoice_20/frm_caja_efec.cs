using System;
using System.Drawing;
using System.Windows.Forms;

namespace EasyInvoice
{
	/// <summary>
	/// Description of frm_caja_efec.
	/// </summary>
	public partial class frm_caja_efec : Form
	{
		private System.Data.Odbc.OdbcConnection m_conn;
        private bool mustSave = false;
		
		public frm_caja_efec()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
            this.m_conn = new System.Data.Odbc.OdbcConnection();
            this.m_conn.ConnectionString = frm_Main.mps_strconnection;

            this.getDepositos();
		}
		
		void Cmd_closeClick(object sender, EventArgs e)
		{
            if (mustSave)
            { 
                if(MessageBox.Show("No ha grabado las entradas capturadas, se perdera TODO lo registrado, a�n desea salir de esta ventana?","",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.No)
                    return;
            }
			this.Close();
		}
		
        private void cmd_save_Click(object sender, EventArgs e)
        {
            try
            {
                Decimal lentrada, limporte;
                if (radioButton1.Checked)
                {
                    lentrada = 1;
                    limporte = System.Math.Round(Convert.ToDecimal(this.txt_importe.Value),2);
                }
                else
                {
                    lentrada = 0;
                    limporte = -1 * System.Math.Round(Convert.ToDecimal(this.txt_importe.Value),2);
                }
                this.m_conn.Open();
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;

                //Almacenar el movimiento de caja
                l_inc.CommandText = "INSERT INTO catCaja (dtfecha,iimporte,clogin,entrada,observaciones) VALUES(?,?,?,?,?);";

                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
                l_inc.Parameters.AddWithValue("@iimporte", limporte );
                l_inc.Parameters.AddWithValue("@clogin", frm_Main.mps_usuario);
                l_inc.Parameters.AddWithValue("@entrada", lentrada );
                l_inc.Parameters.AddWithValue("@observaciones", this.txt_observs.Text);

                l_inc.ExecuteNonQuery();
                
                this.txt_importe.Value =1;
                this.txt_observs.Text = "";
                this.radioButton1.Focus();
                mustSave = false;
                this.m_conn.Close();
                this.getDepositos();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
			finally
            {
                if(this.m_conn.State== System.Data.ConnectionState.Open)
                    this.m_conn.Close();  				
            }

        }

        private void txt_observs_TextChanged(object sender, EventArgs e)
        {
            mustSave = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            mustSave = true;
        }

        private void txt_importe_ValueChanged(object sender, EventArgs e)
        {
            mustSave = true;
        }

        private void getDepositos()
        {
            string mess;
            try
            {
                object res;
                Decimal dDepositos=0, dEfectivo=0,dVentas=0,dRetiros=0;
 
                this.m_conn.Open();
                System.Data.Odbc.OdbcCommand l_inc = new System.Data.Odbc.OdbcCommand();
                l_inc.Connection = this.m_conn;

                //Depositos
                l_inc.CommandText = "SELECT SUM(iimporte) FROM catCaja WHERE dtfecha=? AND entrada=1;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
                res = l_inc.ExecuteScalar();
                if(res!=null && res!= System.DBNull.Value)
                    dDepositos = Convert.ToDecimal(res);

                //Efectivo=ventas mas depositos menos retiros (checar pagos proveedores)
                l_inc.CommandText = "SELECT SUM(Total) FROM catFacturas WHERE fecha=? AND cancelada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dVentas = Convert.ToDecimal(res);
                
                l_inc.CommandText = "SELECT SUM(Total) FROM catNotas WHERE fecha=? AND cancelada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dVentas += Convert.ToDecimal(res);

                l_inc.CommandText = "SELECT SUM(iimporte) FROM catCaja WHERE dtfecha=? AND entrada=0;";
                l_inc.Parameters.Clear();
                l_inc.Parameters.AddWithValue("@dtfecha", this.dateTimePicker1.Value);
                res = l_inc.ExecuteScalar();
                if (res != null && res != System.DBNull.Value)
                    dRetiros = Convert.ToDecimal(res);

                dEfectivo = dVentas + dDepositos + dRetiros;
                mess = "Total de depositos del d�a: " + dDepositos.ToString("####,##0.00") + Convert.ToChar(13) + Convert.ToChar(10) + "Total de efectivo del d�a: " + dEfectivo.ToString("####,##0.00");

            }
            catch (Exception ee)
            {
                mess = "";
                MessageBox.Show(ee.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (this.m_conn.State == System.Data.ConnectionState.Open)
                    this.m_conn.Close();
            }

            this.lbl_Depositos.Text = mess;
        }

        private void frm_caja_efec_Load(object sender, EventArgs e)
        {

        }

	}
}
